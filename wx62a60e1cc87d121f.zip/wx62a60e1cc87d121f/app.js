var n = require("./config.js"), e = require("./utils/common.js"), t = require("./utils/api.js").api;

App({
    api: t,
    config: n,
    js: e,
    audioPlay: wx.getBackgroundAudioManager(),
    pageThis: !1,
    onLaunch: function() {
        this.setAudioEvent();
    },
    onShow: function(n) {
        var e = n.query;
        if (console.log(n), e.share_id && !this.share_id && (this.share_id = e.share_id), 
        e.scene) {
            var t = decodeURIComponent(e.scene), i = this.getObj(t);
            i.share_id && (this.share_id = i.share_id);
        }
        this.upData();
    },
    getOpenId: function(n) {
        var e = this.config, t = e.domain, i = e.version;
        wx.login({
            success: function(e) {
                var a = {
                    code: e.code
                };
                wx.request({
                    url: t + i + "/user.openpid",
                    data: a,
                    success: function(e) {
                        var t = e.data.data;
                        wx.setStorageSync("openid", t.openid), n && n(t.openid);
                    }
                });
            }
        });
    },
    onHide: function() {},
    toPrevious: function() {
        getCurrentPages().length >= 2 ? wx.navigateBack({
            delta: 1
        }) : this.js.reLaunch("/pages/site/home");
    },
    upData: function() {
        var n = this, e = wx.getUpdateManager();
        e.onCheckForUpdate(function(t) {
            t.hasUpdate && (e.onUpdateReady(function() {
                n.js.showModal("新版本已经准备好，是否重启小程序？", "更新提示", !1).then(function(n) {
                    e.applyUpdate();
                });
            }), e.onUpdateFailed(function() {
                n.js.showModal("更新失败，请稍后再试", "更新失败", !1).then(function(n) {});
            }));
        });
    },
    setAudioClear: function() {
        this.pageThis = !1;
    },
    setAudioStyle: function(n, e, t) {
        var i = this.audioPlay;
        i.src = n, i.title = e, i.epname = "FLOW冥想", i.coverImgUrl = t;
    },
    setAudioEvent: function() {
        var n = this;
        this.audioPlay.onEnded(function() {
            var e = n.pageThis;
            if (!e) return null;
            e.onEnded && e.onEnded();
        }), this.audioPlay.onPause(function() {
            var e = n.pageThis;
            if (!e) return null;
            e.onPause && e.onPause();
        }), this.audioPlay.onStop(function() {
            var e = n.pageThis;
            if (!e) return null;
            e.onStop && e.onStop();
        }), this.audioPlay.onPlay(function() {
            var e = n.pageThis;
            if (!e) return null;
            e.onPlay && e.onPlay();
        }), this.audioPlay.onCanplay(function() {
            var e = n.pageThis;
            if (!e) return null;
            e.onCanplay && e.onCanplay();
        }), this.audioPlay.onTimeUpdate(function() {
            var e = n.pageThis;
            if (!e) return null;
            e.onTimeUpdate && e.onTimeUpdate();
        }), this.audioPlay.onWaiting(function() {
            var e = n.pageThis;
            if (!e) return null;
            e.onWaiting && e.onWaiting();
        }), this.audioPlay.onSeeked(function() {
            if (!pageThis) return null;
            pageThis.onSeeked && pageThis.onSeeked();
        });
    },
    onPageNotFound: function() {
        var n = this;
        this.js.showModal("该页面不存在", "温馨提示", !1).then(function(e) {
            n.js.switchTab("/pages/site/home");
        });
    },
    downloadApp: function() {
        var n = wx.getSystemInfoSync().platform, e = "FLOW冥想";
        "ios" == n || "mac" == n || (e = this.config.webUrl), this.js.setClone(e);
    },
    getWxCode: function() {
        var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = arguments.length > 1 ? arguments[1] : void 0, t = "https://api-v2-mini.flownow.cn/v2.0.0/index.wxacode";
        n.width = 200, wx.request({
            url: t,
            data: n,
            method: "GET",
            success: function(n) {
                e && e(n);
            }
        });
    },
    onShare: function() {
        var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "/pagse/site/home", e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "跟随FLOW，开始冥想练习吧！", t = arguments.length > 2 ? arguments[2] : void 0, i = {
            title: e,
            path: n,
            imageUrl: t = t || this.config.shartImg
        };
        return i;
    },
    getPostMeditation: function(n, e) {
        if (!n.duration && n.duration < 10) return e && e();
        this.api.getPostMeditation(n).then(function(n) {
            e && e(n);
        });
    },
    getPhone: function(n, e) {
        var t = n.detail;
        if (console.log(t), t.encryptedData && t.iv) {
            var i = {
                encryptedData: t.encryptedData,
                iv: t.iv
            };
            return t.code && (i.code = t.code), this.share_id && (i.share_uid = this.share_id), 
            console.log(i), this.api.getLogin(i).then(function(n) {
                e && e(n), wx.setStorageSync("userInfo", n);
            }), null;
        }
    },
    getObj: function(n) {
        for (var e = {}, t = n.split(","), i = 0; i < t.length; i++) {
            var a = t[i].split("=");
            e[a[0]] = a[1];
        }
        return e;
    },
    getObj2: function(n) {
        for (var e = {}, t = n.split("&"), i = 0; i < t.length; i++) {
            var a = t[i].split("=");
            e[a[0]] = a[1];
        }
        return e;
    },
    uploadImage: function(n, e) {
        var t = wx.getSystemInfoSync(), i = wx.getStorageSync("userInfo"), a = __wxConfig, o = {
            "DEVICE-ID": wx.getStorageSync("openid") || !1,
            "APP-VERSION": a.envVersion,
            "DEVICE-OS": t.platform,
            "DEVICE-BRAND": t.brand,
            "APP-CHANNEL": "wechatMiniapp",
            "DEVICE-NETTYPE": "wifi",
            TOKEN: i.access_token || ""
        };
        wx.uploadFile({
            url: this.config.domain + "/" + this.config.version + "/user.upload",
            filePath: n,
            name: "file",
            header: {
                "content-type": "multipart/form-data"
            },
            formData: o,
            complete: function(n) {
                n.data = JSON.parse(n.data), 0 === n.data.errorcode ? e && e(n.data.data) : n.data.errorcode && (wx.hideLoading(), 
                wx.showModal({
                    title: "温馨提示",
                    content: "图片违规，请重新上传",
                    showCancel: !1
                }));
            }
        });
    }
});