var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.api = void 0;

var r = require("./request.js"), n = e(require("../config.js")), t = "/user.login", i = "/user.openpid", o = "/index.index", u = "/lesson.storey", v = "/user.info", s = "/lesson.category", a = "/lesson.detail", g = "/lesson.courseware", d = "/user.play", l = "/lesson.idchange", c = "/lesson.catidchange", f = "/user.redeemvip", h = "/user.vipbuy", p = "/user.payment", T = "/user.buyrecord", y = "/user.upload", P = n.default.version, E = {
    setImg: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + y, e, "POST");
    },
    setVip: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + f, e, "POST");
    },
    getAudioCidChange: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + c, e);
    },
    getAudioIdChange: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + l, e);
    },
    getPostMeditation: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + d, e, "POST");
    },
    getRecord: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + T, e);
    },
    setPayment: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + p, e, "POST");
    },
    getVip: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + h, e);
    },
    getLogin: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + t, e, "POST");
    },
    getOpenid: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + i, e, "GET");
    },
    getIndex: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + o, e, "GET");
    },
    putInfo: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + v, e, "PUT");
    },
    getInfo: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + v, e, "GET");
    },
    getCourseware: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + g, e, "GET");
    },
    getStoreyList: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + u, e, "GET");
    },
    getCategory: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + s, e, "GET");
    },
    getAudioDetail: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, r.serve)(P + a, e, "GET");
    }
};

exports.api = E;