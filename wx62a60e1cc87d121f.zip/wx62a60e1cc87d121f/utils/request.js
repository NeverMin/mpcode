var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.serve = function(e, o) {
    var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "GET", n = getApp();
    return r = r.toUpperCase(), new Promise(function(a, i) {
        var s = wx.getStorageSync("userInfo") || {}, u = wx.getSystemInfoSync(), c = __wxConfig, d = {
            "DEVICE-ID": wx.getStorageSync("openid") || !1,
            "APP-VERSION": c.envVersion,
            "DEVICE-OS": u.platform,
            "DEVICE-BRAND": u.brand,
            "APP-CHANNEL": "wechatMiniapp",
            "DEVICE-NETTYPE": "wifi",
            TOKEN: s.access_token || "",
            "IS-START-PAGE": 0,
            "content-type": "POST" === r ? "application/x-www-form-urlencoded" : "application/json"
        }, l = getCurrentPages(), f = l[l.length - 1];
        f && f.route && (d["APP-PAGE"] = f.route), 1 == getCurrentPages().length && "pages/my/home" != f.route && "pages/course/home" != f.route && (d["IS-START-PAGE"] = 1);
        var p = new Promise(function(e, t) {
            e();
        });
        Promise.all([ p ]).then(function() {
            d["DEVICE-ID"] ? wx.request({
                url: t + e,
                data: o,
                method: r,
                header: d,
                success: function(e) {
                    0 == e.data.errorcode ? a(e.data.data) : (i(e), wx.showToast({
                        title: e.data.errormsg,
                        icon: "none"
                    }));
                },
                fail: function(e) {
                    i();
                },
                complete: function(e) {}
            }) : n.getOpenId(function(n) {
                d["DEVICE-ID"] = n, wx.request({
                    url: t + e,
                    data: o,
                    method: r,
                    header: d,
                    success: function(e) {
                        console.log(d), 0 == e.data.errorcode ? a(e.data.data) : (i(e), wx.showToast({
                            title: e.data.errormsg,
                            icon: "none"
                        }));
                    },
                    fail: function(e) {
                        i();
                    },
                    complete: function(e) {}
                });
            });
        });
    });
};

require("request");

var t = e(require("../config.js")).default.domain;