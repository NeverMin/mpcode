function n(n) {
    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], e = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 2e3, o = arguments.length > 3 ? arguments[3] : void 0;
    wx.showToast({
        title: n,
        icon: t ? "success" : "none",
        mask: !0,
        duration: e,
        success: function() {
            o && o();
        }
    });
}

function t(n) {
    return n > 0 ? n > 9 ? n : "0" + n : "00";
}

var e = {
    setClone: function(n) {
        wx.setClipboardData({
            data: n,
            success: function(n) {}
        });
    },
    showToast: n,
    showModal: function(n) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "提示", e = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2], o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "确认", i = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "取消";
        return new Promise(function(a, r) {
            wx.showModal({
                title: t,
                content: n,
                showCancel: e,
                cancelText: i,
                confirmText: o,
                success: function(n) {
                    n.confirm ? a() : n.cancel && r();
                },
                fail: function(n) {}
            });
        });
    },
    showLoading: function(n) {
        var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        wx.showLoading({
            title: n,
            mask: t
        });
    },
    hideLoading: function() {
        wx.hideLoading();
    },
    setTitle: function(n) {
        wx.setNavigationBarTitle({
            title: n
        });
    },
    navTo: function(n, t) {
        wx.navigateTo({
            url: n,
            success: function(n) {
                t && t();
            }
        });
    },
    reLaunch: function(n) {
        wx.reLaunch({
            url: n
        });
    },
    switchTab: function(n) {
        wx.switchTab({
            url: n
        });
    },
    redTo: function(n) {
        wx.redirectTo({
            url: n
        });
    },
    addZero: function(n) {
        return (n = parseInt(n)) < 10 && (n = "0" + n), n;
    },
    navigateToMiniProgram: function(n, t) {
        wx.navigateToMiniProgram({
            appId: n,
            path: t,
            envVersion: "release"
        });
    },
    getModelIos: function() {
        return new Promise(function(n, t) {
            wx.getSystemInfo({
                success: function(e) {
                    "ios" == e.platform ? t() : n();
                }
            });
        });
    },
    requestPayment: function(t) {
        return new Promise(function(e, o) {
            wx.requestPayment({
                timeStamp: t.timeStamp,
                nonceStr: t.nonceStr,
                package: t.package,
                signType: t.signType,
                paySign: t.paySign,
                success: function(n) {
                    e(n);
                },
                fail: function(t) {
                    n("支付失败");
                }
            });
        });
    },
    formatDateTime: function(n, e) {
        n = parseInt(n + "000");
        var o = new Date(n), i = o.getFullYear(), a = t(o.getMonth() + 1), r = t(o.getDate()), c = t(o.getHours()), s = t(o.getMinutes()), u = t(o.getSeconds());
        return e ? i + "-" + a + "-" + r : i + "-" + a + "-" + r + "  " + c + ":" + s + ":" + u;
    },
    timeFormate: t,
    durationFormate: function(n) {
        var e = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], o = {
            hour: 0,
            minute: 0,
            second: 0
        };
        o.hour = parseInt(n / 60 / 60), o.minute = parseInt(n / 60 % 60), o.second = n % 60, 
        e || 0 !== o.hour || delete o.hour;
        var i = "";
        for (var a in o) i += t(o[a]) + ("second" === a ? "" : ":");
        return i;
    }
};

module.exports = e;