var t = getApp();

Page({
    data: {
        code: t.config.code,
        title: "",
        imgUrl: "",
        userInfo: {},
        logo: "../../images/logo/logoBlack.png",
        timeImg: "../../images/image/time.png"
    },
    setTimeDate: function() {
        var e, o = new Date(), i = t.js.timeFormate(o.getFullYear()) + "", a = t.js.timeFormate(o.getMonth() + 1) + "", n = t.js.timeFormate(o.getDate()) + "", s = o.getDay();
        t.config.monthList.forEach(function(t) {
            t.id == s && (e = t.text2);
        }), this.setData({
            year: i,
            month: a,
            date: n,
            dayText: e
        });
    },
    canvasSuc: function(e) {
        console.log(e), wx.hideLoading(), wx.saveImageToPhotosAlbum({
            filePath: e.detail.path,
            success: function(e) {
                t.js.showToast("保存成功", "success");
            },
            fail: function(o) {
                t.js.showToast("图片保存失败，请长按保存图片", "none", 1500, function() {
                    wx.previewImage({
                        current: e.detail.path,
                        urls: [ e.detail.path ]
                    });
                });
            }
        });
    },
    setCanvas: function() {
        t.js.showLoading("图片生成中");
        var e = this.data, o = e.logo, i = e.imgUrl, a = e.title, n = ("".concat(this.data.year, "—").concat(this.data.month), 
        this.data.date, this.data.dayText, {
            background: "#FFFFFF",
            width: "335px",
            height: "585px",
            views: [ {
                type: "image",
                url: i,
                css: {
                    top: "0px",
                    left: "0px",
                    width: "335px",
                    height: "335px"
                }
            }, {
                type: "image",
                url: e.timeImg,
                css: {
                    top: "355px",
                    right: "22px",
                    width: "74px",
                    height: "39px"
                }
            }, {
                type: "image",
                url: o,
                css: {
                    bottom: "23px",
                    left: "29px",
                    width: "93px",
                    height: "35px"
                }
            }, {
                type: "text",
                text: e.dayText + ".",
                css: {
                    top: "370px",
                    left: "249px",
                    fontSize: "10px",
                    color: "#1B1B1B",
                    fontFamily: "PingFang SC",
                    textDecoration: "oblique",
                    textAlign: "left",
                    maxLines: 1
                }
            }, {
                type: "text",
                text: e.date,
                css: {
                    top: "358px",
                    left: "276px",
                    fontSize: "25px",
                    color: "#1B1B1B",
                    fontFamily: "PingFang SC",
                    textDecoration: "oblique",
                    textAlign: "left",
                    maxLines: 1
                }
            }, {
                type: "image",
                url: e.code,
                css: {
                    bottom: "17px",
                    right: "40px",
                    width: "67px",
                    height: "67px"
                }
            }, {
                type: "text",
                text: a,
                css: {
                    top: "362px",
                    left: "22px",
                    fontSize: "20px",
                    color: "#2B2B2B",
                    fontFamily: "PingFang SC",
                    textDecoration: "oblique",
                    width: "230px",
                    textAlign: "left",
                    maxLines: 1
                }
            }, {
                type: "rect",
                css: {
                    top: "414px",
                    left: "23px",
                    width: "290px",
                    height: "65px",
                    color: "#F4F4F4",
                    borderRadius: "8px"
                }
            }, {
                type: "rect",
                css: {
                    top: "427px",
                    left: "167px",
                    width: "1px",
                    height: "40px",
                    color: "#5E5E5E"
                }
            }, {
                type: "text",
                text: "累计时长",
                css: {
                    top: "450px",
                    left: "78px",
                    fontSize: "10px",
                    color: "#5E5E5E",
                    fontFamily: "PingFang SC"
                }
            }, {
                type: "text",
                text: "坚持练习",
                css: {
                    top: "450px",
                    right: "77px",
                    fontSize: "10px",
                    color: "#5E5E5E",
                    fontFamily: "PingFang SC"
                }
            }, {
                type: "text",
                text: e.userInfo.time + "分钟",
                css: {
                    bottom: "137px",
                    left: "26px",
                    fontSize: "10px",
                    color: "#5E5E5E",
                    fontFamily: "PingFang SC",
                    width: "145px",
                    textAlign: "center"
                }
            }, {
                type: "text",
                text: e.userInfo.total_day + "天",
                css: {
                    bottom: "137px",
                    right: "22px",
                    fontSize: "10px",
                    color: "#5E5E5E",
                    fontFamily: "PingFang SC",
                    width: "145px",
                    textAlign: "center"
                }
            } ]
        });
        this.setData({
            template: n
        });
    },
    getCode: function() {
        var e = this, o = {
            path: "pages/detailsPlay/detailsPlay"
        };
        wx.getStorageSync("userInfo").user_id, this.options;
        o.path = o.path + "?id=10", t.getWxCode(o, function(t) {
            e.setData({
                code: t.data.data.path
            });
        });
    },
    onLoad: function(t) {
        var e = wx.getStorageSync("userInfo") || {};
        console.log(e), e.time = Math.floor(e.total_duration / 60), this.getCode(), this.setTimeDate(), 
        this.setData({
            title: t.title,
            imgUrl: t.imgUrl,
            userInfo: e
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = this.options, o = "/pages/detailsPlay/transit?id=".concat(e.id, "&detailId=").concat(e.detailId);
        return t.onShare(o, e.title, e.imgUrl);
    }
});