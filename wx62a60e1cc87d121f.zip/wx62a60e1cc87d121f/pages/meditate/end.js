var t = require("../../@babel/runtime/helpers/objectSpread2"), e = getApp();

Page({
    data: {
        downloadAppText: e.config.downloadAppText,
        title: "",
        imgUrl: ""
    },
    downloadApp: function() {
        e.downloadApp();
    },
    onLoad: function(a) {
        var o = this;
        this.getHeight();
        wx.getStorageSync("userInfo");
        e.api.getInfo().then(function(e) {
            var i = wx.getStorageSync("userInfo");
            (i = t(t({}, i), e)).time = Math.floor(i.total_duration / 60), o.setData({
                title: a.title,
                imgUrl: a.imgUrl,
                userInfo: i
            }), wx.setStorageSync("userInfo", i);
        });
    },
    setShare: function() {
        var t = this.options, a = "/pages/meditate/share?title=".concat(t.title, "&imgUrl=").concat(t.imgUrl);
        a += "&id=".concat(t.id, "&detailId=").concat(t.detailId), e.js.navTo(a);
    },
    toPrevious: function() {
        e.toPrevious();
    },
    getHeight: function() {
        var t = wx.getSystemInfoSync(), e = t.statusBarHeight;
        if (t && t.system) {
            var a = (t.system.indexOf("Android") > 0 ? 48 : 44) + e;
            this.setData({
                height: a,
                statusBarHeight: e
            });
        }
    },
    onShareAppMessage: function() {
        var t = "/pages/site/home", a = wx.getStorageSync("userInfo") || {};
        return a.user_id && (t = t + "?share_id=" + a.user_id), e.onShare(t, "跟随FLOW，开始冥想练习吧！");
    }
});