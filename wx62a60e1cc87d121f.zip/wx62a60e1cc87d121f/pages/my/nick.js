var t = getApp();

Page({
    data: {
        value: ""
    },
    onLoad: function(t) {
        this.setData({
            value: t.title
        });
    },
    bindinput: function(t) {
        this.setData({
            value: t.detail.value
        });
    },
    setBtn: function() {
        var e = this;
        if (this.data.value) {
            var i = {
                nick: this.text
            };
            t.api.putInfo(i).then(function(i) {
                t.nick = e.text, wx.showToast({
                    title: "保存成功"
                }), setTimeout(function() {
                    t.toPrevious();
                }, 1500);
            });
        } else wx.showToast({
            title: "请输入昵称",
            icon: "none"
        });
    },
    onShareAppMessage: function() {}
});