Page({
    data: {
        img: "https://img.fulou.life/uploads/image/20220317/97fb1f4da69ae897d619f2ff045f1ae831.png"
    },
    getImg: function() {
        wx.previewImage({
            current: this.data.img,
            urls: [ this.data.img ]
        });
    },
    onLoad: function(n) {
        var t = n.img;
        t && -1 != t.indexOf("http") && this.setData({
            img: n.img
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});