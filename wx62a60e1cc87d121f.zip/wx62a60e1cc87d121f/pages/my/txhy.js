Page({
    data: {
        url: "https://meeting.tencent.com/dm/7PgbrN9qLFZs"
    },
    onLoad: function(n) {},
    toTxhy: function() {
        wx.navigateToMiniProgram({
            appId: "wx33fd6cdc62520063",
            path: "/pages/sub-preMeeting/join-meeting/join-meeting.html?scene=m%3D548690017",
            extraData: {
                foo: "bar"
            },
            envVersion: "release",
            success: function(n) {},
            fail: function(n) {
                console.log(n);
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});