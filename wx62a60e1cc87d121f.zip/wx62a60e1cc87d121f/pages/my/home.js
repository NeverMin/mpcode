var e, n = require("../../@babel/runtime/helpers/defineProperty"), t = require("../../@babel/runtime/helpers/objectSpread2"), o = getApp();

Page((n(e = {
    data: {
        login: !0,
        userImg: "../../images/image/user.png",
        nick: "阿说阿说阿说阿说阿说阿说阿说阿说阿说阿说",
        flowText: "FLOW让冥想融入生活。我们借助互联网和科技的力量，打造一个健康时尚，每人每天都能使用的，身心健康生活方式平台，帮助更多人释放焦虑，改善睡眠，提升能量，探知自我。愿越来越多人从冥想中获益。",
        userInfo: {}
    },
    onLoad: function(e) {},
    onReady: function() {},
    toVip: function() {
        o.js.navTo("/pages/vip/vip");
    },
    setUser: function() {
        if (!this.data.userInfo.access_token) return null;
        o.js.navTo("/pages/my/user");
    },
    getPhone: function(e) {
        var n = this;
        o.getPhone(e, function(e) {
            wx.setStorageSync("userInfo", e), n.getInfo();
        });
    },
    onShow: function() {
        this.getTabBar().setData({
            selected: 2
        });
        var e = wx.getStorageSync("userInfo") || {};
        if (!e.access_token) return null;
        this.setData({
            userInfo: e
        }), this.getInfo();
    },
    getInfo: function() {
        var e = this;
        o.api.getInfo().then(function(n) {
            var o = wx.getStorageSync("userInfo");
            o = t(t({}, o), n), e.setData({
                userInfo: o
            }), wx.setStorageSync("userInfo", o);
        });
    },
    onHide: function() {}
}, "toVip", function() {
    if (!this.data.userInfo.access_token) return null;
    o.js.navTo("/pages/vip/vip");
}), n(e, "onUnload", function() {}), n(e, "downloadApp", function() {
    o.downloadApp();
}), n(e, "onPullDownRefresh", function() {}), n(e, "onReachBottom", function() {}), 
n(e, "onShareAppMessage", function() {
    var e = "/pages/site/home", n = wx.getStorageSync("userInfo") || {};
    return n.user_id && (e = e + "?share_id=" + n.user_id), o.onShare(e, "跟随FLOW，开始冥想练习吧！");
}), e));