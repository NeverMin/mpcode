var t = getApp();

Page({
    data: {
        userInfo: wx.getStorageSync("userInfo") || {},
        sexText: "",
        dateText: "",
        date: "",
        title: "编辑头像",
        sex: [ {
            id: 0,
            text: "保密"
        }, {
            id: 1,
            text: "男"
        }, {
            id: 2,
            text: "女"
        } ]
    },
    onLoad: function(e) {
        this.setDay();
        var a = wx.getStorageSync("userInfo") || {};
        a.sexText = this.data.sex[a.sex].text, a.create_time = t.js.formatDateTime(a.create_time), 
        this.setData({
            userInfo: a
        });
    },
    sexChange: function(e) {
        var a = e.detail.value, n = this.data.sex[a];
        this.setData({
            sexText: n.text
        });
        var i = {
            sex: a
        };
        t.api.putInfo(i);
    },
    setImg: function() {
        var e = this;
        wx.chooseMedia({
            count: 1,
            mediaType: [ "image" ],
            sourceType: [ "album", "camera" ],
            maxDuration: 30,
            camera: "back",
            sizeType: [ "compressed" ],
            success: function(a) {
                var n = a.tempFiles[0].tempFilePath;
                t.uploadImage(n, function(a) {
                    var n = {
                        avatar: a.path
                    };
                    t.api.putInfo(n).then(function(t) {
                        var a = e.data.userInfo;
                        a.avatar = n.avatar, e.setData({
                            userInfo: a
                        });
                    });
                });
            }
        });
    },
    getNick: function() {
        var e = this.data.userInfo;
        t.js.navTo("/pages/my/nick?title=" + e.nick);
    },
    onReady: function() {},
    birthdayChange: function(e) {
        var a = e.detail.value, n = {
            birthday: a
        };
        this.setData({
            dateText: a
        }), t.api.putInfo(n);
    },
    setDay: function() {
        var t = new Date(), e = t.getFullYear() + "-" + (t.getMonth() + 1) + "-" + t.getDate();
        this.setData({
            date: e
        });
    },
    onShow: function() {
        if (t.nick) {
            var e = wx.getStorageSync("userInfo") || {};
            e.nick = t.nick, this.setData({
                userInfo: e
            }, function() {
                t.nick = !1;
            });
        }
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});