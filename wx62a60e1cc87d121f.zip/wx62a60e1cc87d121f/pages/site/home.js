var e = require("../../@babel/runtime/helpers/objectSpread2"), t = getApp();

Page({
    data: {
        userInfo: wx.getStorageSync("userInfo") || {},
        greetText: "早上好",
        nick: "未登录",
        rouletteIndex: 0,
        sceneObj: {
            courseware_id: "8bb9541f31699fa94cc71e47599cba91",
            lesson_id: "8bb9541f31699fa94cc71e47599cba91",
            title: "专注",
            type: "audio",
            click_ico: "../../images/roulette/6d.png",
            ico: "../../images/roulette/6.png"
        }
    },
    getLabelDay: function() {
        var e = this.data.everyday, a = "/pages/detailsPlay/transit?id=" + e.lesson_id + "&detailId=" + e.courseware_id + "&day=true";
        t.js.navTo(a);
    },
    getPhoneTwo: function(e) {
        var a = this;
        t.getPhone(e, function(e) {
            a.setData({
                userInfo: e
            }, a.getVip);
        });
    },
    getPhone: function(e) {
        var a = this;
        t.getPhone(e, function(e) {
            a.setData({
                userInfo: e
            });
        });
    },
    toAudio: function(e) {
        var a = e.currentTarget.dataset;
        this.setData({
            rouletteIndex: Number(a.idx + 1)
        }, function() {
            if (console.log(a), "audio" == a.item.type) {
                var e = "/pages/detailsPlay/transit?id=" + a.item.lesson_id + "&detailId=" + a.item.courseware_id;
                t.js.navTo(e);
            }
        });
    },
    onLoad: function(e) {},
    init: function() {
        var a = this, n = {};
        this.options.giveVip && (n.givevip = this.options.giveVip), t.api.getIndex(n).then(function(n) {
            var i = new Date(Date.now()), o = i.getMonth() + 1, s = t.config.monthList.find(function(e) {
                if (e.id == o) return e;
            }), r = a.data.sceneObj;
            n.scene.splice(n.scene.length - 1, 1, r), n.everyday.dayText = s.text2, n.everyday.year = i.getFullYear(), 
            n.everyday.date = i.getDate();
            var c = a.data;
            console.log(n), c = e(e({}, c), n), a.setData(c);
        });
    },
    onReady: function() {},
    getGreetText: function() {
        var e, t = new Date().getHours();
        e = t < 6 || 24 == t ? "夜深了" : t >= 6 && t < 11 ? "早上好" : t >= 11 && t < 13 ? "中午好" : t >= 13 && t < 17 ? "下午好" : t >= 17 && t < 19 ? "傍晚好" : t >= 19 && t < 22 ? "晚上好" : "该入梦了，晚安", 
        this.setData({
            greetText: e
        });
    },
    onShow: function() {
        var e = this;
        this.getTabBar().setData({
            selected: 0
        }), this.setData({
            userInfo: wx.getStorageSync("userInfo") || {}
        }, function() {
            e.data.everyday || (e.getGreetText(), e.init());
        });
    },
    onHide: function() {},
    onUnload: function() {},
    getVip: function() {
        var e = this;
        if (console.log("领取"), this.data.userInfo.access_token) {
            var a = {
                id: this.data.givevip.id
            };
            t.api.setVip(a).then(function(a) {
                t.js.showToast("领取成功"), e.setData({
                    givevip: null
                });
            }).catch(function(t) {
                console.log("f"), e.setData({
                    givevip: null
                });
            });
        }
    },
    onShareAppMessage: function() {
        var e = "/pages/site/home", a = wx.getStorageSync("userInfo") || {};
        return a.user_id && (e = e + "?share_id=" + a.user_id), t.onShare(e, "跟随FLOW，开始冥想练习吧！");
    }
});