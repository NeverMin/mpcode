var t = require("../../@babel/runtime/helpers/toConsumableArray"), a = getApp();

Page({
    data: {
        list: [],
        id: 0,
        page: 1,
        limit: 20,
        total: 0
    },
    onLoad: function(t) {
        this.setData({
            id: t.id
        }, this.getList), a.js.setTitle(t.title);
    },
    getList: function() {
        var i = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, n = {
            parent_id: this.data.id,
            page: e,
            limit: this.data.limit
        }, o = this.data.list || [];
        1 == e && (o = []), a.api.getCategory(n).then(function(e) {
            e.data.data.forEach(function(t) {
                t.duration && (t.duration = a.js.durationFormate(t.duration, !1));
            }), o = [].concat(t(o), t(e.data.data)), i.setData({
                page: e.data.current_page,
                list: o,
                total: e.data.total
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    getDetails: function(t) {
        var i = t.currentTarget.dataset.item;
        if (i.is_single) {
            var e = "/pages/detailsPlay/transit?id=" + i.lesson_id + "&detailId=" + i.courseware_id;
            a.js.navTo(e);
        } else {
            var n = "/pages/detailsPlay/audioList?id=" + i.courseware_id;
            a.js.navTo(n);
        }
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        var t = this.data, a = t.list.length, i = t.total, e = Number(t.page);
        a < i && (e += 1, this.getList(e));
    },
    onShareAppMessage: function() {}
});