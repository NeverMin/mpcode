var t = getApp();

Page({
    data: {
        list: []
    },
    onLoad: function(t) {},
    onReady: function() {
        this.getList();
    },
    getListDetails: function(e) {
        var a = e.currentTarget.dataset.item, i = "/pages/course/details?id=" + a.id + "&title=" + a.title;
        t.js.navTo(i);
    },
    getDetails: function(e) {
        var a = e.currentTarget.dataset.item;
        if (a.is_single) {
            var i = "/pages/detailsPlay/transit?id=" + a.lesson_id + "&detailId=" + a.courseware_id;
            t.js.navTo(i);
        } else {
            var n = "/pages/detailsPlay/audioList?id=" + a.courseware_id;
            t.js.navTo(n);
        }
    },
    getList: function() {
        var e = this;
        t.api.getStoreyList().then(function(a) {
            a.forEach(function(e, a) {
                e.children && e.children.forEach(function(e, a) {
                    e.duration && (e.duration = t.js.durationFormate(e.duration, !1));
                });
            }), e.setData({
                list: a
            });
        });
    },
    onShow: function() {
        this.getTabBar().setData({
            selected: 1
        });
    },
    onHide: function() {},
    onShareAppMessage: function() {
        var e = "/pages/site/home", a = wx.getStorageSync("userInfo") || {};
        return a.user_id && (e = e + "?share_id=" + a.user_id), t.onShare(e, "跟随FLOW，开始冥想练习吧！");
    }
});