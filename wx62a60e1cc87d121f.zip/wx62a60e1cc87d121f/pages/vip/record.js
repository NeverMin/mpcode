var t = require("../../@babel/runtime/helpers/toConsumableArray"), a = getApp();

Page({
    data: {
        page: 1,
        total: 0
    },
    onLoad: function(t) {
        this.getList();
    },
    getList: function() {
        var e = this, i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, n = {
            page: i,
            limit: 5
        }, o = this.data.list || [];
        1 == i && (o = []), a.api.getRecord(n).then(function(i) {
            i.data.forEach(function(t) {
                t.time = a.js.formatDateTime(t.payment_time, !1), t.amount = parseInt(t.amount);
            }), o = [].concat(t(o), t(i.data)), e.setData({
                list: o,
                page: i.current_page,
                total: i.total
            });
        });
    },
    onReachBottom: function() {
        var t = this.data, a = t.list.length, e = Number(t.page);
        a < t.total && (e += 1, this.getList(e));
    },
    onShareAppMessage: function() {}
});