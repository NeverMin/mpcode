var e = require("../../@babel/runtime/helpers/objectSpread2"), t = getApp();

Page({
    data: {
        freeImg: "../../images/image/free.png",
        vipImg: "../../images/image/vip.png",
        tipsTitle: "开通会员",
        list: [],
        idx: 0,
        userInfo: {},
        vipText: !1
    },
    onLoad: function(e) {},
    downloadApp: function() {
        t.downloadApp();
    },
    setIos: function() {
        var e = wx.getSystemInfoSync().platform;
        "ios" != e && "mac" != e || this.setData({
            vipText: !0
        });
    },
    toRecord: function() {
        t.js.navTo("/pages/vip/record");
    },
    onReady: function() {
        wx.getStorageSync("userInfo") ? (this.getInfo(), this.getVip()) : t.toPrevious(), 
        this.setIos();
    },
    setVip: function() {
        var e = this, i = this.data, n = i.idx, o = {
            bid: i.list[n].level_id,
            type: "vip"
        };
        if (this.data.vipText) return null;
        t.api.setPayment(o).then(function(t) {
            e.payment(t);
        });
    },
    getInfo: function() {
        var i = this;
        t.api.getInfo().then(function(n) {
            var o = wx.getStorageSync("userInfo");
            n.vip_endtime && (console.log("执行"), n.vipTime = t.js.formatDateTime(n.vip_endtime, !1)), 
            o = e(e({}, o), n), i.setData({
                userInfo: o
            }), wx.setStorageSync("userInfo", o);
        });
    },
    payment: function(e) {
        var i = this;
        wx.requestPayment({
            timeStamp: e.timeStamp,
            nonceStr: e.nonceStr,
            package: e.package,
            signType: e.signType,
            paySign: e.paySign,
            success: function(e) {
                t.js.showToast("支付成功"), i.getInfo();
            },
            fail: function(e) {
                t.js.showToast("支付失败");
            }
        });
    },
    setVipType: function(e) {
        var t = e.currentTarget.dataset.idx;
        this.setData({
            idx: t
        }, this.setVip);
    },
    getVip: function() {
        var e = this;
        t.api.getVip().then(function(t) {
            console.log(t), t.forEach(function(e) {
                e.price = parseInt(e.price), "month" == e.unit && 1 == e.effective ? e.time = Number(e.price / 30).toFixed(2) : "year" == e.unit ? e.time = Number(e.price / 365).toFixed(2) : "month" == e.unit && 3 == e.effective && (e.time = Number(e.price / 90).toFixed(2));
            }), e.setData({
                list: t
            });
        });
    },
    onShow: function() {},
    onShareAppMessage: function() {
        var e = "/pages/site/home", i = wx.getStorageSync("userInfo") || {};
        return i.user_id && (e = e + "?share_id=" + i.user_id), t.onShare(e, "跟随FLOW，开始冥想练习吧！");
    }
});