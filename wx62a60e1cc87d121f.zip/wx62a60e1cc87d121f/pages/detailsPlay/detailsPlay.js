var i = getApp();

Page({
    data: {
        playImg: "../../images/play/play.png",
        pauseImg: "../../images/play/pend.png",
        isPlaying: !1,
        currentTime: "00:00",
        value: 0,
        audioNum: 0
    },
    setClose: function() {
        i.toPrevious();
    },
    setTime: function() {
        this.time = Date.now();
    },
    delTime: function() {
        this.time && (this.count || (this.count = 0), this.count = this.count + Math.floor((Date.now() - this.time) / 1e3), 
        this.time = !1), console.log(this.data.isPlaying, "del");
    },
    setCloseLogin: function() {
        i.toPrevious();
    },
    setPlay: function() {
        var t = i.audioPlay;
        t.paused ? t.play() : t.pause();
    },
    plusSeek: function(t) {
        var e, a = i.audioPlay;
        e = 1 == t.currentTarget.dataset.type ? -15 : 15;
        var s = Math.floor(a.currentTime);
        if (s += e, a.duration - s <= 30) return null;
        i.audioPlay.seek(s);
    },
    getAudioDetail: function() {
        var t = this, e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], a = this.options, s = {
            id: a.id,
            courseware_id: a.detailId
        };
        i.api.getAudioDetail(s).then(function(a) {
            var s = a.lesson_sku[0];
            a.specs && a.specs[0] && (5 != a.specs[0].options[0].id && 5 != a.specs[0].options[1].id || (a.auidoType = a.specs[0], 
            s = a.lesson_sku.find(function(i) {
                if (5 == i.specs) return i;
            }), a.audioNum = s.specs)), a.durations = i.js.durationFormate(s.media.duration, !1), 
            t.setData(a, function() {
                return wx.getStorageSync("userInfo").access_token ? a.is_vip_lesson && !a.user_status.is_vip ? i.js.showModal("会员专享，开通会员后即可开始练习", "提示", !0, "开通VIP", "取消").then(function(t) {
                    i.js.navTo("/pages/vip/vip");
                }).catch(function(t) {
                    i.toPrevious();
                }) : void (i.pageThis && i.pageThis.data.lesson_id == a.lesson_id ? (i.pageThis = t, 
                e && i.setAudioStyle(s.media.url, a.title, a.thumbnail)) : (i.pageThis = t, i.setAudioStyle(s.media.url, a.title, a.thumbnail))) : t.selectComponent("#login").checkIsLogin();
            });
        });
    },
    onLoad: function(t) {
        if (t.scene) {
            var e = decodeURIComponent(t.scene), a = i.getObj(e), s = Number(a.id);
            if (s) this.options.id = s; else {
                var n = i.getObj2(e);
                this.options.id = n.id;
            }
        }
        this.reLaunch = !0, t.id && t.detailId ? this.getAudioDetail() : this.getAudioIdChange();
    },
    getAudioIdChange: function() {
        var t = this, e = {
            id: this.options.id,
            type: "audio"
        };
        i.api.getAudioIdChange(e).then(function(i) {
            t.options = {
                id: i.id,
                detailId: i.courseware_id
            }, t.getAudioDetail();
        });
    },
    postEnd: function(t) {
        var e = this.options, a = this.data;
        this.delTime();
        var s = {
            lesson_id: e.id,
            courseware_id: e.detailId,
            duration: this.count,
            is_finish: 0
        };
        a.duration - 30 <= s.duration && (s.is_finish = 1), i.getPostMeditation(s, function(i) {
            t && t(i);
        });
    },
    onReady: function() {},
    onShow: function() {
        var t = wx.getStorageSync("userInfo") || {}, e = this.data;
        if (e.title) {
            var a = e.user_status;
            console.log(e), e.is_vip_lesson && (t.vip_endtime && !a.is_vip ? (a.is_vip = 1, 
            this.getAudioDetail(!0), this.setData({
                user_status: a
            })) : t.vip_endtime || i.toPrevious());
        }
    },
    onUnload: function() {
        this.reLaunch = !1;
    },
    onShareAppMessage: function() {
        var t = this.data, e = this.options, a = "/pages/detailsPlay/detailsPlay?id=" + e.id + "&detailId=" + e.detailId, s = wx.getStorageSync("userInfo") || {};
        return s.user_id && (a = a + "&share_id=" + s.user_id), i.onShare(a, t.title, t.thumbnail);
    },
    changeProcess: function(t) {
        var e = parseInt(i.audioPlay.duration), a = t.detail.value, s = parseInt(a * (e / 100));
        this.setData({
            currentTime: i.js.durationFormate(s, !1)
        }), i.audioPlay.seek(s);
    },
    onPlay: function() {
        console.log(this.data.isPlaying, "play"), this.setData({
            isPlaying: !0
        }, this.setTime);
    },
    onPause: function() {
        console.log(this.data.isPlaying, "pause"), this.setData({
            isPlaying: !1
        }, this.delTime);
    },
    onStop: function() {
        console.log(this.data.isPlaying, "stop"), this.setData({
            isPlaying: !1
        }, this.delTime), i.setAudioClear();
    },
    onEnded: function() {
        var t = this;
        console.log("结束"), this.setData({
            isPlaying: !1
        });
        var e = this.data, a = e.audioNum;
        if (5 == a) {
            var s = e.lesson_sku.find(function(i) {
                if (6 == i.specs) return i;
            }), n = i.js.durationFormate(s.media.duration, !1);
            return a = s.specs, this.setData({
                durations: n,
                audioNum: a
            }), i.setAudioStyle(s.media.url, e.title, e.thumbnail);
        }
        i.setAudioClear(), this.postEnd(function() {
            var e = t.data, a = t.options, s = "/pages/meditate/end?title=" + e.title + "&imgUrl=" + e.thumbnail;
            s += "&id=".concat(a.id, "&detailId=").concat(a.detailId), t.reLaunch ? i.js.reLaunch(s) : i.js.navTo(s);
        });
    },
    getCallback: function() {
        this.getAudioDetail();
    },
    onWaiting: function() {},
    onTimeUpdate: function() {
        var t = i.audioPlay, e = parseInt(t.currentTime), a = (e / parseInt(t.duration) * 100).toFixed(1);
        e = i.js.durationFormate(e, !1), this.setData({
            currentTime: e,
            value: a
        });
    }
});