var i = getApp();

Page({
    data: {
        day: !1
    },
    onLoad: function(i) {
        i.day && this.setData({
            day: !0
        });
    },
    onReady: function() {},
    setClose: function() {
        i.toPrevious();
    },
    audioPlay: function() {
        var t = this.options.id, e = this.options.detailId, o = wx.getStorageSync("userInfo") || {}, a = this.data;
        if (!o.access_token) return console.log("需要登录"), this.selectComponent("#login").checkIsLogin(), 
        null;
        if (a.is_vip_lesson && !a.user_status.is_vip) return i.js.navTo("/pages/vip/vip");
        var n = "/pages/detailsPlay/detailsPlay?id=" + t + "&detailId=" + e;
        i.js.navTo(n);
    },
    getCallback: function() {
        console.log("执行");
    },
    getAudioDetail: function() {
        var t = this, e = this.options, o = {
            id: e.id,
            courseware_id: e.detailId
        };
        i.api.getAudioDetail(o).then(function(e) {
            e.duration = i.js.durationFormate(e.duration, !1), t.setData(e);
        });
    },
    getAudioIdChange: function() {
        var t = this, e = {
            id: this.options.id,
            type: "audio"
        };
        i.api.getAudioIdChange(e).then(function(i) {
            t.options = {
                id: i.id,
                detailId: i.courseware_id
            }, t.getAudioDetail();
        });
    },
    onShow: function() {
        var i = this.options;
        i.id && i.detailId ? this.getAudioDetail() : this.getAudioIdChange();
    },
    onHide: function() {},
    onUnload: function() {},
    onShareAppMessage: function() {
        var t = this.data, e = this.options, o = "/pages/detailsPlay/transit?id=" + e.id + "&detailId=" + e.detailId, a = wx.getStorageSync("userInfo") || {};
        return a.user_id && (o = o + "&share_id=" + a.user_id), i.onShare(o, t.title, t.thumbnail);
    }
});