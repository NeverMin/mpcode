var t = require("../../@babel/runtime/helpers/objectSpread2"), e = getApp();

Page({
    data: {
        play: "../../images/play/listPlay.png",
        play2: "../../images/play/listPlay2.png",
        lock: "../../images/vip/lock.png",
        type: 0,
        listIdx: 0,
        btnText: "开始练习"
    },
    onLoad: function(t) {
        Number(t.id) ? this.getAudioCidChange(t.id) : this.getCourseware();
    },
    getAudioCidChange: function(t) {
        var i = this, a = {
            cat_id: t,
            type: "audio"
        };
        console.log(a), e.api.getAudioCidChange(a).then(function(t) {
            i.options.id = t.courseware_id, i.getCourseware();
        });
    },
    setIndexAudio: function() {
        var t = this.data.listIdx, e = this.data.list;
        this.getAudioDetails(e[t], !0);
    },
    getAudioDetails: function(t) {
        var i, a = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        i = a ? t : t.currentTarget.dataset.item;
        var n = wx.getStorageSync("userInfo") || {};
        if (!n.access_token) return this.selectComponent("#login").checkIsLogin();
        var o = "/pages/detailsPlay/detailsPlay?id=".concat(i.lesson_id, "&detailId=").concat(i.courseware_id);
        e.js.navTo(o);
    },
    setType: function(t) {
        var e = Number(t.currentTarget.dataset.type);
        if (e == this.data.type) return null;
        this.setData({
            type: e
        });
    },
    getCourseware: function() {
        var i = this, a = {
            courseware_id: this.options.id
        };
        e.api.getCourseware(a).then(function(e) {
            var a;
            console.log(e);
            var n, o = i.btnTrue;
            e.list.forEach(function(t, e) {
                t.is_finish || o || (a = "开始练习第".concat(e + 1, "节"), o = !0, n = e);
            });
            var s = t(t({}, i.data), e);
            s.btnText = a, s.listIdx = n, s.btnTrue = o, i.setData(s);
        });
    },
    onReady: function() {},
    setClose: function() {
        e.toPrevious();
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = "pages/detailsPlay/audioList?id=" + this.options.id, i = this.data.info, a = wx.getStorageSync("userInfo") || {};
        return a.user_id && (t = t + "?share_id=" + a.user_id), e.onShare(t, i.title, i.thumbnail);
    }
});