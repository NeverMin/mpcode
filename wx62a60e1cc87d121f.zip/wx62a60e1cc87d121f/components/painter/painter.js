var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/regenerator")), i = require("../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), n = require("../../@babel/runtime/helpers/toConsumableArray"), r = t(require("./lib/pen")), o = t(require("./lib/downloader")), a = t(require("./lib/wx-canvas")), c = require("./lib/util"), h = new o.default();

function d(t, e) {
    String.prototype.toPx = function(i, s) {
        if ("0" === this) return 0;
        var n = (i ? /^-?[0-9]+([.]{1}[0-9]+){0,1}(rpx|px|%)$/g : /^[0-9]+([.]{1}[0-9]+){0,1}(rpx|px|%)$/g).exec(this);
        if (!this || !n) return console.error("The size: ".concat(this, " is illegal")), 
        0;
        var r = n[2], o = parseFloat(this), a = 0;
        return "rpx" === r ? a = Math.round(o * (t || .5) * (e || 1)) : "px" === r ? a = Math.round(o * (e || 1)) : "%" === r && (a = Math.round(o * s / 100)), 
        a;
    };
}

Component({
    canvasWidthInPx: 0,
    canvasHeightInPx: 0,
    canvasNode: null,
    paintCount: 0,
    currentPalette: {},
    movingCache: {},
    outterDisabled: !1,
    isDisabled: !1,
    needClear: !1,
    properties: {
        use2D: {
            type: Boolean
        },
        customStyle: {
            type: String
        },
        customActionStyle: {
            type: Object
        },
        palette: {
            type: Object,
            observer: function(t, e) {
                this.isNeedRefresh(t, e) && (this.paintCount = 0, this.startPaint());
            }
        },
        dancePalette: {
            type: Object,
            observer: function(t, e) {
                this.isEmpty(t) || this.properties.use2D || this.initDancePalette(t);
            }
        },
        scaleRatio: {
            type: Number,
            value: 1
        },
        widthPixels: {
            type: Number,
            value: 0
        },
        dirty: {
            type: Boolean,
            value: !1
        },
        LRU: {
            type: Boolean,
            value: !0
        },
        action: {
            type: Object,
            observer: function(t, e) {
                var i = this;
                !t || this.isEmpty(t) || this.properties.use2D || this.doAction(t, function(t) {
                    i.movingCache = t;
                }, !1, !0);
            }
        },
        disableAction: {
            type: Boolean,
            observer: function(t) {
                this.outterDisabled = t, this.isDisabled = t;
            }
        },
        clearActionBox: {
            type: Boolean,
            observer: function(t) {
                var e = this;
                t && !this.needClear && this.frontContext && (setTimeout(function() {
                    e.frontContext.draw();
                }, 100), this.touchedView = {}, this.prevFindedIndex = this.findedIndex, this.findedIndex = -1), 
                this.needClear = t;
            }
        }
    },
    data: {
        picURL: "",
        showCanvas: !0,
        painterStyle: ""
    },
    methods: {
        isEmpty: function(t) {
            for (var e in t) return !1;
            return !0;
        },
        isNeedRefresh: function(t, e) {
            return !(!t || this.isEmpty(t) || this.data.dirty && c.equal(t, e));
        },
        getBox: function(t, e) {
            var i = {
                type: "rect",
                css: {
                    height: "".concat(t.bottom - t.top, "px"),
                    width: "".concat(t.right - t.left, "px"),
                    left: "".concat(t.left, "px"),
                    top: "".concat(t.top, "px"),
                    borderWidth: "4rpx",
                    borderColor: "#1A7AF8",
                    color: "transparent"
                }
            };
            return "text" === e && (i.css = Object.assign({}, i.css, {
                borderStyle: "dashed"
            })), this.properties.customActionStyle && this.properties.customActionStyle.border && (i.css = Object.assign({}, i.css, this.properties.customActionStyle.border)), 
            Object.assign(i, {
                id: "box"
            }), i;
        },
        getScaleIcon: function(t, e) {
            var i = {}, s = this.properties.customActionStyle;
            return (i = s && s.scale ? {
                type: "image",
                url: "text" === e ? s.scale.textIcon : s.scale.imageIcon,
                css: {
                    height: "".concat(48, "rpx"),
                    width: "".concat(48, "rpx"),
                    borderRadius: "".concat(24, "rpx")
                }
            } : {
                type: "rect",
                css: {
                    height: "".concat(48, "rpx"),
                    width: "".concat(48, "rpx"),
                    borderRadius: "".concat(24, "rpx"),
                    color: "#0000ff"
                }
            }).css = Object.assign({}, i.css, {
                align: "center",
                left: "".concat(t.right + "2rpx".toPx(), "px"),
                top: "".concat("text" === e ? t.top - "2rpx".toPx() - i.css.height.toPx() / 2 : t.bottom - "2rpx".toPx() - i.css.height.toPx() / 2, "px")
            }), Object.assign(i, {
                id: "scale"
            }), i;
        },
        getDeleteIcon: function(t) {
            var e = {}, i = this.properties.customActionStyle;
            return (e = i && i.scale ? {
                type: "image",
                url: i.delete.icon,
                css: {
                    height: "".concat(48, "rpx"),
                    width: "".concat(48, "rpx"),
                    borderRadius: "".concat(24, "rpx")
                }
            } : {
                type: "rect",
                css: {
                    height: "".concat(48, "rpx"),
                    width: "".concat(48, "rpx"),
                    borderRadius: "".concat(24, "rpx"),
                    color: "#0000ff"
                }
            }).css = Object.assign({}, e.css, {
                align: "center",
                left: "".concat(t.left - "2rpx".toPx(), "px"),
                top: "".concat(t.top - "2rpx".toPx() - e.css.height.toPx() / 2, "px")
            }), Object.assign(e, {
                id: "delete"
            }), e;
        },
        doAction: function(t, e, i, s) {
            var r = this;
            if (!this.properties.use2D) {
                var o = null;
                if (t && (o = t.view), o && o.id && this.touchedView.id !== o.id) for (var a = this.currentPalette.views, c = 0; c < a.length; c++) if (a[c].id === o.id) {
                    this.touchedView = a[c], this.findedIndex = c, this.sliceLayers();
                    break;
                }
                var d = this.touchedView;
                d && !this.isEmpty(d) && (o && o.css && (s ? d.css = o.css : Array.isArray(d.css) && Array.isArray(o.css) ? d.css = Object.assign.apply(Object, [ {} ].concat(n(d.css), n(o.css))) : Array.isArray(d.css) ? d.css = Object.assign.apply(Object, [ {} ].concat(n(d.css), [ o.css ])) : Array.isArray(o.css) ? d.css = Object.assign.apply(Object, [ {}, d.css ].concat(n(o.css))) : d.css = Object.assign({}, d.css, o.css)), 
                o && o.rect && (d.rect = o.rect), o && o.url && d.url && o.url !== d.url ? h.download(o.url, this.properties.LRU).then(function(t) {
                    o.url.startsWith("https") && (d.originUrl = o.url), d.url = t, wx.getImageInfo({
                        src: t,
                        success: function(t) {
                            d.sHeight = t.height, d.sWidth = t.width, r.reDraw(d, e, i);
                        },
                        fail: function() {
                            r.reDraw(d, e, i);
                        }
                    });
                }).catch(function(t) {
                    console.error(t), r.reDraw(d, e, i);
                }) : (o && o.text && d.text && o.text !== d.text && (d.text = o.text), o && o.content && d.content && o.content !== d.content && (d.content = o.content), 
                this.reDraw(d, e, i)));
            }
        },
        reDraw: function(t, e, i) {
            var s = this, n = {
                width: this.currentPalette.width,
                height: this.currentPalette.height,
                views: this.isEmpty(t) ? [] : [ t ]
            }, o = new r.default(this.globalContext, n);
            i && "text" === t.type ? o.paint(function(t) {
                e && e(t), s.triggerEvent("viewUpdate", {
                    view: s.touchedView
                });
            }, !0, this.movingCache) : o.paint(function(t) {
                e && e(t), s.triggerEvent("viewUpdate", {
                    view: s.touchedView
                });
            });
            var a = t.rect, c = t.css, h = t.type;
            this.block = {
                width: this.currentPalette.width,
                height: this.currentPalette.height,
                views: this.isEmpty(t) ? [] : [ this.getBox(a, t.type) ]
            }, c && c.scalable && this.block.views.push(this.getScaleIcon(a, h)), c && c.deletable && this.block.views.push(this.getDeleteIcon(a)), 
            new r.default(this.frontContext, this.block).paint();
        },
        isInView: function(t, e, i) {
            return t > i.left && e > i.top && t < i.right && e < i.bottom;
        },
        isInDelete: function(t, e) {
            var i, n = s(this.block.views);
            try {
                for (n.s(); !(i = n.n()).done; ) {
                    var r = i.value;
                    if ("delete" === r.id) return t > r.rect.left && e > r.rect.top && t < r.rect.right && e < r.rect.bottom;
                }
            } catch (t) {
                n.e(t);
            } finally {
                n.f();
            }
            return !1;
        },
        isInScale: function(t, e) {
            var i, n = s(this.block.views);
            try {
                for (n.s(); !(i = n.n()).done; ) {
                    var r = i.value;
                    if ("scale" === r.id) return t > r.rect.left && e > r.rect.top && t < r.rect.right && e < r.rect.bottom;
                }
            } catch (t) {
                n.e(t);
            } finally {
                n.f();
            }
            return !1;
        },
        touchedView: {},
        findedIndex: -1,
        onClick: function() {
            for (var t = this.startX, e = this.startY, i = [], s = !1, n = -1, r = this.currentPalette.views.length - 1; r >= 0; r--) {
                var o = this.currentPalette.views[r], a = o.rect;
                if (this.touchedView && this.touchedView.id && this.touchedView.id === o.id && this.isInDelete(t, e, a)) {
                    i.length = 0, n = r, s = !0;
                    break;
                }
                this.isInView(t, e, a) && i.push({
                    view: o,
                    index: r
                });
            }
            if (this.touchedView = {}, 0 === i.length) this.findedIndex = -1; else {
                var c = 0, h = i.filter(function(t) {
                    return Boolean(t.view.id);
                });
                if (0 === h.length) this.findedIndex = i[0].index; else {
                    for (c = 0; c < h.length; c++) if (this.findedIndex === h[c].index) {
                        c++;
                        break;
                    }
                    c === h.length && (c = 0), this.touchedView = h[c].view, this.findedIndex = h[c].index, 
                    this.triggerEvent("viewClicked", {
                        view: this.touchedView
                    });
                }
            }
            this.findedIndex < 0 || this.touchedView && !this.touchedView.id ? (this.frontContext.draw(), 
            s ? (this.triggerEvent("touchEnd", {
                view: this.currentPalette.views[n],
                index: n,
                type: "delete"
            }), this.doAction()) : this.findedIndex < 0 && this.triggerEvent("viewClicked", {}), 
            this.findedIndex = -1, this.prevFindedIndex = -1) : this.touchedView && this.touchedView.id && this.sliceLayers();
        },
        sliceLayers: function() {
            var t = this, e = this.currentPalette.views.slice(0, this.findedIndex), i = this.currentPalette.views.slice(this.findedIndex + 1), s = {
                width: this.currentPalette.width,
                height: this.currentPalette.height,
                background: this.currentPalette.background,
                views: e
            }, n = {
                width: this.currentPalette.width,
                height: this.currentPalette.height,
                views: i
            };
            this.prevFindedIndex < this.findedIndex ? (new r.default(this.bottomContext, s).paint(), 
            this.doAction(null, function(e) {
                t.movingCache = e;
            }), new r.default(this.topContext, n).paint()) : (new r.default(this.topContext, n).paint(), 
            this.doAction(null, function(e) {
                t.movingCache = e;
            }), new r.default(this.bottomContext, s).paint()), this.prevFindedIndex = this.findedIndex;
        },
        startX: 0,
        startY: 0,
        startH: 0,
        startW: 0,
        isScale: !1,
        startTimeStamp: 0,
        onTouchStart: function(t) {
            if (!this.isDisabled) {
                var e = t.touches[0], i = e.x, s = e.y;
                if (this.startX = i, this.startY = s, this.startTimeStamp = new Date().getTime(), 
                this.touchedView && !this.isEmpty(this.touchedView)) {
                    var n = this.touchedView.rect;
                    this.isInScale(i, s, n) ? (this.isScale = !0, this.movingCache = {}, this.startH = n.bottom - n.top, 
                    this.startW = n.right - n.left) : this.isScale = !1;
                } else this.isScale = !1;
            }
        },
        onTouchEnd: function(t) {
            this.isDisabled || (new Date().getTime() - this.startTimeStamp <= 500 && !this.hasMove ? !this.isScale && this.onClick(t) : this.touchedView && !this.isEmpty(this.touchedView) && this.triggerEvent("touchEnd", {
                view: this.touchedView
            }), this.hasMove = !1);
        },
        onTouchCancel: function(t) {
            this.isDisabled || this.onTouchEnd(t);
        },
        hasMove: !1,
        onTouchMove: function(t) {
            var e = this;
            if (!this.isDisabled && (this.hasMove = !0, this.touchedView && (!this.touchedView || this.touchedView.id))) {
                var i = t.touches[0], s = i.x, n = i.y, r = s - this.startX, o = n - this.startY, a = this.touchedView, c = a.rect, h = a.type, d = {};
                if (this.isScale) {
                    var u = this.startW + r > 1 ? this.startW + r : 1;
                    if (this.touchedView.css && this.touchedView.css.minWidth && u < this.touchedView.css.minWidth.toPx()) return;
                    if (this.touchedView.rect && this.touchedView.rect.minWidth && u < this.touchedView.rect.minWidth) return;
                    var l = this.startH + o > 1 ? this.startH + o : 1;
                    d = {
                        width: "".concat(u, "px")
                    }, "text" !== h && (d.height = "".concat("image" === h ? u * this.startH / this.startW : l, "px"));
                } else this.startX = s, this.startY = n, d = {
                    left: "".concat(c.x + r, "px"),
                    top: "".concat(c.y + o, "px"),
                    right: void 0,
                    bottom: void 0
                };
                this.doAction({
                    view: {
                        css: d
                    }
                }, function(t) {
                    e.isScale && (e.movingCache = t);
                }, !this.isScale);
            }
        },
        initScreenK: function() {
            if (!(getApp() && getApp().systemInfo && getApp().systemInfo.screenWidth)) try {
                getApp().systemInfo = wx.getSystemInfoSync();
            } catch (t) {
                return void console.error("Painter get system info failed, ".concat(JSON.stringify(t)));
            }
            this.screenK = .5, getApp() && getApp().systemInfo && getApp().systemInfo.screenWidth && (this.screenK = getApp().systemInfo.screenWidth / 750), 
            d(this.screenK, this.properties.scaleRatio);
        },
        initDancePalette: function() {
            var t = this;
            this.properties.use2D || (this.isDisabled = !0, this.initScreenK(), this.downloadImages(this.properties.dancePalette).then(function() {
                var s = i(e.default.mark(function i(s) {
                    var n, o;
                    return e.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (t.currentPalette = s, n = s.width, o = s.height, n && o) {
                                e.next = 5;
                                break;
                            }
                            return console.error("You should set width and height correctly for painter, width: ".concat(n, ", height: ").concat(o)), 
                            e.abrupt("return");

                          case 5:
                            if (t.setData({
                                painterStyle: "width:".concat(n.toPx(), "px;height:").concat(o.toPx(), "px;")
                            }), e.t0 = t.frontContext, e.t0) {
                                e.next = 11;
                                break;
                            }
                            return e.next = 10, t.getCanvasContext(t.properties.use2D, "front");

                          case 10:
                            t.frontContext = e.sent;

                          case 11:
                            if (e.t1 = t.bottomContext, e.t1) {
                                e.next = 16;
                                break;
                            }
                            return e.next = 15, t.getCanvasContext(t.properties.use2D, "bottom");

                          case 15:
                            t.bottomContext = e.sent;

                          case 16:
                            if (e.t2 = t.topContext, e.t2) {
                                e.next = 21;
                                break;
                            }
                            return e.next = 20, t.getCanvasContext(t.properties.use2D, "top");

                          case 20:
                            t.topContext = e.sent;

                          case 21:
                            if (e.t3 = t.globalContext, e.t3) {
                                e.next = 26;
                                break;
                            }
                            return e.next = 25, t.getCanvasContext(t.properties.use2D, "k-canvas");

                          case 25:
                            t.globalContext = e.sent;

                          case 26:
                            new r.default(t.bottomContext, s, t.properties.use2D).paint(function() {
                                t.isDisabled = !1, t.isDisabled = t.outterDisabled, t.triggerEvent("didShow");
                            }), t.globalContext.draw(), t.frontContext.draw(), t.topContext.draw();

                          case 30:
                          case "end":
                            return e.stop();
                        }
                    }, i);
                }));
                return function(t) {
                    return s.apply(this, arguments);
                };
            }()), this.touchedView = {});
        },
        startPaint: function() {
            var t = this;
            this.initScreenK(), this.downloadImages(this.properties.palette).then(function() {
                var s = i(e.default.mark(function i(s) {
                    var n, o, a, c;
                    return e.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (n = s.width, o = s.height, n && o) {
                                e.next = 4;
                                break;
                            }
                            return console.error("You should set width and height correctly for painter, width: ".concat(n, ", height: ").concat(o)), 
                            e.abrupt("return");

                          case 4:
                            if (a = !1, n.toPx() !== t.canvasWidthInPx && (t.canvasWidthInPx = n.toPx(), a = t.properties.use2D), 
                            t.properties.widthPixels && (d(t.screenK, t.properties.widthPixels / t.canvasWidthInPx), 
                            t.canvasWidthInPx = t.properties.widthPixels), t.canvasHeightInPx !== o.toPx() && (t.canvasHeightInPx = o.toPx(), 
                            a = a || t.properties.use2D), t.setData({
                                photoStyle: "width:".concat(t.canvasWidthInPx, "px;height:").concat(t.canvasHeightInPx, "px;")
                            }), t.photoContext) {
                                e.next = 13;
                                break;
                            }
                            return e.next = 12, t.getCanvasContext(t.properties.use2D, "photo");

                          case 12:
                            t.photoContext = e.sent;

                          case 13:
                            a && (c = getApp().systemInfo.pixelRatio, t.photoContext.width = t.canvasWidthInPx * c, 
                            t.photoContext.height = t.canvasHeightInPx * c, t.photoContext.scale(c, c)), new r.default(t.photoContext, s).paint(function() {
                                t.saveImgToLocal();
                            }), d(t.screenK, t.properties.scaleRatio);

                          case 16:
                          case "end":
                            return e.stop();
                        }
                    }, i);
                }));
                return function(t) {
                    return s.apply(this, arguments);
                };
            }());
        },
        downloadImages: function(t) {
            var e = this;
            return new Promise(function(i, n) {
                var r = 0, o = 0, a = JSON.parse(JSON.stringify(t));
                if (a.background && (r++, h.download(a.background, e.properties.LRU).then(function(t) {
                    a.background = t, o++, r === o && i(a);
                }, function() {
                    o++, r === o && i(a);
                })), a.views) {
                    var c, d = s(a.views);
                    try {
                        var u = function() {
                            var t = c.value;
                            t && "image" === t.type && t.url && (r++, h.download(t.url, e.properties.LRU).then(function(e) {
                                t.originUrl = t.url, t.url = e, wx.getImageInfo({
                                    src: e,
                                    success: function(e) {
                                        t.sWidth = e.width, t.sHeight = e.height;
                                    },
                                    fail: function(e) {
                                        t.url = "", console.error("getImageInfo ".concat(t.url, " failed, ").concat(JSON.stringify(e)));
                                    },
                                    complete: function() {
                                        o++, r === o && i(a);
                                    }
                                });
                            }, function() {
                                o++, r === o && i(a);
                            }));
                        };
                        for (d.s(); !(c = d.n()).done; ) u();
                    } catch (t) {
                        d.e(t);
                    } finally {
                        d.f();
                    }
                }
                0 === r && i(a);
            });
        },
        saveImgToLocal: function() {
            var t = this, e = this;
            setTimeout(function() {
                wx.canvasToTempFilePath({
                    canvasId: "photo",
                    canvas: e.properties.use2D ? e.canvasNode : null,
                    destWidth: e.canvasWidthInPx * getApp().systemInfo.pixelRatio,
                    destHeight: e.canvasHeightInPx * getApp().systemInfo.pixelRatio,
                    success: function(t) {
                        e.getImageInfo(t.tempFilePath);
                    },
                    fail: function(t) {
                        console.error("canvasToTempFilePath failed, ".concat(JSON.stringify(t))), e.triggerEvent("imgErr", {
                            error: t
                        });
                    }
                }, t);
            }, 300);
        },
        getCanvasContext: function(t, e) {
            var i = this;
            return new Promise(function(s) {
                if (t) {
                    var n = wx.createSelectorQuery().in(i), r = "#".concat(e);
                    n.select(r).fields({
                        node: !0,
                        size: !0
                    }).exec(function(t) {
                        i.canvasNode = t[0].node;
                        var n = i.canvasNode.getContext("2d"), r = new a.default("2d", n, e, !0, i.canvasNode);
                        s(r);
                    });
                } else {
                    var o = wx.createCanvasContext(e, i);
                    s(new a.default("mina", o, e, !0));
                }
            });
        },
        getImageInfo: function(t) {
            var e = this;
            wx.getImageInfo({
                src: t,
                success: function(i) {
                    if (e.paintCount > 5) {
                        var s = "The result is always fault, even we tried ".concat(5, " times");
                        return console.error(s), void e.triggerEvent("imgErr", {
                            error: s
                        });
                    }
                    Math.abs((i.width * e.canvasHeightInPx - e.canvasWidthInPx * i.height) / (i.height * e.canvasHeightInPx)) < .01 ? e.triggerEvent("imgOK", {
                        path: t
                    }) : e.startPaint(), e.paintCount++;
                },
                fail: function(t) {
                    console.error("getImageInfo failed, ".concat(JSON.stringify(t))), e.triggerEvent("imgErr", {
                        error: t
                    });
                }
            });
        }
    }
});