function t(t, e, r) {
    return e in t ? Object.defineProperty(t, e, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = r, t;
}

var e = require("../libs/config.js").errorImg;

Component({
    data: {
        canIUse: !!wx.chooseMessageFile,
        placeholder: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='225'/>",
        ctrl: []
    },
    properties: {
        nodes: Array,
        lazyLoad: Boolean,
        loading: String
    },
    methods: {
        play: function(t) {
            if (this.top.group && this.top.group.pause(this.top.i), this.top.videoContexts.length > 1 && this.top.data.autopause) for (var e = this.top.videoContexts.length; e--; ) this.top.videoContexts[e].id != t.currentTarget.id && this.top.videoContexts[e].pause();
        },
        imgtap: function(t) {
            var e = t.currentTarget.dataset.attrs;
            if (!e.ignore) {
                var r = !0;
                if (this.top.triggerEvent("imgtap", {
                    id: t.currentTarget.id,
                    src: e.src,
                    ignore: function() {
                        return r = !1;
                    }
                }), r) {
                    if (this.top.group) return this.top.group.preview(this.top.i, e.i);
                    var i = this.top.imgList, a = i[e.i] ? i[e.i] : (i = [ e.src ], e.src);
                    wx.previewImage({
                        current: a,
                        urls: i
                    });
                }
            }
        },
        loadImg: function(e) {
            var r = e.target.dataset.i;
            this.data.lazyLoad && !this.data.ctrl[r] ? this.setData(t({}, "ctrl[" + r + "]", 1)) : this.data.loading && 2 != this.data.ctrl[r] && this.setData(t({}, "ctrl[" + r + "]", 2));
        },
        linkpress: function(t) {
            var e = !0, r = t.currentTarget.dataset.attrs;
            r.ignore = function() {
                return e = !1;
            }, this.top.triggerEvent("linkpress", r), e && (r["app-id"] ? wx.navigateToMiniProgram({
                appId: r["app-id"],
                path: r.path
            }) : r.href && ("#" == r.href[0] ? this.top.navigateTo({
                id: r.href.substring(1)
            }) : 0 == r.href.indexOf("http") || 0 == r.href.indexOf("//") ? wx.setClipboardData({
                data: r.href,
                success: function() {
                    return wx.showToast({
                        title: "链接已复制"
                    });
                }
            }) : wx.navigateTo({
                url: r.href,
                fail: function() {
                    wx.switchTab({
                        url: r.href
                    });
                }
            })));
        },
        error: function(r) {
            var i = r.target.dataset.source, a = r.target.dataset.i, s = this.data.nodes[a];
            if ("video" == i || "audio" == i) {
                var o = (s.i || 0) + 1;
                if (o < s.attrs.source.length) return this.setData(t({}, "nodes[" + a + "].i", o));
            } else "img" == i && e && (this.top.imgList.setItem(r.target.dataset.index, e), 
            this.setData(t({}, "nodes[" + a + "].attrs.src", e)));
            this.top && this.top.triggerEvent("error", {
                source: i,
                target: r.target,
                errMsg: r.detail.errMsg
            });
        },
        loadVideo: function(e) {
            this.setData(t({}, "nodes[" + e.target.dataset.i + "].attrs.autoplay", !0));
        }
    }
});