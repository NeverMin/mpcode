var o = getApp();

Component({
    properties: {},
    data: {
        show: !1
    },
    methods: {
        checkIsLogin: function() {
            var o = wx.getStorageSync("userInfo") || {};
            return o.phone || o.access_token ? (this.hideLogin(), !0) : (console.log("需要登录"), 
            this.showLogin(), !1);
        },
        setCloseLogin: function() {
            this.triggerEvent("setCloseLogin"), this.hideLogin();
        },
        showLogin: function() {
            this.setData({
                show: !0
            });
        },
        hideLogin: function() {
            this.setData({
                show: !1
            });
        },
        getPhone: function(t) {
            var n = this;
            o.getPhone(t, function() {
                console.log("授权成功"), n.hideLogin(), n.triggerEvent("loginCallback");
            });
        }
    }
});