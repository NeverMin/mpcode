Component({
    options: {
        styleIsolation: "apply-shared"
    },
    properties: {},
    data: {
        show: !0,
        selected: 0,
        color: "#fff",
        selectedColor: "#fff",
        list: [ {
            pagePath: "/pages/site/home",
            iconPath: "/images/tabbar/index.png",
            selectedIconPath: "/images/tabbar/index-selected.png",
            text: "首页"
        }, {
            pagePath: "/pages/course/home",
            iconPath: "/images/tabbar/course.png",
            selectedIconPath: "/images/tabbar/course-selected.png",
            text: "冥想"
        }, {
            pagePath: "/pages/my/home",
            iconPath: "/images/tabbar/my.png",
            selectedIconPath: "/images/tabbar/my-selected.png",
            text: "我的"
        } ]
    },
    methods: {
        switchTab: function(e) {
            var t = e.currentTarget.dataset;
            wx.switchTab({
                url: this.data.list[t.index].pagePath
            });
        }
    }
});