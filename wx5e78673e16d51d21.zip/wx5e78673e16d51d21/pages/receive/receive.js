(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/receive/receive" ], {
    "399d": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = {
                components: {},
                data: function() {
                    return {
                        isJurisdiction: !1,
                        fromUserKey: "",
                        meditatingId: "",
                        avatarUrl: "",
                        headImg: n("5268"),
                        fissionStatus: "",
                        defaultMediId: 87,
                        isOldUser: !1
                    };
                },
                computed: {},
                onLoad: function(t) {
                    t.fromUserKey && (this.fromUserKey = t.fromUserKey), t.meditatingId && (this.meditatingId = t.meditatingId), 
                    t.avatarUrl && (this.avatarUrl = decodeURIComponent(t.avatarUrl)), e.setStorageSync("__IS_RECEIVE_PAGE", !0), 
                    this.getReceiveStatus();
                },
                onUnload: function() {
                    e.removeStorageSync("__IS_RECEIVE_PAGE");
                },
                onShow: function() {},
                onShareAppMessage: function(e) {
                    return this.$onShareAppMessage();
                },
                methods: {
                    backHome: function() {
                        e.reLaunch({
                            url: "/pages/explore/explore"
                        });
                    },
                    goPracticeDetail: function() {
                        var e = this;
                        this.$utils.getUser().then(function() {
                            e.getPractice();
                        });
                    },
                    getPractice: function() {
                        var t = this;
                        this.$http({
                            url: this.$APIS.receivePractise,
                            data: {
                                meditatingId: this.meditatingId,
                                fromUserKey: this.fromUserKey
                            }
                        }).then(function(n) {
                            var i = n.code;
                            n.data, 1 != +i && (t.isOldUser = !0);
                            var a = t, r = t.isOldUser ? "您已是老用户啦" : "领取成功";
                            e.showToast({
                                title: r,
                                success: function() {
                                    a.$navTo.redirect({
                                        name: "practiceDetail",
                                        data: {
                                            meditatingId: a.defaultMediId
                                        }
                                    });
                                }
                            });
                        });
                    },
                    reGetReceiveStatus: function() {
                        this.getReceiveStatus();
                    },
                    getReceiveStatus: function() {
                        var e = this;
                        this.$utils.getUserOver().then(function() {
                            e.$http(e.$APIS.getPractiseInvite).then(function(t) {
                                var n = t.code, i = t.data;
                                1 == +n && i.fissionUserKey && i.fissionUserKey.includes(e.fromUserKey) && e.$navTo.redirect({
                                    name: "practiceDetail",
                                    data: {
                                        meditatingId: e.meditatingId
                                    }
                                });
                            });
                        });
                    }
                }
            };
            t.default = i;
        }).call(this, n("543d").default);
    },
    "7c9e": function(e, t, n) {
        var i = n("ff34");
        n.n(i).a;
    },
    "7d48": function(e, t, n) {
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var i = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    "8b2d": function(e, t, n) {
        (function(e, t) {
            var i = n("4ea4");
            n("6f19"), i(n("66fd"));
            var a = i(n("c31d"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    9384: function(e, t, n) {
        n.r(t);
        var i = n("399d"), a = n.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        t.default = a.a;
    },
    c31d: function(e, t, n) {
        n.r(t);
        var i = n("7d48"), a = n("9384");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        n("7c9e");
        var c = n("f0c5"), o = Object(c.a)(a.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = o.exports;
    },
    ff34: function(e, t, n) {}
}, [ [ "8b2d", "common/runtime", "common/vendor" ] ] ]);