(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/practiceComplete/components/clockIn" ], {
    3139: function(t, o, e) {},
    "9b44": function(t, o, e) {
        var n = e("3139");
        e.n(n).a;
    },
    bb3c: function(t, o, e) {
        e.r(o);
        var n = e("d5cb"), c = e("bbe3");
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(o, t, function() {
                return c[t];
            });
        }(a);
        e("9b44");
        var i = e("f0c5"), s = Object(i.a)(c.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        o.default = s.exports;
    },
    bbe3: function(t, o, e) {
        e.r(o);
        var n = e("e92b"), c = e.n(n);
        for (var a in n) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(o, t, function() {
                return n[t];
            });
        }(a);
        o.default = c.a;
    },
    d5cb: function(t, o, e) {
        e.d(o, "b", function() {
            return n;
        }), e.d(o, "c", function() {
            return c;
        }), e.d(o, "a", function() {});
        var n = function() {
            this.$createElement;
            var t = (this._self._c, this._f("secondsFormat")(this.learnTime)), o = this._f("secondsFormat")(this.learnTime);
            this.$mp.data = Object.assign({}, {
                $root: {
                    f0: t,
                    f1: o
                }
            });
        }, c = [];
    },
    e92b: function(t, o, e) {
        (function(t) {
            var n = e("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var c = e("ebf2"), a = n(e("39e7")), i = {
                props: [ "learnTime", "count", "title", "clockInBg" ],
                data: function() {
                    return {
                        clockInShow: !1,
                        clockImgList: [],
                        domDrawCount: 0,
                        headImg: "/static/images/clockIn/user-head.png",
                        clockInBgLoad: this.clockInBg,
                        canvasImg: ""
                    };
                },
                filters: {
                    secondsFormat: c.secondsFormat
                },
                computed: {
                    completeCount: function() {
                        return this.count;
                    },
                    completeCountArray: function() {
                        return String(this.count).split("");
                    },
                    userInfo: function() {
                        return this.$store.getters["common/getBaseInfo"];
                    },
                    getWxUserInfo: function() {
                        return this.$store.getters["common/getWxUserInfo"];
                    },
                    saveImg: function() {
                        return this.clockImgList[0] || "";
                    },
                    completeType: function() {
                        return this.$store.getters["common/getCompleteShare"].type;
                    }
                },
                created: function() {},
                mounted: function() {
                    this.downloadFile(), this.downClockInBg();
                },
                methods: {
                    hideModel: function() {
                        this.clockInShow = !1;
                    },
                    downClockInBg: function() {
                        var o = this;
                        t.downloadFile({
                            url: this.clockInBg,
                            success: function(t) {
                                console.log(t), o.clockInBgLoad = t.tempFilePath;
                            },
                            fail: function(t) {
                                console.log("downloadFile-clockInBgLoad" + o.clockInBg), o.setTime(500, o.downClockInBg);
                            }
                        });
                    },
                    downloadFile: function() {
                        var o = this;
                        this.getWxUserInfo.avatarUrl ? t.downloadFile({
                            url: this.getWxUserInfo.avatarUrl,
                            success: function(t) {
                                o.headImg = t.tempFilePath;
                            },
                            fail: function(t) {
                                console.log("downloadFile-avatarUrl" + o.getWxUserInfo.avatarUrl), o.setTime(500, o.downloadFile);
                            }
                        }) : this.setTime(500, this.downloadFile);
                    },
                    setTime: function(t, o) {
                        setTimeout(o, t, this);
                    },
                    open: function() {
                        this.canvasImg || t.showLoading({
                            title: "图片生成中"
                        }), this.clockInShow = !0;
                        var o = this;
                        this.drawImage = new a.default({
                            obj: o,
                            width: 630,
                            height: 952,
                            element: "canvas-map",
                            background: "#fff",
                            progress: function(t) {},
                            finish: function(e) {
                                console.log(e), t.hideLoading(), o.canvasImg = e;
                            },
                            error: function(o) {
                                console.log(o), t.hideLoading(), t.showToast({
                                    title: "图片生成失败请重试"
                                });
                            }
                        }), this.drawImage.draw({
                            list: [ {
                                type: "wxml",
                                class: ".wrapper .draw",
                                limit: ".wrapper",
                                x: 0,
                                y: 0
                            } ]
                        });
                    },
                    save: function() {
                        console.log("保存图片");
                        var o = this;
                        t.saveImageToPhotosAlbum({
                            filePath: this.canvasImg,
                            success: function() {
                                t.showToast({
                                    title: "图片保存成功"
                                }), o.hideModel();
                            }
                        });
                    }
                }
            };
            o.default = i;
        }).call(this, e("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "pages/practiceComplete/components/clockIn-create-component", {
    "pages/practiceComplete/components/clockIn-create-component": function(t, o, e) {
        e("543d").createComponent(e("bb3c"));
    }
}, [ [ "pages/practiceComplete/components/clockIn-create-component" ] ] ]);