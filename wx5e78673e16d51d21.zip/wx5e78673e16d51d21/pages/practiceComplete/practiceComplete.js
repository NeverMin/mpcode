require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/practiceComplete/practiceComplete" ], {
    "100a": function(t, e, i) {},
    "32ef": function(t, e, i) {
        var n = i("100a");
        i.n(n).a;
    },
    "63ce": function(t, e, i) {
        i.r(e);
        var n = i("c0cd"), o = i("f7dc");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(t) {
            i.d(e, t, function() {
                return o[t];
            });
        }(a);
        i("32ef");
        var c = i("f0c5"), r = Object(c.a)(o.default, n.b, n.c, !1, null, "37784d6b", null, !1, n.a, void 0);
        e.default = r.exports;
    },
    "774e": function(t, e, i) {
        (function(t, e) {
            var n = i("4ea4");
            i("6f19"), n(i("66fd"));
            var o = n(i("63ce"));
            t.__webpack_require_UNI_MP_PLUGIN__ = i, e(o.default);
        }).call(this, i("bc2e").default, i("543d").createPage);
    },
    a456: function(t, e, i) {
        (function(t) {
            var n = i("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = n(i("5ccf")), a = i("ebf2"), c = i("4834"), r = {
                mixins: [ o.default ],
                components: {
                    clockIn: function() {
                        Promise.all([ i.e("common/vendor"), i.e("pages/practiceComplete/components/clockIn") ]).then(function() {
                            return resolve(i("bb3c"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    step: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/meditation/step/index") ]).then(function() {
                            return resolve(i("147f"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    practiceFeelingsInDetail: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/meditation/practiceFeelingsInDetail/index") ]).then(function() {
                            return resolve(i("f357"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    goApp: function() {
                        i.e("components/common/goApp/index").then(function() {
                            return resolve(i("570c"));
                        }.bind(null, i)).catch(i.oe);
                    }
                },
                data: function() {
                    return {
                        count: 0,
                        learnTime: 0,
                        meditatingId: 0,
                        tabActive: 0,
                        practiceTimes: "",
                        meditatingInfo: {},
                        clockInShow: !1,
                        saveImgOk: !1,
                        saveImgURL: "",
                        tagNames: "",
                        style: {
                            width: "315px",
                            margin: "0 auto 24px",
                            height: "476px"
                        },
                        isAndroid: !1,
                        isIOS: !1,
                        headImg: i("5268"),
                        referrerPage: "",
                        isMuse: "",
                        clickCount: 0,
                        clockImgList: [],
                        clockImgLength: 5,
                        domDrawCount: 0,
                        hdImgList: [],
                        bgImgList: [],
                        toRelease: !1,
                        beforePageRoute: null
                    };
                },
                onShareAppMessage: function(t) {
                    var e = {};
                    return "voice" === this.completeType ? e = {
                        title: "我正在听「".concat(this.meditatingInfo.title, "」，很舒服！推荐给你！"),
                        path: "/pages/voicePlay/voicePlay?id=".concat(this.meditatingId)
                    } : "practice" === this.completeType && (e = {
                        title: "我正在练习".concat(this.meditatingInfo.title, "冥想，超有用！推荐给你"),
                        path: "/pages/practiceDetail/practiceDetail?meditatingId=".concat(this.meditatingId)
                    }), this.$onShareAppMessage(e);
                },
                computed: {
                    DPR: function() {
                        return getApp().globalData.systemInfo.pixelRatio || 1;
                    },
                    userInfo: function() {
                        return this.$store.getters["common/getBaseInfo"];
                    },
                    completeCount: function() {
                        return this.count;
                    },
                    completeCountArray: function() {
                        return String(this.completeCount).split("");
                    },
                    saveImg: function() {
                        return this.clockImgList[0] || "";
                    },
                    completeType: function() {
                        return this.$store.getters["common/getCompleteShare"].type;
                    },
                    isAudit: function() {
                        return getApp().globalData.isAudit;
                    }
                },
                onLoad: function(t) {
                    console.log(t), this.count = t.count || 0, this.meditatingId = t.meditatingId || 0, 
                    this.learnTime = t.learnTime || 0, this.referrerPage = t.referrerPage;
                    var e = getCurrentPages();
                    this.beforePageRoute = e[e.length - 2].route;
                },
                created: function() {
                    c.bgList.sort(function() {
                        return Math.random() > .5 ? -1 : 1;
                    }), this.hdImgList = c.bgList.map(function(t) {
                        return t.header;
                    }), this.bgImgList = c.bgList.map(function(t) {
                        return t.card;
                    });
                },
                onShow: function() {
                    var t = this;
                    console.log("onShow-practiceComplete"), setTimeout(function() {
                        t.$refs.feelingList.refreshData();
                    }, 200);
                },
                filters: {
                    secondsFormat: a.secondsFormat
                },
                methods: {
                    _initData: function() {
                        "voice" === this.completeType ? this.mediVoiceInfo() : "practice" === this.completeType && this.getDataDetail();
                    },
                    routerGoback: function() {
                        [ "pages/voicePlay/voicePlay", "pages/practiceToPlay/practiceToPlay" ].includes(this.beforePageRoute) ? t.navigateBack({
                            delta: 2
                        }) : t.navigateBack();
                    },
                    hideModel: function() {
                        this.clockInShow = !1;
                        var t = this.computedCount(this.clickCount + 1);
                        this.clockImgList[t - 1] ? this.saveImgURL = this.clockImgList[0] : this.saveImgURL = "";
                    },
                    goToPracticeDetail: function() {
                        console.log("将播放器标记为练习完全结束"), this.medi_mix_setMediComplete(), this.bookPlayerBar_initPlayer(), 
                        this.routerGoback();
                    },
                    mediVoiceInfo: function() {
                        var t = this;
                        return this.$http({
                            url: this.$APIS.mediVoiceInfo,
                            data: {
                                id: this.meditatingId
                            }
                        }).then(function(e) {
                            var i = e.code, n = e.data;
                            1 == +i && (t.meditatingInfo = n.voiceInfo);
                        });
                    },
                    getDataDetail: function() {
                        var t = this;
                        return this.$http({
                            url: this.$APIS.fetchPractice,
                            data: {
                                id: this.meditatingId
                            }
                        }).then(function(e) {
                            if (1 * e.code == 1) {
                                var i = e.data, n = i.meditatingInfo, o = i.tagNames;
                                t.meditatingInfo = n, t.tagNames = o;
                            }
                        });
                    },
                    goToIndex: function() {
                        this.$navTo.goIndex();
                    },
                    clockIn: function() {
                        this.$refs.clockIn.open();
                    },
                    goToReleaseFeeling: function() {
                        var t = {
                            url: "/meditation/releaseFeeling/".concat(this.meditatingId, "/").concat(this.completeCount),
                            title: this.meditatingInfo.title
                        };
                        "voice" === this.completeType ? (t.objectName = "college_medi_voice", t.practiceDays = this.completeCount) : "practice" === this.completeType && (t.onShareAppMessagePath = encodeURIComponent("/pages/practiceDetail/practiceDetail?meditatingId=".concat(this.meditatingId)), 
                        t.onShareAppMessageTitle = "我正在练习".concat(this.meditatingInfo.title, "冥想，超有用！推荐给你")), 
                        this.$navTo.push({
                            name: "opinion",
                            params: t
                        });
                    }
                }
            };
            e.default = r;
        }).call(this, i("543d").default);
    },
    c0cd: function(t, e, i) {
        i.d(e, "b", function() {
            return n;
        }), i.d(e, "c", function() {
            return o;
        }), i.d(e, "a", function() {});
        var n = function() {
            this.$createElement;
            var t = (this._self._c, this._f("secondsFormat")(this.learnTime));
            this.$mp.data = Object.assign({}, {
                $root: {
                    f0: t
                }
            });
        }, o = [];
    },
    f7dc: function(t, e, i) {
        i.r(e);
        var n = i("a456"), o = i.n(n);
        for (var a in n) [ "default" ].indexOf(a) < 0 && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(a);
        e.default = o.a;
    }
}, [ [ "774e", "common/runtime", "common/vendor" ] ] ]);