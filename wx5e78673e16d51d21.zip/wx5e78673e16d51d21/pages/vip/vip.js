(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/vip/vip" ], {
    "0dcd": function(i, e, t) {
        (function(i, p) {
            var n = t("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = n(t("9523")), o = n(t("4082")), s = (n(t("452e")), [ "vipInfo" ]);
            function m(i, e) {
                var t = Object.keys(i);
                if (Object.getOwnPropertySymbols) {
                    var p = Object.getOwnPropertySymbols(i);
                    e && (p = p.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(i, e).enumerable;
                    })), t.push.apply(t, p);
                }
                return t;
            }
            function c(i) {
                for (var e = 1; e < arguments.length; e++) {
                    var t = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? m(Object(t), !0).forEach(function(e) {
                        (0, a.default)(i, e, t[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(i, Object.getOwnPropertyDescriptors(t)) : m(Object(t)).forEach(function(e) {
                        Object.defineProperty(i, e, Object.getOwnPropertyDescriptor(t, e));
                    });
                }
                return i;
            }
            var g = {
                components: {
                    goApp: function() {
                        t.e("components/common/goApp/index").then(function() {
                            return resolve(t("570c"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    countDown: function() {
                        t.e("pages/vip/components/countDown").then(function() {
                            return resolve(t("481e"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                mixins: [],
                data: function() {
                    return {
                        activeImg: [ "https://lapp.xinli001.com/images/medi-wxapp/images/vip/VIP_1.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/VIP_2.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/VIP_3.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/VIP_4.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/VIP_5.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/VIP_6.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/VIP_7.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/VIP_8.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/VIP_9.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/VIP_10.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/VIP_11.png" ],
                        makingImg: [ "https://lapp.xinli001.com/images/medi-wxapp/images/vip/making1.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/making2.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/making3.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/making4.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/making5.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/making6.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/making7.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/making8.png" ],
                        voiceImg: [ "https://lapp.xinli001.com/images/medi-wxapp/images/vip/voiceimg1.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/voiceimg2.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/voiceimg3.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/voiceimg4.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/voiceimg5.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/voiceimg6.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/voiceimg7.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/voiceimg8.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/voiceimg9.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/voiceimg10.png" ],
                        activeImgs: [ "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/VIP_1.png?1655370751092", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/VIP_2.png?1655370751092", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/VIP_3.png?1655370751092", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/VIP_4.png?1655370751092", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/VIP_5.png?1655370751092", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/VIP_6.png?1655370751092", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/VIP_7.png?1655370751092", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/VIP_8.png?1655370751092", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/VIP_9.png?1655370751092" ],
                        aboutList: [ "https://lapp.xinli001.com/images/medi-wxapp/images/vip/about1.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/about2.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/about3.png", "https://lapp.xinli001.com/images/medi-wxapp/images/vip/about4.png" ],
                        disCode: "",
                        loopImgList: {
                            preleft: 9,
                            left: 0,
                            nearLeft: 1,
                            center: 2,
                            nearRight: 3,
                            right: 4,
                            nextright: 5
                        },
                        loopTimer: null,
                        recommendRate: [],
                        isInIOS: !1,
                        dataReady: !1,
                        mediActiveExpiredTime: 0,
                        vipPrice: 49,
                        vipOriginalPrice: 199,
                        isVipActive: !1,
                        mediActivityBuy: !1,
                        isWechatVersion: !0
                    };
                },
                filters: {
                    toFixedTwo: function(i) {
                        return i ? parseFloat(i).toFixed(2) : "0.00";
                    }
                },
                computed: {
                    vipotherInfo: function() {
                        return this.$store.getters["mine/getVipotherInfo"];
                    },
                    isAudit: function() {
                        return console.log(getApp().globalData.isAudit), getApp().globalData.isAudit;
                    }
                },
                onLoad: function(i) {
                    this.disCode = i.disCode || "";
                },
                onShow: function() {
                    this.init();
                },
                onShareAppMessage: function(i) {
                    return this.$onShareAppMessage({
                        path: "/pages/vip/vip"
                    });
                },
                methods: {
                    timeout_event: function(i) {
                        "timeout_end" === i && (this.isVipActive = !1, this.init());
                    },
                    setVoiceSwiper: function() {
                        var i = this;
                        this.loopTimer = setInterval(function() {
                            i.loopImgList.preleft = (i.loopImgList.preleft + 1) % 10, i.loopImgList.left = (i.loopImgList.left + 1) % 10, 
                            i.loopImgList.nearLeft = (i.loopImgList.nearLeft + 1) % 10, i.loopImgList.center = (i.loopImgList.center + 1) % 10, 
                            i.loopImgList.nearRight = (i.loopImgList.nearRight + 1) % 10, i.loopImgList.right = (i.loopImgList.right + 1) % 10, 
                            i.loopImgList.nextright = (i.loopImgList.nextright + 1) % 10;
                        }, 3e3);
                    },
                    init: function() {
                        var i = this;
                        this.$utils.getUserOver().then(function(e) {
                            i.$store.dispatch("mine/fetchVipotherInfo"), i.$store.dispatch("mine/fetchMyVip");
                        });
                        var e = setInterval(function() {
                            if (i.isInIOS = "ios" === getApp().globalData._platform, console.log(i.isInIOS, "是否ios"), 
                            i.vipotherInfo && i.vipotherInfo.vipInfo) {
                                var t = i.vipotherInfo, p = t.vipInfo, n = (0, o.default)(t, s);
                                i.vipPrice = p.price || 49, i.vipOriginalPrice = p.originalPrice || 199;
                                var a = n.mediActivityEndTime, m = n.mediActivityStartTime;
                                if (n && n.mediActivityStartTime && n.mediActivityEndTime) {
                                    var c = new Date().getTime();
                                    a = a.replace(/-/g, "/"), a = new Date(a), m = m.replace(/-/g, "/"), m = new Date(m), 
                                    i.isVipActive = c >= m.getTime() && c < a.getTime(), console.log("活动标识", i.isVipActive), 
                                    i.mediActivityBuy = n.mediActivityBuy && 1 === n.mediActivityBuy, i.mediActiveExpiredTime = (a - c) / 1e3;
                                    var g = i.isInIOS ? "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/noIOS.png" : "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/VIP_1.png", r = i.isInIOS ? "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/noIOS.png" : "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/VIP_8.png";
                                    i.$set(i.activeImgs, "0", g), i.$set(i.activeImgs, "7", r), i.isInIOS && i.activeImgs.splice("7", 1);
                                } else {
                                    var l = i.isInIOS ? "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/noIOS.png" : "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/VIP_NORMAL_1.png", d = i.isInIOS ? "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/noIOS.png" : "https://lapp.xinli001.com/images/medi-wxapp/images/vip/centroid/VIP_NORMAL_8.png";
                                    i.$set(i.activeImgs, "0", l), i.$set(i.activeImgs, "7", d), i.activeImgs.splice("8", 1), 
                                    i.isInIOS && i.activeImgs.splice("7", 1);
                                }
                                i.fetchRecommendMediRate(), i.setVoiceSwiper(), i.dataReady = !0, clearInterval(e), 
                                e = null;
                            }
                        }, 500);
                    },
                    _initData: function() {
                        this.vipotherInfo || this.$store.dispatch("mine/fetchVipotherInfo");
                    },
                    pushloadList: function() {},
                    fetchRecommendMediRate: function() {
                        var i = this;
                        this.$http(this.$APIS.getRecommendMediRate, {
                            data: {
                                "queryVo.page": 1,
                                "queryVo.size": 50
                            }
                        }).then(function(e) {
                            var t = e.code, p = e.data;
                            if (1 == +t) {
                                var n = p.length;
                                n <= 1 || p.forEach(function(i, e) {
                                    var t = parseInt(Math.random() * (n - 1)), a = i;
                                    p[e] = p[t], p[t] = a;
                                }), i.recommendRate = p;
                            }
                        });
                    },
                    payVip: function() {
                        var e = this;
                        this.$utils.getUser().then(function(t) {
                            e.$http(e.$APIS.meditationPay, {
                                data: c({}, {
                                    "order.orderType": 4,
                                    "order.buyType": 0,
                                    "order.lessonId": 3,
                                    "order.isPay": 1,
                                    "order.quantity": 1,
                                    "order.disCode": "",
                                    channelId: 2147,
                                    "order.channelId": 2147,
                                    "order.tradeType": "WX_MINIAPP"
                                })
                            }).then(function(e) {
                                var t = e.code, p = e.data;
                                if (1 == +t) {
                                    var n = p.body;
                                    i.requestPayment({
                                        timeStamp: n.timeStamp,
                                        nonceStr: n.nonceStr,
                                        package: n.package,
                                        signType: n.signType,
                                        paySign: n.paySign,
                                        success: function(i) {
                                            console.log(i);
                                        },
                                        fail: function(i) {
                                            console.log(i);
                                        },
                                        cancel: function(i) {
                                            console.log(i);
                                        }
                                    });
                                }
                            });
                        });
                    },
                    vipBuy: function() {
                        var i = this;
                        this.isInIOS || !this.isWechatVersion ? this.$utils.getUser().then(function() {
                            i.$navTo.push({
                                name: "task"
                            });
                        }) : this.payVip();
                    },
                    toindex: function() {
                        p.switchTab({
                            url: "/pages/explore/explore"
                        });
                    },
                    toServePage: function() {
                        p.navigateTo({
                            url: "/pages/opinion/opinion?url=/meditation/serve",
                            success: function(i) {
                                console.log(i);
                            },
                            fail: function(i) {
                                console.log(i);
                            }
                        });
                    }
                }
            };
            e.default = g;
        }).call(this, t("bc2e").default, t("543d").default);
    },
    "5da6": function(i, e, t) {
        (function(i, e) {
            var p = t("4ea4");
            t("6f19"), p(t("66fd"));
            var n = p(t("ed85"));
            i.__webpack_require_UNI_MP_PLUGIN__ = t, e(n.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    a02a: function(i, e, t) {},
    b2b1: function(i, e, t) {
        t.r(e);
        var p = t("0dcd"), n = t.n(p);
        for (var a in p) [ "default" ].indexOf(a) < 0 && function(i) {
            t.d(e, i, function() {
                return p[i];
            });
        }(a);
        e.default = n.a;
    },
    cd00: function(i, e, t) {
        var p = t("a02a");
        t.n(p).a;
    },
    ddf8: function(i, e, t) {
        t.d(e, "b", function() {
            return p;
        }), t.d(e, "c", function() {
            return n;
        }), t.d(e, "a", function() {});
        var p = function() {
            var i = this, e = (i.$createElement, i._self._c, i.__map(i.activeImgs, function(e, t) {
                return {
                    $orig: i.__get_orig(e),
                    g0: 6 === t && i.recommendRate && i.recommendRate.length
                };
            })), t = i.dataReady && 0 === i.vipotherInfo.isJoin && i.isWechatVersion && !i.isInIOS ? i._f("toFixedTwo")(i.vipPrice) : null, p = !i.dataReady || 0 === i.vipotherInfo.isJoin || i.isVipActive && (!i.isVipActive || i.mediActivityBuy) || !i.isWechatVersion || i.isInIOS || i.isVipActive ? null : i._f("toFixedTwo")(i.vipPrice), n = i.dataReady && 0 !== i.vipotherInfo.isJoin && (!i.isVipActive || i.isVipActive && !i.mediActivityBuy) && i.isWechatVersion && !i.isInIOS && i.isVipActive ? i._f("toFixedTwo")(i.vipPrice) : null;
            i.$mp.data = Object.assign({}, {
                $root: {
                    l0: e,
                    f0: t,
                    f1: p,
                    f2: n
                }
            });
        }, n = [];
    },
    ed85: function(i, e, t) {
        t.r(e);
        var p = t("ddf8"), n = t("b2b1");
        for (var a in n) [ "default" ].indexOf(a) < 0 && function(i) {
            t.d(e, i, function() {
                return n[i];
            });
        }(a);
        t("cd00");
        var o = t("f0c5"), s = Object(o.a)(n.default, p.b, p.c, !1, null, null, null, !1, p.a, void 0);
        e.default = s.exports;
    }
}, [ [ "5da6", "common/runtime", "common/vendor" ] ] ]);