(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/practiceDetail/practiceDetail" ], {
    "15c3": function(e, t, i) {
        i.r(t);
        var n = i("602c"), a = i("84e3");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            i.d(t, e, function() {
                return a[e];
            });
        }(o);
        i("84a7"), i("9ce1");
        var s = i("f0c5"), r = Object(s.a)(a.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = r.exports;
    },
    "43fb": function(e, t, i) {},
    "602c": function(e, t, i) {
        i.d(t, "b", function() {
            return n;
        }), i.d(t, "c", function() {
            return a;
        }), i.d(t, "a", function() {});
        var n = function() {
            var e = this, t = (e.$createElement, e._self._c, e.meditatingInfo && e.meditatingInfo.practiceNum ? e.__map(e.avatarList, function(t, i) {
                return {
                    $orig: e.__get_orig(t),
                    g0: e.avatarList.length
                };
            }) : null), i = e.practiceStep.length, n = e.isExit || e.isJoin ? null : e.assistanceUser.length, a = e.isExit || e.isJoin ? null : e.assistanceNum > 0 && e.practiceUser && e.practiceUser.length > 0, o = e.isExit || e.isJoin || !a ? null : e.__map(e.practiceUser, function(t, i) {
                return {
                    $orig: e.__get_orig(t),
                    m0: e.getSecretName(t.nickname)
                };
            });
            e.$mp.data = Object.assign({}, {
                $root: {
                    l0: t,
                    g1: i,
                    g2: n,
                    g3: a,
                    l1: o
                }
            });
        }, a = [];
    },
    "82f0": function(e, t, i) {
        (function(e) {
            var n = i("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n(i("448a")), o = n(i("452e")), s = i("2976"), r = n(i("d489")), c = n(i("29f9")), l = {
                mixins: [ r.default, o.default ],
                filters: {
                    filterPennyToYuan: s.filterPennyToYuan
                },
                components: {
                    step: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/meditation/step/index") ]).then(function() {
                            return resolve(i("147f"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    textFold: function() {
                        i.e("components/meditation/textFold/index").then(function() {
                            return resolve(i("a0e2"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    practiceFeelingsInDetail: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/meditation/practiceFeelingsInDetail/index") ]).then(function() {
                            return resolve(i("f357"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    practiceOtherInfo: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/common/practiceOtherInfo") ]).then(function() {
                            return resolve(i("a3bf"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    goApp: function() {
                        i.e("components/common/goApp/index").then(function() {
                            return resolve(i("570c"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    dialogBox: function() {
                        i.e("components/common/dialogBox").then(function() {
                            return resolve(i("ca9f"));
                        }.bind(null, i)).catch(i.oe);
                    }
                },
                data: function() {
                    return {
                        practiceStep: [],
                        isJoin: !1,
                        isExit: !1,
                        avatarList: [],
                        practiceTimes: "",
                        meditatingInfo: {},
                        changeTabIng: !1,
                        list: [],
                        meditatingInfoTitle: "",
                        isFree: !1,
                        tagNames: "",
                        canClick: !0,
                        disCode: "",
                        gaussianBlurCover: "",
                        wrongImg: "https://lapp.xinli001.com/images/medi-wxapp/images/practice-z-bg.png",
                        gaussianCover: "https://lapp.xinli001.com/images/medi-wxapp/images/meditation/gaussianCover.png",
                        emptyHead: "https://lapp.xinli001.com/images/medi-wxapp/images/empty_head.png",
                        isMuse: !1,
                        bottomShow: !1,
                        isMuseIos: !1,
                        meditatingId: 40,
                        sc_mix_tabIndex: 0,
                        sc_mix_isFixed: !1,
                        assistanceNum: 0,
                        practiceUser: [],
                        assistanceUser: [],
                        shareBackgroundImg: "",
                        shareTitle: "",
                        fissionUserKey: 0,
                        practiceIntro: []
                    };
                },
                onLoad: function(e) {
                    this.meditatingId = e.meditatingId, this.disCode = e.disCode;
                },
                created: function() {
                    console.log("created");
                },
                onPageScroll: function(e) {
                    e.scrollTop - this.practiceTabBox > 0 ? this.sc_mix_isFixed = !0 : this.sc_mix_isFixed = !1, 
                    e.scrollTop < this.anchor1 ? this.sc_mix_tabIndex = 0 : e.scrollTop > this.anchor2 ? this.sc_mix_tabIndex = 2 : this.sc_mix_tabIndex = 1;
                },
                mounted: function() {
                    var t = this;
                    setTimeout(function() {
                        e.createSelectorQuery().select("#practiceTabBox").boundingClientRect(function(e) {
                            t.practiceTabBox = e.top;
                        }).exec();
                    }, 500);
                },
                onShareAppMessage: function(e) {
                    if (console.log(e), "menu" === e.from) return this.$onShareAppMessage({
                        title: "我正在练习「".concat(this.meditatingInfoTitle, "」冥想，超有用！推荐给你"),
                        path: "/pages/practiceDetail/practiceDetail?meditatingId=".concat(this.meditatingId)
                    });
                    var t = "/pages/receive/receive?fromUserKey=".concat(this.fissionUserKey, "&meditatingId=").concat(this.meditatingId);
                    return this.getWxUserInfo.avatarUrl && (t += "&avatarUrl=".concat(encodeURIComponent(this.getWxUserInfo.avatarUrl))), 
                    this.$onShareAppMessage({
                        imageUrl: this.shareBackgroundImg,
                        title: this.shareTitle,
                        path: t
                    });
                },
                onShow: function() {
                    var e = this;
                    console.log("onShow-practiceDetail"), this.init();
                    var t = setInterval(function() {
                        e.$refs.feelingList && e.$refs.feelingList.refreshData && (e.$refs.feelingList.refreshData(), 
                        clearInterval(t), t = null);
                    }, 200);
                },
                computed: {
                    userOtherInfo: function() {
                        return this.$store.getters["mine/getMyVip"] || {};
                    },
                    getWxUserInfo: function() {
                        return this.$store.getters["common/getWxUserInfo"];
                    }
                },
                methods: {
                    init: function() {
                        var t = this;
                        getApp().globalData.userInfoSQ || e.getUserInfo({
                            provider: getApp().globalData._provider,
                            fail: function(e) {
                                t.$store.commit("common/setUserInfoDialog", !0);
                            }
                        }), this.$utils.getUserOver().then(function(e) {
                            t.getDataDetail(), t.$store.dispatch("mine/fetchMyVip");
                        });
                    },
                    getSecretName: function(e) {
                        return e = "".concat(e.substr(0, 1), "***").concat(e.substr(e.length - 1));
                    },
                    _initData: function() {},
                    getShareInfo: function() {
                        var e = this;
                        this.$http({
                            url: this.$APIS.getPractiseInvite
                        }).then(function(t) {
                            1 == +t.code && (e.shareBackgroundImg = t.data.shareBackgroundImg, e.shareTitle = t.data.shareTitle, 
                            e.fissionUserKey = t.data.fissionUserKey[0]);
                        }).catch(function(e) {
                            console.log(e);
                        });
                    },
                    getDomOffset: function() {
                        var t = this;
                        setTimeout(function() {
                            [ "anchor0", "anchor1", "anchor2" ].forEach(function(i, n) {
                                var a = e.createSelectorQuery();
                                a.select("#" + i).boundingClientRect(), a.selectViewport().scrollOffset(), a.exec(function(e) {
                                    var n = e[0].top + e[1].scrollTop;
                                    t[i] = n - 80;
                                });
                            });
                        }, 200);
                    },
                    goToVip: function() {
                        this.$utils.getUser().then(function() {
                            e.navigateTo({
                                url: "/pages/receive/receive"
                            });
                        });
                    },
                    joinAgainMeditating: function() {
                        var t = this;
                        this.$http({
                            url: this.$APIS.joinAgainMeditating,
                            data: {
                                id: this.meditatingId
                            }
                        }).then(function(i) {
                            1 == +i.code && (e.showToast({
                                title: "参与成功"
                            }), t.getDataDetail());
                        });
                    },
                    joinPractice: function() {
                        this.buyPractice();
                    },
                    buyPractice: function() {
                        var t = this;
                        this.canClick && (this.canclick = !1, this.bookClubPay({
                            "order.orderType": 7,
                            "order.buyType": 0,
                            "order.lessonId": this.meditatingId,
                            "order.isPay": 1,
                            "order.quantity": 1,
                            "order.disCode": this.disCode
                        }).then(function(i) {
                            "chooseWXPay:ok" !== i.errMsg && "freeSuccess" !== i.message || (i.message && "freeSuccess" === i.message && e.showToast({
                                title: "参与成功"
                            }), t.getDataDetail()), t.canclick = !0;
                        }));
                    },
                    goToGetForGive: function() {
                        this.buriedPoint(1), this.p_mix_goTo({
                            name: "getForGive",
                            params: {
                                meditatingId: this.$route.query.meditatingId
                            }
                        });
                    },
                    changeTab: function(t) {
                        e.pageScrollTo({
                            scrollTop: this["anchor" + t] + 10,
                            duration: 0
                        });
                    },
                    goToIndex: function() {
                        e.switchTab({
                            url: "/pages/explore/explore"
                        });
                    },
                    startPractice: function() {
                        this.$http({
                            url: this.$APIS.fetchBeforePlay,
                            data: {
                                meditatingId: this.meditatingId,
                                flag: 1
                            }
                        }), this.$navTo.push({
                            name: "practiceToPlay",
                            params: {
                                meditatingId: this.meditatingId
                            }
                        });
                    },
                    getDataDetail: function() {
                        var e = this;
                        this.$http({
                            url: this.$APIS.fetchDetail,
                            data: {
                                id: this.meditatingId
                            }
                        }).then(function(t) {
                            if (e.bottomShow = !0, 1 * t.code == 1) {
                                var i = t.data, n = i.isJoin, o = i.isExit, s = i.avatarList, r = i.practiceTimes, l = i.meditatingInfo, u = i.tagNames, d = i.isFree;
                                e.isJoin = n, e.isExit = o, e.isFree = d, e.avatarList = [].concat((0, a.default)(s), [ "https://lapp.xinli001.com/images/medi-wxapp/images/more-head-icon.png" ]), 
                                e.practiceTimes = r, e.meditatingInfo = l, e.meditatingInfoTitle = l.title;
                                var f = l.cover;
                                if (f.indexOf("@80") > 0) e.gaussianBlurCover = f.replace(/@80/g, "?x-oss-process=image/resize,m_fill,h_45,w_150/blur,r_30,s_10"); else if (f.indexOf("?x-oss-process=image/quality,Q_80") > 0) {
                                    var m = f.indexOf("?x-oss-process=image/quality,Q_80");
                                    e.gaussianBlurCover = f.substring(0, m) + "?x-oss-process=image/resize,m_fill,h_45,w_150/blur,r_30,s_10";
                                }
                                if (e.tagNames = u, e.practiceStep = l.practiceStep && JSON.parse(l.practiceStep) || [], 
                                l && l.intro) {
                                    var g = e;
                                    (0, c.default)(l.intro, function(t, i) {
                                        t || (g.practiceIntro = i, e.getDomOffset());
                                    });
                                }
                                e.$store.commit("common/setCompleteShare", {
                                    type: "practice",
                                    meditatingId: e.meditatingId,
                                    title: e.meditatingInfoTitle
                                }), e.isExit || e.isJoin || e.getShareInfo();
                            }
                        }).catch(function(e) {});
                    },
                    getAssistanceInfo: function() {
                        e.navigateTo({
                            url: "/pages/vip/vip",
                            success: function(e) {
                                console.log(e);
                            },
                            fail: function(e) {
                                console.log(e);
                            }
                        });
                    },
                    buriedPoint: function(e) {
                        switch (e) {
                          case 0:
                            this.$stat.send({
                                name: "冥想星球-交互行为",
                                properties: {
                                    "业务": "参与练习",
                                    "行为": "点击",
                                    "对象": "练习详情页-参与练习",
                                    "文字": "参与练习",
                                    "练习标题": this.meditatingInfo.title,
                                    "练习分类": this.tagNames,
                                    "页面来源": "练习详情页",
                                    "运营跟踪标识": this.sourceNameCookie
                                }
                            });
                            break;

                          case 1:
                            this.$stat.send({
                                name: "冥想星球-交互行为",
                                properties: {
                                    "业务": "练习详情",
                                    "行为": "点击",
                                    "对象": "练习详情页-赠一得一",
                                    "文字": "赠一得一",
                                    "练习标题": this.meditatingInfo.title,
                                    "运营跟踪标识": this.sourceNameCookie
                                }
                            });
                            break;

                          case 2:
                            this.$stat.send({
                                name: "冥想星球-交互行为",
                                properties: {
                                    "业务": "练习详情",
                                    "行为": "点击",
                                    "对象": "练习详情页-首页",
                                    "文字": "首页",
                                    "练习标题": this.meditatingInfo.title,
                                    "运营跟踪标识": this.sourceNameCookie
                                }
                            });
                            break;

                          case 3:
                            this.$stat.send({
                                name: "冥想星球-页面访问",
                                properties: {
                                    "页面描述": "练习完成次数",
                                    "练习标题": this.meditatingInfo.title,
                                    "完成次数": this.practiceTimes,
                                    "运营跟踪标识": this.sourceNameCookie
                                }
                            });
                            break;

                          case 4:
                            this.$stat.send({
                                name: "冥想星球-页面访问",
                                properties: {
                                    "页面title": this.meditatingInfo.title,
                                    "页面描述": "练习详情页",
                                    "练习标题": this.meditatingInfo.title,
                                    "来源入口": this.$route.query.sourceName || this.$route.params.sourceEntry || this.$route.query.sourceEntry || "其他",
                                    "运营跟踪标识": this.sourceNameCookie
                                }
                            });
                            break;

                          case 5:
                            this.$stat.send({
                                name: "冥想星球-交互行为",
                                properties: {
                                    "业务": "购买",
                                    "行为": "点击",
                                    "对象": "冥想星球-练习-购买",
                                    "练习标题": this.meditatingInfo.title,
                                    "页面来源": "练习详情页",
                                    "运营跟踪标识": this.sourceNameCookie
                                }
                            });
                        }
                    }
                }
            };
            t.default = l;
        }).call(this, i("543d").default);
    },
    "84a7": function(e, t, i) {
        var n = i("a6c6");
        i.n(n).a;
    },
    "84e3": function(e, t, i) {
        i.r(t);
        var n = i("82f0"), a = i.n(n);
        for (var o in n) [ "default" ].indexOf(o) < 0 && function(e) {
            i.d(t, e, function() {
                return n[e];
            });
        }(o);
        t.default = a.a;
    },
    "9ce1": function(e, t, i) {
        var n = i("43fb");
        i.n(n).a;
    },
    a6c6: function(e, t, i) {},
    c0b2: function(e, t, i) {
        (function(e, t) {
            var n = i("4ea4");
            i("6f19"), n(i("66fd"));
            var a = n(i("15c3"));
            e.__webpack_require_UNI_MP_PLUGIN__ = i, t(a.default);
        }).call(this, i("bc2e").default, i("543d").createPage);
    }
}, [ [ "c0b2", "common/runtime", "common/vendor" ] ] ]);