require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/task/task" ], {
    "205e": function(e, t, n) {
        n.r(t);
        var s = n("6608"), i = n("64dc");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(o);
        var r = n("f0c5"), a = Object(r.a)(i.default, s.b, s.c, !1, null, null, null, !1, s.a, void 0);
        t.default = a.exports;
    },
    3041: function(e, t, n) {
        (function(e, t) {
            var s = n("4ea4");
            n("6f19"), s(n("66fd"));
            var i = s(n("205e"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "64dc": function(e, t, n) {
        n.r(t);
        var s = n("eeac"), i = n.n(s);
        for (var o in s) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return s[e];
            });
        }(o);
        t.default = i.a;
    },
    6608: function(e, t, n) {
        n.d(t, "b", function() {
            return s;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var s = function() {
            this.$createElement;
            var e = (this._self._c, [ 1, 2 ].includes(this.fissionStatus));
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: e
                }
            });
        }, i = [];
    },
    eeac: function(e, t, n) {
        (function(e) {
            var s = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0, s(n("452e"));
            var i = {
                mixins: [],
                components: {
                    present: function() {
                        n.e("pages/task/components/present").then(function() {
                            return resolve(n("abb0"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    lottery: function() {
                        n.e("pages/task/components/lottery").then(function() {
                            return resolve(n("7a98"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    taskDialog: function() {
                        n.e("pages/task/components/dialog").then(function() {
                            return resolve(n("ac41"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        isJurisdiction: !1,
                        fromUserKey: "",
                        fromUserName: "",
                        fissionStatus: ""
                    };
                },
                computed: {
                    wxUserInfo: function() {
                        return this.$store.getters["common/getBaseInfo"];
                    },
                    isShowLottery: function() {
                        return !this.isJurisdiction || (console.log(this.fromUserKey, this.fissionStatus), 
                        this.fromUserKey && 0 === this.fissionStatus);
                    },
                    isShow7Vip: function() {
                        return !this.fromUserKey && 0 === this.fissionStatus;
                    }
                },
                onLoad: function(e) {
                    var t = this;
                    console.log("进入", e), e.fromUserKey && (this.fromUserKey = e.fromUserKey), e.fromUserName && (this.fromUserName = decodeURIComponent(e.fromUserName)), 
                    this.$observer.$on("lotteryOver", function() {
                        t.fissionStatus = 2;
                    });
                },
                onUnload: function() {
                    this.$observer.$off("lotteryOver");
                },
                onShow: function() {
                    var e = this;
                    this.$utils.getUserOver().then(function(t) {
                        e.isJurisdiction = !0, e.getFissionInvite();
                    });
                },
                onShareAppMessage: function(e) {
                    "button" === e.from && console.log(e.target);
                    var t = "/pages/task/task?fromUserKey=".concat(this.fissionUserKey);
                    return this.wxUserInfo.nickName && (t += "&fromUserName=".concat(encodeURIComponent(this.wxUserInfo.nickName))), 
                    this.$onShareAppMessage({
                        title: this.shareTitle,
                        imageUrl: "https://lapp.xinli001.com/images/medi-wxapp/images/task/share.png",
                        path: t
                    });
                },
                methods: {
                    getFissionInvite: function() {
                        var e = this;
                        this.$http(this.$APIS.getFissionInvite).then(function(t) {
                            var n = t.code, s = t.data;
                            1 == +n && (e.shareBackgroundImg = s.shareBackgroundImg, e.shareTitle = s.shareTitle, 
                            e.fissionUserKey = s.fissionUserKey[0], e.getFissionStatus(s.fissionUserKey));
                        });
                    },
                    getFissionStatus: function(e) {
                        var t = this;
                        this.$http(this.$APIS.getFissionStatus).then(function(n) {
                            var s = n.code, i = n.data;
                            1 == +s && (t.fissionStatus = +i, 0 === t.fissionStatus ? t.getreceive() : t.fromUserKey && !e.includes(t.fromUserKey) && t.alreayJoinTip());
                        }).catch(function(e) {
                            console.log(e);
                        });
                    },
                    getreceive: function() {
                        var e = this;
                        this.fromUserKey && this.$http({
                            url: this.$APIS.receive,
                            data: {
                                fromUserKey: this.fromUserKey
                            }
                        }).then(function(t) {
                            var n = t.code;
                            t.data, 50012 == +n && (e.fromUserKey = "");
                        });
                    },
                    alreayJoinTip: function() {
                        e.showToast({
                            title: "每人只可参与一次哦~",
                            duration: 2e3,
                            icon: "none"
                        });
                    }
                }
            };
            t.default = i;
        }).call(this, n("543d").default);
    }
}, [ [ "3041", "common/runtime", "common/vendor" ] ] ]);