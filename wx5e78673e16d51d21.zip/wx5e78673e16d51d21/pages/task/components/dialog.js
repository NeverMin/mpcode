(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/task/components/dialog" ], {
    "2ea5": function(n, o, e) {
        e.d(o, "b", function() {
            return t;
        }), e.d(o, "c", function() {
            return a;
        }), e.d(o, "a", function() {});
        var t = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    "35ad": function(n, o, e) {
        Object.defineProperty(o, "__esModule", {
            value: !0
        }), o.default = void 0;
        var t = {
            components: {
                dialogBox: function() {
                    e.e("components/common/dialogBox").then(function() {
                        return resolve(e("ca9f"));
                    }.bind(null, e)).catch(e.oe);
                }
            },
            data: function() {
                return {
                    visible: !1,
                    vipId: ""
                };
            },
            computed: {
                vipText: function() {
                    return {
                        3: "1年",
                        6: "1个月",
                        4: "7天"
                    }[this.vipId] || "7天";
                }
            },
            created: function() {
                var n = this;
                console.log("created"), this.$observer.$on("lotteryOver", function(o) {
                    n.vipId = o.vipId, n.showDialog();
                });
            },
            destroyed: function() {
                this.$observer.$off("lotteryOver");
            },
            methods: {
                showDialog: function() {
                    this.$refs.dialogBox.open();
                },
                goApp: function() {
                    this.$navTo.goIndex();
                }
            }
        };
        o.default = t;
    },
    5531: function(n, o, e) {},
    5831: function(n, o, e) {
        e.r(o);
        var t = e("35ad"), a = e.n(t);
        for (var c in t) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(o, n, function() {
                return t[n];
            });
        }(c);
        o.default = a.a;
    },
    "9d99": function(n, o, e) {
        var t = e("5531");
        e.n(t).a;
    },
    ac41: function(n, o, e) {
        e.r(o);
        var t = e("2ea5"), a = e("5831");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(o, n, function() {
                return a[n];
            });
        }(c);
        e("9d99");
        var i = e("f0c5"), r = Object(i.a)(a.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        o.default = r.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "pages/task/components/dialog-create-component", {
    "pages/task/components/dialog-create-component": function(n, o, e) {
        e("543d").createComponent(e("ac41"));
    }
}, [ [ "pages/task/components/dialog-create-component" ] ] ]);