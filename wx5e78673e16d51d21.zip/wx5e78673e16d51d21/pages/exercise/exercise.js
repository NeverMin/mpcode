(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/exercise/exercise" ], {
    "0730": function(e, n, t) {
        (function(e) {
            var o = t("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = o(t("2eee")), c = o(t("9523")), r = o(t("c973")), a = o(t("452e")), s = t("2976");
            function u(e, n) {
                var t = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    n && (o = o.filter(function(n) {
                        return Object.getOwnPropertyDescriptor(e, n).enumerable;
                    })), t.push.apply(t, o);
                }
                return t;
            }
            function l(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var t = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? u(Object(t), !0).forEach(function(n) {
                        (0, c.default)(e, n, t[n]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : u(Object(t)).forEach(function(n) {
                        Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
                    });
                }
                return e;
            }
            var f = {
                mixins: [ a.default ],
                components: {
                    goApp: function() {
                        t.e("components/common/goApp/index").then(function() {
                            return resolve(t("570c"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    vipDialog: function() {
                        t.e("components/common/vip/dialog/index").then(function() {
                            return resolve(t("4702"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    uniml2canvas: function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/common/uniml2canvas/uniml2canvas") ]).then(function() {
                            return resolve(t("6384"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    listItem: function() {
                        t.e("components/voice/listItem").then(function() {
                            return resolve(t("c113"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    practiceCover: function() {
                        t.e("components/exercise/practiceCover/practiceCover").then(function() {
                            return resolve(t("8208"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                data: function() {
                    return {
                        headImg: t("5268"),
                        voiceRecordList: [],
                        playRecords: [],
                        todayLearningTime: 0,
                        playRecordCount: 0,
                        listView: !1,
                        BGMPLayer: null
                    };
                },
                computed: {
                    userInfo: function() {
                        return this.$store.getters["common/getBaseInfo"];
                    },
                    playRecordsView: function() {
                        return this.listView ? this.playRecords : this.playRecords.slice(0, 3);
                    }
                },
                onShareAppMessage: function() {
                    return this.$onShareAppMessage({
                        path: "/pages/exercise/exercise"
                    });
                },
                onShow: function() {
                    console.log("onShow-exercise"), this.init();
                },
                onHide: function() {
                    this.$store.commit("voice/setVipDialog", !1);
                },
                methods: {
                    init: function() {
                        var e = this;
                        this.$utils.getUserOver().then(function(n) {
                            e.$store.dispatch("mine/fetchHomeInfo"), e.$store.dispatch("mine/fetchMyVip"), e.$store.dispatch("mine/fetchMyPrompt"), 
                            e.fetchPlayRecordList();
                        });
                    },
                    fetchPlayRecordList: function() {
                        var e = this;
                        this.$http(this.$APIS.getPlayRecordList, {
                            data: {
                                page: 1,
                                size: 20
                            }
                        }).then(function(n) {
                            1 == +n.code && (e.voiceRecordList = n.data.voiceRecordList, e.playRecords = n.data.playRecords, 
                            e.todayLearningTime = (0, s.secondToTimes)(n.data.todayLearningTime, 1));
                        });
                    },
                    newManual: function() {
                        this.$navTo.push({
                            name: "opinion",
                            query: {
                                url: "/meditation/manual"
                            }
                        });
                    },
                    clockIn: function() {
                        this.$refs.uniml2canvas.open();
                    },
                    findExercise: function() {
                        this.$navTo.goIndex({
                            avtive: 0
                        });
                    },
                    findVoice: function() {
                        this.$navTo.goIndex({
                            avtive: 2
                        });
                    },
                    getAudioSrc: function(n) {
                        return (0, r.default)(i.default.mark(function t() {
                            return i.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return n.vid || console.log("获取音频src, 没有vid", n), t.abrupt("return", new Promise(function(t, o) {
                                        var i = {
                                            vid: n.vid,
                                            useAudio: !0,
                                            callback: function(n) {
                                                console.log(n, "获取音频src成功"), n && n.src ? t(l(l({}, n), {}, {
                                                    src: n.src[0]
                                                })) : (e.showToast({
                                                    title: "获取音频src失败"
                                                }), o());
                                            }
                                        };
                                        polyv.getVideo(i);
                                    }));

                                  case 2:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    }
                }
            };
            n.default = f;
        }).call(this, t("543d").default);
    },
    1609: function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return i;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this, n = (e.$createElement, e._self._c, e.playRecords.length), t = n ? e.playRecords.length : null, o = e.voiceRecordList.length;
            e._isMounted || (e.e0 = e.$utils.getUser, e.e1 = e.$utils.getUser, e.e2 = function(n) {
                e.listView = !e.listView;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: n,
                    g1: t,
                    g2: o
                }
            });
        }, i = [];
    },
    "74e6": function(e, n, t) {},
    c9c0: function(e, n, t) {
        (function(e, n) {
            var o = t("4ea4");
            t("6f19"), o(t("66fd"));
            var i = o(t("e310"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(i.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    d2dc: function(e, n, t) {
        t.r(n);
        var o = t("0730"), i = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(c);
        n.default = i.a;
    },
    e310: function(e, n, t) {
        t.r(n);
        var o = t("1609"), i = t("d2dc");
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(c);
        t("feef");
        var r = t("f0c5"), a = Object(r.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = a.exports;
    },
    feef: function(e, n, t) {
        var o = t("74e6");
        t.n(o).a;
    }
}, [ [ "c9c0", "common/runtime", "common/vendor" ] ] ]);