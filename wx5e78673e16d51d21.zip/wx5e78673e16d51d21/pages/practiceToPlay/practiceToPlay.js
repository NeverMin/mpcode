(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/practiceToPlay/practiceToPlay" ], {
    "3e0d": function(e, i, t) {
        (function(e, i) {
            var n = t("4ea4");
            t("6f19"), n(t("66fd"));
            var o = n(t("c5e2"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, i(o.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    6576: function(e, i, t) {},
    "88e8": function(e, i, t) {
        t.d(i, "b", function() {
            return n;
        }), t.d(i, "c", function() {
            return o;
        }), t.d(i, "a", function() {});
        var n = function() {
            var e = this, i = (e.$createElement, e._self._c, e._f("secondToTime")(e.medi_mix_progress)), t = e._f("secondToTime")(e.medi_mix_duration);
            e._isMounted || (e.e0 = function(i) {
                e.confirmVisible = !0;
            }, e.e1 = function(i) {
                e.seekTime(-15), e.play();
            }, e.e2 = function(i) {
                e.seekTime(15), e.play();
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    f0: i,
                    f1: t
                }
            });
        }, o = [];
    },
    "9c4c": function(e, i, t) {
        (function(e) {
            var n = t("4ea4");
            Object.defineProperty(i, "__esModule", {
                value: !0
            }), i.default = void 0;
            var o = n(t("5ccf")), a = t("ebf2"), c = e.getSystemInfoSync().statusBarHeight + 44 + "px", d = {
                name: "practiceToPlay",
                mixins: [ o.default ],
                components: {
                    stepWrapper: function() {
                        t.e("components/meditation/step/stepWrapper").then(function() {
                            return resolve(t("8896"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    loadingIcon: function() {
                        t.e("components/meditation/playerBarLoading/playerBar-loading").then(function() {
                            return resolve(t("82f9"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    confirm: function() {
                        t.e("components/meditation/confirm/index").then(function() {
                            return resolve(t("6c73"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                data: function() {
                    return {
                        practiceCommentaryVisible: !1,
                        confirmVisible: !1,
                        headImg: t("5268"),
                        seekTimer: "",
                        meditatingId: "",
                        fromDetail: null,
                        wrapperTop: c
                    };
                },
                filters: {
                    secondToTime: a.secondToTime
                },
                computed: {
                    praticeStep: function() {
                        return this.medi_mix_mediInfo.practiceStep && "string" == typeof this.medi_mix_mediInfo.practiceStep ? JSON.parse(this.medi_mix_mediInfo.practiceStep) : [];
                    },
                    ifCurrentAudio: function() {
                        return this.medi_mix_mediInfo && this.medi_mix_mediInfo.id == this.meditatingId;
                    }
                },
                watch: {},
                onLoad: function(e) {
                    this.meditatingId = e.meditatingId, this.fromDetail = e.fromDetail;
                },
                onShareAppMessage: function(e) {
                    return this.$onShareAppMessage({
                        title: "我正在练习".concat(this.medi_mix_mediInfo.title, "冥想，超有用！推荐给你"),
                        path: "/pages/practiceDetail/practiceDetail?meditatingId=".concat(this.meditatingId)
                    });
                },
                mounted: function() {},
                methods: {
                    sliderChange: function(e) {
                        var i = this;
                        console.log("sliderChange", e.detail.value), this.medi_mix_seek(e.detail.value), 
                        this.$nextTick(function() {
                            i.play();
                        });
                    },
                    _initData: function() {
                        console.log(this.meditatingId, 0, this.fromDetail), this.medi_mix_initPlayer(this.meditatingId, 0, this.fromDetail);
                    },
                    play: function() {
                        console.log(this.medi_mix_playComplete, "是否完成"), this.medi_mix_playComplete ? this.medi_mix_replay() : this.medi_mix_play();
                    },
                    pause: function() {
                        this.medi_mix_pause();
                    },
                    toggleBgm: function() {
                        this.medi_mix_BGMtoggle();
                    },
                    dragStart: function() {
                        this.medi_mix_pause();
                    },
                    dragEnd: function() {
                        this.medi_mix_playing || this.medi_mix_play();
                    },
                    seekTime: function(e) {
                        e = (e = this.medi_mix_progress + e) >= this.medi_mix_duration ? this.medi_mix_duration : e, 
                        console.log("seek", e), this.medi_mix_seek(e);
                    },
                    seekToStep: function(e) {
                        this.medi_mix_play(e);
                    },
                    goBack: function() {
                        e.navigateBack();
                    },
                    goToIndex: function() {
                        this.p_mix_goTo({
                            name: "meditation",
                            query: {
                                channelId: this.channelId
                            }
                        });
                    },
                    stopEvent: function(e) {
                        e.preventDefault();
                    },
                    showPracticeCommentaryModal: function() {
                        this.practiceCommentaryVisible = !0;
                    },
                    closePracticeCommentaryModal: function() {
                        this.practiceCommentaryVisible = !1;
                    }
                }
            };
            i.default = d;
        }).call(this, t("543d").default);
    },
    "9d78": function(e, i, t) {
        t.r(i);
        var n = t("9c4c"), o = t.n(n);
        for (var a in n) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(i, e, function() {
                return n[e];
            });
        }(a);
        i.default = o.a;
    },
    c5e2: function(e, i, t) {
        t.r(i);
        var n = t("88e8"), o = t("9d78");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(i, e, function() {
                return o[e];
            });
        }(a);
        t("d2a8");
        var c = t("f0c5"), d = Object(c.a)(o.default, n.b, n.c, !1, null, "2c63c486", null, !1, n.a, void 0);
        i.default = d.exports;
    },
    d2a8: function(e, i, t) {
        var n = t("6576");
        t.n(n).a;
    }
}, [ [ "3e0d", "common/runtime", "common/vendor" ] ] ]);