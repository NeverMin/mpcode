(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/mine" ], {
    "08a8": function(n, e, t) {
        var o = t("a9c9");
        t.n(o).a;
    },
    "5c4e": function(n, e, t) {
        t.r(e);
        var o = t("65df"), i = t("b798");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return i[n];
            });
        }(a);
        t("08a8");
        var c = t("f0c5"), s = Object(c.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = s.exports;
    },
    "65df": function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return i;
        }), t.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c, this._isMounted || (this.e0 = this.$utils.getUser, this.e1 = this.$utils.getUser);
        }, i = [];
    },
    8645: function(n, e, t) {
        (function(n, e) {
            var o = t("4ea4");
            t("6f19"), o(t("66fd"));
            var i = o(t("5c4e"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(i.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    a9c9: function(n, e, t) {},
    b798: function(n, e, t) {
        t.r(e);
        var o = t("f567"), i = t.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        e.default = i.a;
    },
    f567: function(n, e, t) {
        (function(n) {
            var o = t("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = o(t("d177")), a = o(t("452e")), c = t("ebf2"), s = (t("2976"), {
                mixins: [ i.default, a.default ],
                components: {
                    goApp: function() {
                        t.e("components/common/goApp/index").then(function() {
                            return resolve(t("570c"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    uniml2canvas: function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/common/uniml2canvas/uniml2canvas") ]).then(function() {
                            return resolve(t("6384"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    uniBadge: function() {
                        t.e("components/common/uni-badge/uni-badge").then(function() {
                            return resolve(t("784b"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                data: function() {
                    return {
                        headImg: t("5268"),
                        otherInfo: {
                            isVip: 0
                        }
                    };
                },
                computed: {
                    wxUserInfo: function() {
                        return this.$store.getters["common/getBaseInfo"];
                    },
                    mediUserInfo: function() {
                        return this.$store.getters["mine/getMyVip"];
                    },
                    homeInfo: function() {
                        return this.$store.getters["mine/getHomeInfo"];
                    },
                    vipotherInfo: function() {
                        return this.$store.getters["mine/getVipotherInfo"];
                    },
                    myPrompt: function() {
                        return this.$store.getters["mine/getMyPrompt"];
                    }
                },
                mounted: function() {},
                destroyed: function() {},
                onShow: function() {
                    console.log("onShow-mine"), this.init();
                },
                onShareAppMessage: function(n) {
                    return this.$onShareAppMessage({
                        path: "/pages/mine/mine"
                    });
                },
                methods: {
                    init: function() {
                        var e = this;
                        this.$utils.getUserOver().then(function(t) {
                            e.$store.dispatch("mine/fetchHomeInfo"), e.$store.dispatch("mine/fetchVipotherInfo"), 
                            e.$store.dispatch("mine/fetchMyVip"), e.$store.dispatch("mine/fetchMyPrompt").then(function() {
                                n.hideTabBarRedDot({
                                    index: 2
                                });
                            });
                        });
                    },
                    linkToFullBack: function() {},
                    toRedeemCode: function() {
                        var n = this;
                        this.$utils.getUser().then(function() {
                            var e = getApp().globalData._sourceFlag, t = getApp().globalData.channelId;
                            n.$navTo.push({
                                name: "opinion",
                                data: {
                                    openUrl: encodeURIComponent("https://static".concat(c.ENV, ".xinli001.com/msite/index.html#/redeem-code?sourceFlag=").concat(e, "&channelId=").concat(t, "&sourceName=meditation&comeFrom=meditation"))
                                }
                            });
                        });
                    },
                    login: function() {},
                    clockIn: function() {
                        this.$refs.uniml2canvas.open();
                    },
                    goVip: function() {
                        var e = this, t = "ios" === getApp().globalData._platform, o = getApp().globalData.channelId, i = {};
                        this.$http({
                            url: this.$APIS.getActivityToo,
                            data: {
                                channelId: o
                            }
                        }).then(function(a) {
                            var c = a.code, s = a.data;
                            "1" === c && ((i = s.find(function(n) {
                                return 2 === n.type;
                            })).status ? t ? (n.navigateTo({
                                url: "/pages/task/task",
                                success: function(n) {
                                    console.log(n);
                                },
                                fail: function(n) {
                                    console.log(n);
                                }
                            }), setTimeout(function() {
                                n.showToast({
                                    title: "分享额外领取vip会员"
                                });
                            }, 1e3)) : e.$navTo.push({
                                name: "opinion",
                                data: {
                                    url: "/meditation/activity",
                                    activityId: i.activityId,
                                    channelId: o
                                }
                            }) : n.navigateTo({
                                url: "/pages/vip/vip",
                                success: function(n) {
                                    console.log(n);
                                },
                                fail: function(n) {
                                    console.log(n);
                                }
                            }));
                        });
                    },
                    goLevel: function() {
                        var n = this;
                        this.$utils.getUser().then(function() {
                            console.log(n.homeInfo), n.$navTo.push({
                                name: "opinion",
                                data: {
                                    url: "/meditation/myLevel",
                                    currentLv: n.homeInfo.currentLevel,
                                    nextLv: n.homeInfo.nextLevel,
                                    nextMin: n.homeInfo.nextLevelMinutes,
                                    nextDay: n.homeInfo.nextLevelDays,
                                    needMin: n.homeInfo.advanceNeedMinutes,
                                    needDay: n.homeInfo.advanceNeedDays
                                }
                            });
                        });
                    },
                    goEessage: function() {
                        var e = this;
                        this.$utils.getUser().then(function() {
                            n.navigateTo({
                                url: "/pages/opinion/opinion?url=/meditation/myMessages",
                                success: function(n) {
                                    e.$store.commit("mine/setMyPrompt", {}), console.log(n);
                                },
                                fail: function(n) {
                                    console.log(n);
                                }
                            });
                        });
                    },
                    goExercise: function() {
                        this.$utils.getUser().then(function() {
                            n.navigateTo({
                                url: "/pages/opinion/opinion?url=/meditation/myPractice",
                                success: function(n) {
                                    console.log(n);
                                },
                                fail: function(n) {
                                    console.log(n);
                                }
                            });
                        });
                    },
                    goTask: function() {
                        this.$utils.getUser().then(function() {
                            n.navigateTo({
                                url: "/pages/task/task"
                            });
                        });
                    }
                }
            });
            e.default = s;
        }).call(this, t("543d").default);
    }
}, [ [ "8645", "common/runtime", "common/vendor" ] ] ]);