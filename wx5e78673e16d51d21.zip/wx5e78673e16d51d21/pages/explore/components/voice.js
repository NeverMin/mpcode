(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/explore/components/voice" ], {
    "2e82": function(t, e, o) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = {
                components: {
                    listItem: function() {
                        o.e("components/voice/listItem").then(function() {
                            return resolve(o("c113"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                data: function() {
                    return {
                        scrollIntoView: "",
                        tabsAvitve: 0,
                        tabsList: [],
                        voiceList: []
                    };
                },
                created: function() {
                    this.voiceTags(), this.voiceTagList();
                },
                mounted: function() {
                    var e = t.createSelectorQuery().select(".tabs");
                    console.log(e), e.fields({
                        scrollOffset: !0
                    }, function(t) {
                        console.log(t);
                    }), console.log("data");
                },
                methods: {
                    scroll: function(t) {
                        this.scrolltolowerEnd || (console.log(t.detail.scrollTop), t.detail.scrollTop < this.name1 ? this.tabsAvitve = 0 : this.name1 < t.detail.scrollTop && t.detail.scrollTop < this.name2 ? this.tabsAvitve = 1 : t.detail.scrollTop > this.name2 && (this.tabsAvitve = 2));
                    },
                    scrolltolower: function() {
                        var t = this;
                        this.tabsAvitve = 3, this.scrolltolowerEnd = !0, setTimeout(function() {
                            t.scrolltolowerEnd = !1;
                        }, 200);
                    },
                    getDomOffset: function() {
                        var e = this;
                        setTimeout(function() {
                            [ "name1", "name2" ].forEach(function(o, n) {
                                var i = t.createSelectorQuery().in(e);
                                i.select("#" + o).boundingClientRect(), i.select("#wrapp").boundingClientRect(), 
                                i.selectViewport().scrollOffset(), i.exec(function(t) {
                                    console.log(t);
                                    var n = t[0].top - t[0].height - t[1].top + t[2].scrollTop;
                                    e[o] = n;
                                });
                            });
                        }, 200);
                    },
                    voiceTags: function() {
                        var t = this;
                        this.$http(this.$APIS.voiceTags).then(function(e) {
                            1 == +e.code && (t.tabsList = e.data);
                        });
                    },
                    voiceTagList: function() {
                        var t = this;
                        this.$http(this.$APIS.voiceTagList).then(function(e) {
                            1 == +e.code && (t.voiceList = e.data.voice_list, t.getDomOffset());
                        });
                    },
                    tabsClick: function(t) {
                        this.scrollIntoView = "name" + t, this.tabsAvitve !== t && (this.tabsAvitve = t);
                    }
                }
            };
            e.default = n;
        }).call(this, o("543d").default);
    },
    "5e70": function(t, e, o) {
        var n = o("ca5c");
        o.n(n).a;
    },
    "8ae0": function(t, e, o) {
        o.d(e, "b", function() {
            return n;
        }), o.d(e, "c", function() {
            return i;
        }), o.d(e, "a", function() {});
        var n = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    a263: function(t, e, o) {
        o.r(e);
        var n = o("2e82"), i = o.n(n);
        for (var c in n) [ "default" ].indexOf(c) < 0 && function(t) {
            o.d(e, t, function() {
                return n[t];
            });
        }(c);
        e.default = i.a;
    },
    ca5c: function(t, e, o) {},
    f533: function(t, e, o) {
        o.r(e);
        var n = o("8ae0"), i = o("a263");
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(t) {
            o.d(e, t, function() {
                return i[t];
            });
        }(c);
        o("5e70");
        var s = o("f0c5"), l = Object(s.a)(i.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        e.default = l.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "pages/explore/components/voice-create-component", {
    "pages/explore/components/voice-create-component": function(t, e, o) {
        o("543d").createComponent(o("f533"));
    }
}, [ [ "pages/explore/components/voice-create-component" ] ] ]);