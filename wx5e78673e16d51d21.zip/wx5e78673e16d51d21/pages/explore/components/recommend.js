(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/explore/components/recommend" ], {
    "23d9": function(t, e, n) {
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {});
        var i = function() {
            this.$createElement;
            var t = (this._self._c, this.filterBannerList.length), e = t > 0 ? this.filterBannerList.length : null, n = t > 0 && e > 1 ? this.filterBannerList.length : null, i = this.featuredList && this.featuredList.length > 0;
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    g1: e,
                    g2: n,
                    g3: i
                }
            });
        }, a = [];
    },
    "33f0": function(t, e, n) {
        n.r(e);
        var i = n("b644"), a = n.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        e.default = a.a;
    },
    "399e": function(t, e, n) {
        n.r(e);
        var i = n("23d9"), a = n("33f0");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        n("fb10");
        var c = n("f0c5"), r = Object(c.a)(a.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        e.default = r.exports;
    },
    "6dc1": function(t, e, n) {},
    b644: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = n("ebf2"), a = {
            components: {
                practiceOtherInfo: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/common/practiceOtherInfo") ]).then(function() {
                        return resolve(n("a3bf"));
                    }.bind(null, n)).catch(n.oe);
                },
                practiceInfo: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/common/practiceInfo/index") ]).then(function() {
                        return resolve(n("b06a"));
                    }.bind(null, n)).catch(n.oe);
                },
                listItem: function() {
                    n.e("components/voice/listItem").then(function() {
                        return resolve(n("c113"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            data: function() {
                return {
                    bannerList: [],
                    recommendMeditatingList: [],
                    freeMeditatings: [],
                    recommendVoiceList: [],
                    page: 0,
                    size: 10,
                    handpickListEnd: !1,
                    handpickListLoading: !1,
                    featuredList: []
                };
            },
            computed: {
                otherInfo: function() {
                    return this.$store.getters["mine/getMyVip"];
                },
                filterBannerList: function() {
                    var t = "ios" === getApp().globalData._platform;
                    return this.bannerList.filter(function(e) {
                        return (!e.attr.includes("activity") || !t) && i.businessDomain.some(function(t) {
                            return e.attr.includes(t);
                        });
                    });
                }
            },
            created: function() {
                var t = this;
                getApp().globalData.isSinglePage && (this.fetchBanner(), this.fetchIndexData(), 
                this.getFeaturedListData()), this.$utils.loginOver().then(function(e) {
                    t.fetchBanner(), t.fetchIndexData(), t.getFeaturedListData();
                });
            },
            onReachBottom: function() {
                console.log("触发了"), this.handpickListEnd || this.getFeaturedListData();
            },
            methods: {
                bannerTap: function(t) {
                    var e = this;
                    this.$utils.getUser().then(function() {
                        switch (+t.type) {
                          case 1:
                            e.$navTo.push({
                                name: "opinion",
                                data: {
                                    openUrl: encodeURIComponent(t.attr)
                                }
                            });
                            break;

                          case 2:
                            e.$navTo.push({
                                name: "vip"
                            });
                            break;

                          case 3:
                            e.$navTo.push({
                                name: "practiceDetail",
                                data: {
                                    meditatingId: t.value
                                }
                            });
                            break;

                          case 4:
                            e.$navTo.goIndex({
                                active: 0
                            });
                            break;

                          case 5:
                            e.$navTo.goIndex({
                                active: 1
                            });
                            break;

                          case 6:
                            e.$navTo.goIndex({
                                active: 2
                            });
                            break;

                          case 7:
                            e.$navTo.push({
                                name: "voicePlay",
                                data: {
                                    id: t.value
                                }
                            });
                        }
                    });
                },
                newBannerTap: function(t) {
                    var e = this, n = this.getUrlParams(t.attr);
                    this.$utils.getUser().then(function() {
                        t.attr.includes("practiceDetail") ? e.$navTo.push({
                            name: "practiceDetail",
                            data: {
                                meditatingId: n.meditatingId
                            }
                        }) : t.attr.includes("vip") ? e.$navTo.push({
                            name: "vip"
                        }) : e.$navTo.push({
                            name: "opinion",
                            data: {
                                openUrl: encodeURIComponent(t.attr)
                            }
                        });
                    });
                },
                goPracticeDetail: function(t) {
                    var e = this;
                    this.$utils.getUser().then(function() {
                        e.$navTo.push({
                            path: "/pages/practiceDetail/practiceDetail",
                            params: {
                                meditatingId: t.meditatingId
                            }
                        });
                    });
                },
                hardTitleTap: function(t) {
                    this.$emit("hardTitleTap", t);
                },
                featuredPractice: function() {},
                getFeaturedListData: function() {
                    var t = this;
                    this.handpickListLoading || this.handpickListEnd || (this.handpickListLoading = !0, 
                    this.$http({
                        url: this.$APIS.getFeaturedData,
                        data: {
                            "queryVo.page": ++this.page,
                            "queryVo.size": this.size
                        }
                    }).then(function(e) {
                        if ("1" === e.code) {
                            var n = e.data;
                            if (n && n.length) {
                                n.length < 10 && (t.handpickListEnd = !0), t.featuredList = t.featuredList.concat(n);
                                var i = {};
                                n.forEach(function(t, e) {
                                    i["ids[".concat(e, "]")] = t.id;
                                }), t.$http({
                                    url: t.$APIS.checkIsJoin,
                                    data: i
                                }).then(function(e) {
                                    if ("1" === e.code) {
                                        var i = e.data;
                                        n.forEach(function(e, a) {
                                            t.$set(n[a], "isJoin", i[a].isJoin), t.$set(n[a], "isShow", !0);
                                        });
                                    }
                                });
                            } else t.handpickListEnd = !0;
                        }
                    }).finally(function() {
                        t.handpickListLoading = !1, console.log("finally");
                    }));
                },
                fetchIndexData: function() {
                    var t = this;
                    this.$http({
                        url: this.$APIS.getIndexData
                    }).then(function(e) {
                        if (1 == +e.code) {
                            for (var n = e.data.recommendMeditatingList, i = 0; i < n.length; i++) {
                                var a = n[i].cover;
                                if (a.indexOf("@80") > 0) n[i].gaussianCover = a.replace(/@80/g, "?x-oss-process=image/resize,m_fill,h_45,w_150/blur,r_30,s_10"); else if (a.indexOf("?x-oss-process=image/quality,Q_80") > 0) {
                                    var o = a.indexOf("?x-oss-process=image/quality,Q_80");
                                    n[i].gaussianCover = a.substring(0, o) + "?x-oss-process=image/resize,m_fill,h_45,w_150/blur,r_30,s_10";
                                }
                            }
                            if (t.recommendMeditatingList = n, t.recommendMeditatingList.length) {
                                var c = {};
                                n.forEach(function(t, e) {
                                    c["ids[".concat(e, "]")] = t.id;
                                }), t.$http({
                                    url: t.$APIS.checkIsJoin,
                                    data: c
                                }).then(function(e) {
                                    if ("1" === e.code) {
                                        var i = e.data;
                                        n.forEach(function(e, a) {
                                            t.$set(n[a], "isJoin", i[a].isJoin);
                                        });
                                    }
                                });
                            }
                            t.freeMeditatings = e.data.freeMeditatingList, t.recommendVoiceList = e.data.recommendVoiceList.slice(0, 8);
                        }
                    }).catch(function(t) {
                        console.log(t);
                    });
                },
                fetchBanner: function() {
                    var t = this;
                    this.$http({
                        url: this.$APIS.getAdvertisingList,
                        data: {
                            "queryVo.advertisingType": 0,
                            "queryVo.channelType": 2
                        }
                    }).then(function(e) {
                        var n = e.code, i = e.data;
                        1 == +n && (t.bannerList = i.map(function(t) {
                            return console.log(t, "banner"), t;
                        }));
                    });
                },
                getUrlParams: function(t) {
                    for (var e = {}, n = t.split("?")[1].split("&"), i = 0, a = n.length; i < a; i++) {
                        var o = n[i].split("=");
                        e[o[0]] = o[1];
                    }
                    return e;
                }
            }
        };
        e.default = a;
    },
    fb10: function(t, e, n) {
        var i = n("6dc1");
        n.n(i).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "pages/explore/components/recommend-create-component", {
    "pages/explore/components/recommend-create-component": function(t, e, n) {
        n("543d").createComponent(n("399e"));
    }
}, [ [ "pages/explore/components/recommend-create-component" ] ] ]);