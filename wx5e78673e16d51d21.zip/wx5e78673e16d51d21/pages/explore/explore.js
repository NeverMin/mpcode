(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/explore/explore" ], {
    "0f94": function(e, t, n) {},
    "12ee": function(e, t, n) {
        (function(e, i) {
            var o = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = o(n("452e")), a = e.getSystemInfoSync().statusBarHeight + 44 + "px", c = {
                mixins: [ r.default ],
                components: {
                    voice: function() {
                        n.e("pages/explore/components/voice").then(function() {
                            return resolve(n("f533"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    recommend: function() {
                        Promise.all([ n.e("common/vendor"), n.e("pages/explore/components/recommend") ]).then(function() {
                            return resolve(n("399e"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    meditationList: function() {
                        n.e("pages/explore/components/meditationList").then(function() {
                            return resolve(n("ef30"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                static: {},
                data: function() {
                    return {
                        harderList: [ {
                            text: "推荐"
                        }, {
                            text: "冥想"
                        }, {
                            text: "声音"
                        } ],
                        harderTitleAvtive: 0,
                        scrollHeight: 520,
                        wrapperTop: a,
                        singlePage: !1
                    };
                },
                methods: {
                    searchPages: function() {
                        var e = this;
                        this.$utils.getUser().then(function() {
                            e.$navTo.push({
                                name: "opinion",
                                data: {
                                    url: "/meditation/practiceSearch"
                                }
                            });
                        });
                    },
                    hardTitleTap: function(e) {
                        e !== this.harderTitleAvtive && (this.harderTitleAvtive = e);
                    },
                    init: function() {
                        var e = this;
                        this.$utils.getUserOver().then(function(t) {
                            e.$store.dispatch("mine/fetchMyVip"), e.$store.dispatch("mine/fetchMyPrompt");
                        });
                    }
                },
                created: function() {},
                onLoad: function() {
                    i.showShareMenu({
                        withShareTicket: !0,
                        menus: [ "shareAppMessage", "shareTimeline" ]
                    }), console.log("onload");
                },
                onShow: function() {
                    var e = i.getLaunchOptionsSync();
                    this.singlePage = 1154 === e.scene, 1154 !== e.scene && this.init(), null != this.$store.getters["explore/getHarderTitleAvtive"] && (this.harderTitleAvtive = this.$store.getters["explore/getHarderTitleAvtive"], 
                    this.$store.commit("explore/setHarderTitleAvtive", null));
                },
                onHide: function() {
                    this.$store.commit("voice/setVipDialog", !1);
                },
                onShareAppMessage: function() {
                    return this.$onShareAppMessage();
                },
                onShareTimeline: function(e) {
                    return this.$onShareTimeLine();
                },
                onReady: function() {}
            };
            t.default = c;
        }).call(this, n("543d").default, n("bc2e").default);
    },
    5489: function(e, t, n) {
        (function(e, t) {
            var i = n("4ea4");
            n("6f19"), i(n("66fd"));
            var o = i(n("f5c6"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(o.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    9815: function(e, t, n) {
        n.r(t);
        var i = n("12ee"), o = n.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        t.default = o.a;
    },
    bff5: function(e, t, n) {
        var i = n("0f94");
        n.n(i).a;
    },
    c953: function(e, t, n) {
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var i = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    f5c6: function(e, t, n) {
        n.r(t);
        var i = n("c953"), o = n("9815");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        n("bff5");
        var a = n("f0c5"), c = Object(a.a)(o.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = c.exports;
    }
}, [ [ "5489", "common/runtime", "common/vendor" ] ] ]);