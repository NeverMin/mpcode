(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/opinion/opinion" ], {
    1842: function(e, t, n) {
        n.r(t);
        var o = n("47f8"), r = n("a819");
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(a);
        var l = n("f0c5"), c = Object(l.a)(r.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = c.exports;
    },
    2980: function(e, t, n) {
        (function(e, t) {
            var o = n("4ea4");
            n("6f19"), o(n("66fd"));
            var r = o(n("1842"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(r.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "47f8": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
    },
    a819: function(e, t, n) {
        n.r(t);
        var o = n("e158"), r = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = r.a;
    },
    e158: function(e, t, n) {
        (function(e) {
            var o = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = o(n("9523")), a = n("ebf2");
            function l(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function c(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? l(Object(n), !0).forEach(function(t) {
                        (0, r.default)(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : l(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            var i = {
                data: function() {
                    return {
                        url: "",
                        webviewStyles: {
                            progress: {
                                color: "#FF3333"
                            }
                        },
                        objShare: {}
                    };
                },
                onShareAppMessage: function() {
                    return this.$onShareAppMessage(this.objShare);
                },
                onLoad: function(t) {
                    this.objShare = {}, t.onShareAppMessagePath && (this.objShare.path = decodeURIComponent(t.onShareAppMessagePath), 
                    console.log("onShareAppMessagePath", this.onShareAppMessagePath), delete t.onShareAppMessagePath), 
                    t.onShareAppMessageTitle && (this.objShare.title = t.onShareAppMessageTitle, console.log("onShareAppMessageTitle", this.onShareAppMessageTitle), 
                    delete t.onShareAppMessageTitle);
                    var n = getApp().globalData._appSource, o = getApp().globalData.channelId, r = getApp().globalData.sessionKey;
                    if (t.openUrl) {
                        t.openUrl = decodeURIComponent(t.openUrl);
                        var l = t.openUrl.includes("?") ? "" : "?", i = t.openUrl.includes("channelId=") ? "" : "&channelId=".concat(o);
                        t.openUrl = t.openUrl + l + i + "&_appSource=".concat(n, "&miniProgramUid=").concat(r), 
                        console.log("openUrl", t.openUrl), this.url = t.openUrl;
                    } else {
                        var s = c(c({}, t), {}, {
                            _appSource: n,
                            miniProgramUid: r,
                            channelId: o
                        });
                        delete s.url;
                        var p = "?";
                        for (var u in s) p += u + "=" + s[u] + "&";
                        var f = t.origin || "https://medi".concat(a.ENV, ".onexinli.com");
                        console.log(f + t.url + p), this.url = f + t.url + p, console.log(this.url);
                    }
                    this.$store.getters["common/getPayStatus"] && (this.$store.commit("common/setPayStatus", !1), 
                    e.navigateBack({
                        delta: 1
                    }));
                }
            };
            t.default = i;
        }).call(this, n("543d").default);
    }
}, [ [ "2980", "common/runtime", "common/vendor" ] ] ]);