(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/voicePlay/voicePlay" ], {
    "335a": function(i, e, n) {
        n.r(e);
        var t = n("7b23"), o = n.n(t);
        for (var a in t) [ "default" ].indexOf(a) < 0 && function(i) {
            n.d(e, i, function() {
                return t[i];
            });
        }(a);
        e.default = o.a;
    },
    "7b23": function(i, e, n) {
        (function(i) {
            var t = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = t(n("5ccf")), a = n("ebf2"), c = {
                23: {
                    kuai: "https://lapp.xinli001.com/images/medi-wxapp/images/voice/asmrkuai.jpg",
                    guan: "https://lapp.xinli001.com/images/medi-wxapp/images/voice/asmrguan.jpg"
                },
                22: {
                    kuai: "https://lapp.xinli001.com/images/medi-wxapp/images/voice/shenghuokuai.jpg",
                    guan: "https://lapp.xinli001.com/images/medi-wxapp/images/voice/shenghuoguan.jpg"
                },
                21: {
                    kuai: "https://lapp.xinli001.com/images/medi-wxapp/images/voice/yinyuekuai.jpg",
                    guan: "https://lapp.xinli001.com/images/medi-wxapp/images/voice/yinyueguan.jpg"
                },
                20: {
                    kuai: "https://lapp.xinli001.com/images/medi-wxapp/images/voice/zirankuai.jpg",
                    guan: "https://lapp.xinli001.com/images/medi-wxapp/images/voice/ziranguan.jpg"
                }
            }, s = {
                mixins: [ o.default ],
                components: {
                    timing: function() {
                        n.e("pages/voicePlay/components/timing").then(function() {
                            return resolve(n("e9ac"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    uniPopup: function() {
                        n.e("components/common/uni-popup/uni-popup").then(function() {
                            return resolve(n("1ddb"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    voiceList: function() {
                        n.e("pages/voicePlay/components/voiceList").then(function() {
                            return resolve(n("a9ea"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    loadingIcon: function() {
                        n.e("components/meditation/playerBarLoading/playerBar-loading").then(function() {
                            return resolve(n("82f9"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    dialogBox: function() {
                        n.e("components/common/dialogBox").then(function() {
                            return resolve(n("ca9f"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        id: "",
                        bgList: c,
                        tabs: []
                    };
                },
                computed: {
                    pageBg: function() {
                        return this.bgList[this.medi_mix_voiceInfo.tagId] || {};
                    },
                    recordToTime: function() {
                        return (0, a.secondToTime)(this.medi_mix_record).split(":").map(function(i) {
                            return i.split("");
                        });
                    },
                    allPlayToTime: function() {
                        return this.medi_mix_allPlayTime ? (0, a.secondToTime)(this.medi_mix_allPlayTime).split(":") : [];
                    },
                    userOtherInfo: function() {
                        return this.$store.getters["mine/getMyVip"] || {};
                    }
                },
                onLoad: function(i) {
                    this.id = i.id;
                },
                created: function() {},
                onShow: function() {
                    var e = this;
                    getApp().globalData.userInfoSQ || i.getUserInfo({
                        provider: getApp().globalData._provider,
                        fail: function(i) {
                            e.$store.commit("common/setUserInfoDialog", !0);
                        }
                    }), this.$utils.getUserOver(!0).then(function() {
                        e.$store.dispatch("mine/fetchMyVip"), e.fetchMediVoiceInfo();
                    });
                },
                onHide: function() {
                    this.$store.commit("voice/setVipDialog", !1);
                },
                destroyed: function() {
                    this.medi_mix_getPlayer() && this.medi_mix_getPlayer().destory();
                },
                onShareAppMessage: function(i) {
                    return this.$onShareAppMessage({
                        title: "我正在听「".concat(this.medi_mix_voiceInfo.title, "」，很舒服！推荐给你！"),
                        path: "/pages/voicePlay/voicePlay?id=".concat(this.id)
                    });
                },
                mounted: function() {},
                methods: {
                    fetchMediVoiceInfo: function() {
                        var e = this;
                        this.$http({
                            url: this.$APIS.mediVoiceInfo,
                            data: {
                                id: this.id
                            }
                        }).then(function(n) {
                            (console.log(n), n.data.needVip && 1 !== e.userOtherInfo.isVip) && (e.$refs.isVip.open(), 
                            e.resetPlayer(), i.getBackgroundAudioManager().stop());
                        });
                    },
                    _initData: function() {
                        var i = this;
                        this.$utils.getUserOver().then(function() {
                            console.log("??", 0), i.medi_mix_initPlayer(i.id, 0);
                        });
                    },
                    goVip: function() {
                        this.$navTo.redirect({
                            name: "vip"
                        });
                    },
                    submitTimeOut: function(i) {
                        this.medi_mix_getPlayer().setOutTime(i);
                    },
                    pause: function() {
                        this.medi_mix_pause();
                    },
                    play: function() {
                        var i = this;
                        this.$utils.getUser().then(function() {
                            i.medi_mix_playComplete ? i.medi_mix_replay() : i.medi_mix_play();
                        });
                    },
                    end: function() {
                        var e = this;
                        this.$utils.getUser().then(function() {
                            i.showModal({
                                title: "确定要结束练习吗？",
                                cancelText: "结束练习",
                                confirmText: "再练一会",
                                success: function(i) {
                                    i.cancel && e.medi_mix_stop(0);
                                }
                            });
                        });
                    },
                    voiceItemTap: function(i) {},
                    voiceCover: function() {
                        var i = this;
                        this.$utils.getUser().then(function() {
                            i.$refs.popup.open();
                        });
                    },
                    timingOpen: function() {
                        var i = this;
                        this.$utils.getUser().then(function() {
                            i.$refs.timing.open();
                        });
                    },
                    voiceTags: function() {
                        var i = this;
                        this.$http({
                            url: this.$APIS.voiceTags
                        }).then(function(e) {
                            1 == +e.code && (i.tabs = e.data, i.$utils.sleep(200).then(function(i) {}));
                        });
                    }
                }
            };
            e.default = s;
        }).call(this, n("543d").default);
    },
    8058: function(i, e, n) {
        (function(i, e) {
            var t = n("4ea4");
            n("6f19"), t(n("66fd"));
            var o = t(n("8f2e"));
            i.__webpack_require_UNI_MP_PLUGIN__ = n, e(o.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "8f2e": function(i, e, n) {
        n.r(e);
        var t = n("c9e0"), o = n("335a");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(i) {
            n.d(e, i, function() {
                return o[i];
            });
        }(a);
        n("9e87");
        var c = n("f0c5"), s = Object(c.a)(o.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = s.exports;
    },
    "9e87": function(i, e, n) {
        var t = n("e44b");
        n.n(t).a;
    },
    c9e0: function(i, e, n) {
        n.d(e, "b", function() {
            return t;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {});
        var t = function() {
            var i = this;
            i.$createElement;
            i._self._c, i._isMounted || (i.e0 = function(e) {
                return i.$refs.popup.close();
            });
        }, o = [];
    },
    e44b: function(i, e, n) {}
}, [ [ "8058", "common/runtime", "common/vendor" ] ] ]);