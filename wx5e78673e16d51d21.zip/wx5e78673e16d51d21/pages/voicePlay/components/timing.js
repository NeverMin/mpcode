(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/voicePlay/components/timing" ], {
    "0e44": function(n, t, i) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = {
                props: [ "medi_mix_allPlayTime" ],
                data: function() {
                    return {
                        timeList: [ "5min", "10min", "15min", "20min", "25min", "30min", "45min", "60min", "90min", "120min", "180min", "无限" ],
                        current: 2,
                        visible: !1
                    };
                },
                methods: {
                    change: function(n) {
                        this.current = n.detail.current;
                    },
                    start: function() {
                        var t = this, i = parseInt(this.timeList[this.current]) ? parseInt(this.timeList[this.current]) : "无限";
                        n.showModal({
                            title: "是否要将定时设置成「".concat(i, "分钟」"),
                            content: "重新开始计时",
                            success: function(n) {
                                n.confirm && t.submit();
                            }
                        });
                    },
                    submit: function() {
                        this.cancel();
                        var n = parseInt(this.timeList[this.current]);
                        this.$emit("submitTimeOut", 60 * n);
                    },
                    open: function() {
                        var n = this;
                        this.visible = !0, this.medi_mix_allPlayTime ? this.current = this.timeList.findIndex(function(t, i) {
                            return n.medi_mix_allPlayTime / 60 === parseInt(t);
                        }) : this.current = this.timeList.length - 1, console.log(this.medi_mix_allPlayTime);
                    },
                    cancel: function() {
                        this.visible = !1;
                    }
                }
            };
            t.default = i;
        }).call(this, i("543d").default);
    },
    d176: function(n, t, i) {
        i.d(t, "b", function() {
            return e;
        }), i.d(t, "c", function() {
            return c;
        }), i.d(t, "a", function() {});
        var e = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    },
    deda: function(n, t, i) {},
    e3f5: function(n, t, i) {
        i.r(t);
        var e = i("0e44"), c = i.n(e);
        for (var a in e) [ "default" ].indexOf(a) < 0 && function(n) {
            i.d(t, n, function() {
                return e[n];
            });
        }(a);
        t.default = c.a;
    },
    e89e: function(n, t, i) {
        var e = i("deda");
        i.n(e).a;
    },
    e9ac: function(n, t, i) {
        i.r(t);
        var e = i("d176"), c = i("e3f5");
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(n) {
            i.d(t, n, function() {
                return c[n];
            });
        }(a);
        i("e89e");
        var o = i("f0c5"), s = Object(o.a)(c.default, e.b, e.c, !1, null, null, null, !1, e.a, void 0);
        t.default = s.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "pages/voicePlay/components/timing-create-component", {
    "pages/voicePlay/components/timing-create-component": function(n, t, i) {
        i("543d").createComponent(i("e9ac"));
    }
}, [ [ "pages/voicePlay/components/timing-create-component" ] ] ]);