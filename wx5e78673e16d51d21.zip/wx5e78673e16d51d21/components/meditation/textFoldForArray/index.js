(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/meditation/textFoldForArray/index" ], {
    1473: function(e, t, n) {
        n.r(t);
        var o = n("9d4d"), i = n("3f45");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        n("24c5");
        var r = n("f0c5"), l = Object(r.a)(i.default, o.b, o.c, !1, null, "057b2b54", null, !1, o.a, void 0);
        t.default = l.exports;
    },
    "24c5": function(e, t, n) {
        var o = n("f054");
        n.n(o).a;
    },
    "3f45": function(e, t, n) {
        n.r(t);
        var o = n("4ab7"), i = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = i.a;
    },
    "4ab7": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                data: function() {
                    return {
                        showUnfoldBtnObj: {},
                        unFoldObj: {}
                    };
                },
                props: {
                    rateId: {
                        type: [ String, Number ],
                        required: !0,
                        default: ""
                    },
                    text: {
                        type: String,
                        required: !0,
                        default: ""
                    },
                    line: {
                        type: Number,
                        required: !0,
                        default: 3
                    },
                    foldKey: {
                        required: !0,
                        default: ""
                    }
                },
                computed: {
                    ellipsisClass: function() {
                        return "ellipsis-" + this.line;
                    },
                    foldContentClass: function() {
                        return "fold-content-" + this.foldKey;
                    },
                    DPR: function() {
                        return getApp().globalData.systemInfo.pixelRatio || 1;
                    }
                },
                mounted: function() {
                    this.calcLineHeight();
                },
                methods: {
                    goToDetailPage: function() {
                        var e = this;
                        this.$utils.getUser().then(function() {
                            var t, n;
                            console.log(e.$store.getters["common/getCompleteShare"]), "practice" === e.$store.getters["common/getCompleteShare"].type && (t = encodeURIComponent("/pages/practiceDetail/practiceDetail?&meditatingId=".concat(e.$store.getters["common/getCompleteShare"].meditatingId)), 
                            n = "我正在练习".concat(e.$store.getters["common/getCompleteShare"].title, "冥想，超有用！推荐给你")), 
                            e.$navTo.push({
                                name: "opinion",
                                query: {
                                    url: "/meditation/feelingsItemPage",
                                    rateId: e.rateId,
                                    onShareAppMessagePath: t,
                                    onShareAppMessageTitle: n
                                }
                            });
                        });
                    },
                    getRem: function() {
                        return getApp().globalData.systemInfo.windowWidth / 375 * 16;
                    },
                    calcLineHeight: function() {
                        var t = this;
                        setTimeout(function() {
                            var n = ".fold-content-" + t.foldKey;
                            e.createSelectorQuery().in(t).select(n).boundingClientRect(function(e) {
                                e.height > 26 * t.line ? (t.$set(t.showUnfoldBtnObj, t.foldKey, !0), t.$set(t.unFoldObj, t.foldKey, !0)) : (t.$set(t.showUnfoldBtnObj, t.foldKey, !1), 
                                t.$set(t.unFoldObj, t.foldKey, !1));
                            }).exec();
                        }, 0);
                    },
                    handleFold: function(e) {
                        this.unFoldObj[e] = !this.unFoldObj[e];
                    }
                }
            };
            t.default = n;
        }).call(this, n("543d").default);
    },
    "9d4d": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    f054: function(e, t, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/meditation/textFoldForArray/index-create-component", {
    "components/meditation/textFoldForArray/index-create-component": function(e, t, n) {
        n("543d").createComponent(n("1473"));
    }
}, [ [ "components/meditation/textFoldForArray/index-create-component" ] ] ]);