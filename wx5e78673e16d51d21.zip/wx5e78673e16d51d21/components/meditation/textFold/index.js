(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/meditation/textFold/index" ], {
    "0e48": function(t, e, n) {
        var o = n("be4a");
        n.n(o).a;
    },
    "1bd5": function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return i;
        }), n.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    "22b5": function(t, e, n) {
        n.r(e);
        var o = n("95e3"), i = n.n(o);
        for (var l in o) [ "default" ].indexOf(l) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(l);
        e.default = i.a;
    },
    "95e3": function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = {
                data: function() {
                    return {
                        showUnfoldButton: !0,
                        unFold: !0,
                        foldText: "查看全部"
                    };
                },
                props: {
                    text: {
                        type: Array,
                        required: !0,
                        default: null
                    },
                    line: {
                        type: Number,
                        required: !0,
                        default: 3
                    }
                },
                computed: {
                    ellipsisClass: function() {
                        return "ellipsis-" + this.line;
                    }
                },
                mounted: function() {
                    this.calcLineHeight();
                },
                methods: {
                    getRem: function() {
                        return getApp().globalData.systemInfo.windowWidth / 375 * 16;
                    },
                    calcLineHeight: function() {
                        var e = this;
                        setTimeout(function() {
                            t.createSelectorQuery().in(e).select(".fold-content").boundingClientRect(function(t) {
                                var n = parseFloat(e.getRem()), o = 4 === e.line ? 5.25 : 4;
                                t.height > o * n ? (console.log("超过了".concat(e.line, "行")), e.showUnfoldButton = !0) : (console.log("没超过".concat(e.line, "行")), 
                                e.showUnfoldButton = !1);
                            }).exec();
                        }, 500);
                    },
                    handleFold: function() {
                        this.$emit("handleFold"), this.unFold = !this.unFold, this.unFold ? this.foldText = "查看全部" : this.foldText = "收起全部";
                    }
                }
            };
            e.default = n;
        }).call(this, n("543d").default);
    },
    a0e2: function(t, e, n) {
        n.r(e);
        var o = n("1bd5"), i = n("22b5");
        for (var l in i) [ "default" ].indexOf(l) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(l);
        n("0e48");
        var c = n("f0c5"), a = Object(c.a)(i.default, o.b, o.c, !1, null, "38595d2c", null, !1, o.a, void 0);
        e.default = a.exports;
    },
    be4a: function(t, e, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/meditation/textFold/index-create-component", {
    "components/meditation/textFold/index-create-component": function(t, e, n) {
        n("543d").createComponent(n("a0e2"));
    }
}, [ [ "components/meditation/textFold/index-create-component" ] ] ]);