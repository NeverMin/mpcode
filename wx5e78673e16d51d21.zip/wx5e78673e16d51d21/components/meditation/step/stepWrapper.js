(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/meditation/step/stepWrapper" ], {
    8896: function(e, t, n) {
        n.r(t);
        var i = n("9d0b"), r = n("b4b8");
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        n("dc5f");
        var a = n("f0c5"), c = Object(a.a)(r.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = c.exports;
    },
    "9d0b": function(e, t, n) {
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var i = function() {
            var e = this, t = (e.$createElement, e._self._c, e.countDownTime.min.length), n = e.countDownTime.min.length, i = n ? e.__map(e.countDownTime.min, function(t, n) {
                return {
                    $orig: e.__get_orig(t),
                    g2: e.countDownTime.min.length
                };
            }) : null, r = e.practiceStep.length;
            e.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    g1: n,
                    l0: i,
                    g3: r
                }
            });
        }, r = [];
    },
    b4b8: function(e, t, n) {
        n.r(t);
        var i = n("f644"), r = n.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(o);
        t.default = r.a;
    },
    dc5f: function(e, t, n) {
        var i = n("f0fe");
        n.n(i).a;
    },
    f0fe: function(e, t, n) {},
    f644: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = n("ebf2"), r = {
            name: "medi_play_stepWrapper",
            components: {
                step: function() {
                    n.e("components/meditation/step/step2").then(function() {
                        return resolve(n("f01f"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            props: {
                practiceStep: {
                    required: !0,
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                playTime: {
                    required: !0,
                    type: Number
                },
                playing: {
                    required: !0,
                    type: Boolean
                }
            },
            data: function() {
                return {
                    curStep: {}
                };
            },
            computed: {
                curPracticeStep: function() {
                    var e = {
                        index: 0,
                        startTime: "00:00.00",
                        duration: "0"
                    };
                    if (0 === this.practiceStep.length) return {};
                    for (var t = this.practiceStep.length - 1; t >= 0; t--) {
                        var n = this.practiceStep[t];
                        if (this.playTime >= (0, i.formatTimeToDuring)(n.startTime)) {
                            n.index = t, e = n, t = -1;
                            break;
                        }
                    }
                    return e;
                },
                countDownTime: function() {
                    var e = Number((0, i.formatTimeToDuring)(this.curPracticeStep.startTime) + this.curPracticeStep.duration / 1e3 - this.playTime);
                    e < 0 && (e = 0);
                    var t = (0, i.secondsFormat)(e, ":", ":", !1).split(":");
                    return {
                        min: 1 * t[0] > 0 ? t[0].split("") : [],
                        sec: t[1].split("")
                    };
                }
            },
            mounted: function() {},
            methods: {
                handleStepClick: function(e) {
                    this.$emit("seekToStep", (0, i.formatTimeToDuring)(e));
                }
            }
        };
        t.default = r;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/meditation/step/stepWrapper-create-component", {
    "components/meditation/step/stepWrapper-create-component": function(e, t, n) {
        n("543d").createComponent(n("8896"));
    }
}, [ [ "components/meditation/step/stepWrapper-create-component" ] ] ]);