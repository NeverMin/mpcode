(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/meditation/practiceFeelingsItem/index" ], {
    1290: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = {
                components: {
                    textFoldForArray: function() {
                        n.e("components/meditation/textFoldForArray/index").then(function() {
                            return resolve(n("1473"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                props: {
                    initData: {
                        type: Object,
                        required: !0,
                        default: function() {}
                    },
                    isInDetailPage: {
                        type: Boolean,
                        required: !1,
                        default: function() {
                            return !0;
                        }
                    },
                    practiceTitle: {
                        type: String,
                        required: !1,
                        default: function() {
                            return "";
                        }
                    }
                },
                data: function() {
                    return {
                        itemData: this.initData,
                        wrongImg: "https://lapp.xinli001.com/images/medi-wxapp/images/meditation/wrog-bg.png",
                        flag: !1
                    };
                },
                computed: {
                    completeType: function() {
                        return this.$store.getters["common/getCompleteShare"].type;
                    }
                },
                watch: {
                    initData: function(e) {
                        this.itemData = e;
                    }
                },
                methods: {
                    goToDetailPage: function(e) {
                        var t = this, n = e.id;
                        this.$utils.getUser().then(function() {
                            var e = {
                                url: "/meditation/feelingsItemPage",
                                rateId: n
                            };
                            "practice" === t.completeType && (e.onShareAppMessagePath = encodeURIComponent("/pages/practiceDetail/practiceDetail?meditatingId=".concat(t.$store.getters["common/getCompleteShare"].meditatingId)), 
                            e.onShareAppMessageTitle = "我正在练习".concat(t.$store.getters["common/getCompleteShare"].title, "冥想，超有用！推荐给你")), 
                            console.log(e), t.$navTo.push({
                                name: "opinion",
                                query: e
                            });
                        });
                    },
                    likeComment: function(e, t, n) {
                        var a = this;
                        this.$utils.getUser().then(function() {
                            if (!a.flag) {
                                var e;
                                a.flag = !0, e = "practice" === a.completeType ? "college_meditating" : "college_medi_voice";
                                var t = getApp().globalData.channelId, n = getApp().globalData._appSource, o = getApp().globalData._version;
                                a.$http({
                                    url: a.$APIS.fetchLikeComment + "?channelId=".concat(t, "&_appSource=").concat(n, "&_platform=").concat("", "&_version=").concat(o, "&objectName=").concat(e, "&rateId=").concat(a.itemData.id),
                                    method: "post",
                                    data: {
                                        objectName: e,
                                        rateId: a.itemData.id
                                    }
                                }).finally(function() {
                                    a.flag = !1;
                                }).then(function(e) {
                                    if ("1" === e.code) {
                                        var t = e.data.status, n = a.itemData.zanNum;
                                        a.itemData.isZan = t, a.itemData.zanNum = 1 === t ? n + 1 : n - 1;
                                    }
                                });
                            }
                        });
                    },
                    previewImage: function(t, n) {
                        var a = this, o = [];
                        t.forEach(function(e, t) {
                            var n = e.img ? e.img : a.wrongImg;
                            o.push(n);
                        }), e.previewImage({
                            current: n,
                            urls: o,
                            longPressActions: !0,
                            success: function(e) {
                                var t = e.index, n = e.tapindex;
                                console.log("成功预览", t, n);
                            },
                            fail: function(e) {
                                console.log("失败", e);
                            }
                        });
                    }
                }
            };
            t.default = a;
        }).call(this, n("543d").default);
    },
    "831d": function(e, t, n) {},
    cdfc: function(e, t, n) {
        var a = n("831d");
        n.n(a).a;
    },
    d88d: function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    e88e: function(e, t, n) {
        n.r(t);
        var a = n("d88d"), o = n("faaa");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        n("cdfc");
        var c = n("f0c5"), r = Object(c.a)(o.default, a.b, a.c, !1, null, "11bf2a9f", null, !1, a.a, void 0);
        t.default = r.exports;
    },
    faaa: function(e, t, n) {
        n.r(t);
        var a = n("1290"), o = n.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        t.default = o.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/meditation/practiceFeelingsItem/index-create-component", {
    "components/meditation/practiceFeelingsItem/index-create-component": function(e, t, n) {
        n("543d").createComponent(n("e88e"));
    }
}, [ [ "components/meditation/practiceFeelingsItem/index-create-component" ] ] ]);