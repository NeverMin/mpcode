(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/exercise/practiceCover/practiceCover" ], {
    "0d62": function(e, t, n) {
        var c = n("f446");
        n.n(c).a;
    },
    "50d8": function(e, t, n) {
        n.d(t, "b", function() {
            return c;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var c = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    8208: function(e, t, n) {
        n.r(t);
        var c = n("50d8"), o = n("aec4");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        n("0d62");
        var i = n("f0c5"), r = Object(i.a)(o.default, c.b, c.c, !1, null, null, null, !1, c.a, void 0);
        t.default = r.exports;
    },
    aec4: function(e, t, n) {
        n.r(t);
        var c = n("b5ef"), o = n.n(c);
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return c[e];
            });
        }(a);
        t.default = o.a;
    },
    b5ef: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var c = {
            components: {
                practiceOtherInfo: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/common/practiceOtherInfo") ]).then(function() {
                        return resolve(n("a3bf"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            props: {
                meditatingInfo: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                }
            },
            data: function() {
                return {
                    practiceWrongImg: "https://lapp.xinli001.com/images/medi-wxapp/images/practice-z-bg.png"
                };
            },
            created: function() {},
            methods: {
                startPractice: function(e) {
                    this.$http({
                        url: this.$APIS.fetchBeforePlay,
                        data: {
                            meditatingId: e,
                            flag: 1
                        }
                    }), this.openMusePlayPage({
                        meditatingId: e
                    });
                },
                openMusePlayPage: function(e) {
                    var t = e.meditatingId;
                    this.$navTo.push({
                        name: "practiceToPlay",
                        params: {
                            meditatingId: t
                        }
                    });
                },
                goToPracticeDetail: function(e) {
                    this.$navTo.push({
                        name: "practiceDetail",
                        query: {
                            meditatingId: e
                        }
                    });
                }
            }
        };
        t.default = c;
    },
    f446: function(e, t, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/exercise/practiceCover/practiceCover-create-component", {
    "components/exercise/practiceCover/practiceCover-create-component": function(e, t, n) {
        n("543d").createComponent(n("8208"));
    }
}, [ [ "components/exercise/practiceCover/practiceCover-create-component" ] ] ]);