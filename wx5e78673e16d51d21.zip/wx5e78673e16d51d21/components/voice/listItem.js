(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/voice/listItem" ], {
    66133: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = {
            props: {
                list: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                num: {
                    type: String | Number,
                    default: 4
                },
                play: {
                    type: Boolean,
                    default: !1
                },
                medi_mix_voiceId: {
                    type: String | Number,
                    default: ""
                },
                medi_mix_loading: {
                    type: Boolean | Number | String,
                    default: !1
                }
            },
            computed: {
                getMediUserInfo: function() {
                    return this.$store.getters["mine/getMyVip"] || {};
                },
                isVip: function() {
                    return this.getMediUserInfo.isVip;
                }
            },
            methods: {
                goVoicePlay: function(e) {
                    var t = this;
                    this.$utils.getUser().then(function() {
                        if (1 !== e.voiceInfo.isVip || 1 === t.isVip) {
                            if (e.voiceInfo.id) {
                                var n = getCurrentPages(), o = n[n.length - 1], i = {
                                    name: "voicePlay",
                                    data: {
                                        id: e.voiceInfo.id
                                    }
                                };
                                console.log("pages/voicePlay/voicePlay" === o.route), "pages/voicePlay/voicePlay" === o.route ? t.$navTo.redirect(i) : t.$navTo.push(i);
                            }
                        } else t.$store.commit("voice/setVipDialog", !0);
                    });
                }
            }
        };
        t.default = o;
    },
    "6d7b": function(e, t, n) {},
    "891a": function(e, t, n) {
        var o = n("6d7b");
        n.n(o).a;
    },
    "97fa": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    b559: function(e, t, n) {
        n.r(t);
        var o = n("66133"), i = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = i.a;
    },
    c113: function(e, t, n) {
        n.r(t);
        var o = n("97fa"), i = n("b559");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        n("891a");
        var c = n("f0c5"), r = Object(c.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = r.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/voice/listItem-create-component", {
    "components/voice/listItem-create-component": function(e, t, n) {
        n("543d").createComponent(n("c113"));
    }
}, [ [ "components/voice/listItem-create-component" ] ] ]);