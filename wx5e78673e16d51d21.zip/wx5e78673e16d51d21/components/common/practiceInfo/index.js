(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/common/practiceInfo/index" ], {
    "402b": function(e, t, n) {
        var o = n("5048");
        n.n(o).a;
    },
    "4b03": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            var e = (this._self._c, this.showButton && this.needBuyBtn ? this._f("toFixedTwo")(this.meditatingInfo.price) : null);
            this.$mp.data = Object.assign({}, {
                $root: {
                    f0: e
                }
            });
        }, i = [];
    },
    5048: function(e, t, n) {},
    a2c5: function(e, t, n) {
        n.r(t);
        var o = n("b5eb"), i = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = i.a;
    },
    b06a: function(e, t, n) {
        n.r(t);
        var o = n("4b03"), i = n("a2c5");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        n("402b");
        var a = n("f0c5"), c = Object(a.a)(i.default, o.b, o.c, !1, null, "16e3bbda", null, !1, o.a, void 0);
        t.default = c.exports;
    },
    b5eb: function(e, t, n) {
        var o = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = o(n("9523")), r = n("2976");
        function a(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var o = Object.getOwnPropertySymbols(e);
                t && (o = o.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, o);
            }
            return n;
        }
        function c(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? a(Object(n), !0).forEach(function(t) {
                    (0, i.default)(e, t, n[t]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                });
            }
            return e;
        }
        var s = {
            props: {
                meditatingInfo: {
                    type: Object,
                    required: !0,
                    default: function() {}
                },
                needBuyBtn: {
                    type: Boolean,
                    required: !1,
                    default: !1
                },
                needVipSituation: {
                    type: Boolean,
                    required: !1,
                    default: !0
                },
                sourceEntry: {
                    type: String,
                    required: !1,
                    default: ""
                },
                showButton: {
                    type: Boolean,
                    required: !1,
                    default: !0
                }
            },
            data: function() {
                return {
                    canclick: !0,
                    disCode: "",
                    practiceWrongImg: "https://lapp.xinli001.com/images/medi-wxapp/images/practice-z-bg.png",
                    isYixinliApp: !1,
                    isMuseApp: !1
                };
            },
            filters: {
                toFixedTwo: r.toFixedTwo
            },
            mounted: function() {},
            computed: {
                otherInfo: function() {
                    return this.$store.getters["mine/getMyVip"];
                },
                comePage: function() {
                    return "其他";
                },
                sourceNameCookie: function() {
                    return "";
                }
            },
            components: {
                practiceOtherInfo: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/common/practiceOtherInfo") ]).then(function() {
                        return resolve(n("a3bf"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            methods: {
                p_mix_goTo: function(e) {
                    var t = e.name, n = e.query, o = e.params;
                    this.routerToMediWithVersion({
                        name: t,
                        query: c({
                            channelId: this.channelId
                        }, n),
                        params: o
                    });
                },
                practiceToPlay: function(e, t, n) {
                    var o = "";
                    "首页" === this.comePage ? o = "首页-限时免费-练习" : "搜索页" === this.comePage && (o = "搜索页-练习"), 
                    this.$stat.send({
                        name: "冥想星球-交互行为",
                        properties: {
                            "业务": "参与练习",
                            "行为": "点击",
                            "对象": o,
                            "练习标题": t,
                            "练习分类": n,
                            "页面来源": this.comePage,
                            "运营跟踪标识": this.sourceNameCookie
                        }
                    }), fetchBeforePlay({
                        meditatingId: e,
                        flag: 1
                    }), this.openMusePlayPage({
                        meditatingId: e,
                        channelId: this.channelId
                    });
                },
                openMusePlayPage: function(e) {
                    var t = e.meditatingId, n = e.channelId;
                    console.log("practiceInfo this.$route", this.$route), localStorage.setItem("formRouteName", this.$route.name), 
                    localStorage.setItem("formRouteParams", JSON.stringify(this.$route.params)), localStorage.setItem("formRouteQuery", JSON.stringify(this.$route.query)), 
                    this.$platform.isYixinliApp && versionfunegt(this.$platform.yixinliAPPVersion, "5.8.2") || this.$platform.isMuseApp ? (getMediPlayer(t), 
                    this.$bridge.call("openMusePlayPage", {
                        meditatingId: t + ""
                    })) : this.routerToMediWithVersion({
                        name: "practiceToPlay",
                        params: {
                            meditatingId: t
                        },
                        query: {
                            channelId: n
                        }
                    });
                },
                goToPracticeDetail: function(e, t) {
                    var n = this;
                    this.$utils.getUser().then(function() {
                        n.$navTo.push({
                            name: "practiceDetail",
                            params: {
                                meditatingId: t.meditatingId
                            }
                        });
                    }).catch(function(e) {
                        console.log("未登录");
                    });
                },
                goToPracticeDetailPush: function(e) {
                    this.routerToMediWithVersion({
                        name: "practiceDetail",
                        query: {
                            channelId: this.channelId,
                            meditatingId: e
                        },
                        params: {
                            sourceEntry: this.sourceEntry
                        }
                    });
                }
            }
        };
        t.default = s;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/common/practiceInfo/index-create-component", {
    "components/common/practiceInfo/index-create-component": function(e, t, n) {
        n("543d").createComponent(n("b06a"));
    }
}, [ [ "components/common/practiceInfo/index-create-component" ] ] ]);