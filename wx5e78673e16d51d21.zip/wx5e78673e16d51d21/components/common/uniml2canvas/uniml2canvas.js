(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/common/uniml2canvas/uniml2canvas" ], {
    1104: function(n, t, e) {},
    3774: function(n, t, e) {
        (function(n) {
            var o = e("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = o(e("39e7")), i = (e("2976"), {
                props: {
                    showPageHeader: {
                        type: Boolean,
                        default: !1
                    }
                },
                components: {},
                data: function() {
                    return {
                        headImg: "/static/images/clockIn/user-head.png",
                        canvasImg: "",
                        visible: !1
                    };
                },
                computed: {
                    userInfo: function() {
                        return this.$store.getters["common/getBaseInfo"];
                    },
                    getWxUserInfo: function() {
                        return this.$store.getters["common/getWxUserInfo"];
                    },
                    homeInfo: function() {
                        return this.$store.getters["mine/getHomeInfo"];
                    }
                },
                mounted: function() {
                    var n = this;
                    this.$utils.getUserOver(!0).then(function(t) {
                        n.downloadFile();
                    });
                },
                methods: {
                    open: function() {
                        var n = this;
                        this.$utils.getUser().then(function() {
                            n.drawCanvas();
                        });
                    },
                    downloadFile: function() {
                        var t = this;
                        this.getWxUserInfo.avatarUrl ? n.downloadFile({
                            url: this.getWxUserInfo.avatarUrl,
                            success: function(n) {
                                t.headImg = n.tempFilePath;
                            },
                            fail: function(n) {
                                console.log(n), t.setTime(500, t.downloadFile);
                            }
                        }) : this.setTime(500, this.downloadFile);
                    },
                    setTime: function(n, t) {
                        setTimeout(t, n, this);
                    },
                    drawCanvas: function() {
                        this.canvasImg || n.showLoading({
                            title: "图片生成中"
                        }), this.visible = !0;
                        var t = this;
                        this.drawImage = new a.default({
                            obj: t,
                            width: 630,
                            height: 952,
                            element: "canvas-map",
                            background: "#fff",
                            progress: function(n) {},
                            finish: function(e) {
                                console.log(e), n.hideLoading(), t.canvasImg = e;
                            },
                            error: function(t) {
                                console.log(t), n.hideLoading(), n.showToast({
                                    title: "图片生成失败请重试"
                                });
                            }
                        }), this.drawImage.draw({
                            list: [ {
                                type: "wxml",
                                class: ".wrapper .draw",
                                limit: ".wrapper",
                                x: 0,
                                y: 0
                            } ]
                        });
                    },
                    cancel: function() {
                        this.visible = !1;
                    },
                    save: function() {
                        console.log("保存图片");
                        var t = this;
                        n.saveImageToPhotosAlbum({
                            filePath: this.canvasImg,
                            success: function() {
                                n.showToast({
                                    title: "图片保存成功"
                                }), t.cancel();
                            },
                            fail: function(t) {
                                n.showToast({
                                    title: t
                                });
                            }
                        });
                    }
                }
            });
            t.default = i;
        }).call(this, e("543d").default);
    },
    "46d4": function(n, t, e) {
        e.r(t);
        var o = e("3774"), a = e.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        t.default = a.a;
    },
    6384: function(n, t, e) {
        e.r(t);
        var o = e("d8c2"), a = e("46d4");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(i);
        e("fe65");
        var s = e("f0c5"), c = Object(s.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = c.exports;
    },
    d8c2: function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    fe65: function(n, t, e) {
        var o = e("1104");
        e.n(o).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/common/uniml2canvas/uniml2canvas-create-component", {
    "components/common/uniml2canvas/uniml2canvas-create-component": function(n, t, e) {
        e("543d").createComponent(e("6384"));
    }
}, [ [ "components/common/uniml2canvas/uniml2canvas-create-component" ] ] ]);