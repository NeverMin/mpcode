(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/common/bookPlayerBar/bookPlayerBar" ], {
    "1b7e": function(e, i, o) {},
    "2aad": function(e, i, o) {
        var n = o("4ea4");
        Object.defineProperty(i, "__esModule", {
            value: !0
        }), i.default = void 0;
        var a = n(o("5ccf")), t = o("ebf2"), m = {
            mixins: [ a.default ],
            props: {
                barBottom: {
                    type: String | Number,
                    default: 0
                }
            },
            data: function() {
                return {
                    isHide: !1,
                    canHideMask: !1,
                    confirmVisible: !1
                };
            },
            components: {
                loadingIcon: function() {
                    o.e("components/meditation/playerBarLoading/playerBar-loading").then(function() {
                        return resolve(o("82f9"));
                    }.bind(null, o)).catch(o.oe);
                },
                confirm: function() {
                    o.e("components/meditation/confirm/index").then(function() {
                        return resolve(o("6c73"));
                    }.bind(null, o)).catch(o.oe);
                }
            },
            filters: {
                secondToTime: t.secondToTime
            },
            mounted: function() {},
            computed: {
                showPlaybar: function() {
                    return this.medi_mix_player && !this.medi_mix_fullComplete;
                }
            },
            watch: {},
            methods: {
                togglePlay: function() {
                    this.medi_mix_playing ? this.medi_mix_pause() : this.medi_mix_play();
                },
                enterPlayerDetail: function() {
                    this.medi_mix_playComplete ? this.medi_mix_goMediComplete() : (console.log(this.medi_mix_player), 
                    "practice" === this.medi_mix_Type ? this.$navTo.push({
                        name: "practiceToPlay",
                        params: {
                            meditatingId: this.medi_mix_player.mediId
                        }
                    }) : this.$navTo.push({
                        name: "voicePlay",
                        params: {
                            id: this.medi_mix_player.mediId
                        }
                    }));
                },
                closePlayer: function() {
                    this.medi_mix_playComplete ? this.medi_mix_stop(0) : this.confirmVisible = !0;
                }
            }
        };
        i.default = m;
    },
    "4e7a": function(e, i, o) {
        o.d(i, "b", function() {
            return n;
        }), o.d(i, "c", function() {
            return a;
        }), o.d(i, "a", function() {});
        var n = function() {
            var e = this, i = (e.$createElement, e._self._c, e.showPlaybar && !e.medi_mix_playComplete && "practice" === e.medi_mix_Type ? e._f("secondToTime")(e.medi_mix_progress) : null), o = e.showPlaybar && !e.medi_mix_playComplete && "practice" === e.medi_mix_Type ? e._f("secondToTime")(e.medi_mix_duration) : null, n = e.showPlaybar && !e.medi_mix_playComplete && "practice" !== e.medi_mix_Type && "voice" === e.medi_mix_Type ? e._f("secondToTime")(e.medi_mix_record) : null, a = e.showPlaybar && !e.medi_mix_playComplete && "practice" !== e.medi_mix_Type && "voice" === e.medi_mix_Type && e.medi_mix_allPlayTime ? e._f("secondToTime")(e.medi_mix_allPlayTime) : null;
            e.$mp.data = Object.assign({}, {
                $root: {
                    f0: i,
                    f1: o,
                    f2: n,
                    f3: a
                }
            });
        }, a = [];
    },
    "6a65": function(e, i, o) {
        o.r(i);
        var n = o("4e7a"), a = o("d411");
        for (var t in a) [ "default" ].indexOf(t) < 0 && function(e) {
            o.d(i, e, function() {
                return a[e];
            });
        }(t);
        o("6c43");
        var m = o("f0c5"), c = Object(m.a)(a.default, n.b, n.c, !1, null, "b037cb88", null, !1, n.a, void 0);
        i.default = c.exports;
    },
    "6c43": function(e, i, o) {
        var n = o("1b7e");
        o.n(n).a;
    },
    d411: function(e, i, o) {
        o.r(i);
        var n = o("2aad"), a = o.n(n);
        for (var t in n) [ "default" ].indexOf(t) < 0 && function(e) {
            o.d(i, e, function() {
                return n[e];
            });
        }(t);
        i.default = a.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/common/bookPlayerBar/bookPlayerBar-create-component", {
    "components/common/bookPlayerBar/bookPlayerBar-create-component": function(e, i, o) {
        o("543d").createComponent(o("6a65"));
    }
}, [ [ "components/common/bookPlayerBar/bookPlayerBar-create-component" ] ] ]);