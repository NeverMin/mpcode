(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/common/goApp/index" ], {
    "570c": function(n, o, e) {
        e.r(o);
        var t = e("c1f0"), c = e("c535");
        for (var i in c) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(o, n, function() {
                return c[n];
            });
        }(i);
        e("9efb");
        var u = e("f0c5"), a = Object(u.a)(c.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        o.default = a.exports;
    },
    "90f8": function(n, o, e) {},
    "9efb": function(n, o, e) {
        var t = e("90f8");
        e.n(t).a;
    },
    c0d0: function(n, o, e) {
        Object.defineProperty(o, "__esModule", {
            value: !0
        }), o.default = void 0;
        var t = {
            components: {
                dialogBox: function() {
                    e.e("components/common/dialogBox").then(function() {
                        return resolve(e("ca9f"));
                    }.bind(null, e)).catch(e.oe);
                }
            },
            computed: {
                isAudit: function() {
                    return getApp().globalData.isAudit;
                }
            },
            data: function() {
                return {
                    visible: !1,
                    isGoApp: !1
                };
            },
            methods: {
                showDialog: function() {
                    this.$refs.dialogBox.open();
                }
            }
        };
        o.default = t;
    },
    c1f0: function(n, o, e) {
        e.d(o, "b", function() {
            return t;
        }), e.d(o, "c", function() {
            return c;
        }), e.d(o, "a", function() {});
        var t = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    },
    c535: function(n, o, e) {
        e.r(o);
        var t = e("c0d0"), c = e.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(o, n, function() {
                return t[n];
            });
        }(i);
        o.default = c.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/common/goApp/index-create-component", {
    "components/common/goApp/index-create-component": function(n, o, e) {
        e("543d").createComponent(e("570c"));
    }
}, [ [ "components/common/goApp/index-create-component" ] ] ]);