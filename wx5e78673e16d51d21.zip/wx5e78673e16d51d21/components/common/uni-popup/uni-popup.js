(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/common/uni-popup/uni-popup" ], {
    "1ddb": function(t, n, o) {
        o.r(n);
        var e = o("6783"), i = o("d4e0");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(t) {
            o.d(n, t, function() {
                return i[t];
            });
        }(a);
        o("9f47");
        var s = o("f0c5"), c = Object(s.a)(i.default, e.b, e.c, !1, null, "182cade8", null, !1, e.a, void 0);
        n.default = c.exports;
    },
    6783: function(t, n, o) {
        o.d(n, "b", function() {
            return e;
        }), o.d(n, "c", function() {
            return i;
        }), o.d(n, "a", function() {});
        var e = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    "7ddf": function(t, n, o) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var e = {
            name: "UniPopup",
            components: {
                uniTransition: function() {
                    o.e("components/common/uni-transition/uni-transition").then(function() {
                        return resolve(o("7de3"));
                    }.bind(null, o)).catch(o.oe);
                }
            },
            props: {
                animation: {
                    type: Boolean,
                    default: !0
                },
                type: {
                    type: String,
                    default: "center"
                },
                maskClick: {
                    type: Boolean,
                    default: !0
                }
            },
            data: function() {
                return {
                    duration: 300,
                    ani: [],
                    showPopup: !1,
                    showTrans: !1,
                    maskClass: {
                        position: "fixed",
                        bottom: 0,
                        top: 0,
                        left: 0,
                        right: 0,
                        backgroundColor: "rgba(0, 0, 0, 0.4)"
                    },
                    transClass: {
                        position: "fixed",
                        left: 0,
                        right: 0
                    }
                };
            },
            watch: {
                type: {
                    handler: function(t) {
                        switch (this.type) {
                          case "top":
                            this.ani = [ "slide-top" ], this.transClass = {
                                position: "fixed",
                                left: 0,
                                right: 0
                            };
                            break;

                          case "bottom":
                            this.ani = [ "slide-bottom" ], this.transClass = {
                                position: "fixed",
                                left: 0,
                                right: 0,
                                bottom: 0
                            };
                            break;

                          case "center":
                            this.ani = [ "zoom-out", "fade" ], this.transClass = {
                                position: "fixed",
                                display: "flex",
                                flexDirection: "column",
                                bottom: 0,
                                left: 0,
                                right: 0,
                                top: 0,
                                justifyContent: "center",
                                alignItems: "center"
                            };
                        }
                    },
                    immediate: !0
                }
            },
            created: function() {
                this.animation ? this.duration = 300 : this.duration = 0;
            },
            methods: {
                clear: function(t) {
                    t.stopPropagation();
                },
                open: function() {
                    var t = this;
                    this.showPopup = !0, this.$nextTick(function() {
                        clearTimeout(t.timer), t.timer = setTimeout(function() {
                            t.showTrans = !0;
                        }, 50);
                    }), this.$emit("change", {
                        show: !0
                    });
                },
                close: function(t) {
                    var n = this;
                    this.showTrans = !1, this.$nextTick(function() {
                        clearTimeout(n.timer), n.timer = setTimeout(function() {
                            n.$emit("change", {
                                show: !1
                            }), n.showPopup = !1;
                        }, 300);
                    });
                },
                onTap: function() {
                    this.maskClick && this.close();
                }
            }
        };
        n.default = e;
    },
    "9f47": function(t, n, o) {
        var e = o("eacd");
        o.n(e).a;
    },
    d4e0: function(t, n, o) {
        o.r(n);
        var e = o("7ddf"), i = o.n(e);
        for (var a in e) [ "default" ].indexOf(a) < 0 && function(t) {
            o.d(n, t, function() {
                return e[t];
            });
        }(a);
        n.default = i.a;
    },
    eacd: function(t, n, o) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/common/uni-popup/uni-popup-create-component", {
    "components/common/uni-popup/uni-popup-create-component": function(t, n, o) {
        o("543d").createComponent(o("1ddb"));
    }
}, [ [ "components/common/uni-popup/uni-popup-create-component" ] ] ]);