(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/common/uni-badge/uni-badge" ], {
    "4e09": function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = {
            name: "UniBadge",
            props: {
                type: {
                    type: String,
                    default: "default"
                },
                inverted: {
                    type: Boolean,
                    default: !1
                },
                text: {
                    type: [ String, Number ],
                    default: ""
                },
                size: {
                    type: String,
                    default: "normal"
                }
            },
            data: function() {
                return {
                    badgeStyle: ""
                };
            },
            watch: {
                text: function() {
                    this.setStyle();
                }
            },
            mounted: function() {
                this.setStyle();
            },
            methods: {
                setStyle: function() {
                    this.badgeStyle = "width: ".concat(8 * String(this.text).length + 12, "px");
                },
                onClick: function() {
                    this.$emit("click");
                }
            }
        };
        e.default = o;
    },
    "58a7": function(n, e, t) {},
    "784b": function(n, e, t) {
        t.r(e);
        var o = t("7d8c"), a = t("ded7");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(c);
        t("9b29");
        var i = t("f0c5"), u = Object(i.a)(a.default, o.b, o.c, !1, null, "6a0beb5d", null, !1, o.a, void 0);
        e.default = u.exports;
    },
    "7d8c": function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return a;
        }), t.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    "9b29": function(n, e, t) {
        var o = t("58a7");
        t.n(o).a;
    },
    ded7: function(n, e, t) {
        t.r(e);
        var o = t("4e09"), a = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        e.default = a.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/common/uni-badge/uni-badge-create-component", {
    "components/common/uni-badge/uni-badge-create-component": function(n, e, t) {
        t("543d").createComponent(t("784b"));
    }
}, [ [ "components/common/uni-badge/uni-badge-create-component" ] ] ]);