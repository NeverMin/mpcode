(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/common/pageHeader/index" ], {
    4776: function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = {
                components: {
                    uniStatusBar: function() {
                        t.e("components/common/uni-status-bar/uni-status-bar").then(function() {
                            return resolve(t("f9de"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                props: {
                    hiedBtn: {
                        type: Boolean,
                        default: !1
                    },
                    icon: {
                        type: String,
                        default: "icon-m-right"
                    },
                    title: {
                        type: String,
                        default: ""
                    },
                    notGoback: {
                        type: Boolean,
                        default: !1
                    }
                },
                methods: {
                    back: function() {
                        (this.$emit("goback"), this.notGoback) || (getCurrentPages().length > 1 ? n.navigateBack() : this.$navTo.goIndex());
                    }
                }
            };
            e.default = o;
        }).call(this, t("543d").default);
    },
    "66b3": function(n, e, t) {
        var o = t("caa6");
        t.n(o).a;
    },
    "6bed": function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return a;
        }), t.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    b2bc: function(n, e, t) {
        t.r(e);
        var o = t("4776"), a = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        e.default = a.a;
    },
    caa6: function(n, e, t) {},
    d179: function(n, e, t) {
        t.r(e);
        var o = t("6bed"), a = t("b2bc");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(c);
        t("66b3");
        var u = t("f0c5"), i = Object(u.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = i.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/common/pageHeader/index-create-component", {
    "components/common/pageHeader/index-create-component": function(n, e, t) {
        t("543d").createComponent(t("d179"));
    }
}, [ [ "components/common/pageHeader/index-create-component" ] ] ]);