require("../@babel/runtime/helpers/Arrayincludes");

var _typeof3 = require("../@babel/runtime/helpers/typeof");

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/vendor" ], {
    "01d0": function(t, e, n) {
        var r, i = this && this.__extends || (r = function(t, e) {
            return (r = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function(t, e) {
                t.__proto__ = e;
            } || function(t, e) {
                for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            })(t, e);
        }, function(t, e) {
            if ("function" != typeof e && null !== e) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
            function n() {
                this.constructor = t;
            }
            r(t, e), t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, 
            new n());
        }), o = this && this.__assign || function() {
            return (o = Object.assign || function(t) {
                for (var e, n = 1, r = arguments.length; n < r; n++) for (var i in e = arguments[n]) Object.prototype.hasOwnProperty.call(e, i) && (t[i] = e[i]);
                return t;
            }).apply(this, arguments);
        };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.cloneNode = e.hasChildren = e.isDocument = e.isDirective = e.isComment = e.isText = e.isCDATA = e.isTag = e.Element = e.Document = e.NodeWithChildren = e.ProcessingInstruction = e.Comment = e.Text = e.DataNode = e.Node = void 0;
        var a = n("6403"), s = new Map([ [ a.ElementType.Tag, 1 ], [ a.ElementType.Script, 1 ], [ a.ElementType.Style, 1 ], [ a.ElementType.Directive, 1 ], [ a.ElementType.Text, 3 ], [ a.ElementType.CDATA, 4 ], [ a.ElementType.Comment, 8 ], [ a.ElementType.Root, 9 ] ]), u = function() {
            function t(t) {
                this.type = t, this.parent = null, this.prev = null, this.next = null, this.startIndex = null, 
                this.endIndex = null;
            }
            return Object.defineProperty(t.prototype, "nodeType", {
                get: function() {
                    var t;
                    return null !== (t = s.get(this.type)) && void 0 !== t ? t : 1;
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(t.prototype, "parentNode", {
                get: function() {
                    return this.parent;
                },
                set: function(t) {
                    this.parent = t;
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(t.prototype, "previousSibling", {
                get: function() {
                    return this.prev;
                },
                set: function(t) {
                    this.prev = t;
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(t.prototype, "nextSibling", {
                get: function() {
                    return this.next;
                },
                set: function(t) {
                    this.next = t;
                },
                enumerable: !1,
                configurable: !0
            }), t.prototype.cloneNode = function(t) {
                return void 0 === t && (t = !1), x(this, t);
            }, t;
        }();
        e.Node = u;
        var c = function(t) {
            function e(e, n) {
                var r = t.call(this, e) || this;
                return r.data = n, r;
            }
            return i(e, t), Object.defineProperty(e.prototype, "nodeValue", {
                get: function() {
                    return this.data;
                },
                set: function(t) {
                    this.data = t;
                },
                enumerable: !1,
                configurable: !0
            }), e;
        }(u);
        e.DataNode = c;
        var l = function(t) {
            function e(e) {
                return t.call(this, a.ElementType.Text, e) || this;
            }
            return i(e, t), e;
        }(c);
        e.Text = l;
        var f = function(t) {
            function e(e) {
                return t.call(this, a.ElementType.Comment, e) || this;
            }
            return i(e, t), e;
        }(c);
        e.Comment = f;
        var d = function(t) {
            function e(e, n) {
                var r = t.call(this, a.ElementType.Directive, n) || this;
                return r.name = e, r;
            }
            return i(e, t), e;
        }(c);
        e.ProcessingInstruction = d;
        var h = function(t) {
            function e(e, n) {
                var r = t.call(this, e) || this;
                return r.children = n, r;
            }
            return i(e, t), Object.defineProperty(e.prototype, "firstChild", {
                get: function() {
                    var t;
                    return null !== (t = this.children[0]) && void 0 !== t ? t : null;
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "lastChild", {
                get: function() {
                    return this.children.length > 0 ? this.children[this.children.length - 1] : null;
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "childNodes", {
                get: function() {
                    return this.children;
                },
                set: function(t) {
                    this.children = t;
                },
                enumerable: !1,
                configurable: !0
            }), e;
        }(u);
        e.NodeWithChildren = h;
        var p = function(t) {
            function e(e) {
                return t.call(this, a.ElementType.Root, e) || this;
            }
            return i(e, t), e;
        }(h);
        e.Document = p;
        var _ = function(t) {
            function e(e, n, r, i) {
                void 0 === r && (r = []), void 0 === i && (i = "script" === e ? a.ElementType.Script : "style" === e ? a.ElementType.Style : a.ElementType.Tag);
                var o = t.call(this, i, r) || this;
                return o.name = e, o.attribs = n, o;
            }
            return i(e, t), Object.defineProperty(e.prototype, "tagName", {
                get: function() {
                    return this.name;
                },
                set: function(t) {
                    this.name = t;
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "attributes", {
                get: function() {
                    var t = this;
                    return Object.keys(this.attribs).map(function(e) {
                        var n, r;
                        return {
                            name: e,
                            value: t.attribs[e],
                            namespace: null === (n = t["x-attribsNamespace"]) || void 0 === n ? void 0 : n[e],
                            prefix: null === (r = t["x-attribsPrefix"]) || void 0 === r ? void 0 : r[e]
                        };
                    });
                },
                enumerable: !1,
                configurable: !0
            }), e;
        }(h);
        function m(t) {
            return (0, a.isTag)(t);
        }
        function y(t) {
            return t.type === a.ElementType.CDATA;
        }
        function g(t) {
            return t.type === a.ElementType.Text;
        }
        function v(t) {
            return t.type === a.ElementType.Comment;
        }
        function b(t) {
            return t.type === a.ElementType.Directive;
        }
        function w(t) {
            return t.type === a.ElementType.Root;
        }
        function x(t, e) {
            var n;
            if (void 0 === e && (e = !1), g(t)) n = new l(t.data); else if (v(t)) n = new f(t.data); else if (m(t)) {
                var r = e ? A(t.children) : [], i = new _(t.name, o({}, t.attribs), r);
                r.forEach(function(t) {
                    return t.parent = i;
                }), null != t.namespace && (i.namespace = t.namespace), t["x-attribsNamespace"] && (i["x-attribsNamespace"] = o({}, t["x-attribsNamespace"])), 
                t["x-attribsPrefix"] && (i["x-attribsPrefix"] = o({}, t["x-attribsPrefix"])), n = i;
            } else if (y(t)) {
                r = e ? A(t.children) : [];
                var s = new h(a.ElementType.CDATA, r);
                r.forEach(function(t) {
                    return t.parent = s;
                }), n = s;
            } else if (w(t)) {
                r = e ? A(t.children) : [];
                var u = new p(r);
                r.forEach(function(t) {
                    return t.parent = u;
                }), t["x-mode"] && (u["x-mode"] = t["x-mode"]), n = u;
            } else {
                if (!b(t)) throw new Error("Not implemented yet: ".concat(t.type));
                var c = new d(t.name, t.data);
                null != t["x-name"] && (c["x-name"] = t["x-name"], c["x-publicId"] = t["x-publicId"], 
                c["x-systemId"] = t["x-systemId"]), n = c;
            }
            return n.startIndex = t.startIndex, n.endIndex = t.endIndex, null != t.sourceCodeLocation && (n.sourceCodeLocation = t.sourceCodeLocation), 
            n;
        }
        function A(t) {
            for (var e = t.map(function(t) {
                return x(t, !0);
            }), n = 1; n < e.length; n++) e[n].prev = e[n - 1], e[n - 1].next = e[n];
            return e;
        }
        e.Element = _, e.isTag = m, e.isCDATA = y, e.isText = g, e.isComment = v, e.isDirective = b, 
        e.isDocument = w, e.hasChildren = function(t) {
            return Object.prototype.hasOwnProperty.call(t, "children");
        }, e.cloneNode = x;
    },
    "0475": function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        e.default = function(t) {
            var e, n, r, i, o, a, s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", u = "", c = 0;
            for (t = t.replace(/[^A-Za-z0-9\+\/\=]/g, ""); c < t.length; ) e = s.indexOf(t.charAt(c++)) << 2 | (i = s.indexOf(t.charAt(c++))) >> 4, 
            n = (15 & i) << 4 | (o = s.indexOf(t.charAt(c++))) >> 2, r = (3 & o) << 6 | (a = s.indexOf(t.charAt(c++))), 
            u += String.fromCharCode(e), 64 != o && (u += String.fromCharCode(n)), 64 != a && (u += String.fromCharCode(r));
            return function(t) {
                for (var e = "", n = 0, r = 0, i = 0, o = 0; n < t.length; ) (r = t.charCodeAt(n)) < 128 ? (e += String.fromCharCode(r), 
                n++) : r > 191 && r < 224 ? (i = t.charCodeAt(n + 1), e += String.fromCharCode((31 & r) << 6 | 63 & i), 
                n += 2) : (i = t.charCodeAt(n + 1), o = t.charCodeAt(n + 2), e += String.fromCharCode((15 & r) << 12 | (63 & i) << 6 | 63 & o), 
                n += 3);
                return e;
            }(u);
        };
    },
    "0676": function(t, e) {
        t.exports = function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    "06e8": function(t, e, n) {
        (function(t) {
            var r = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = r(n("2eee")), o = r(n("9523")), a = r(n("c973")), s = r(n("970b")), u = r(n("5bc3")), c = r(n("6e5b"));
            function l(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function f(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? l(Object(n), !0).forEach(function(e) {
                        (0, o.default)(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : l(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            var d = function() {
                function e() {
                    (0, s.default)(this, e), console.log("create voicePolyvPlayer"), this.loading = 1, 
                    this.progress = 0, this.duration = 0, this.record = 0, this.allPlayTime = 900, this.playing = 0, 
                    this.playComplete = 0, this.forceStop = !1, this.startTimeStr = "", this.MainPlayer = null, 
                    this.progeressTimer = null, this.loopPlay = !1, this.MainPolyvConfig = null, this.userPlay = !1, 
                    this.progressHandler = null;
                }
                return (0, u.default)(e, [ {
                    key: "setOutTime",
                    value: function(t) {
                        this.record = 0, console.log("时间设置", t), this.allPlayTime = t;
                    }
                }, {
                    key: "getAudioSrc",
                    value: function() {
                        var e = (0, a.default)(i.default.mark(function e(n) {
                            return i.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return n.vid || console.log("获取音频src, 没有vid", n), e.abrupt("return", new Promise(function(e, r) {
                                        var i = {
                                            vid: n.vid,
                                            useAudio: !0,
                                            callback: function(n) {
                                                console.log(n, "获取音频src成功"), n && n.src ? e(f(f({}, n), {}, {
                                                    src: n.src[0]
                                                })) : (t.showToast({
                                                    title: "获取音频src失败"
                                                }), r());
                                            }
                                        };
                                        c.default.getVideo(i);
                                    }));

                                  case 2:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }));
                        return function(t) {
                            return e.apply(this, arguments);
                        };
                    }()
                }, {
                    key: "initPay",
                    value: function() {
                        this.playing = 1, this.record = 0, this.playComplete = 0, this.startProgress();
                    }
                }, {
                    key: "replay",
                    value: function() {
                        this.record = 0, this.play();
                    }
                }, {
                    key: "initMainPlayer",
                    value: function() {
                        var t = (0, a.default)(i.default.mark(function t() {
                            var e, n = this, r = arguments;
                            return i.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return (e = r.length > 0 && void 0 !== r[0] ? r[0] : this.MainPolyvConfig) && (this.MainPolyvConfig = e), 
                                    t.abrupt("return", new Promise(function(t) {
                                        n.setMainPlayer(e).then(function() {
                                            console.log("初始化setMainPlayer回调"), n.initPay(), (e.autoplay || n.userPlay) && (n.startTimeStr = n.getCurTime()), 
                                            t();
                                        });
                                    }));

                                  case 3:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        return function() {
                            return t.apply(this, arguments);
                        };
                    }()
                }, {
                    key: "getCurTime",
                    value: function() {
                        var t = new Date();
                        return "".concat(t.getFullYear(), "-").concat((t.getMonth() + 1 + "").padStart(2, "0"), "-").concat(t.getDate(), " ").concat(String(t.getHours()).padStart(2, "0"), ":").concat(String(t.getMinutes()).padStart(2, "0"), ":").concat(String(t.getSeconds()).padStart(2, "0"));
                    }
                }, {
                    key: "changeVid",
                    value: function() {
                        var t = (0, a.default)(i.default.mark(function t(e) {
                            var n = this;
                            return i.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    this.MainPolyvConfig = e, this.setMainPlayer({
                                        vid: e.vid
                                    }).then(function(t) {
                                        n.initPay();
                                    });

                                  case 2:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        return function(e) {
                            return t.apply(this, arguments);
                        };
                    }()
                }, {
                    key: "setMainPlayer",
                    value: function(e) {
                        var n = this;
                        return new Promise(function() {
                            var r = (0, a.default)(i.default.mark(function r(o, a) {
                                var s, u, c;
                                return i.default.wrap(function(r) {
                                    for (;;) switch (r.prev = r.next) {
                                      case 0:
                                        return r.next = 2, n.getAudioSrc(e);

                                      case 2:
                                        s = r.sent, u = s.src, c = s.duration, n.MainPlayer || (n.MainPlayer = t.getBackgroundAudioManager()), 
                                        console.log(n.MainPolyvConfig), n.MainPlayer.src = u, n.MainPlayer.title = n.MainPolyvConfig.title, 
                                        n.MainPlayer.coverImgUrl = n.MainPolyvConfig.cover, n.duration = Math.ceil(c), console.log("duration", c), 
                                        n.MainPlayer.onEnded(function() {
                                            console.log("自然结束"), n.MainPlayer.src = u, n.MainPlayer.title = n.MainPolyvConfig.title, 
                                            n.MainPlayer.coverImgUrl = n.MainPolyvConfig.cover;
                                        }), n.MainPlayer.onStop(function() {
                                            console.log("监听到停止事件"), n.playing = 0, n.playComplete = 1, n.forceStop = !0;
                                        }), n.MainPlayer.onPause(function() {
                                            console.log("监听到暂停事件"), n.pause();
                                        }), n.MainPlayer.onPlay(function() {
                                            console.log("监听到播放事件"), n.loopPlay ? n.loopPlay = !1 : n.play();
                                        }), n.MainPlayer.onCanplay(function() {
                                            console.log("主音频进入可以播放状态，但不保证后面可以流畅播放, 这个时候主音频对象上还没有src"), o();
                                        }), console.log(n.MainPlayer, "this.MainPlayer");

                                      case 17:
                                      case "end":
                                        return r.stop();
                                    }
                                }, r);
                            }));
                            return function(t, e) {
                                return r.apply(this, arguments);
                            };
                        }());
                    }
                }, {
                    key: "play",
                    value: function() {
                        var t = (0, a.default)(i.default.mark(function t(e) {
                            return i.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    this.userPlay = !0, this.MainPlayer && this.MainPlayer.src ? (void 0 === e || Number.isNaN(1 * e) || this.seek(e), 
                                    this.startTimeStr = this.startTimeStr || this.getCurTime(), this.MainPlayer.play(), 
                                    this.playing = 1, this.playComplete = 0, this.startProgress()) : this.MainPolyvConfig ? (this.initMainPlayer(), 
                                    this.startTimeStr = this.startTimeStr || this.getCurTime()) : console.error("@Medi player: progressTimer is undefined"), 
                                    this.forceStop = !1;

                                  case 3:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        return function(e) {
                            return t.apply(this, arguments);
                        };
                    }()
                }, {
                    key: "seek",
                    value: function(t) {
                        var e = this;
                        return console.log("sec, dontRecord = 0", t, 0), new Promise(function(n) {
                            if (!e.MainPlayer || !e.MainPlayer.src) {
                                if (!e.MainPolyvConfig) return void console.error("@mediPlayerSeek: mediPlayerPlay is undefined，unable to seek");
                                e.initMainPlayer().then(function() {
                                    e.seek(t);
                                });
                            }
                            e.MainPlayer.seek(t), console.info("@Medi player: seek " + t), n();
                        });
                    }
                }, {
                    key: "pause",
                    value: function() {
                        var t = this;
                        console.log("pause"), setTimeout(function() {
                            t.MainPlayer && t.MainPlayer.pause(), t.playing = 0;
                        }, 50);
                    }
                }, {
                    key: "stop",
                    value: function(t) {
                        console.info("@Medi player: polyv stop", t), this.playing = 0, this.playComplete = 1, 
                        this.MainPlayer && !t && (this.MainPlayer.stop(), "function" == typeof this.endHandler && this.endHandler(this.getStayTime(), t), 
                        this.forceStop = !0);
                    }
                }, {
                    key: "startProgress",
                    value: function() {
                        var t = this;
                        if (this.progeressTimer && this.stopProgress(), this.MainPlayer) {
                            if (this.playing) {
                                var e = this.progress;
                                this.progress = this.getProgress(), console.log(this.duration - this.progress), 
                                this.duration - this.progress <= 3 && (this.MainPlayer.seek(0), this.loopPlay = !0), 
                                e === this.progress ? this.loading = 1 : (this.progress > 0 && (this.record++, this.allPlayTime === this.record && this.stop(!1)), 
                                this.loading = 0), this.progeressTimer = setTimeout(function() {
                                    t.startProgress();
                                }, 1e3), "function" == typeof this.progressHandler && this.progressHandler();
                            }
                        } else console.error("@mediPlayerRunProgress: medi_mix_PlayerProgressTimer is undefined");
                    }
                }, {
                    key: "stopProgress",
                    value: function() {
                        this.progeressTimer && clearTimeout(this.progeressTimer);
                    }
                }, {
                    key: "getProgress",
                    value: function() {
                        var t = this.MainPlayer.currentTime;
                        return this.MainPlayer ? t : 0;
                    }
                }, {
                    key: "getStayTime",
                    value: function() {
                        return this.record;
                    }
                }, {
                    key: "destory",
                    value: function() {
                        this.MainPlayer.destroy();
                    }
                }, {
                    key: "onEnd",
                    value: function(t) {
                        if (this.MainPlayer && "function" == typeof t) if ("function" == typeof this.endHandler) {
                            var e = this.endHandler;
                            this.endHandler = function() {
                                e(), t();
                            };
                        } else this.endHandler = t;
                    }
                }, {
                    key: "onProgress",
                    value: function(t) {
                        this.MainPlayer && "function" == typeof t && (this.progressHandler = t);
                    }
                }, {
                    key: "clearSeekHistory",
                    value: function() {}
                } ]), e;
            }();
            e.default = d;
        }).call(this, n("543d").default);
    },
    "10db": function(t, e, n) {
        (function(t) {
            var r = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.toSubscribeMessage = e.sleep = e.loginOver = e.getUserOver = e.getUser = e.default = void 0;
            var i = r(n("1123")), o = r(n("eb14")), a = function() {
                return new Promise(function(t, e) {
                    getApp().globalData.userInfoSQ ? (t(), i.default.commit("common/setUserInfoDialog", !1)) : (e(), 
                    i.default.commit("common/setUserInfoDialog", !0));
                });
            };
            e.getUser = a;
            var s = function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                return new Promise(function(e, n) {
                    getApp().globalData.userInfoSQ ? e() : t ? setTimeout(function() {
                        o.default.$on("onGotUserInfo", function() {
                            e();
                        });
                    }, 800) : o.default.$once("onGotUserInfo", function() {
                        e();
                    });
                });
            };
            e.getUserOver = s;
            var u = function() {
                return new Promise(function(t, e) {
                    getApp().globalData.sessionKey ? t() : o.default.$on("loginOver", function() {
                        t();
                    });
                });
            };
            e.loginOver = u;
            var c = function(t) {
                return new Promise(function(e) {
                    return setTimeout(e, t);
                });
            };
            e.sleep = c;
            var l = function() {
                for (var e = arguments.length, n = new Array(e), r = 0; r < e; r++) n[r] = arguments[r];
                t.requestSubscribeMessage({
                    tmplIds: [].concat(n),
                    success: function(t) {
                        console.log("订阅", t);
                    },
                    fail: function(t) {
                        console.log("订阅失败"), console.log(t);
                    }
                });
            };
            e.toSubscribeMessage = l;
            var f = {
                getUser: a,
                getUserOver: s,
                loginOver: u,
                sleep: c,
                toSubscribeMessage: l
            };
            e.default = f;
        }).call(this, n("543d").default);
    },
    1123: function(t, e, n) {
        var r = n("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = r(n("66fd")), o = r(n("26cb")), a = r(n("f4d9")), s = r(n("e2ed")), u = r(n("2f08")), c = r(n("aa2e"));
        i.default.use(o.default);
        var l = new o.default.Store({
            modules: {
                explore: a.default,
                common: s.default,
                mine: u.default,
                voice: c.default
            }
        });
        e.default = l;
    },
    "11b0": function(t, e) {
        t.exports = function(t) {
            if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t);
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    "154c": function(t, e, n) {
        (function(t) {
            var r = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0, e.param = c;
            var i = r(n("9523")), o = r(n("1123"));
            function a(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function s(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? a(Object(n), !0).forEach(function(e) {
                        (0, i.default)(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function u(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = "";
                return "[object Object]" === Object.prototype.toString.call(t) ? (t.path ? n = t.path : t.name && (n = "/pages/".concat(t.name, "/").concat(t.name)), 
                e = s(s(s({}, t.data), t.query), t.params)) : n = t, {
                    url: n += (n.indexOf("?") < 0 ? "?" : "&") + c(e)
                };
            }
            function c(t) {
                var e = "";
                for (var n in t) {
                    e += "&" + n + "=" + (void 0 !== t[n] ? t[n] : "");
                }
                return e ? e.substring(1) : "";
            }
            var l = {
                push: function(e) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    console.log("push", u(e, n)), t.navigateTo(u(e, n));
                },
                redirect: function(e) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    console.log("redirect", u(e, n)), t.redirectTo(u(e, n));
                },
                goIndex: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    null != e.avtive && o.default.commit("explore/setHarderTitleAvtive", e.avtive), 
                    t.switchTab({
                        url: "/pages/explore/explore"
                    });
                }
            };
            e.default = l;
        }).call(this, n("543d").default);
    },
    2236: function(t, e, n) {
        var r = n("5a43");
        t.exports = function(t) {
            if (Array.isArray(t)) return r(t);
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    2504: function(t) {
        t.exports = JSON.parse('{"0":65533,"128":8364,"130":8218,"131":402,"132":8222,"133":8230,"134":8224,"135":8225,"136":710,"137":8240,"138":352,"139":8249,"140":338,"142":381,"145":8216,"146":8217,"147":8220,"148":8221,"149":8226,"150":8211,"151":8212,"152":732,"153":8482,"154":353,"155":8250,"156":339,"158":382,"159":376}');
    },
    "26cb": function(t, e, n) {
        (function(e) {
            var n = ("undefined" != typeof window ? window : void 0 !== e ? e : {}).__VUE_DEVTOOLS_GLOBAL_HOOK__;
            function r(t, e) {
                if (void 0 === e && (e = []), null === t || "object" !== _typeof3(t)) return t;
                var n = function(t, e) {
                    return t.filter(e)[0];
                }(e, function(e) {
                    return e.original === t;
                });
                if (n) return n.copy;
                var i = Array.isArray(t) ? [] : {};
                return e.push({
                    original: t,
                    copy: i
                }), Object.keys(t).forEach(function(n) {
                    i[n] = r(t[n], e);
                }), i;
            }
            function i(t, e) {
                Object.keys(t).forEach(function(n) {
                    return e(t[n], n);
                });
            }
            function o(t) {
                return null !== t && "object" === _typeof3(t);
            }
            var a = function(t, e) {
                this.runtime = e, this._children = Object.create(null), this._rawModule = t;
                var n = t.state;
                this.state = ("function" == typeof n ? n() : n) || {};
            }, s = {
                namespaced: {
                    configurable: !0
                }
            };
            s.namespaced.get = function() {
                return !!this._rawModule.namespaced;
            }, a.prototype.addChild = function(t, e) {
                this._children[t] = e;
            }, a.prototype.removeChild = function(t) {
                delete this._children[t];
            }, a.prototype.getChild = function(t) {
                return this._children[t];
            }, a.prototype.hasChild = function(t) {
                return t in this._children;
            }, a.prototype.update = function(t) {
                this._rawModule.namespaced = t.namespaced, t.actions && (this._rawModule.actions = t.actions), 
                t.mutations && (this._rawModule.mutations = t.mutations), t.getters && (this._rawModule.getters = t.getters);
            }, a.prototype.forEachChild = function(t) {
                i(this._children, t);
            }, a.prototype.forEachGetter = function(t) {
                this._rawModule.getters && i(this._rawModule.getters, t);
            }, a.prototype.forEachAction = function(t) {
                this._rawModule.actions && i(this._rawModule.actions, t);
            }, a.prototype.forEachMutation = function(t) {
                this._rawModule.mutations && i(this._rawModule.mutations, t);
            }, Object.defineProperties(a.prototype, s);
            var u, c = function(t) {
                this.register([], t, !1);
            };
            c.prototype.get = function(t) {
                return t.reduce(function(t, e) {
                    return t.getChild(e);
                }, this.root);
            }, c.prototype.getNamespace = function(t) {
                var e = this.root;
                return t.reduce(function(t, n) {
                    return t + ((e = e.getChild(n)).namespaced ? n + "/" : "");
                }, "");
            }, c.prototype.update = function(t) {
                !function t(e, n, r) {
                    if (n.update(r), r.modules) for (var i in r.modules) {
                        if (!n.getChild(i)) return;
                        t(e.concat(i), n.getChild(i), r.modules[i]);
                    }
                }([], this.root, t);
            }, c.prototype.register = function(t, e, n) {
                var r = this;
                void 0 === n && (n = !0);
                var o = new a(e, n);
                0 === t.length ? this.root = o : this.get(t.slice(0, -1)).addChild(t[t.length - 1], o);
                e.modules && i(e.modules, function(e, i) {
                    r.register(t.concat(i), e, n);
                });
            }, c.prototype.unregister = function(t) {
                var e = this.get(t.slice(0, -1)), n = t[t.length - 1], r = e.getChild(n);
                r && r.runtime && e.removeChild(n);
            }, c.prototype.isRegistered = function(t) {
                var e = this.get(t.slice(0, -1)), n = t[t.length - 1];
                return !!e && e.hasChild(n);
            };
            var l = function(t) {
                var e = this;
                void 0 === t && (t = {}), !u && "undefined" != typeof window && window.Vue && g(window.Vue);
                var r = t.plugins;
                void 0 === r && (r = []);
                var i = t.strict;
                void 0 === i && (i = !1), this._committing = !1, this._actions = Object.create(null), 
                this._actionSubscribers = [], this._mutations = Object.create(null), this._wrappedGetters = Object.create(null), 
                this._modules = new c(t), this._modulesNamespaceMap = Object.create(null), this._subscribers = [], 
                this._watcherVM = new u(), this._makeLocalGettersCache = Object.create(null);
                var o = this, a = this.dispatch, s = this.commit;
                this.dispatch = function(t, e) {
                    return a.call(o, t, e);
                }, this.commit = function(t, e, n) {
                    return s.call(o, t, e, n);
                }, this.strict = i;
                var l = this._modules.root.state;
                _(this, l, [], this._modules.root), p(this, l), r.forEach(function(t) {
                    return t(e);
                });
                var f = void 0 !== t.devtools ? t.devtools : u.config.devtools;
                f && function(t) {
                    n && (t._devtoolHook = n, n.emit("vuex:init", t), n.on("vuex:travel-to-state", function(e) {
                        t.replaceState(e);
                    }), t.subscribe(function(t, e) {
                        n.emit("vuex:mutation", t, e);
                    }, {
                        prepend: !0
                    }), t.subscribeAction(function(t, e) {
                        n.emit("vuex:action", t, e);
                    }, {
                        prepend: !0
                    }));
                }(this);
            }, f = {
                state: {
                    configurable: !0
                }
            };
            function d(t, e, n) {
                return e.indexOf(t) < 0 && (n && n.prepend ? e.unshift(t) : e.push(t)), function() {
                    var n = e.indexOf(t);
                    n > -1 && e.splice(n, 1);
                };
            }
            function h(t, e) {
                t._actions = Object.create(null), t._mutations = Object.create(null), t._wrappedGetters = Object.create(null), 
                t._modulesNamespaceMap = Object.create(null);
                var n = t.state;
                _(t, n, [], t._modules.root, !0), p(t, n, e);
            }
            function p(t, e, n) {
                var r = t._vm;
                t.getters = {}, t._makeLocalGettersCache = Object.create(null);
                var o = t._wrappedGetters, a = {};
                i(o, function(e, n) {
                    a[n] = function(t, e) {
                        return function() {
                            return t(e);
                        };
                    }(e, t), Object.defineProperty(t.getters, n, {
                        get: function() {
                            return t._vm[n];
                        },
                        enumerable: !0
                    });
                });
                var s = u.config.silent;
                u.config.silent = !0, t._vm = new u({
                    data: {
                        $$state: e
                    },
                    computed: a
                }), u.config.silent = s, t.strict && function(t) {
                    t._vm.$watch(function() {
                        return this._data.$$state;
                    }, function() {}, {
                        deep: !0,
                        sync: !0
                    });
                }(t), r && (n && t._withCommit(function() {
                    r._data.$$state = null;
                }), u.nextTick(function() {
                    return r.$destroy();
                }));
            }
            function _(t, e, n, r, i) {
                var o = !n.length, a = t._modules.getNamespace(n);
                if (r.namespaced && (t._modulesNamespaceMap[a], t._modulesNamespaceMap[a] = r), 
                !o && !i) {
                    var s = m(e, n.slice(0, -1)), c = n[n.length - 1];
                    t._withCommit(function() {
                        u.set(s, c, r.state);
                    });
                }
                var l = r.context = function(t, e, n) {
                    var r = "" === e, i = {
                        dispatch: r ? t.dispatch : function(n, r, i) {
                            var o = y(n, r, i), a = o.payload, s = o.options, u = o.type;
                            return s && s.root || (u = e + u), t.dispatch(u, a);
                        },
                        commit: r ? t.commit : function(n, r, i) {
                            var o = y(n, r, i), a = o.payload, s = o.options, u = o.type;
                            s && s.root || (u = e + u), t.commit(u, a, s);
                        }
                    };
                    return Object.defineProperties(i, {
                        getters: {
                            get: r ? function() {
                                return t.getters;
                            } : function() {
                                return function(t, e) {
                                    if (!t._makeLocalGettersCache[e]) {
                                        var n = {}, r = e.length;
                                        Object.keys(t.getters).forEach(function(i) {
                                            if (i.slice(0, r) === e) {
                                                var o = i.slice(r);
                                                Object.defineProperty(n, o, {
                                                    get: function() {
                                                        return t.getters[i];
                                                    },
                                                    enumerable: !0
                                                });
                                            }
                                        }), t._makeLocalGettersCache[e] = n;
                                    }
                                    return t._makeLocalGettersCache[e];
                                }(t, e);
                            }
                        },
                        state: {
                            get: function() {
                                return m(t.state, n);
                            }
                        }
                    }), i;
                }(t, a, n);
                r.forEachMutation(function(e, n) {
                    !function(t, e, n, r) {
                        (t._mutations[e] || (t._mutations[e] = [])).push(function(e) {
                            n.call(t, r.state, e);
                        });
                    }(t, a + n, e, l);
                }), r.forEachAction(function(e, n) {
                    var r = e.root ? n : a + n, i = e.handler || e;
                    !function(t, e, n, r) {
                        (t._actions[e] || (t._actions[e] = [])).push(function(e) {
                            var i = n.call(t, {
                                dispatch: r.dispatch,
                                commit: r.commit,
                                getters: r.getters,
                                state: r.state,
                                rootGetters: t.getters,
                                rootState: t.state
                            }, e);
                            return function(t) {
                                return t && "function" == typeof t.then;
                            }(i) || (i = Promise.resolve(i)), t._devtoolHook ? i.catch(function(e) {
                                throw t._devtoolHook.emit("vuex:error", e), e;
                            }) : i;
                        });
                    }(t, r, i, l);
                }), r.forEachGetter(function(e, n) {
                    !function(t, e, n, r) {
                        t._wrappedGetters[e] || (t._wrappedGetters[e] = function(t) {
                            return n(r.state, r.getters, t.state, t.getters);
                        });
                    }(t, a + n, e, l);
                }), r.forEachChild(function(r, o) {
                    _(t, e, n.concat(o), r, i);
                });
            }
            function m(t, e) {
                return e.reduce(function(t, e) {
                    return t[e];
                }, t);
            }
            function y(t, e, n) {
                return o(t) && t.type && (n = e, e = t, t = t.type), {
                    type: t,
                    payload: e,
                    options: n
                };
            }
            function g(t) {
                u && t === u || function(t) {
                    if (Number(t.version.split(".")[0]) >= 2) t.mixin({
                        beforeCreate: n
                    }); else {
                        var e = t.prototype._init;
                        t.prototype._init = function(t) {
                            void 0 === t && (t = {}), t.init = t.init ? [ n ].concat(t.init) : n, e.call(this, t);
                        };
                    }
                    function n() {
                        var t = this.$options;
                        t.store ? this.$store = "function" == typeof t.store ? t.store() : t.store : t.parent && t.parent.$store && (this.$store = t.parent.$store);
                    }
                }(u = t);
            }
            f.state.get = function() {
                return this._vm._data.$$state;
            }, f.state.set = function(t) {}, l.prototype.commit = function(t, e, n) {
                var r = this, i = y(t, e, n), o = i.type, a = i.payload, s = (i.options, {
                    type: o,
                    payload: a
                }), u = this._mutations[o];
                u && (this._withCommit(function() {
                    u.forEach(function(t) {
                        t(a);
                    });
                }), this._subscribers.slice().forEach(function(t) {
                    return t(s, r.state);
                }));
            }, l.prototype.dispatch = function(t, e) {
                var n = this, r = y(t, e), i = r.type, o = r.payload, a = {
                    type: i,
                    payload: o
                }, s = this._actions[i];
                if (s) {
                    try {
                        this._actionSubscribers.slice().filter(function(t) {
                            return t.before;
                        }).forEach(function(t) {
                            return t.before(a, n.state);
                        });
                    } catch (t) {}
                    var u = s.length > 1 ? Promise.all(s.map(function(t) {
                        return t(o);
                    })) : s[0](o);
                    return new Promise(function(t, e) {
                        u.then(function(e) {
                            try {
                                n._actionSubscribers.filter(function(t) {
                                    return t.after;
                                }).forEach(function(t) {
                                    return t.after(a, n.state);
                                });
                            } catch (t) {}
                            t(e);
                        }, function(t) {
                            try {
                                n._actionSubscribers.filter(function(t) {
                                    return t.error;
                                }).forEach(function(e) {
                                    return e.error(a, n.state, t);
                                });
                            } catch (t) {}
                            e(t);
                        });
                    });
                }
            }, l.prototype.subscribe = function(t, e) {
                return d(t, this._subscribers, e);
            }, l.prototype.subscribeAction = function(t, e) {
                return d("function" == typeof t ? {
                    before: t
                } : t, this._actionSubscribers, e);
            }, l.prototype.watch = function(t, e, n) {
                var r = this;
                return this._watcherVM.$watch(function() {
                    return t(r.state, r.getters);
                }, e, n);
            }, l.prototype.replaceState = function(t) {
                var e = this;
                this._withCommit(function() {
                    e._vm._data.$$state = t;
                });
            }, l.prototype.registerModule = function(t, e, n) {
                void 0 === n && (n = {}), "string" == typeof t && (t = [ t ]), this._modules.register(t, e), 
                _(this, this.state, t, this._modules.get(t), n.preserveState), p(this, this.state);
            }, l.prototype.unregisterModule = function(t) {
                var e = this;
                "string" == typeof t && (t = [ t ]), this._modules.unregister(t), this._withCommit(function() {
                    var n = m(e.state, t.slice(0, -1));
                    u.delete(n, t[t.length - 1]);
                }), h(this);
            }, l.prototype.hasModule = function(t) {
                return "string" == typeof t && (t = [ t ]), this._modules.isRegistered(t);
            }, l.prototype[[ 104, 111, 116, 85, 112, 100, 97, 116, 101 ].map(function(t) {
                return String.fromCharCode(t);
            }).join("")] = function(t) {
                this._modules.update(t), h(this, !0);
            }, l.prototype._withCommit = function(t) {
                var e = this._committing;
                this._committing = !0, t(), this._committing = e;
            }, Object.defineProperties(l.prototype, f);
            var v = S(function(t, e) {
                var n = {};
                return A(e).forEach(function(e) {
                    var r = e.key, i = e.val;
                    n[r] = function() {
                        var e = this.$store.state, n = this.$store.getters;
                        if (t) {
                            var r = T(this.$store, "mapState", t);
                            if (!r) return;
                            e = r.context.state, n = r.context.getters;
                        }
                        return "function" == typeof i ? i.call(this, e, n) : e[i];
                    }, n[r].vuex = !0;
                }), n;
            }), b = S(function(t, e) {
                var n = {};
                return A(e).forEach(function(e) {
                    var r = e.key, i = e.val;
                    n[r] = function() {
                        for (var e = [], n = arguments.length; n--; ) e[n] = arguments[n];
                        var r = this.$store.commit;
                        if (t) {
                            var o = T(this.$store, "mapMutations", t);
                            if (!o) return;
                            r = o.context.commit;
                        }
                        return "function" == typeof i ? i.apply(this, [ r ].concat(e)) : r.apply(this.$store, [ i ].concat(e));
                    };
                }), n;
            }), w = S(function(t, e) {
                var n = {};
                return A(e).forEach(function(e) {
                    var r = e.key, i = e.val;
                    i = t + i, n[r] = function() {
                        if (!t || T(this.$store, "mapGetters", t)) return this.$store.getters[i];
                    }, n[r].vuex = !0;
                }), n;
            }), x = S(function(t, e) {
                var n = {};
                return A(e).forEach(function(e) {
                    var r = e.key, i = e.val;
                    n[r] = function() {
                        for (var e = [], n = arguments.length; n--; ) e[n] = arguments[n];
                        var r = this.$store.dispatch;
                        if (t) {
                            var o = T(this.$store, "mapActions", t);
                            if (!o) return;
                            r = o.context.dispatch;
                        }
                        return "function" == typeof i ? i.apply(this, [ r ].concat(e)) : r.apply(this.$store, [ i ].concat(e));
                    };
                }), n;
            });
            function A(t) {
                return function(t) {
                    return Array.isArray(t) || o(t);
                }(t) ? Array.isArray(t) ? t.map(function(t) {
                    return {
                        key: t,
                        val: t
                    };
                }) : Object.keys(t).map(function(e) {
                    return {
                        key: e,
                        val: t[e]
                    };
                }) : [];
            }
            function S(t) {
                return function(e, n) {
                    return "string" != typeof e ? (n = e, e = "") : "/" !== e.charAt(e.length - 1) && (e += "/"), 
                    t(e, n);
                };
            }
            function T(t, e, n) {
                return t._modulesNamespaceMap[n];
            }
            function P(t, e, n) {
                var r = n ? t.groupCollapsed : t.group;
                try {
                    r.call(t, e);
                } catch (n) {
                    t.log(e);
                }
            }
            function M(t) {
                try {
                    t.groupEnd();
                } catch (e) {
                    t.log("—— log end ——");
                }
            }
            function k() {
                var t = new Date();
                return " @ " + E(t.getHours(), 2) + ":" + E(t.getMinutes(), 2) + ":" + E(t.getSeconds(), 2) + "." + E(t.getMilliseconds(), 3);
            }
            function E(t, e) {
                return function(t, e) {
                    return new Array(e + 1).join("0");
                }(0, e - t.toString().length) + t;
            }
            var O = {
                Store: l,
                install: g,
                version: "3.6.2",
                mapState: v,
                mapMutations: b,
                mapGetters: w,
                mapActions: x,
                createNamespacedHelpers: function(t) {
                    return {
                        mapState: v.bind(null, t),
                        mapGetters: w.bind(null, t),
                        mapMutations: b.bind(null, t),
                        mapActions: x.bind(null, t)
                    };
                },
                createLogger: function(t) {
                    void 0 === t && (t = {});
                    var e = t.collapsed;
                    void 0 === e && (e = !0);
                    var n = t.filter;
                    void 0 === n && (n = function(t, e, n) {
                        return !0;
                    });
                    var i = t.transformer;
                    void 0 === i && (i = function(t) {
                        return t;
                    });
                    var o = t.mutationTransformer;
                    void 0 === o && (o = function(t) {
                        return t;
                    });
                    var a = t.actionFilter;
                    void 0 === a && (a = function(t, e) {
                        return !0;
                    });
                    var s = t.actionTransformer;
                    void 0 === s && (s = function(t) {
                        return t;
                    });
                    var u = t.logMutations;
                    void 0 === u && (u = !0);
                    var c = t.logActions;
                    void 0 === c && (c = !0);
                    var l = t.logger;
                    return void 0 === l && (l = console), function(t) {
                        var f = r(t.state);
                        void 0 !== l && (u && t.subscribe(function(t, a) {
                            var s = r(a);
                            if (n(t, f, s)) {
                                var u = k(), c = o(t), d = "mutation " + t.type + u;
                                P(l, d, e), l.log("%c prev state", "color: #9E9E9E; font-weight: bold", i(f)), l.log("%c mutation", "color: #03A9F4; font-weight: bold", c), 
                                l.log("%c next state", "color: #4CAF50; font-weight: bold", i(s)), M(l);
                            }
                            f = s;
                        }), c && t.subscribeAction(function(t, n) {
                            if (a(t, n)) {
                                var r = k(), i = s(t), o = "action " + t.type + r;
                                P(l, o, e), l.log("%c action", "color: #03A9F4; font-weight: bold", i), M(l);
                            }
                        }));
                    };
                }
            };
            t.exports = O;
        }).call(this, n("c8ba"));
    },
    "278c": function(t, e, n) {
        var r = n("c135"), i = n("9b42"), o = n("6613"), a = n("c240");
        t.exports = function(t, e) {
            return r(t) || i(t, e) || o(t, e) || a();
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    2976: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.toFixedTwo = e.toFilterTime = e.secondToTimes = e.filterPracticeLevel = e.filterPennyToYuan = void 0, 
        e.filterPracticeLevel = function(t) {
            var e = "";
            return [ {
                code: 0,
                text: "零基础"
            }, {
                code: 1,
                text: "入门"
            }, {
                code: 2,
                text: "进阶"
            }, {
                code: 3,
                text: "大师"
            } ].forEach(function(n) {
                1 * t === n.code && (e = n.text);
            }), e;
        }, e.secondToTimes = function(t, e) {
            var n = parseInt(t), r = 0;
            if (n > 60) {
                if (r = parseInt(n / 60), e) return r;
                if (!isNaN(r)) return "".concat(r, "分钟");
            } else {
                if (e) return "0";
                if (!isNaN(n)) return "".concat(n, "秒");
            }
        }, e.filterPennyToYuan = function(t) {
            return t ? (t / 100).toFixed(2) : "0.00";
        }, e.toFixedTwo = function(t) {
            return t ? parseFloat(t).toFixed(2) : "0.00";
        }, e.toFilterTime = function(t) {
            if (!t) return "";
            var e = t.indexOf("-"), n = t.lastIndexOf(":");
            return t.substring(e + 1, n);
        };
    },
    "29f9": function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = function(t, e) {
            var n = new r.default(function(t, n) {
                t && (console.error(t), e(t));
                try {
                    e(null, s(n));
                } catch (t) {
                    console.error(t), e(t);
                }
            }, {}), o = new i.default(n, {
                xmlMode: !0
            });
            o.write(t), o.done();
        };
        var r = o(n("f23f")), i = o(n("b69b"));
        function o(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        function a(t) {
            if (-1 === [ "tag", "text" ].indexOf(t.type)) throw new Error("not supported name " + t.name + " of type " + t.type);
            return "text" === t.type ? {
                type: t.type,
                text: t.data
            } : {
                name: t.name,
                children: s(t.children),
                attrs: t.attribs
            };
        }
        function s(t) {
            return t.map(a);
        }
        t.exports = e.default;
    },
    "2eee": function(t, e, n) {
        var r = n("7ec2")();
        t.exports = r;
    },
    "2f08": function(t, e, n) {
        (function(t) {
            var r = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = n("f8e4"), o = r(n("b887")), a = n("2976"), s = {
                namespaced: !0,
                state: {
                    homeInfo: {
                        totalLearningTimeList: [ "0" ],
                        todayLearningTimeList: [ "0" ],
                        totalLearnDaysList: [ "0" ],
                        currentLevel: 0
                    },
                    vipotherInfo: null,
                    myVip: {},
                    homeInfoBool: !1,
                    myPrompt: {}
                },
                getters: {
                    getHomeInfo: function(t) {
                        return t.homeInfo;
                    },
                    getVipotherInfo: function(t) {
                        return t.vipotherInfo;
                    },
                    getMyVip: function(t) {
                        return t.myVip;
                    },
                    getMyPrompt: function(t) {
                        return t.myPrompt;
                    }
                },
                mutations: {
                    setHomeInfo: function(t, e) {
                        t.homeInfo = e;
                    },
                    setVipotherInfo: function(t, e) {
                        t.vipotherInfo = e;
                    },
                    setMyVip: function(t, e) {
                        t.myVip = e;
                    },
                    setMyPrompt: function(t, e) {
                        t.myPrompt = e;
                    }
                },
                actions: {
                    fetchHomeInfo: function(t, e) {
                        var n = t.state, r = t.commit;
                        if (!n.homeInfoBool) return n.homeInfoBool = !0, (0, i.http)(o.default.myHomeInfo).finally(function() {
                            n.homeInfoBool = !1;
                        }).then(function(t) {
                            var e = t.code, n = t.data;
                            if ("1" === e) {
                                var i = n;
                                return i.totalLearningTimeList = (0, a.secondToTimes)(n.totalLearningTime, 1).toString().split(""), 
                                i.todayLearningTimeList = (0, a.secondToTimes)(n.todayLearningTime, 1).toString().split(""), 
                                i.totalLearnDaysList = n.totalLearnDays.toString().split(""), i.totalLearnDays = n.totalLearnDays, 
                                r("setHomeInfo", i), i;
                            }
                        });
                    },
                    fetchVipotherInfo: function(e, n) {
                        e.state;
                        var r = e.commit;
                        return (0, i.http)({
                            url: o.default.meditationVip,
                            data: {
                                vipId: getApp().globalData.vipId
                            }
                        }).then(function(t) {
                            if ("1" === t.code) {
                                var e = t.data || {};
                                r("setVipotherInfo", e);
                            }
                        }).catch(function(e) {
                            return t.showToast({
                                title: e.msg || "传输数据异常"
                            }), e;
                        });
                    },
                    fetchMyVip: function(t, e) {
                        var n = t.getters, r = t.commit;
                        (0, i.http)({
                            url: o.default.getMyVip,
                            data: {
                                vipType: 2
                            }
                        }).then(function(t) {
                            var e = t.data;
                            if ("1" === t.code) {
                                var i = {
                                    isLogin: !0,
                                    isVip: e.isVip
                                };
                                r("setMyVip", i), console.log("fetchMyVip", n.getMyVip);
                            }
                            return t;
                        });
                    },
                    fetchMyPrompt: function(e) {
                        var n = e.commit, r = e.getters;
                        console.log(r);
                        var a = r.getMyPrompt.commentNum, s = r.getMyPrompt.externalLike;
                        return (0, i.http)({
                            url: o.default.fetchMyPrompt
                        }).then(function(e) {
                            if (1 == +e.code && e.data) {
                                var r = {
                                    commentNum: +e.data.commentNum || 0,
                                    actualLike: +e.data.actualLike || 0,
                                    externalLike: +e.data.externalLike || 0
                                };
                                return n("setMyPrompt", r), !(e.data.externalLike > 0 || e.data.commentNum > 0) || a === +e.data.commentNum && s === +e.data.externalLike || t.showTabBarRedDot({
                                    index: 2
                                }), r;
                            }
                        }).catch(function(t) {
                            console.log("fetchMyPrompt error: " + t);
                        });
                    }
                }
            };
            e.default = s;
        }).call(this, n("543d").default);
    },
    3329: function(t, e, n) {},
    "36c6": function(t, e) {
        function n(e) {
            return t.exports = n = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
                return t.__proto__ || Object.getPrototypeOf(t);
            }, t.exports.__esModule = !0, t.exports.default = t.exports, n(e);
        }
        t.exports = n, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    "37dc": function(t, e, n) {
        (function(t, r) {
            var i = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.LOCALE_ZH_HANT = e.LOCALE_ZH_HANS = e.LOCALE_FR = e.LOCALE_ES = e.LOCALE_EN = e.I18n = e.Formatter = void 0, 
            e.compileI18nJsonStr = function(t, e) {
                var n = e.locale, r = e.locales, i = e.delimiters;
                if (!P(t, i)) return t;
                S || (S = new d());
                var o = [];
                Object.keys(r).forEach(function(t) {
                    t !== n && o.push({
                        locale: t,
                        values: r[t]
                    });
                }), o.unshift({
                    locale: n,
                    values: r[n]
                });
                try {
                    return JSON.stringify(function t(e, n, r) {
                        return k(e, function(e, i) {
                            !function(e, n, r, i) {
                                var o = e[n];
                                if (T(o)) {
                                    if (P(o, i) && (e[n] = M(o, r[0].values, i), r.length > 1)) {
                                        var a = e[n + "Locales"] = {};
                                        r.forEach(function(t) {
                                            a[t.locale] = M(o, t.values, i);
                                        });
                                    }
                                } else t(o, r, i);
                            }(e, i, n, r);
                        }), e;
                    }(JSON.parse(t), o, i), null, 2);
                } catch (t) {}
                return t;
            }, e.hasI18nJson = function t(e, n) {
                return S || (S = new d()), k(e, function(e, r) {
                    var i = e[r];
                    return T(i) ? !!P(i, n) || void 0 : t(i, n);
                });
            }, e.initVueI18n = function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = arguments.length > 2 ? arguments[2] : void 0, r = arguments.length > 3 ? arguments[3] : void 0;
                if ("string" != typeof t) {
                    var i = [ e, t ];
                    t = i[0], e = i[1];
                }
                "string" != typeof t && (t = A()), "string" != typeof n && (n = "undefined" != typeof __uniConfig && __uniConfig.fallbackLocale || "en");
                var o = new w({
                    locale: t,
                    fallbackLocale: n,
                    messages: e,
                    watcher: r
                }), a = function(t, e) {
                    if ("function" != typeof getApp) a = function(t, e) {
                        return o.t(t, e);
                    }; else {
                        var n = !1;
                        a = function(t, e) {
                            var r = getApp().$vm;
                            return r && (r.$locale, n || (n = !0, x(r, o))), o.t(t, e);
                        };
                    }
                    return a(t, e);
                };
                return {
                    i18n: o,
                    f: function(t, e, n) {
                        return o.f(t, e, n);
                    },
                    t: function(t, e) {
                        return a(t, e);
                    },
                    add: function(t, e) {
                        var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                        return o.add(t, e, n);
                    },
                    watch: function(t) {
                        return o.watchLocale(t);
                    },
                    getLocale: function() {
                        return o.getLocale();
                    },
                    setLocale: function(t) {
                        return o.setLocale(t);
                    }
                };
            }, e.isI18nStr = P, e.isString = void 0, e.normalizeLocale = b, e.parseI18nJson = function t(e, n, r) {
                return S || (S = new d()), k(e, function(e, i) {
                    var o = e[i];
                    T(o) ? P(o, r) && (e[i] = M(o, n, r)) : t(o, n, r);
                }), e;
            }, e.resolveLocale = function(t) {
                return function(e) {
                    return e ? function(t) {
                        for (var e = [], n = t.split("-"); n.length; ) e.push(n.join("-")), n.pop();
                        return e;
                    }(e = b(e) || e).find(function(e) {
                        return t.indexOf(e) > -1;
                    }) : e;
                };
            };
            var o = i(n("278c")), a = i(n("970b")), s = i(n("5bc3")), u = i(n("7037")), c = Array.isArray, l = function(t) {
                return null !== t && "object" === (0, u.default)(t);
            }, f = [ "{", "}" ], d = function() {
                function t() {
                    (0, a.default)(this, t), this._caches = Object.create(null);
                }
                return (0, s.default)(t, [ {
                    key: "interpolate",
                    value: function(t, e) {
                        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : f;
                        if (!e) return [ t ];
                        var r = this._caches[t];
                        return r || (r = _(t, n), this._caches[t] = r), m(r, e);
                    }
                } ]), t;
            }();
            e.Formatter = d;
            var h = /^(?:\d)+/, p = /^(?:\w)+/;
            function _(t, e) {
                for (var n = (0, o.default)(e, 2), r = n[0], i = n[1], a = [], s = 0, u = ""; s < t.length; ) {
                    var c = t[s++];
                    if (c === r) {
                        u && a.push({
                            type: "text",
                            value: u
                        }), u = "";
                        var l = "";
                        for (c = t[s++]; void 0 !== c && c !== i; ) l += c, c = t[s++];
                        var f = c === i, d = h.test(l) ? "list" : f && p.test(l) ? "named" : "unknown";
                        a.push({
                            value: l,
                            type: d
                        });
                    } else u += c;
                }
                return u && a.push({
                    type: "text",
                    value: u
                }), a;
            }
            function m(t, e) {
                var n = [], r = 0, i = c(e) ? "list" : l(e) ? "named" : "unknown";
                if ("unknown" === i) return n;
                for (;r < t.length; ) {
                    var o = t[r];
                    switch (o.type) {
                      case "text":
                        n.push(o.value);
                        break;

                      case "list":
                        n.push(e[parseInt(o.value, 10)]);
                        break;

                      case "named":
                        "named" === i && n.push(e[o.value]);
                    }
                    r++;
                }
                return n;
            }
            e.LOCALE_ZH_HANS = "zh-Hans", e.LOCALE_ZH_HANT = "zh-Hant", e.LOCALE_EN = "en", 
            e.LOCALE_FR = "fr", e.LOCALE_ES = "es";
            var y = Object.prototype.hasOwnProperty, g = function(t, e) {
                return y.call(t, e);
            }, v = new d();
            function b(t, e) {
                if (t) return t = t.trim().replace(/_/g, "-"), e && e[t] ? t : 0 === (t = t.toLowerCase()).indexOf("zh") ? t.indexOf("-hans") > -1 ? "zh-Hans" : t.indexOf("-hant") > -1 || function(t, e) {
                    return !![ "-tw", "-hk", "-mo", "-cht" ].find(function(e) {
                        return -1 !== t.indexOf(e);
                    });
                }(t) ? "zh-Hant" : "zh-Hans" : function(t, e) {
                    return [ "en", "fr", "es" ].find(function(e) {
                        return 0 === t.indexOf(e);
                    });
                }(t) || void 0;
            }
            var w = function() {
                function t(e) {
                    var n = e.locale, r = e.fallbackLocale, i = e.messages, o = e.watcher, s = e.formater;
                    (0, a.default)(this, t), this.locale = "en", this.fallbackLocale = "en", this.message = {}, 
                    this.messages = {}, this.watchers = [], r && (this.fallbackLocale = r), this.formater = s || v, 
                    this.messages = i || {}, this.setLocale(n || "en"), o && this.watchLocale(o);
                }
                return (0, s.default)(t, [ {
                    key: "setLocale",
                    value: function(t) {
                        var e = this, n = this.locale;
                        this.locale = b(t, this.messages) || this.fallbackLocale, this.messages[this.locale] || (this.messages[this.locale] = {}), 
                        this.message = this.messages[this.locale], n !== this.locale && this.watchers.forEach(function(t) {
                            t(e.locale, n);
                        });
                    }
                }, {
                    key: "getLocale",
                    value: function() {
                        return this.locale;
                    }
                }, {
                    key: "watchLocale",
                    value: function(t) {
                        var e = this, n = this.watchers.push(t) - 1;
                        return function() {
                            e.watchers.splice(n, 1);
                        };
                    }
                }, {
                    key: "add",
                    value: function(t, e) {
                        var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2], r = this.messages[t];
                        r ? n ? Object.assign(r, e) : Object.keys(e).forEach(function(t) {
                            g(r, t) || (r[t] = e[t]);
                        }) : this.messages[t] = e;
                    }
                }, {
                    key: "f",
                    value: function(t, e, n) {
                        return this.formater.interpolate(t, e, n).join("");
                    }
                }, {
                    key: "t",
                    value: function(t, e, n) {
                        var r = this.message;
                        return "string" == typeof e ? (e = b(e, this.messages)) && (r = this.messages[e]) : n = e, 
                        g(r, t) ? this.formater.interpolate(r[t], n).join("") : (console.warn("Cannot translate the value of keypath ".concat(t, ". Use the value of keypath as default.")), 
                        t);
                    }
                } ]), t;
            }();
            function x(t, e) {
                t.$watchLocale ? t.$watchLocale(function(t) {
                    e.setLocale(t);
                }) : t.$watch(function() {
                    return t.$locale;
                }, function(t) {
                    e.setLocale(t);
                });
            }
            function A() {
                return void 0 !== t && t.getLocale ? t.getLocale() : void 0 !== r && r.getLocale ? r.getLocale() : "en";
            }
            e.I18n = w;
            var S, T = function(t) {
                return "string" == typeof t;
            };
            function P(t, e) {
                return t.indexOf(e[0]) > -1;
            }
            function M(t, e, n) {
                return S.interpolate(t, e, n).join("");
            }
            function k(t, e) {
                if (c(t)) {
                    for (var n = 0; n < t.length; n++) if (e(t, n)) return !0;
                } else if (l(t)) for (var r in t) if (e(t, r)) return !0;
                return !1;
            }
            e.isString = T;
        }).call(this, n("543d").default, n("c8ba"));
    },
    "39e7": function(t, e, n) {
        (function(t, r) {
            var i = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = i(n("970b")), a = i(n("5bc3")), s = i(n("9516")), u = [ "scaleToFill", "aspectFit", "aspectFill", "widthFix", "top", "bottom", "center", "left", "right", "top left", "top right", "bottom left", "bottom right" ], c = function() {
                function e() {
                    var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    (0, o.default)(this, e), this.device = t.getSystemInfoSync && t.getSystemInfoSync() || {}, 
                    n.zoom ? this.zoom = n.zoom || 1 : this.zoom = this.device.windowWidth / 375, this.element = n.element, 
                    this.object = n.obj, this.width = n.width * this.zoom || 0, this.height = n.height * this.zoom || 0, 
                    this.destZoom = n.destZoom || 3, this.destWidth = this.width * this.destZoom, this.destHeight = this.height * this.destZoom, 
                    this.translateX = n.translateX * this.zoom || 0, this.translateY = n.translateY * this.zoom || 0, 
                    this.gradientBackground = n.gradientBackground || null, this.background = n.background || "#ffffff", 
                    this.finishDraw = n.finish || function(t) {}, this.errorHandler = n.error || function(t) {}, 
                    this.progress = n.progress || function(t) {}, this.textAlign = n.textAlign || "left", 
                    this.fullText = n.fullText || !1, this.font = n.font || "14px PingFang SC", this._init();
                }
                return (0, a.default)(e, [ {
                    key: "draw",
                    value: function() {
                        var t = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 ? arguments[1] : void 0, r = this;
                        this.data = e, this.fef = n, this.progress(10), this._preloadImage(e.list).then(function(e) {
                            t.progress(30), r._draw();
                        }).catch(function(t) {
                            r.errorHandler(t);
                        });
                    }
                }, {
                    key: "measureWidth",
                    value: function(t, e) {
                        return e && (this.ctx.font = e), (this.ctx.measureText(t) || {}).width || 0;
                    }
                }, {
                    key: "_init",
                    value: function() {
                        this.progressPercent = 0, this.data = null, this.ref = null, this.allPic = [], this.screenList = [], 
                        this.asyncList = [], this.imgUrl = "", this.progressPercent = 0, this.distance = 0, 
                        this.progress(0), this.ctx = t.createCanvasContext(this.element, this.object), this.ctx.font = this.font, 
                        this.ctx.setTextBaseline("top"), this.ctx.setStrokeStyle("white"), this.debug = "devtools" === this.device.platform, 
                        this._drawBakcground();
                    }
                }, {
                    key: "_drawBakcground",
                    value: function() {
                        if (this.gradientBackground) {
                            var t = {
                                fill: {
                                    line: this.gradientBackground.line || [ 0, 0, 0, this.height ],
                                    color: this.gradientBackground.color || [ "#fff", "#fff" ]
                                }
                            };
                            this._drawRectToCanvas(0, 0, this.width, this.height, t);
                        } else {
                            var e = {
                                fill: this.background
                            };
                            this._drawRectToCanvas(0, 0, this.width, this.height, e);
                        }
                    }
                }, {
                    key: "_draw",
                    value: function() {
                        var t = this, e = this.data.list || [], n = 0, r = [], i = 0;
                        function o() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], i = arguments.length > 1 ? arguments[1] : void 0;
                            e.forEach(function(e, o) {
                                r[n++] = new Promise(function(n, r) {
                                    var o = e.style;
                                    e.progress = t.distance, i && (e.delay = 0), "radius-image" === e.type ? t._drawCircle(e, o, n, r, "image") : "text" === e.type ? t._drawText(e, o, n, r) : "line" === e.type ? t._drawLine(e, o, n, r) : "circle" === e.type ? t._drawCircle(e, o, n, r) : "rect" === e.type ? t._drawRect(e, o, n, r) : "image" === e.type ? t._drawRect(e, o, n, r, "image") : "wxml" === e.type ? t._drawWxml(e, o, n, r) : n();
                                });
                            });
                        }
                        e.forEach(function(t) {
                            "wxml" === t.type ? i += 3 : i += 1;
                        }), this.distance = 60 / (i || 1), this.progressPercent = 30, this.asyncList = e.filter(function(t) {
                            return 1 == t.delay;
                        }), o(e = e.filter(function(t) {
                            return 1 != t.delay;
                        })), Promise.all(r).then(function(e) {
                            n = 0, o(t.asyncList, !0), Promise.all(r).then(function(e) {
                                t.progress(90), t._saveCanvasToImage();
                            });
                        }).catch(function(e) {
                            t.errorHandler(e);
                        });
                    }
                }, {
                    key: "_saveCanvasToImage",
                    value: function() {
                        var e = this;
                        setTimeout(function() {
                            e.progress(95);
                            var n = {
                                x: 0,
                                y: 0,
                                width: e.width,
                                height: e.height,
                                canvasId: e.element,
                                success: function(t) {
                                    e.progress(100), e.imgUrl = t.tempFilePath, e.finishDraw(e.imgUrl);
                                },
                                fail: function(t) {
                                    e.errorHandler({
                                        errcode: 1e3,
                                        errmsg: "save canvas error",
                                        e: t
                                    });
                                }
                            };
                            3 !== e.destZoom && (n.destWidth = e.destWidth, n.destHeight = e.destHeight), t.canvasToTempFilePath(n, e.object);
                        }, -1 === e.device.system.indexOf("iOS") ? 300 : 100);
                    }
                }, {
                    key: "_preloadImage",
                    value: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], n = this, r = [], i = 0;
                        return e.forEach(function(e, o) {
                            e.url && -1 === n._findPicIndex(e.url) && (n.allPic.push({
                                url: e.url,
                                local: ""
                            }), r[i++] = new Promise(function(r, i) {
                                if (!/^http/.test(e.url) || /^http:\/\/(tmp)|(usr)\//.test(e.url) || /^http:\/\/127\.0\.0\.1/.test(e.url)) {
                                    var o = function(e) {
                                        t.getImageInfo({
                                            src: e,
                                            success: function(t) {
                                                var i = n._findPicIndex(e);
                                                i > -1 && (n.allPic[i].local = e, n.allPic[i].width = t.width, n.allPic[i].height = t.height), 
                                                r({
                                                    tempFilePath: e
                                                });
                                            },
                                            fail: function(t) {
                                                i(t);
                                            }
                                        });
                                    };
                                    if (e.isBase64) t.getFileSystemManager().writeFile({
                                        filePath: e.url,
                                        data: e.isBase64.replace(/data:image\/(.*);base64,/, ""),
                                        encoding: "base64",
                                        success: function(t) {
                                            o(e.url);
                                        },
                                        fail: function(t) {
                                            i(t);
                                        }
                                    }); else o(e.url);
                                } else t.downloadFile({
                                    url: e.url.replace(/^https?/, "https"),
                                    success: function(o) {
                                        t.getImageInfo({
                                            src: o.tempFilePath,
                                            success: function(t) {
                                                var i = n._findPicIndex(e.url);
                                                i > -1 && (n.allPic[i].local = o.tempFilePath, n.allPic[i].width = t.width, n.allPic[i].height = t.height), 
                                                r(o);
                                            },
                                            fail: function(t) {
                                                i(t);
                                            }
                                        });
                                    },
                                    fail: function(t) {
                                        i({
                                            errcode: 1001,
                                            errmsg: "download pic error"
                                        });
                                    }
                                });
                            }));
                        }), Promise.all(r).then(function(t) {
                            return new Promise(function(t) {
                                t();
                            });
                        }).catch(function(t) {
                            return new Promise(function(e, n) {
                                n(t);
                            });
                        });
                    }
                }, {
                    key: "_findPicIndex",
                    value: function(t) {
                        return this.allPic.findIndex(function(e) {
                            return e.url === t;
                        });
                    }
                }, {
                    key: "_drawRect",
                    value: function(t, e, n, r, i, o) {
                        var a = this.zoom, s = 0, c = e.width, l = e.height, f = e.width, d = e.height, h = null;
                        try {
                            var p;
                            if (t.x = this._resetPositionX(t, e), t.y = this._resetPositionY(t, e), i) {
                                var _ = this._findPicIndex(t.url);
                                _ > -1 ? (p = this.allPic[_].local, f = this.allPic[_].width, d = this.allPic[_].height) : p = t.url;
                            }
                            if (e.padding = e.padding || [], "inline-wxml" === o && (t.x = t.x + (e.padding[3] && e.padding[3] || 0), 
                            t.y = t.y + (e.padding[0] && e.padding[0] || 0)), s = t.x + e.width + (e.padding[1] && e.padding[1] || 0), 
                            o || (c *= a, l *= a), e.dataset && e.dataset.mode && u.indexOf(e.dataset.mode) > -1 && (h = {
                                type: e.dataset.mode,
                                width: f,
                                height: d
                            }), this._drawRectToCanvas(t.x, t.y, c, l, e, p, h), this._updateProgress(t.progress), 
                            !n) return {
                                leftOffset: s,
                                topOffset: 0
                            };
                            n();
                        } catch (t) {
                            r && r({
                                errcode: i ? 1003 : 1002,
                                errmsg: i ? "drawImage error" : "drawRect error",
                                e: t
                            });
                        }
                    }
                }, {
                    key: "_drawRectToCanvas",
                    value: function(t, e, n, r, i, o, a) {
                        var s = this, u = i.fill, c = i.border, l = i.boxShadow;
                        this.ctx.save(), this._drawBoxShadow(l, function(i) {
                            u && "string" != typeof u && !s.debug && (s.ctx.setFillStyle(i.color || "#ffffff"), 
                            s.ctx.fillRect(t, e, n, r));
                        }), o ? a ? this._resetImageByMode(o, t, e, n, r, a) : this.ctx.drawImage(o, t, e, n, r) : this._setFill(u, function() {
                            s.ctx.fillRect(t, e, n, r);
                        }), this._drawBorder(c, i, function(i) {
                            var o = i.width;
                            s.ctx.strokeRect(t - o / 2, e - o / 2, n + o, r + o);
                        }), this.ctx.draw(!0), this.ctx.restore();
                    }
                }, {
                    key: "_resetImageByMode",
                    value: function(t, e, n, r, i, o) {
                        var a = this, s = 0, u = 0, c = o.width, l = o.height;
                        switch (o.type) {
                          case "scaleToFill":
                            c = r, l = i, a.ctx.drawImage(t, e, n, r, i);
                            break;

                          case "widthFix":
                            i = r / ((c || 1) / (l || 1)), a.ctx.drawImage(t, e, n, r, i);
                            break;

                          case "aspectFit":
                            if (c > l) {
                                var f = r / ((c || 1) / (l || 1));
                                u = -(i - f) / 2, c = r, l = f;
                            } else {
                                var d = i / ((l || 1) / (c || 1));
                                s = -(r - d) / 2, c = d, l = i;
                            }
                            _();
                            break;

                          case "aspectFill":
                            if (c > l) {
                                var h = c / ((l || 1) / (i || 1));
                                s = (h - r) / 2, c = h, l = i;
                            } else {
                                var p = l / ((c || 1) / (r || 1));
                                u = (p - i) / 2, c = r, l = p;
                            }
                            _();
                            break;

                          case "top left":
                            _();
                            break;

                          case "top":
                            s = (o.width - r) / 2, _();
                            break;

                          case "top right":
                            s = o.width - r, _();
                            break;

                          case "left":
                            u = (o.height - i) / 2, _();
                            break;

                          case "center":
                            s = (o.width - r) / 2, u = (o.height - i) / 2, _();
                            break;

                          case "right":
                            s = o.width - r, u = (o.height - i) / 2, _();
                            break;

                          case "bottom left":
                            u = o.height - i, _();
                            break;

                          case "bottom":
                            s = (o.width - r) / 2, u = o.height - i, _();
                            break;

                          case "bottom right":
                            s = o.width - r, u = o.height - i, _();
                            break;

                          default:
                            c = r, l = i;
                        }
                        function _() {
                            a.ctx.save(), a.ctx.beginPath(), a.ctx.rect(e, n, r, i), a.ctx.clip(), a.ctx.drawImage(t, e - s, n - u, c, l), 
                            a.ctx.closePath(), a.ctx.restore();
                        }
                    }
                }, {
                    key: "_drawText",
                    value: function(t, e, n, r, i, o) {
                        var a = this.zoom, u = 0, c = 0;
                        try {
                            e.fontSize = this._parseNumber(e.fontSize);
                            var l = Math.ceil((e.fontSize || 14) * a);
                            this.ctx.setTextBaseline("top"), this.ctx.font = "".concat(e.fontWeight ? e.fontWeight : "normal", " ").concat(l, "px ").concat(e.fontFamily || "PingFang SC"), 
                            this.ctx.setFillStyle(e.color || "#454545");
                            var f = t.text || "", d = Math.floor(this.measureWidth(f, e.font || this.ctx.font)), h = this._getLineHeight(e), p = Math.ceil(d / (e.width || d)) * h, _ = Math.ceil((e.width || d) * (o ? 1 : a)), m = e.whiteSpace || "wrap", y = 0, g = 0;
                            if ("string" == typeof e.padding && (e.padding = s.default.transferPadding(e.padding)), 
                            t.x = this._resetPositionX(t, e), t.y = this._resetPositionY(t, e, p), this._drawBoxShadow(e.boxShadow), 
                            (e.background || e.border) && this._drawTextBackgroud(t, e, d, p, o), "inline-text" === i) if (_ = t.maxWidth, 
                            t.leftOffset + d > _) {
                                var v = Math.max(Math.floor(d / _), 1), b = f.length, w = Math.floor(b / v), x = t.leftOffset ? t.leftOffset - t.originX : 0, A = this._getTextSingleLine(f, _, w, 0, x), S = A.endIndex, T = A.single, P = A.singleWidth;
                                y = this._resetTextPositionX(t, e, P), g = this._resetTextPositionY(t, e), this.ctx.fillText(T, y, g), 
                                u = y + P, c = g, f = f.substring(S, f.length), S = 0, v = Math.max(Math.floor(d / _), 1), 
                                d = Math.floor(this.measureWidth(f, e.font || this.ctx.font)), t.x = t.originX;
                                for (var M = 0; M < v; M++) {
                                    var k = this._getTextSingleLine(f, _, w, S), E = k.endIndex, O = k.single, C = k.singleWidth;
                                    S = E, O && (y = this._resetTextPositionX(t, e, C, _), g = this._resetTextPositionY(t, e, M + 1), 
                                    this.ctx.fillText(O, y, g), M === v - 1 && (u = y + C, c = h * v));
                                }
                                var I = f.substring(S, b), R = this.measureWidth(I);
                                I && (y = this._resetTextPositionX(t, e, R, _), g = this._resetTextPositionY(t, e, v + 1), 
                                this.ctx.fillText(I, y, g), u = y + R, c = h * (v + 1));
                            } else y = this._resetTextPositionX(t, e, d, _), g = this._resetTextPositionY(t, e), 
                            this.ctx.fillText(t.text, y, g), u = y + d, c = h; else if (_ && d > _ && "nowrap" !== m) {
                                var L = Math.max(Math.floor(d / _), 1), N = f.length, j = Math.floor(N / L), D = 0;
                                e.lineClamp && L + 1 > e.lineClamp && (L = e.lineClamp - 1);
                                for (var B = 0; B < L; B++) {
                                    var U = this._getTextSingleLine(f, _, j, D), F = U.endIndex, H = U.single, $ = U.singleWidth;
                                    D = F, y = this._resetTextPositionX(t, e, $, _), g = this._resetTextPositionY(t, e, B), 
                                    this.ctx.fillText(H, y, g);
                                }
                                var V = f.substring(D, N), z = this.measureWidth(V);
                                if (z > _) {
                                    var Y = this._getTextSingleLine(V, _, j), G = Y.single;
                                    z = Y.singleWidth, V = G.substring(0, G.length - 1) + "...";
                                }
                                y = this._resetTextPositionX(t, e, z, _), g = this._resetTextPositionY(t, e, L), 
                                this.ctx.fillText(V, y, g);
                            } else y = this._resetTextPositionX(t, e, d, _), g = this._resetTextPositionY(t, e), 
                            this.ctx.fillText(t.text, y, g);
                            if (this.ctx.draw(!0), this._updateProgress(t.progress), !n) return {
                                leftOffset: u,
                                topOffset: c
                            };
                            n();
                        } catch (t) {
                            r && r({
                                errcode: 1004,
                                errmsg: "drawText error",
                                e: t
                            });
                        }
                    }
                }, {
                    key: "_drawTextBackgroud",
                    value: function(t, e, n, r, i) {
                        if (e.width) {
                            var o = i ? 1 : this.zoom, a = e.width || n, s = e.height || r, u = {
                                fill: e.background,
                                border: e.border
                            };
                            e.padding = e.padding || [ 0, 0, 0, 0 ], a += (e.padding[1] || 0) + (e.padding[3] || 0), 
                            s += (e.padding[0] || 0) + (e.padding[2] || 0), a *= o, s *= o, this._drawRectToCanvas(t.x, t.y, a, s, u);
                        }
                    }
                }, {
                    key: "_drawCircle",
                    value: function(t, e, n, r, i, o) {
                        var a = this.zoom, s = e.r;
                        try {
                            var u;
                            if (t.x = this._resetPositionX(t, e), t.y = this._resetPositionY(t, e), i) {
                                var c = this._findPicIndex(t.url);
                                u = c > -1 ? this.allPic[c].local : t.url;
                            }
                            o || (s *= a), this._drawCircleToCanvas(t.x, t.y, s, e, u), this._updateProgress(t.progress), 
                            n && n();
                        } catch (t) {
                            r && r({
                                errcode: i ? 1006 : 1005,
                                errmsg: i ? "drawCircleImage error" : "drawCircle error",
                                e: t
                            });
                        }
                    }
                }, {
                    key: "_drawCircleToCanvas",
                    value: function(t, e, n, r, i) {
                        var o = this, a = r.fill, s = r.border, u = r.boxShadow;
                        this.ctx.save(), this._drawBoxShadow(u, function(r) {
                            (a && "string" != typeof a || i && r.color) && (o.ctx.setFillStyle(r.color || "#ffffff"), 
                            o.ctx.beginPath(), o.ctx.arc(t + n, e + n, n, 0, 2 * Math.PI), o.ctx.closePath(), 
                            o.ctx.fill());
                        }), i ? (this.ctx.save(), this.ctx.beginPath(), this.ctx.arc(t + n, e + n, n, 0, 2 * Math.PI), 
                        this.ctx.clip(), this.ctx.drawImage(i, t, e, 2 * n, 2 * n), this.ctx.closePath(), 
                        this.ctx.restore()) : this._setFill(a, function() {
                            o.ctx.beginPath(), o.ctx.arc(t + n, e + n, n, 0, 2 * Math.PI), o.ctx.closePath(), 
                            o.ctx.fill();
                        }), this._drawBorder(s, r, function(r) {
                            o.ctx.beginPath(), o.ctx.arc(t + n, e + n, n + r.width / 2, 0, 2 * Math.PI), o.ctx.stroke(), 
                            o.ctx.closePath();
                        }), this.ctx.draw(!0), this.ctx.restore();
                    }
                }, {
                    key: "_drawLine",
                    value: function(t, e, n, r, i) {
                        var o = this.zoom;
                        try {
                            var a = t.x * o + this.translateX, s = t.y * o + this.translateY, u = t.x2 * o + this.translateX, c = t.y2 * o + this.translateY;
                            this._drawLineToCanvas(a, s, u, c, e), this._updateProgress(t.progress), n && n();
                        } catch (t) {
                            r && r({
                                errcode: 1007,
                                errmsg: "drawLine error",
                                e: t
                            });
                        }
                    }
                }, {
                    key: "_drawLineToCanvas",
                    value: function(t, e, n, r, i) {
                        var o = i.stroke, a = i.dash, s = i.boxShadow;
                        if (this.ctx.save(), o && this._setStroke(o), this._drawBoxShadow(s), a) {
                            var u = [ i.dash[0] || 5, i.dash[1] || 5 ], c = i.dash[2] || 0;
                            this.ctx.setLineDash(u, c || 0);
                        }
                        this.ctx.moveTo(t, e), this.ctx.setLineWidth((i.width || 1) * this.zoom), this.ctx.lineTo(n, r), 
                        this.ctx.stroke(), this.ctx.draw(!0), this.ctx.restore();
                    }
                }, {
                    key: "_drawImage",
                    value: function(t, e, n, r, i) {
                        var o = this.zoom;
                        try {
                            t.x = this._resetPositionX(t, e), t.y = this._resetPositionY(t, e), t.x = t.x + (e.padding[3] || 0), 
                            t.y = t.y + (e.padding[0] || 0);
                            var a = this._findPicIndex(t.url), s = a > -1 ? this.allPic[a].local : t.url;
                            this._drawImageToCanvas(s, t.x, t.y, e.width * o, e.height * o, e), this._updateProgress(t.progress), 
                            n && n();
                        } catch (t) {
                            r && r({
                                errcode: 1012,
                                errmsg: "drawRect error",
                                e: t
                            });
                        }
                    }
                }, {
                    key: "_drawImageToCanvas",
                    value: function(t, e, n, r, i, o) {
                        var a = this, s = (o.fill, o.border), u = o.boxShadow;
                        this.ctx.save(), this._drawBoxShadow(u), this.ctx.drawImage(t, e, n, r, i), this._drawBorder(s, o, function(t) {
                            var o = t.width;
                            a.ctx.strokeRect(e - o / 2, n - o / 2, r + o, i + o);
                        }), this.ctx.draw(!0), this.ctx.restore();
                    }
                }, {
                    key: "_drawWxml",
                    value: function(t, e, n, r) {
                        var i = this, o = this, a = [];
                        try {
                            this._getWxml(t, e).then(function(e) {
                                var s, u = o._sortListByTop(e[0]), c = 0;
                                Object.keys(u).forEach(function(t) {
                                    c += u[t].length;
                                }), s = 3 * i.distance / (c || 1), a = i._drawWxmlBlock(t, u, a, s, e[1]), a = i._drawWxmlInline(t, u, a, s, e[1]), 
                                Promise.all(a).then(function(t) {
                                    n && n();
                                }).catch(function(t) {
                                    r && r(t);
                                });
                            });
                        } catch (t) {
                            r && r({
                                errcode: 1008,
                                errmsg: "drawWxml error"
                            });
                        }
                    }
                }, {
                    key: "_drawWxmlBlock",
                    value: function(t, e, n, r, i) {
                        var o = this, a = i ? i.left : 0, s = i ? i.top : 0;
                        return Object.keys(e).forEach(function(i, u) {
                            var c = e[i].sort(function(t, e) {
                                return t.left - e.left;
                            });
                            (c = c.filter(function(t) {
                                return t.dataset.type && -1 === t.dataset.type.indexOf("inline");
                            })).forEach(function(e, i) {
                                n[i] = new Promise(function(n, i) {
                                    (e = o._transferWxmlStyle(e, t, a, s)).progress = r;
                                    var u = e.dataset.type;
                                    function c() {
                                        "text" === u ? o._drawWxmlText(e, n, i) : "image" === u ? o._drawWxmlImage(e, n, i) : "radius-image" === u ? o._drawWxmlCircleImage(e, n, i) : "background-image" === u && o._drawWxmlBackgroundImage(e, n, i);
                                    }
                                    e.dataset.delay ? setTimeout(function() {
                                        c();
                                    }, e.dataset.delay) : c();
                                });
                            });
                        }), n;
                    }
                }, {
                    key: "_drawWxmlInline",
                    value: function(t, e, n, r, i) {
                        var o = this, a = 0, s = 0, u = 0, c = i ? i.left : 0, l = i ? i.top : 0, f = new Promise(function(n, i) {
                            var f, d = 1 / 0, h = 0;
                            Object.keys(e).forEach(function(t) {
                                e[t].filter(function(t) {
                                    return t.dataset.type && t.dataset.type.indexOf("inline") > -1;
                                }).forEach(function(t) {
                                    t.left < d && (d = t.left), t.right > h && (h = t.right);
                                });
                            }), f = Math.ceil(h - d || o.width), Object.keys(e).forEach(function(n, i) {
                                for (var d = e[n].sort(function(t, e) {
                                    return t.left - e.left;
                                }), h = -1, p = 0, _ = d.length; p < _; p++) if (d[p] && d[p + 1] && d[p].bottom > d[p + 1].bottom) {
                                    h = p;
                                    break;
                                }
                                h > -1 && d.push(d.splice(h, 1)[0]);
                                var m = d.filter(function(t) {
                                    return t.dataset.type && t.dataset.type.indexOf("inline") > -1;
                                }), y = m[0] ? m[0].left : 0;
                                (Math.abs(a + u - n) > 2 || s - y - c >= f || s <= y - c - 2) && (s = 0), u = +n, 
                                a = 0, m.forEach(function(e, n) {
                                    (e = o._transferWxmlStyle(e, t, c, l)).progress = r;
                                    var i = e.dataset.type;
                                    if ("inline-text" === i) {
                                        var u = o._drawWxmlInlineText(e, s, f);
                                        s = u.leftOffset, a = u.topOffset;
                                    } else if ("inline-image" === i) {
                                        var d = o._drawWxmlImage(e) || {};
                                        s = d.leftOffset || 0, a = d.topOffset || 0;
                                    }
                                });
                            }), n();
                        });
                        return n.push(f), n;
                    }
                }, {
                    key: "_drawWxmlInlineText",
                    value: function(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, n = arguments.length > 2 ? arguments[2] : void 0, r = t.dataset.text || "";
                        t.dataset.maxlength && r.length > t.dataset.maxlength && (r = r.substring(0, t.dataset.maxlength) + "...");
                        var i = {
                            text: r,
                            originX: t.left,
                            x: e || t.left,
                            y: t.top,
                            progress: t.progress,
                            leftOffset: e,
                            maxWidth: n
                        };
                        "rgba(0, 0, 0, 0)" !== t.backgroundColor ? t.background = t.backgroundColor : t.background = "rgba(0, 0, 0, 0)", 
                        t.dataset.background && (t.background = t.dataset.background);
                        var o = this._drawText(i, t, null, null, "inline-text", "wxml");
                        return o;
                    }
                }, {
                    key: "_drawWxmlText",
                    value: function(t, e, n) {
                        var r = t.dataset.text || "";
                        t.dataset.maxlength && r.length > t.dataset.maxlength && (r = r.substring(0, t.dataset.maxlength) + "...");
                        var i = {
                            text: r,
                            x: t.left,
                            y: t.top,
                            progress: t.progress
                        };
                        "rgba(0, 0, 0, 0)" !== t.backgroundColor ? t.background = t.backgroundColor : t.background = "rgba(0, 0, 0, 0)", 
                        t.dataset.background && (t.background = t.dataset.background), this._drawText(i, t, e, n, "text", "wxml");
                    }
                }, {
                    key: "_drawWxmlImage",
                    value: function(t, e, n) {
                        var r = {
                            url: t.dataset.url,
                            x: t.left,
                            y: t.top,
                            progress: t.progress
                        };
                        return this._drawRect(r, t, e, n, "image", "inline-wxml");
                    }
                }, {
                    key: "_drawWxmlCircleImage",
                    value: function(t, e, n) {
                        var r = {
                            url: t.dataset.url,
                            x: t.left,
                            y: t.top,
                            progress: t.progress
                        };
                        t.r = t.width / 2, this._drawCircle(r, t, e, n, !0, "wxml");
                    }
                }, {
                    key: "_drawWxmlBackgroundImage",
                    value: function(t, e, n) {
                        var r = t.dataset.url, i = this._findPicIndex(r);
                        r = i > -1 ? this.allPic[i].local : r, t.backgroundSize.replace(/px/g, "").split(" ");
                        var o = {
                            url: r,
                            x: t.left,
                            y: t.top,
                            progress: t.progress
                        };
                        this._drawRect(o, t, e, n, "image", "wxml");
                    }
                }, {
                    key: "_getWxml",
                    value: function(e, n) {
                        var r, i = this;
                        r = this.object ? t.createSelectorQuery().in(this.object) : t.createSelectorQuery();
                        var o = new Promise(function(t, n) {
                            var o = 0;
                            r.selectAll("".concat(e.class)).fields({
                                dataset: !0,
                                size: !0,
                                rect: !0,
                                computedStyle: [ "width", "height", "font", "fontSize", "fontFamily", "fontWeight", "fontStyle", "textAlign", "color", "lineHeight", "border", "borderColor", "borderStyle", "borderWidth", "verticalAlign", "boxShadow", "background", "backgroundColor", "backgroundImage", "backgroundPosition", "backgroundSize", "paddingLeft", "paddingTop", "paddingRight", "paddingBottom" ]
                            }, function(e) {
                                if (0 == o++) {
                                    var r = i._formatImage(e), a = r.list;
                                    e = r.res, i._preloadImage(a).then(function(n) {
                                        t(e);
                                    }).catch(function(t) {
                                        n && n({
                                            errcode: 1009,
                                            errmsg: "drawWxml preLoadImage error"
                                        });
                                    });
                                }
                            }).exec();
                        }), a = new Promise(function(t, n) {
                            e.limit || t({
                                top: 0,
                                width: i.width / i.zoom
                            }), r.select("".concat(e.limit)).fields({
                                dataset: !0,
                                size: !0,
                                rect: !0
                            }, function(e) {
                                t(e);
                            }).exec();
                        });
                        return Promise.all([ o, a ]);
                    }
                }, {
                    key: "_getLineHeight",
                    value: function(t) {
                        var e, n = this.zoom;
                        return t.dataset && t.dataset.type && (n = 1), !isNaN(t.lineHeight) && t.lineHeight > t.fontSize ? e = t.lineHeight : (t.lineHeight = (t.lineHeight || "") + "", 
                        e = (e = +t.lineHeight.replace("px", "")) || 1.2 * (t.fontSize || 14)), e * n;
                    }
                }, {
                    key: "_formatImage",
                    value: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], e = [];
                        return t.forEach(function(n, i) {
                            var o = n.dataset, a = s.default.getUid(), u = "".concat(r.env.USER_DATA_PATH, "/").concat(a, ".png");
                            if ("image" !== o.type && "radius-image" !== o.type || !o.url) {
                                if ("background-image" === o.type && n.backgroundImage.indexOf("url") > -1) {
                                    var c = n.backgroundImage.replace(/url\((\"|\')?/, "").replace(/(\"|\')?\)$/, ""), l = {
                                        url: o.base64 ? u : c,
                                        isBase64: !!o.base64 && c
                                    };
                                    t[i].dataset = Object.assign(t[i].dataset, l), e.push(l);
                                }
                            } else {
                                var f = {
                                    url: o.base64 ? u : o.url,
                                    isBase64: !!o.base64 && o.url
                                };
                                t[i].dataset = Object.assign(t[i].dataset, f), e.push(f);
                            }
                        }), {
                            list: e,
                            res: t
                        };
                    }
                }, {
                    key: "_updateProgress",
                    value: function(t) {
                        this.progressPercent += t, this.progress(this.progressPercent);
                    }
                }, {
                    key: "_sortListByTop",
                    value: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], e = {};
                        return t.forEach(function(t, n) {
                            var r = t.top;
                            e[r] || (e[r - 2] ? r -= 2 : e[r - 1] ? r -= 1 : e[r + 1] ? r += 1 : e[r + 2] ? r += 2 : e[r] = []), 
                            e[r].push(t);
                        }), e;
                    }
                }, {
                    key: "_parseNumber",
                    value: function(t) {
                        return isNaN(t) ? +(t || "").replace("px", "") : t;
                    }
                }, {
                    key: "_transferWxmlStyle",
                    value: function(t, e, n, r) {
                        var i = +t.dataset.left || 0, o = +t.dataset.top || 0;
                        t.width = this._parseNumber(t.width), t.height = this._parseNumber(t.height), t.left = this._parseNumber(t.left) - n + (i + (e.x || 0)) * this.zoom, 
                        t.top = this._parseNumber(t.top) - r + (o + (e.y || 0)) * this.zoom;
                        var a = t.dataset.padding || "0 0 0 0";
                        "string" == typeof a && (a = s.default.transferPadding(a));
                        var u = Number(t.paddingTop.replace("px", "")) + Number(a[0]), c = Number(t.paddingRight.replace("px", "")) + Number(a[1]), l = Number(t.paddingBottom.replace("px", "")) + Number(a[2]), f = Number(t.paddingLeft.replace("px", "")) + Number(a[3]);
                        return t.padding = [ u, c, l, f ], t;
                    }
                }, {
                    key: "_resetPositionX",
                    value: function(t, e) {
                        var n = this.zoom, r = 0;
                        return e.dataset && e.dataset.type && (n = 1), r = t.x < 0 && t.type ? this.width + t.x * n - e.width * n : t.x * n, 
                        parseInt(e.borderWidth) && (r += parseInt(e.borderWidth)), r + this.translateX;
                    }
                }, {
                    key: "_resetPositionY",
                    value: function(t, e, n) {
                        var r = this.zoom, i = 0;
                        return e.dataset && e.dataset.type && (r = 1), i = t.y < 0 ? this.height + t.y * r - (n || e.height * r) : t.y * r, 
                        parseInt(e.borderWidth) && (i += parseInt(e.borderWidth)), i + this.translateY;
                    }
                }, {
                    key: "_resetTextPositionX",
                    value: function(t, e, n, r) {
                        var i = e.textAlign || "left", o = t.x;
                        return "center" === i ? o = (r - n) / 2 + t.x : "right" === i && (o = r - n + t.x), 
                        o + (e.padding && e.padding[3] || 0) + this.translateX;
                    }
                }, {
                    key: "_resetTextPositionY",
                    value: function(t, e) {
                        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0, r = this.zoom;
                        e.dataset && e.dataset.type && (r = 1);
                        var i = this._getLineHeight(e), o = Math.ceil((e.fontSize || 14) * r), a = (e.dataset && e.dataset.type || "").indexOf("inline") > -1 ? 0 : (i - o) / 2, s = e.padding && e.padding[0] || 0;
                        return t.y + a + n * i + s + this.translateY;
                    }
                }, {
                    key: "_getTextSingleLine",
                    value: function(t, e, n) {
                        for (var r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0, i = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0, o = 0, a = r + n + o, s = t.substring(r, a), u = this.measureWidth(s); Math.round(i + u) > e; ) a = r + n + --o, 
                        s = t.substring(r, a), u = this.measureWidth(s);
                        return {
                            endIndex: a,
                            single: s,
                            singleWidth: u
                        };
                    }
                }, {
                    key: "_drawBorder",
                    value: function(t, e, n) {
                        var r = this.zoom;
                        if (e.dataset && e.dataset.type && (r = 1), (t = s.default.transferBorder(t)) && t.width) {
                            if (this._drawBoxShadow(), t) {
                                if (this.ctx.setLineWidth(t.width * r), "dashed" === t.style) {
                                    var i = e.dash || [ 5, 5, 0 ], o = i[2] || 0, a = [ i[0] || 5, i[1] || 5 ];
                                    this.ctx.setLineDash(a, o);
                                }
                                this.ctx.setStrokeStyle(t.color);
                            }
                            n && n(t);
                        }
                    }
                }, {
                    key: "_drawBoxShadow",
                    value: function(t, e) {
                        (t = s.default.transferBoxShadow(t)) ? this.ctx.setShadow(t.offsetX, t.offsetY, t.blur, t.color) : this.ctx.setShadow(0, 0, 0, "#ffffff"), 
                        e && e(t || {});
                    }
                }, {
                    key: "_setFill",
                    value: function(t, e) {
                        if (t) {
                            if ("string" == typeof t) this.ctx.setFillStyle(t); else {
                                var n = t.line, r = t.color, i = this.ctx.createLinearGradient(n[0], n[1], n[2], n[3]);
                                i.addColorStop(0, r[0]), i.addColorStop(1, r[1]), this.ctx.setFillStyle(i);
                            }
                            e && e();
                        }
                    }
                }, {
                    key: "_setStroke",
                    value: function(t, e) {
                        if (t) {
                            if ("string" == typeof t) this.ctx.setStrokeStyle(t); else {
                                var n = t.line, r = t.color, i = this.ctx.createLinearGradient(n[0], n[1], n[2], n[3]);
                                i.addColorStop(0, r[0]), i.addColorStop(1, r[1]), this.ctx.setStrokeStyle(i);
                            }
                            e && e();
                        }
                    }
                } ]), e;
            }();
            e.default = c;
        }).call(this, n("543d").default, n("bc2e").default);
    },
    "3c96": function(t, e) {
        t.exports = function(t) {
            if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return t;
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    4082: function(t, e, n) {
        var r = n("f0e4");
        t.exports = function(t, e) {
            if (null == t) return {};
            var n, i, o = r(t, e);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(t);
                for (i = 0; i < a.length; i++) n = a[i], e.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(t, n) && (o[n] = t[n]);
            }
            return o;
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    "448a": function(t, e, n) {
        var r = n("2236"), i = n("11b0"), o = n("6613"), a = n("0676");
        t.exports = function(t) {
            return r(t) || i(t) || o(t) || a();
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    "44a2": function(t, e, n) {
        var r = n("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = r(n("970b")), o = r(n("5bc3")), a = r(n("ed6d")), s = r(n("6b58")), u = r(n("36c6")), c = r(n("e546")), l = n("f8e4"), f = r(n("b887"));
        var d = {
            loop: !0,
            vid: "605ea32bee649c04194fe0569b5882b1_6",
            autoplay: !0,
            obeyMuteSwitch: !1,
            volume: 1
        }, h = function(t) {
            (0, a.default)(n, t);
            var e = function(t) {
                var e = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
                        !0;
                    } catch (t) {
                        return !1;
                    }
                }();
                return function() {
                    var n, r = (0, u.default)(t);
                    if (e) {
                        var i = (0, u.default)(this).constructor;
                        n = Reflect.construct(r, arguments, i);
                    } else n = r.apply(this, arguments);
                    return (0, s.default)(this, n);
                };
            }(n);
            function n(t) {
                var r, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                return (0, i.default)(this, n), (r = e.call(this, d)).playType = "practice", r.mainConfig = null, 
                r.recordBase = 0, r.mediId = t, r.mediInfo = {}, r.startAtSecond = o, r.mediTimes = 0, 
                r.endMediHandler = null, r.mediComplete = !1, r.polyvVid = null, r.init(t), r;
            }
            return (0, o.default)(n, [ {
                key: "init",
                value: function(t) {
                    var e = this;
                    this.mediId = t, this.getPlayData(t).then(function() {
                        e.initBothPlayer({
                            vid: e.polyvVid,
                            title: e.mediInfo.title,
                            cover: e.mediInfo.cover
                        }, d).then(function() {
                            e.onProgress(function() {});
                        });
                    });
                }
            }, {
                key: "getPlayData",
                value: function(t) {
                    var e = this;
                    return (0, l.http)({
                        url: f.default.fetchBeforePlay,
                        data: {
                            meditatingId: t
                        }
                    }).then(function() {
                        return (0, l.http)({
                            url: f.default.fetchBookPlayInfo,
                            data: {
                                id: t
                            }
                        }).then(function(t) {
                            var n = t.code, r = t.data;
                            t.msg, console.log("medi api done", r), 1 == +n && (e.recordBase = r.todayLearnTime, 
                            e.mediInfo = r.meditatingInfo, e.duration = e.mediInfo.duration, e.mediTimes = r.practiceTimes, 
                            e.polyvVid = r.polyvVid);
                        });
                    });
                }
            }, {
                key: "changeMediId",
                value: function(t, e) {
                    var n = this;
                    console.info("替换音频"), this.mediId = t, this.startAtSecond = e, this.mediComplete = !1, 
                    this.getPlayData(t).then(function() {
                        n.polyvVid && n.changeVid({
                            vid: n.polyvVid,
                            title: n.mediInfo.title,
                            cover: n.mediInfo.cover
                        });
                    });
                }
            }, {
                key: "trackLearnTime",
                value: function() {
                    var t = this.getStayTime();
                    return console.log("学习时间", {
                        "play.objectName": "MEDITATING",
                        "play.objectPid": this.mediInfo.id,
                        "play.objectId": this.mediInfo.id,
                        "play.playTime": t + "",
                        "play.learningTime": this.recordBase + t + ""
                    }), (0, l.http)({
                        url: f.default.fetchCountTime,
                        data: {
                            "play.objectName": "MEDITATING",
                            "play.objectPid": this.mediInfo.id,
                            "play.objectId": this.mediInfo.id,
                            "play.playTime": t + "",
                            "play.learningTime": this.recordBase + t + ""
                        },
                        hideLoading: !0
                    });
                }
            }, {
                key: "fetchFinishRecord",
                value: function(t) {
                    var e = this.getStayTime(), n = {
                        objectName: "MEDITATING",
                        objectId: this.mediInfo.id,
                        objectChildId: 0,
                        startTimeStr: this.startTimeStr ? this.startTimeStr : p(),
                        recordSecond: e ? e + "" : 0,
                        iosStatus: 0,
                        platform: 4,
                        offline: 0,
                        playDone: t ? 1 : 0
                    };
                    [ null, void 0, "", NaN ].includes(n.startTimeStr) && (n.startTimeStr = p(new Date()));
                    var r = [ n ];
                    return console.log("播放记录", r), this.startTimeStr = "", (0, l.http)({
                        url: f.default.fetchPlayRecord,
                        data: {
                            visiteds: JSON.stringify(r)
                        }
                    });
                }
            }, {
                key: "endHandler",
                value: function(t, e) {
                    var n = this;
                    if (this.fetchFinishRecord(e), e) return (0, l.http)({
                        url: f.default.fetchPlayDone,
                        data: {
                            meditatingId: this.mediId
                        }
                    }).then(function(r) {
                        var i = r.code, o = r.data;
                        if (console.log("playDone", o), 1 * i == 1) {
                            var a = o.practiseTimes;
                            n.mediTimes = a;
                        }
                        "function" == typeof n.endMediHandler && (console.log("end handler", t, n.mediTimes), 
                        n.endMediHandler(t, e));
                    });
                    console.log("放弃冥想活动"), "function" == typeof this.endMediHandler && (console.log("end handler", t, this.mediTimes), 
                    this.endMediHandler(t, e));
                }
            }, {
                key: "saveStorageMediInfo",
                value: function() {}
            } ]), n;
        }(c.default), p = function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : new Date(), e = t.getFullYear(), n = t.getMonth() + 1 < 10 ? "0" + (t.getMonth() + 1) : t.getMonth() + 1, r = t.getDate() < 10 ? "0" + t.getDate() : t.getDate(), i = t.getHours() < 10 ? "0" + t.getHours() : t.getHours(), o = t.getMinutes() < 10 ? "0" + t.getMinutes() : t.getMinutes(), a = t.getSeconds() < 10 ? "0" + t.getSeconds() : t.getSeconds();
            return e + "-" + n + "-" + r + " " + i + ":" + o + ":" + a;
        }, _ = h;
        e.default = _;
    },
    "452e": function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0, e.default = {
            onShow: function() {
                this.$refs.bookPlayerBar && this.$refs.bookPlayerBar.bookPlayerBar_initPlayer && this.$refs.bookPlayerBar.bookPlayerBar_initPlayer();
            }
        };
    },
    4834: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.bgList = void 0, e.bgList = [ {
            header: "https://imgco.xinli001.com/ceping/resources/images/trinyMCE/a88f054ec3844b3ba213fe0e90adaee8.png",
            card: "https://imgco.xinli001.com/ceping/resources/images/trinyMCE/3cb846a709ef4c5ab35ab2b689f57a68.png"
        }, {
            header: "https://imgco.xinli001.com/ceping/resources/images/trinyMCE/ba7eec7224f24eb68375d7d983326c5f.png",
            card: "https://imgco.xinli001.com/ceping/resources/images/trinyMCE/2f8352711b42470db26437af6afc80b7.png"
        }, {
            header: "https://imgco.xinli001.com/ceping/resources/images/trinyMCE/998574262a474fc98654b66b974b85fa.png",
            card: "https://imgco.xinli001.com/ceping/resources/images/trinyMCE/f7160fbd6021451e86e60f6f3ae81d4c.png"
        }, {
            header: "https://imgco.xinli001.com/ceping/resources/images/trinyMCE/eebf5400ab7c460aa72424464b178a0f.png",
            card: "https://imgco.xinli001.com/ceping/resources/images/trinyMCE/3303107a276d4211a7fd0e92d6c30ec4.png"
        }, {
            header: "https://imgco.xinli001.com/ceping/resources/images/trinyMCE/8f2e330b9ec141569d6875c6fc29c155.png",
            card: "https://imgco.xinli001.com/ceping/resources/images/trinyMCE/75a9d090e917454590ab6ac1a43df6d6.png"
        } ];
    },
    "4a4b": function(t, e) {
        function n(e, r) {
            return t.exports = n = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                return t.__proto__ = e, t;
            }, t.exports.__esModule = !0, t.exports.default = t.exports, n(e, r);
        }
        t.exports = n, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    "4ea4": function(t, e) {
        t.exports = function(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    5268: function(t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGkAAABpCAYAAAA5gg06AAAAAXNSR0IArs4c6QAAEFpJREFUeAHtXXtwVNUZ/87uZhPyIAmPACGJCeGZAEkgCaAIhsSp7bTFVrE6ymiHGadVlNo62ocUbXU6+kcdH7UzjnZkxDJTpNXWdrSGlxV5BcIrCAlI5E0EEpIQkuzj9vfd7Ibdzd7NvXfvPpLdb+bsufc8vnPO99tzzneeV9AQoaampsSvWztnk9NUKJEjX5AoQNYLJJJy8DyCSEoiEkkksU0WiUS7IKmVBLWRJGBLlyRJHDObxREhxJGsZEtjcXFx71AovojWTNbuPDROIudCCHoBkfNmCH0uALAamF8HwDoGflsB5KdmK22tKitrM5C/YayiCqRP6xryyGG7SziluyG4BRL++oaVdHBGDhKijiT62GK1rquaW3x88CjhCRFOIfgt0edHj6Z1t3b9GE3V/Wi6Kv0GioSjEJ8LIb2TlJ78t4XTp3dEIgvuNCMG0rZdBwrsTudjTiGtwL93pDtDUWcL6hKSab1IMP+hunzWiUjkL+wgbd61r8TpFGvQkC1FH2OKRKF1pumAgrIuQdALi+eXNenkoSta2ED6rO7IhF579/NQAB4aYuD4CpYVjvVmiVZXLShr9vUMxXvIQaqrO5fcZr/wJMB5CuCkhKIQEeGJZhCKxrOWytKXq4SwhzIPIQVp8576WxwOehfgFISyEJHkjVp1QJjFw9UVpbtDlY+QgFRXJyW02fc/JxE9PcSbNnVyF8IJQb42Ic36VCgGyIaDtG3HoRk2sr8HdbpMXQmHTygoFrsTzJa7F1fOOm1kqQwFadPuA99zOp3rh1Xfo1HaQtAlMtN9NRVzajVGVQxumApcu7N+FQD6IJYBYilLEo2RHOKT2l31v1aUukaPoGsSpm7Mm3btfwX2oxrTHvbBoVS8UT2vdCVsdM/6KSiQXArCBgC0VH8WhndM9FNrq+eXrgBQDr0l1Q2Sqwath71Mb+KxEg8AbciwlN5fXi5sesqsq08CMGLTzv1vxwFSJ3KWE4Yk3OKY1cXwDqULJPRBr0PFftCbVfwtkAQA0FLuuwOFUfLTDBJrLUjwESWGcXdlCUBuj7IWrBzCv4+mPql2z74aVi9jYhbBv7yCd8XshMlkurO6suRfapmpBmnb7kO5NqdtH48D1DKPh1OQgBDXrJKlYvGCWV8qhPByVtXcNTQ0WG0O+/txgLxkp/8FqwE2sq3jIYwaJqpAOt/R+1JULW2rKVmUh8Hodg5PQqvJ5qDN3aY9+yudDmlHvB9SI06NYdA/mc20aElF2fZAMQOCtEWSLI5d++uglZQEYqLFz4QZSCfazaFI6anJNDYznSwWC/XabHTlaie1dXQGVxQhTmZaxs0sL8/uUmJkUfJgd/vu/U+gBgUN0Kj0NJqYNZrGoIBmk4nsdgcK2EGnLrSgkNcCZSEq/DLSUmjGpDxKGcH7Lm/QpByi9s4uOnyimbqu99zw0PKEBVFeuUaU3ylFU6xJW3bU59uF1ICdPMlKkdW4FxfeRBPGjlIMeuL0eTp59oKif6Q9+A9WMnUSmc3K3XdPr43qGhrpeo/ODbHQ9hItiVMWlRed91dexZSxNeb3wQI0a0pBQIA4Q4W5Eyhv/Fh/eYu424hEK5VOCwwQZzLRmkBzZkzGlgfF/3zgskDb4006SoH8ct22s35KrySxDq9rrokTGz8mk2ZOzufHQQl9Hn1e30D8j9RCLJzkpERKQB9hwT/dgl7YDMPklJxoqbFR2Smh/7DLvHvQj3Aa7K6GuInjZlotHWw8SS1XdO5UZiVCSHOWzJtzwDc9v30SRPUMAuoGiBPJGad+zMv/wOyxoxWbPVY20lKSKR19A3feqckjiP/lGLn7lmfQdwaoq7uHOruuUwdM57Xr1IrO3+FwDojLSoIWykazrhsk7EF0SmIN0vuhb5oDQNpUd6jQabPd7xtQyztXz/RUbbu3xo5K9wIpCbWEFQ12z0xL1QWIvzzzH4IVADbjRmfKQRi4q1AArlxtlxUaVma4D7ImDBCPP5b9br6KRb+HygfeMMo7exfPKznpGWVALiSb41cIEFQtsljMmttnbrJYMOMhuIlZY2gkaky4iIFjDY7NpJwJ1N3bSxcvtWpOPuihBWpTLzkfR8JPeCbu1Sfx5vnrbV0XglUYOIGqyhJZ3fZMLNAzjztYPXf3KYHCRqvfxcttdKjJqxJoz6qg9hEZyTmehwS8GvXuq133GAEQ50xr22xNSBjSAHGZL16+wlZwhMMLfadMbrDxAgkLrg/d8Aru6VzL5eAYDLHYPDhvuXLVoFwLL52gH6QtexsmQzddaFAq1NreSc1nLxrFLqr5MEAHjn1lWB55Mls+UOfi2A+Sw2ZbblgqLkbHT5+jU+dbjGYbNfxYK2xt76D9R0+QwzlQhQ8qozjx6I7fDxJq0R1uRyPtxq/PUuPXZ4wvhJGZ1MmLtcLMkWk0e2qBPJDWycZvNPlIqstH1u621Ndn2LulS3ALSvX2l9qknPGyWuvPbzi58bzdwcavqAODYyMIfwDJbLJmV1UWX5BrkrNXVIGxoQAx+kWYVuFxRywQz4CUF01BzUo1pLhoSoXdab+FmckgwaHGEM4uJtwMlEwvpGwN815Gph8pXjzGK0O5x2QacwQYm15v5rL0gUQS1yRDiGvQbMx+j8kwJqOGZCqMTHg+cTaWNrJGZQSfqkQLmIngTSbn2nt4VdCQ5m7m5JswA668fhR8zocGB5wwoXpofTwU0U1C9OaPTh1paumyTwUTQwDitaE4QH2Q9NWoggGruZoAww0wfFWPCf1RkaaICoG5ecvPHqfgG5vOPGlcij5K62y6l7Rwl5LJ4QgeJNZsitHMscIQJ28JyLLBFgK9xJddYT1NmqaXgTteUWGevDrqfo/b3hIYjVYmb0KWt6PKN5xvKjDhmjH1S6h+GLOazaPuOAWWwOTcbKwu48Y37QSQhNS3PKk9stzWTs2bqCNm7EUxmQTxzimtHQImW3NQk0i3Qj8tPxcbBQ1RDGMCNd6bkatxZxRO2yabcJ2MrprES83jRuvGNyZA8VfISRimaNL2BCWiEkq6pga4jY2TdgnwtrPJeVpkJ5J4WsiuNSkeE2UYNJGoNe3hEH4CZmR4v6Aqwp2yUBxEt6rAHoEK47XIQxraH3k8mT9R9cDfgpokaQKJa5FOVVJ7aYZxDK5NPNAdjKAztAMkbTVJq3YyWCZi1Z9rk5oBLl+bDe1OUr2UyO0onzKIkzES4NrE46dAhF2trQgizgQK5OnHpx/i83OeEgnumceY7q3OSpyEJNpYu1O15ZI3zY8PcM5IKRE97p3XFA+96WGnKk7TiVN07sI3qsIaGSgHW6oDEr4MwM2dKpB48zzr+KGkq1ggu+ehp6nituX04E/W0HWcfggHPfP8G/T9e5+g25c+Qh98tCUcSfanwSdF+HCCEmGrwzE0d+ZmpQCe7uGYXfjg31vpUMNxOdndew/TJ7VfeGYhJM8dOE2x8cNNMm9eTV27/qOQpBOI6dgAS+38bQ0TmZyDXkjOG+m5JoWaUjC35UmpGo/PeMZV+5yMIzBZOPDmpjxM24SbAp2Dgg5wxHJTZurB5sudvdgcqai08+4XBirU9IPvVtFRnJbbvvMA1dw2j6oXV4Q6Sfm4zZuvrqa31v6D0tD0rPrpfSFP0zcBnr3hrsSOq599yMFfp5H1v9qd+77Ajll5Z4pPIPmV98/F2vYsf3IIpRtvVb7U1u6VBNeimvllxa7qYQrY+MfHRl6yC8kLKxB+aCu7ySBh6mGHnwCyE09dJKmYvlCKH3dXJwFe+hlA+K4Tu8kgCTLhMzT+L3ONL40PEF1IHEamDADJwR/e4sTkM7M182ddrN1Rz7VJ3tbKHm4yam+zm5/R9tHGZtpZdwgKRzN1Qp3uwcb50ViMzMbsyNzS6TSvYlbIx3dGlInPC3OL1e2+sAMf3HJ/GU0GiRORTOJ9XH4wAKRonfHm8c0vn32VNm/bE1BG6dCcfvHYclp2Z03AcNHgyXOj/SDhi2juPN3Qq80JG92Obpvn6ZKTvO/TcftF2uaZgcEA4jzyLMZvX/gz/ee/AS/CinRx5PQ9FwL5k3XuTPWDdHt58Sn+1oLbg22+l2CwWVrP8OF8XrKognJx9kkN8Z8tIyP6Z+/715fwqTrPbwr2g9RXWOk9z0KnJkdnLeI8TszOog/X/5GefHw5zS6e4nd2PhV3QSzBgHjD2hfp5srZnkWLymfelswEHe4d+cH147WY4brH4Qy2ecmbU3iziYZlXk++YX+24f6g8xcv0WXc7ZOYmEip2IiYAyD1XG0T9sy7EuRrFQ42nezCPQ7jFe9x6PMQf3FnMilReXbWHSZa7ARcMZOH5q9s9nQqmlYgPw8lgFiOCXyTDD7y6AkQu/s0d0RWYXoV9U0+Sp1oVZzO47hxMlgCOCno4K9w+rIdABJfPoRh7YcckK8qi1P4JIBr39b5+0zqAJA4SyaT9BzXpkCLUeHLesyk5DBJlhf8ldYvSHwxntVsfmeoten+CjiE3Nanpyc1+cuvX5A4YEqKhS8mjP5bbP2Vaui58aaO1UrZVgSpvEi+tPUlpYhxd0Ml8CwG3M1KHL3GSb6BcJ42GW6HYQp8/eLvhkngADiVAyTFPfmKNYmzgIhcDZfDGHy7EXOPEyTAcn04EEAspYAgcQAw2A7rRX6Ok+ESeA3y9Zov9ZdCwObOHQHNHg+YdsGUud3idtASYHBuBUi9g3FSBRIzAVAzYPHizYAlRPaPkyYJ8I1ocwDQaTWxBm3u3EzA8Es8836neP/kFoo+m+V3n1qAOAnVIHFgMOZPnP2cn+OkWwKrIcdaLbFVN3eeTNH0vY73Rz3d4s+qJPAGANIsN001ySMbq/AsT8J6uEX08ZNNO+j4V95N/De4gH3lky9SyzdXIpo3V+JrYa/Uk5H+jShaIuPf4EBtWoY478GwHXGaUzqDFt2xgu6961t0263l9Nn2vfRx7Q564EffoawwHdkJIIQN8ONPa0sBwih66Wru3NwAFJ+FeRvmQbdbJO2z51po4z8308HDjbRwQSlVYz95rvoDxKHKOrc4ywCQTW8CQYHEiQIo5sF91CP8HicvCfwJb6u45fFy1fiit0/qT4arMAx3hr+BiavnfZJhOfwMclkZLEDMLuia1Jenvl/Uqtvx9FeYMZ7uMfbMyzs8DuLhiiFkKEicIwCVC+t9mEp+jzHah/I+AIB44G8YBd3c+eYEGWQ9+FaYV2BipfnjcvIGkvlGAwSexjZ3zNCTUKu4Nr0JU+LpPsye+WD4coDDqwUhIcNrkmcukXGe6S2HeQqG16aGE3HfswZmZigBCqvAUKvyYd6FscMMZeKB/Nsw4T8BHS7EULgpMGthhhpYDM7fYYZz0+39N0BhC2HegrkGE810FZl7GabAuwQx9IbCp8GsgPkfTDTRLmTmcZiIn5kxfJwUzP8LApmM+A/AfBtmLgzPDYaLePKTj6TyGG8jlIFT4Up4sHSiCiTPzAIwvoW3CqbGZU+FbSRovLdgLwwD8wUMH+6+CDvqKGpB8pUUQLPCjYEqcplpsHn6KROGAWWbz1Xx/jW+DbPHZbPqfwaGxzPNLvsE7IMAhcNEPf0f6oRiFK48Xp0AAAAASUVORK5CYII=";
    },
    "543d": function(t, e, n) {
        (function(t, r) {
            var i = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.createApp = Se, e.createComponent = Re, e.createPage = Ie, e.createPlugin = Ne, 
            e.createSubpackageApp = Le, e.default = void 0;
            var o, a = i(n("278c")), s = i(n("9523")), u = i(n("b17c")), c = i(n("448a")), l = i(n("7037")), f = n("37dc"), d = i(n("66fd"));
            function h(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function p(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? h(Object(n), !0).forEach(function(e) {
                        (0, s.default)(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : h(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            var _ = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", m = /^(?:[A-Za-z\d+/]{4})*?(?:[A-Za-z\d+/]{2}(?:==)?|[A-Za-z\d+/]{3}=?)?$/;
            function y() {
                var e, n = t.getStorageSync("uni_id_token") || "", r = n.split(".");
                if (!n || 3 !== r.length) return {
                    uid: null,
                    role: [],
                    permission: [],
                    tokenExpired: 0
                };
                try {
                    e = JSON.parse(function(t) {
                        return decodeURIComponent(o(t).split("").map(function(t) {
                            return "%" + ("00" + t.charCodeAt(0).toString(16)).slice(-2);
                        }).join(""));
                    }(r[1]));
                } catch (t) {
                    throw new Error("获取当前用户信息出错，详细错误信息为：" + t.message);
                }
                return e.tokenExpired = 1e3 * e.exp, delete e.exp, delete e.iat, e;
            }
            o = "function" != typeof atob ? function(t) {
                if (t = String(t).replace(/[\t\n\f\r ]+/g, ""), !m.test(t)) throw new Error("Failed to execute 'atob' on 'Window': The string to be decoded is not correctly encoded.");
                var e;
                t += "==".slice(2 - (3 & t.length));
                for (var n, r, i = "", o = 0; o < t.length; ) e = _.indexOf(t.charAt(o++)) << 18 | _.indexOf(t.charAt(o++)) << 12 | (n = _.indexOf(t.charAt(o++))) << 6 | (r = _.indexOf(t.charAt(o++))), 
                i += 64 === n ? String.fromCharCode(e >> 16 & 255) : 64 === r ? String.fromCharCode(e >> 16 & 255, e >> 8 & 255) : String.fromCharCode(e >> 16 & 255, e >> 8 & 255, 255 & e);
                return i;
            } : atob;
            var g = Object.prototype.toString, v = Object.prototype.hasOwnProperty;
            function b(t) {
                return "function" == typeof t;
            }
            function w(t) {
                return "string" == typeof t;
            }
            function x(t) {
                return "[object Object]" === g.call(t);
            }
            function A(t, e) {
                return v.call(t, e);
            }
            function S() {}
            function T(t) {
                var e = Object.create(null);
                return function(n) {
                    return e[n] || (e[n] = t(n));
                };
            }
            var P = /-(\w)/g, M = T(function(t) {
                return t.replace(P, function(t, e) {
                    return e ? e.toUpperCase() : "";
                });
            });
            function k(t) {
                var e = {};
                return x(t) && Object.keys(t).sort().forEach(function(n) {
                    e[n] = t[n];
                }), Object.keys(e) ? e : t;
            }
            var E = [ "invoke", "success", "fail", "complete", "returnValue" ], O = {}, C = {};
            function I(t, e) {
                Object.keys(e).forEach(function(n) {
                    -1 !== E.indexOf(n) && b(e[n]) && (t[n] = function(t, e) {
                        var n = e ? t ? t.concat(e) : Array.isArray(e) ? e : [ e ] : t;
                        return n ? function(t) {
                            for (var e = [], n = 0; n < t.length; n++) -1 === e.indexOf(t[n]) && e.push(t[n]);
                            return e;
                        }(n) : n;
                    }(t[n], e[n]));
                });
            }
            function R(t, e) {
                t && e && Object.keys(e).forEach(function(n) {
                    -1 !== E.indexOf(n) && b(e[n]) && function(t, e) {
                        var n = t.indexOf(e);
                        -1 !== n && t.splice(n, 1);
                    }(t[n], e[n]);
                });
            }
            function L(t) {
                return function(e) {
                    return t(e) || e;
                };
            }
            function N(t) {
                return !!t && ("object" === (0, l.default)(t) || "function" == typeof t) && "function" == typeof t.then;
            }
            function j(t, e) {
                for (var n = !1, r = 0; r < t.length; r++) {
                    var i = t[r];
                    if (n) n = Promise.resolve(L(i)); else {
                        var o = i(e);
                        if (N(o) && (n = Promise.resolve(o)), !1 === o) return {
                            then: function() {}
                        };
                    }
                }
                return n || {
                    then: function(t) {
                        return t(e);
                    }
                };
            }
            function D(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return [ "success", "fail", "complete" ].forEach(function(n) {
                    if (Array.isArray(t[n])) {
                        var r = e[n];
                        e[n] = function(e) {
                            j(t[n], e).then(function(t) {
                                return b(r) && r(t) || t;
                            });
                        };
                    }
                }), e;
            }
            function B(t, e) {
                var n = [];
                Array.isArray(O.returnValue) && n.push.apply(n, (0, c.default)(O.returnValue));
                var r = C[t];
                return r && Array.isArray(r.returnValue) && n.push.apply(n, (0, c.default)(r.returnValue)), 
                n.forEach(function(t) {
                    e = t(e) || e;
                }), e;
            }
            function U(t) {
                var e = Object.create(null);
                Object.keys(O).forEach(function(t) {
                    "returnValue" !== t && (e[t] = O[t].slice());
                });
                var n = C[t];
                return n && Object.keys(n).forEach(function(t) {
                    "returnValue" !== t && (e[t] = (e[t] || []).concat(n[t]));
                }), e;
            }
            function F(t, e, n) {
                for (var r = arguments.length, i = new Array(r > 3 ? r - 3 : 0), o = 3; o < r; o++) i[o - 3] = arguments[o];
                var a = U(t);
                if (a && Object.keys(a).length) {
                    if (Array.isArray(a.invoke)) {
                        var s = j(a.invoke, n);
                        return s.then(function(t) {
                            return e.apply(void 0, [ D(a, t) ].concat(i));
                        });
                    }
                    return e.apply(void 0, [ D(a, n) ].concat(i));
                }
                return e.apply(void 0, [ n ].concat(i));
            }
            var H = {
                returnValue: function(t) {
                    return N(t) ? new Promise(function(e, n) {
                        t.then(function(t) {
                            t[0] ? n(t[0]) : e(t[1]);
                        });
                    }) : t;
                }
            }, $ = /^\$|Window$|WindowStyle$|sendHostEvent|sendNativeEvent|restoreGlobal|requireGlobal|getCurrentSubNVue|getMenuButtonBoundingClientRect|^report|interceptors|Interceptor$|getSubNVueById|requireNativePlugin|upx2px|hideKeyboard|canIUse|^create|Sync$|Manager$|base64ToArrayBuffer|arrayBufferToBase64|getLocale|setLocale|invokePushCallback|getWindowInfo|getDeviceInfo|getAppBaseInfo|getSystemSetting|getAppAuthorizeSetting|initUTS|requireUTS|registerUTS/, V = /^create|Manager$/, z = [ "createBLEConnection" ], Y = [ "createBLEConnection", "createPushMessage" ], G = /^on|^off/;
            function W(t) {
                return V.test(t) && -1 === z.indexOf(t);
            }
            function K(t) {
                return $.test(t) && -1 === Y.indexOf(t);
            }
            function X(t) {
                return t.then(function(t) {
                    return [ null, t ];
                }).catch(function(t) {
                    return [ t ];
                });
            }
            function J(t, e) {
                return function(t) {
                    return !(W(t) || K(t) || function(t) {
                        return G.test(t) && "onPush" !== t;
                    }(t));
                }(t) && b(e) ? function() {
                    for (var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), o = 1; o < r; o++) i[o - 1] = arguments[o];
                    return b(n.success) || b(n.fail) || b(n.complete) ? B(t, F.apply(void 0, [ t, e, n ].concat(i))) : B(t, X(new Promise(function(r, o) {
                        F.apply(void 0, [ t, e, Object.assign({}, n, {
                            success: r,
                            fail: o
                        }) ].concat(i));
                    })));
                } : e;
            }
            Promise.prototype.finally || (Promise.prototype.finally = function(t) {
                var e = this.constructor;
                return this.then(function(n) {
                    return e.resolve(t()).then(function() {
                        return n;
                    });
                }, function(n) {
                    return e.resolve(t()).then(function() {
                        throw n;
                    });
                });
            });
            var Q, q = !1, Z = 0, tt = 0, et = {};
            Q = it(t.getSystemInfoSync().language) || "en", function() {
                if ("undefined" != typeof __uniConfig && __uniConfig.locales && Object.keys(__uniConfig.locales).length) {
                    var t = Object.keys(__uniConfig.locales);
                    t.length && t.forEach(function(t) {
                        var e = et[t], n = __uniConfig.locales[t];
                        e ? Object.assign(e, n) : et[t] = n;
                    });
                }
            }();
            var nt = (0, f.initVueI18n)(Q, {}), rt = nt.t;
            function it(t, e) {
                if (t) return t = t.trim().replace(/_/g, "-"), e && e[t] ? t : "chinese" === (t = t.toLowerCase()) ? "zh-Hans" : 0 === t.indexOf("zh") ? t.indexOf("-hans") > -1 ? "zh-Hans" : t.indexOf("-hant") > -1 || function(t, e) {
                    return !![ "-tw", "-hk", "-mo", "-cht" ].find(function(e) {
                        return -1 !== t.indexOf(e);
                    });
                }(t) ? "zh-Hant" : "zh-Hans" : function(t, e) {
                    return [ "en", "fr", "es" ].find(function(e) {
                        return 0 === t.indexOf(e);
                    });
                }(t) || void 0;
            }
            function ot() {
                if (b(getApp)) {
                    var e = getApp({
                        allowDefault: !0
                    });
                    if (e && e.$vm) return e.$vm.$locale;
                }
                return it(t.getSystemInfoSync().language) || "en";
            }
            nt.mixin = {
                beforeCreate: function() {
                    var t = this, e = nt.i18n.watchLocale(function() {
                        t.$forceUpdate();
                    });
                    this.$once("hook:beforeDestroy", function() {
                        e();
                    });
                },
                methods: {
                    $$t: function(t, e) {
                        return rt(t, e);
                    }
                }
            }, nt.setLocale, nt.getLocale;
            var at = [];
            void 0 !== r && (r.getLocale = ot);
            var st, ut = {
                promiseInterceptor: H
            }, ct = Object.freeze({
                __proto__: null,
                upx2px: function(e, n) {
                    if (0 === Z && function() {
                        var e = t.getSystemInfoSync(), n = e.platform, r = e.pixelRatio, i = e.windowWidth;
                        Z = i, tt = r, q = "ios" === n;
                    }(), 0 === (e = Number(e))) return 0;
                    var r = e / 750 * (n || Z);
                    return r < 0 && (r = -r), 0 === (r = Math.floor(r + 1e-4)) && (r = 1 !== tt && q ? .5 : 1), 
                    e < 0 ? -r : r;
                },
                getLocale: ot,
                setLocale: function(t) {
                    var e = !!b(getApp) && getApp();
                    return !!e && (e.$vm.$locale !== t && (e.$vm.$locale = t, at.forEach(function(e) {
                        return e({
                            locale: t
                        });
                    }), !0));
                },
                onLocaleChange: function(t) {
                    -1 === at.indexOf(t) && at.push(t);
                },
                addInterceptor: function(t, e) {
                    "string" == typeof t && x(e) ? I(C[t] || (C[t] = {}), e) : x(t) && I(O, t);
                },
                removeInterceptor: function(t, e) {
                    "string" == typeof t ? x(e) ? R(C[t], e) : delete C[t] : x(t) && R(O, t);
                },
                interceptors: ut
            });
            function lt(e) {
                (st = st || t.getStorageSync("__DC_STAT_UUID")) || (st = Date.now() + "" + Math.floor(1e7 * Math.random()), 
                t.setStorage({
                    key: "__DC_STAT_UUID",
                    data: st
                })), e.deviceId = st;
            }
            function ft(t) {
                if (t.safeArea) {
                    var e = t.safeArea;
                    t.safeAreaInsets = {
                        top: e.top,
                        left: e.left,
                        right: t.windowWidth - e.right,
                        bottom: t.screenHeight - e.bottom
                    };
                }
            }
            function dt(t, e) {
                for (var n = t.deviceType || "phone", r = {
                    ipad: "pad",
                    windows: "pc",
                    mac: "pc"
                }, i = Object.keys(r), o = e.toLocaleLowerCase(), a = 0; a < i.length; a++) {
                    var s = i[a];
                    if (-1 !== o.indexOf(s)) {
                        n = r[s];
                        break;
                    }
                }
                return n;
            }
            function ht(t) {
                var e = t;
                return e && (e = t.toLocaleLowerCase()), e;
            }
            function pt(t) {
                return ot ? ot() : t;
            }
            function _t(t) {
                var e = t.hostName || "WeChat";
                return t.environment ? e = t.environment : t.host && t.host.env && (e = t.host.env), 
                e;
            }
            var mt = {
                returnValue: function(t) {
                    lt(t), ft(t), function(t) {
                        var e, n = t.brand, r = void 0 === n ? "" : n, i = t.model, o = void 0 === i ? "" : i, a = t.system, s = void 0 === a ? "" : a, u = t.language, c = void 0 === u ? "" : u, l = t.theme, f = t.version, d = (t.platform, 
                        t.fontSizeSetting), h = t.SDKVersion, p = t.pixelRatio, _ = t.deviceOrientation, m = "";
                        m = s.split(" ")[0] || "", e = s.split(" ")[1] || "";
                        var y = f, g = dt(t, o), v = ht(r), b = _t(t), w = _, x = p, A = h, S = c.replace(/_/g, "-"), T = {
                            appId: "__UNI__8384F39",
                            appName: "冥想星球",
                            appVersion: "1.0.0",
                            appVersionCode: "100",
                            appLanguage: pt(S),
                            uniCompileVersion: "3.7.9",
                            uniRuntimeVersion: "3.7.9",
                            uniPlatform: "mp-weixin",
                            deviceBrand: v,
                            deviceModel: o,
                            deviceType: g,
                            devicePixelRatio: x,
                            deviceOrientation: w,
                            osName: m.toLocaleLowerCase(),
                            osVersion: e,
                            hostTheme: l,
                            hostVersion: y,
                            hostLanguage: S,
                            hostName: b,
                            hostSDKVersion: A,
                            hostFontSizeSetting: d,
                            windowTop: 0,
                            windowBottom: 0,
                            osLanguage: void 0,
                            osTheme: void 0,
                            ua: void 0,
                            hostPackageName: void 0,
                            browserName: void 0,
                            browserVersion: void 0
                        };
                        Object.assign(t, T, {});
                    }(t);
                }
            }, yt = {
                redirectTo: {
                    name: function(t) {
                        return "back" === t.exists && t.delta ? "navigateBack" : "redirectTo";
                    },
                    args: function(t) {
                        if ("back" === t.exists && t.url) {
                            var e = function(t) {
                                for (var e = getCurrentPages(), n = e.length; n--; ) {
                                    var r = e[n];
                                    if (r.$page && r.$page.fullPath === t) return n;
                                }
                                return -1;
                            }(t.url);
                            if (-1 !== e) {
                                var n = getCurrentPages().length - 1 - e;
                                n > 0 && (t.delta = n);
                            }
                        }
                    }
                },
                previewImage: {
                    args: function(t) {
                        var e = parseInt(t.current);
                        if (!isNaN(e)) {
                            var n = t.urls;
                            if (Array.isArray(n)) {
                                var r = n.length;
                                if (r) return e < 0 ? e = 0 : e >= r && (e = r - 1), e > 0 ? (t.current = n[e], 
                                t.urls = n.filter(function(t, r) {
                                    return !(r < e) || t !== n[e];
                                })) : t.current = n[0], {
                                    indicator: !1,
                                    loop: !1
                                };
                            }
                        }
                    }
                },
                getSystemInfo: mt,
                getSystemInfoSync: mt,
                showActionSheet: {
                    args: function(t) {
                        "object" === (0, l.default)(t) && (t.alertText = t.title);
                    }
                },
                getAppBaseInfo: {
                    returnValue: function(t) {
                        var e = t, n = e.version, r = e.language, i = e.SDKVersion, o = e.theme, a = _t(t), s = r.replace("_", "-");
                        t = k(Object.assign(t, {
                            appId: "__UNI__8384F39",
                            appName: "冥想星球",
                            appVersion: "1.0.0",
                            appVersionCode: "100",
                            appLanguage: pt(s),
                            hostVersion: n,
                            hostLanguage: s,
                            hostName: a,
                            hostSDKVersion: i,
                            hostTheme: o
                        }));
                    }
                },
                getDeviceInfo: {
                    returnValue: function(t) {
                        var e = t, n = e.brand, r = e.model, i = dt(t, r), o = ht(n);
                        lt(t), t = k(Object.assign(t, {
                            deviceType: i,
                            deviceBrand: o,
                            deviceModel: r
                        }));
                    }
                },
                getWindowInfo: {
                    returnValue: function(t) {
                        ft(t), t = k(Object.assign(t, {
                            windowTop: 0,
                            windowBottom: 0
                        }));
                    }
                },
                getAppAuthorizeSetting: {
                    returnValue: function(t) {
                        var e = t.locationReducedAccuracy;
                        t.locationAccuracy = "unsupported", !0 === e ? t.locationAccuracy = "reduced" : !1 === e && (t.locationAccuracy = "full");
                    }
                },
                compressImage: {
                    args: function(t) {
                        t.compressedHeight && !t.compressHeight && (t.compressHeight = t.compressedHeight), 
                        t.compressedWidth && !t.compressWidth && (t.compressWidth = t.compressedWidth);
                    }
                }
            }, gt = [ "success", "fail", "cancel", "complete" ];
            function vt(t, e, n) {
                return function(r) {
                    return e(wt(t, r, n));
                };
            }
            function bt(t, e) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {}, i = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
                if (x(e)) {
                    var o = !0 === i ? e : {};
                    for (var a in b(n) && (n = n(e, o) || {}), e) if (A(n, a)) {
                        var s = n[a];
                        b(s) && (s = s(e[a], e, o)), s ? w(s) ? o[s] = e[a] : x(s) && (o[s.name ? s.name : a] = s.value) : console.warn("The '".concat(t, "' method of platform '微信小程序' does not support option '").concat(a, "'"));
                    } else -1 !== gt.indexOf(a) ? b(e[a]) && (o[a] = vt(t, e[a], r)) : i || (o[a] = e[a]);
                    return o;
                }
                return b(e) && (e = vt(t, e, r)), e;
            }
            function wt(t, e, n) {
                var r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                return b(yt.returnValue) && (e = yt.returnValue(t, e)), bt(t, e, n, {}, r);
            }
            function xt(e, n) {
                if (A(yt, e)) {
                    var r = yt[e];
                    return r ? function(n, i) {
                        var o = r;
                        b(r) && (o = r(n));
                        var a = [ n = bt(e, n, o.args, o.returnValue) ];
                        void 0 !== i && a.push(i), b(o.name) ? e = o.name(n) : w(o.name) && (e = o.name);
                        var s = t[e].apply(t, a);
                        return K(e) ? wt(e, s, o.returnValue, W(e)) : s;
                    } : function() {
                        console.error("Platform '微信小程序' does not support '".concat(e, "'."));
                    };
                }
                return n;
            }
            var At = Object.create(null);
            [ "onTabBarMidButtonTap", "subscribePush", "unsubscribePush", "onPush", "offPush", "share" ].forEach(function(t) {
                At[t] = function(t) {
                    return function(e) {
                        var n = e.fail, r = e.complete, i = {
                            errMsg: "".concat(t, ":fail method '").concat(t, "' not supported")
                        };
                        b(n) && n(i), b(r) && r(i);
                    };
                }(t);
            });
            var St = {
                oauth: [ "weixin" ],
                share: [ "weixin" ],
                payment: [ "wxpay" ],
                push: [ "weixin" ]
            }, Tt = Object.freeze({
                __proto__: null,
                getProvider: function(t) {
                    var e = t.service, n = t.success, r = t.fail, i = t.complete, o = !1;
                    St[e] ? (o = {
                        errMsg: "getProvider:ok",
                        service: e,
                        provider: St[e]
                    }, b(n) && n(o)) : (o = {
                        errMsg: "getProvider:fail service not found"
                    }, b(r) && r(o)), b(i) && i(o);
                }
            }), Pt = function() {
                var t;
                return function() {
                    return t || (t = new d.default()), t;
                };
            }();
            function Mt(t, e, n) {
                return t[e].apply(t, n);
            }
            var kt, Et, Ot, Ct = Object.freeze({
                __proto__: null,
                $on: function() {
                    return Mt(Pt(), "$on", Array.prototype.slice.call(arguments));
                },
                $off: function() {
                    return Mt(Pt(), "$off", Array.prototype.slice.call(arguments));
                },
                $once: function() {
                    return Mt(Pt(), "$once", Array.prototype.slice.call(arguments));
                },
                $emit: function() {
                    return Mt(Pt(), "$emit", Array.prototype.slice.call(arguments));
                }
            });
            function It(t) {
                return function() {
                    try {
                        return t.apply(t, arguments);
                    } catch (t) {
                        console.error(t);
                    }
                };
            }
            function Rt(t) {
                try {
                    return JSON.parse(t);
                } catch (t) {}
                return t;
            }
            var Lt = [];
            function Nt(t, e) {
                Lt.forEach(function(n) {
                    n(t, e);
                }), Lt.length = 0;
            }
            var jt = [], Dt = t.getAppBaseInfo && t.getAppBaseInfo();
            Dt || (Dt = t.getSystemInfoSync());
            var Bt = Dt ? Dt.host : null, Ut = Bt && "SAAASDK" === Bt.env ? t.miniapp.shareVideoMessage : t.shareVideoMessage, Ft = Object.freeze({
                __proto__: null,
                shareVideoMessage: Ut,
                getPushClientId: function(t) {
                    x(t) || (t = {});
                    var e = function(t) {
                        var e = {};
                        for (var n in t) {
                            var r = t[n];
                            b(r) && (e[n] = It(r), delete t[n]);
                        }
                        return e;
                    }(t), n = e.success, r = e.fail, i = e.complete, o = b(n), a = b(r), s = b(i);
                    Promise.resolve().then(function() {
                        void 0 === Ot && (Ot = !1, kt = "", Et = "uniPush is not enabled"), Lt.push(function(t, e) {
                            var u;
                            t ? (u = {
                                errMsg: "getPushClientId:ok",
                                cid: t
                            }, o && n(u)) : (u = {
                                errMsg: "getPushClientId:fail" + (e ? " " + e : "")
                            }, a && r(u)), s && i(u);
                        }), void 0 !== kt && Nt(kt, Et);
                    });
                },
                onPushMessage: function(t) {
                    -1 === jt.indexOf(t) && jt.push(t);
                },
                offPushMessage: function(t) {
                    if (t) {
                        var e = jt.indexOf(t);
                        e > -1 && jt.splice(e, 1);
                    } else jt.length = 0;
                },
                invokePushCallback: function(t) {
                    if ("enabled" === t.type) Ot = !0; else if ("clientId" === t.type) kt = t.cid, Et = t.errMsg, 
                    Nt(kt, t.errMsg); else if ("pushMsg" === t.type) for (var e = {
                        type: "receive",
                        data: Rt(t.message)
                    }, n = 0; n < jt.length; n++) {
                        if ((0, jt[n])(e), e.stopped) break;
                    } else "click" === t.type && jt.forEach(function(e) {
                        e({
                            type: "click",
                            data: Rt(t.message)
                        });
                    });
                }
            }), Ht = [ "__route__", "__wxExparserNodeId__", "__wxWebviewId__" ];
            function $t(t) {
                return Behavior(t);
            }
            function Vt() {
                return !!this.route;
            }
            function zt(t) {
                this.triggerEvent("__l", t);
            }
            function Yt(t) {
                var e = t.$scope, n = {};
                Object.defineProperty(t, "$refs", {
                    get: function() {
                        var t = {};
                        return function t(e, n, r) {
                            (e.selectAllComponents(n) || []).forEach(function(e) {
                                var i = e.dataset.ref;
                                r[i] = e.$vm || Kt(e), "scoped" === e.dataset.vueGeneric && e.selectAllComponents(".scoped-ref").forEach(function(e) {
                                    t(e, n, r);
                                });
                            });
                        }(e, ".vue-ref", t), (e.selectAllComponents(".vue-ref-in-for") || []).forEach(function(e) {
                            var n = e.dataset.ref;
                            t[n] || (t[n] = []), t[n].push(e.$vm || Kt(e));
                        }), function(t, e) {
                            var n = (0, u.default)(Set, (0, c.default)(Object.keys(t)));
                            return Object.keys(e).forEach(function(r) {
                                var i = t[r], o = e[r];
                                Array.isArray(i) && Array.isArray(o) && i.length === o.length && o.every(function(t) {
                                    return i.includes(t);
                                }) || (t[r] = o, n.delete(r));
                            }), n.forEach(function(e) {
                                delete t[e];
                            }), t;
                        }(n, t);
                    }
                });
            }
            function Gt(t) {
                var e, n = t.detail || t.value, r = n.vuePid, i = n.vueOptions;
                r && (e = function t(e, n) {
                    for (var r, i = e.$children, o = i.length - 1; o >= 0; o--) {
                        var a = i[o];
                        if (a.$scope._$vueId === n) return a;
                    }
                    for (var s = i.length - 1; s >= 0; s--) if (r = t(i[s], n)) return r;
                }(this.$vm, r)), e || (e = this.$vm), i.parent = e;
            }
            function Wt(t) {
                return Object.defineProperty(t, "__v_isMPComponent", {
                    configurable: !0,
                    enumerable: !1,
                    value: !0
                }), t;
            }
            function Kt(t) {
                return function(t) {
                    return null !== t && "object" === (0, l.default)(t);
                }(t) && Object.isExtensible(t) && Object.defineProperty(t, "__ob__", {
                    configurable: !0,
                    enumerable: !1,
                    value: (0, s.default)({}, "__v_skip", !0)
                }), t;
            }
            var Xt = /_(.*)_worklet_factory_/, Jt = Page, Qt = Component, qt = /:/g, Zt = T(function(t) {
                return M(t.replace(qt, "-"));
            });
            function te(t) {
                var e = t.triggerEvent, n = function(t) {
                    for (var n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), i = 1; i < n; i++) r[i - 1] = arguments[i];
                    if (this.$vm || this.dataset && this.dataset.comType) t = Zt(t); else {
                        var o = Zt(t);
                        o !== t && e.apply(this, [ o ].concat(r));
                    }
                    return e.apply(this, [ t ].concat(r));
                };
                try {
                    t.triggerEvent = n;
                } catch (e) {
                    t._triggerEvent = n;
                }
            }
            function ee(t, e, n) {
                var r = e[t];
                e[t] = function() {
                    if (Wt(this), te(this), r) {
                        for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                        return r.apply(this, e);
                    }
                };
            }
            function ne(t, e, n) {
                e.forEach(function(e) {
                    (function t(e, n) {
                        if (!n) return !0;
                        if (d.default.options && Array.isArray(d.default.options[e])) return !0;
                        if (b(n = n.default || n)) return !!b(n.extendOptions[e]) || !!(n.super && n.super.options && Array.isArray(n.super.options[e]));
                        if (b(n[e]) || Array.isArray(n[e])) return !0;
                        var r = n.mixins;
                        return Array.isArray(r) ? !!r.find(function(n) {
                            return t(e, n);
                        }) : void 0;
                    })(e, n) && (t[e] = function(t) {
                        return this.$vm && this.$vm.__call_hook(e, t);
                    });
                });
            }
            function re(t, e) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [];
                ie(e).forEach(function(e) {
                    return oe(t, e, n);
                });
            }
            function ie(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                return t && Object.keys(t).forEach(function(n) {
                    0 === n.indexOf("on") && b(t[n]) && e.push(n);
                }), e;
            }
            function oe(t, e, n) {
                -1 !== n.indexOf(e) || A(t, e) || (t[e] = function(t) {
                    return this.$vm && this.$vm.__call_hook(e, t);
                });
            }
            function ae(t, e) {
                var n;
                return [ n = b(e = e.default || e) ? e : t.extend(e), e = n.options ];
            }
            function se(t, e) {
                if (Array.isArray(e) && e.length) {
                    var n = Object.create(null);
                    e.forEach(function(t) {
                        n[t] = !0;
                    }), t.$scopedSlots = t.$slots = n;
                }
            }
            function ue(t, e) {
                var n = (t = (t || "").split(",")).length;
                1 === n ? e._$vueId = t[0] : 2 === n && (e._$vueId = t[0], e._$vuePid = t[1]);
            }
            function ce(t, e) {
                var n = t.data || {}, r = t.methods || {};
                if ("function" == typeof n) try {
                    n = n.call(e);
                } catch (t) {
                    Object({
                        VUE_APP_DARK_MODE: "false",
                        VUE_APP_NAME: "冥想星球",
                        VUE_APP_PLATFORM: "mp-weixin",
                        NODE_ENV: "production",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG && console.warn("根据 Vue 的 data 函数初始化小程序 data 失败，请尽量确保 data 函数中不访问 vm 对象，否则可能影响首次数据渲染速度。", n);
                } else try {
                    n = JSON.parse(JSON.stringify(n));
                } catch (t) {}
                return x(n) || (n = {}), Object.keys(r).forEach(function(t) {
                    -1 !== e.__lifecycle_hooks__.indexOf(t) || A(n, t) || (n[t] = r[t]);
                }), n;
            }
            Jt.__$wrappered || (Jt.__$wrappered = !0, Page = function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return ee("onLoad", t), Jt(t);
            }, Page.after = Jt.after, Component = function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return ee("created", t), Qt(t);
            });
            var le = [ String, Number, Boolean, Object, Array, null ];
            function fe(t) {
                return function(e, n) {
                    this.$vm && (this.$vm[t] = e);
                };
            }
            function de(t, e) {
                var n = t.behaviors, r = t.extends, i = t.mixins, o = t.props;
                o || (t.props = o = []);
                var a = [];
                return Array.isArray(n) && n.forEach(function(t) {
                    a.push(t.replace("uni://", "wx".concat("://"))), "uni://form-field" === t && (Array.isArray(o) ? (o.push("name"), 
                    o.push("value")) : (o.name = {
                        type: String,
                        default: ""
                    }, o.value = {
                        type: [ String, Number, Boolean, Array, Object, Date ],
                        default: ""
                    }));
                }), x(r) && r.props && a.push(e({
                    properties: pe(r.props, !0)
                })), Array.isArray(i) && i.forEach(function(t) {
                    x(t) && t.props && a.push(e({
                        properties: pe(t.props, !0)
                    }));
                }), a;
            }
            function he(t, e, n, r) {
                return Array.isArray(e) && 1 === e.length ? e[0] : e;
            }
            function pe(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], n = arguments.length > 3 ? arguments[3] : void 0, r = {};
                return e || (r.vueId = {
                    type: String,
                    value: ""
                }, n.virtualHost && (r.virtualHostStyle = {
                    type: null,
                    value: ""
                }, r.virtualHostClass = {
                    type: null,
                    value: ""
                }), r.scopedSlotsCompiler = {
                    type: String,
                    value: ""
                }, r.vueSlots = {
                    type: null,
                    value: [],
                    observer: function(t, e) {
                        var n = Object.create(null);
                        t.forEach(function(t) {
                            n[t] = !0;
                        }), this.setData({
                            $slots: n
                        });
                    }
                }), Array.isArray(t) ? t.forEach(function(t) {
                    r[t] = {
                        type: null,
                        observer: fe(t)
                    };
                }) : x(t) && Object.keys(t).forEach(function(e) {
                    var n = t[e];
                    if (x(n)) {
                        var i = n.default;
                        b(i) && (i = i()), n.type = he(0, n.type), r[e] = {
                            type: -1 !== le.indexOf(n.type) ? n.type : null,
                            value: i,
                            observer: fe(e)
                        };
                    } else {
                        var o = he(0, n);
                        r[e] = {
                            type: -1 !== le.indexOf(o) ? o : null,
                            observer: fe(e)
                        };
                    }
                }), r;
            }
            function _e(t, e, n, r) {
                var i = {};
                return Array.isArray(e) && e.length && e.forEach(function(e, o) {
                    "string" == typeof e ? e ? "$event" === e ? i["$" + o] = n : "arguments" === e ? i["$" + o] = n.detail && n.detail.__args__ || r : 0 === e.indexOf("$event.") ? i["$" + o] = t.__get_value(e.replace("$event.", ""), n) : i["$" + o] = t.__get_value(e) : i["$" + o] = t : i["$" + o] = function(t, e) {
                        var n = t;
                        return e.forEach(function(e) {
                            var r = e[0], i = e[2];
                            if (r || void 0 !== i) {
                                var o, a = e[1], s = e[3];
                                Number.isInteger(r) ? o = r : r ? "string" == typeof r && r && (o = 0 === r.indexOf("#s#") ? r.substr(3) : t.__get_value(r, n)) : o = n, 
                                Number.isInteger(o) ? n = i : a ? Array.isArray(o) ? n = o.find(function(e) {
                                    return t.__get_value(a, e) === i;
                                }) : x(o) ? n = Object.keys(o).find(function(e) {
                                    return t.__get_value(a, o[e]) === i;
                                }) : console.error("v-for 暂不支持循环数据：", o) : n = o[i], s && (n = t.__get_value(s, n));
                            }
                        }), n;
                    }(t, e);
                }), i;
            }
            function me(t) {
                for (var e = {}, n = 1; n < t.length; n++) {
                    var r = t[n];
                    e[r[0]] = r[1];
                }
                return e;
            }
            function ye(t, e) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [], r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : [], i = arguments.length > 4 ? arguments[4] : void 0, o = arguments.length > 5 ? arguments[5] : void 0, a = !1, s = x(e.detail) && e.detail.__args__ || [ e.detail ];
                if (i && (a = e.currentTarget && e.currentTarget.dataset && "wx" === e.currentTarget.dataset.comType, 
                !n.length)) return a ? [ e ] : s;
                var u = _e(t, r, e, s), c = [];
                return n.forEach(function(t) {
                    "$event" === t ? "__set_model" !== o || i ? i && !a ? c.push(s[0]) : c.push(e) : c.push(e.target.value) : Array.isArray(t) && "o" === t[0] ? c.push(me(t)) : "string" == typeof t && A(u, t) ? c.push(u[t]) : c.push(t);
                }), c;
            }
            function ge(t) {
                var e = this, n = ((t = function(t) {
                    try {
                        t.mp = JSON.parse(JSON.stringify(t));
                    } catch (t) {}
                    return t.stopPropagation = S, t.preventDefault = S, t.target = t.target || {}, A(t, "detail") || (t.detail = {}), 
                    A(t, "markerId") && (t.detail = "object" === (0, l.default)(t.detail) ? t.detail : {}, 
                    t.detail.markerId = t.markerId), x(t.detail) && (t.target = Object.assign({}, t.target, t.detail)), 
                    t;
                }(t)).currentTarget || t.target).dataset;
                if (!n) return console.warn("事件信息不存在");
                var r = n.eventOpts || n["event-opts"];
                if (!r) return console.warn("事件信息不存在");
                var i = t.type, o = [];
                return r.forEach(function(n) {
                    var r = n[0], a = n[1], s = "^" === r.charAt(0), u = "~" === (r = s ? r.slice(1) : r).charAt(0);
                    r = u ? r.slice(1) : r, a && function(t, e) {
                        return t === e || "regionchange" === e && ("begin" === t || "end" === t);
                    }(i, r) && a.forEach(function(n) {
                        var r = n[0];
                        if (r) {
                            var i = e.$vm;
                            if (i.$options.generic && (i = function(t) {
                                for (var e = t.$parent; e && e.$parent && (e.$options.generic || e.$parent.$options.generic || e.$scope._$vuePid); ) e = e.$parent;
                                return e && e.$parent;
                            }(i) || i), "$emit" === r) return void i.$emit.apply(i, ye(e.$vm, t, n[1], n[2], s, r));
                            var a = i[r];
                            if (!b(a)) {
                                var c = "page" === e.$vm.mpType ? "Page" : "Component", l = e.route || e.is;
                                throw new Error("".concat(c, ' "').concat(l, '" does not have a method "').concat(r, '"'));
                            }
                            if (u) {
                                if (a.once) return;
                                a.once = !0;
                            }
                            var f = ye(e.$vm, t, n[1], n[2], s, r);
                            f = Array.isArray(f) ? f : [], /=\s*\S+\.eventParams\s*\|\|\s*\S+\[['"]event-params['"]\]/.test(a.toString()) && (f = f.concat([ , , , , , , , , , , t ])), 
                            o.push(a.apply(i, f));
                        }
                    });
                }), "input" === i && 1 === o.length && void 0 !== o[0] ? o[0] : void 0;
            }
            var ve = {}, be = [], we = [ "onShow", "onHide", "onError", "onPageNotFound", "onThemeChange", "onUnhandledRejection" ];
            function xe(e, n) {
                var r = n.mocks, i = n.initRefs;
                (function() {
                    d.default.prototype.getOpenerEventChannel = function() {
                        return this.$scope.getOpenerEventChannel();
                    };
                    var t = d.default.prototype.__call_hook;
                    d.default.prototype.__call_hook = function(e, n) {
                        return "onLoad" === e && n && n.__id__ && (this.__eventChannel__ = function(t) {
                            if (t) {
                                var e = ve[t];
                                return delete ve[t], e;
                            }
                            return be.shift();
                        }(n.__id__), delete n.__id__), t.call(this, e, n);
                    };
                })(), function() {
                    var t = {}, e = {};
                    d.default.prototype.$hasScopedSlotsParams = function(n) {
                        var r = t[n];
                        return r || (e[n] = this, this.$on("hook:destroyed", function() {
                            delete e[n];
                        })), r;
                    }, d.default.prototype.$getScopedSlotsParams = function(n, r, i) {
                        var o = t[n];
                        if (o) {
                            var a = o[r] || {};
                            return i ? a[i] : a;
                        }
                        e[n] = this, this.$on("hook:destroyed", function() {
                            delete e[n];
                        });
                    }, d.default.prototype.$setScopedSlotsParams = function(n, r) {
                        var i = this.$options.propsData.vueId;
                        if (i) {
                            var o = i.split(",")[0];
                            (t[o] = t[o] || {})[n] = r, e[o] && e[o].$forceUpdate();
                        }
                    }, d.default.mixin({
                        destroyed: function() {
                            var n = this.$options.propsData, r = n && n.vueId;
                            r && (delete t[r], delete e[r]);
                        }
                    });
                }(), e.$options.store && (d.default.prototype.$store = e.$options.store), function(t) {
                    t.prototype.uniIDHasRole = function(t) {
                        return y().role.indexOf(t) > -1;
                    }, t.prototype.uniIDHasPermission = function(t) {
                        var e = y().permission;
                        return this.uniIDHasRole("admin") || e.indexOf(t) > -1;
                    }, t.prototype.uniIDTokenValid = function() {
                        return y().tokenExpired > Date.now();
                    };
                }(d.default), d.default.prototype.mpHost = "mp-weixin", d.default.mixin({
                    beforeCreate: function() {
                        if (this.$options.mpType) {
                            if (this.mpType = this.$options.mpType, this.$mp = (0, s.default)({
                                data: {}
                            }, this.mpType, this.$options.mpInstance), this.$scope = this.$options.mpInstance, 
                            delete this.$options.mpType, delete this.$options.mpInstance, "page" === this.mpType && "function" == typeof getApp) {
                                var t = getApp();
                                t.$vm && t.$vm.$i18n && (this._i18n = t.$vm.$i18n);
                            }
                            "app" !== this.mpType && (i(this), function(t, e) {
                                var n = t.$mp[t.mpType];
                                e.forEach(function(e) {
                                    A(n, e) && (t[e] = n[e]);
                                });
                            }(this, r));
                        }
                    }
                });
                var o = {
                    onLaunch: function(n) {
                        this.$vm || (t.canIUse && !t.canIUse("nextTick") && console.error("当前微信基础库版本过低，请将 微信开发者工具-详情-项目设置-调试基础库版本 更换为`2.3.0`以上"), 
                        this.$vm = e, this.$vm.$mp = {
                            app: this
                        }, this.$vm.$scope = this, this.$vm.globalData = this.globalData, this.$vm._isMounted = !0, 
                        this.$vm.__call_hook("mounted", n), this.$vm.__call_hook("onLaunch", n));
                    }
                };
                o.globalData = e.$options.globalData || {};
                var a = e.$options.methods;
                return a && Object.keys(a).forEach(function(t) {
                    o[t] = a[t];
                }), function(t, e, n) {
                    var r = t.observable({
                        locale: n || nt.getLocale()
                    }), i = [];
                    e.$watchLocale = function(t) {
                        i.push(t);
                    }, Object.defineProperty(e, "$locale", {
                        get: function() {
                            return r.locale;
                        },
                        set: function(t) {
                            r.locale = t, i.forEach(function(e) {
                                return e(t);
                            });
                        }
                    });
                }(d.default, e, it(t.getSystemInfoSync().language) || "en"), ne(o, we), re(o, e.$options), 
                o;
            }
            function Ae(t) {
                return xe(t, {
                    mocks: Ht,
                    initRefs: Yt
                });
            }
            function Se(t) {
                return App(Ae(t)), t;
            }
            var Te = /[!'()*]/g, Pe = function(t) {
                return "%" + t.charCodeAt(0).toString(16);
            }, Me = /%2C/g, ke = function(t) {
                return encodeURIComponent(t).replace(Te, Pe).replace(Me, ",");
            };
            function Ee(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ke, n = t ? Object.keys(t).map(function(n) {
                    var r = t[n];
                    if (void 0 === r) return "";
                    if (null === r) return e(n);
                    if (Array.isArray(r)) {
                        var i = [];
                        return r.forEach(function(t) {
                            void 0 !== t && (null === t ? i.push(e(n)) : i.push(e(n) + "=" + e(t)));
                        }), i.join("&");
                    }
                    return e(n) + "=" + e(r);
                }).filter(function(t) {
                    return t.length > 0;
                }).join("&") : null;
                return n ? "?".concat(n) : "";
            }
            function Oe(t, e) {
                return function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = e.isPage, r = e.initRelation, i = arguments.length > 2 ? arguments[2] : void 0, o = ae(d.default, t), s = (0, 
                    a.default)(o, 2), u = s[0], c = s[1], l = p({
                        multipleSlots: !0,
                        addGlobalClass: !0
                    }, c.options || {});
                    c["mp-weixin"] && c["mp-weixin"].options && Object.assign(l, c["mp-weixin"].options);
                    var f = {
                        options: l,
                        data: ce(c, d.default.prototype),
                        behaviors: de(c, $t),
                        properties: pe(c.props, !1, c.__file, l),
                        lifetimes: {
                            attached: function() {
                                var t = this.properties, e = {
                                    mpType: n.call(this) ? "page" : "component",
                                    mpInstance: this,
                                    propsData: t
                                };
                                ue(t.vueId, this), r.call(this, {
                                    vuePid: this._$vuePid,
                                    vueOptions: e
                                }), this.$vm = new u(e), se(this.$vm, t.vueSlots), this.$vm.$mount();
                            },
                            ready: function() {
                                this.$vm && (this.$vm._isMounted = !0, this.$vm.__call_hook("mounted"), this.$vm.__call_hook("onReady"));
                            },
                            detached: function() {
                                this.$vm && this.$vm.$destroy();
                            }
                        },
                        pageLifetimes: {
                            show: function(t) {
                                this.$vm && this.$vm.__call_hook("onPageShow", t);
                            },
                            hide: function() {
                                this.$vm && this.$vm.__call_hook("onPageHide");
                            },
                            resize: function(t) {
                                this.$vm && this.$vm.__call_hook("onPageResize", t);
                            }
                        },
                        methods: {
                            __l: Gt,
                            __e: ge
                        }
                    };
                    return c.externalClasses && (f.externalClasses = c.externalClasses), Array.isArray(c.wxsCallMethods) && c.wxsCallMethods.forEach(function(t) {
                        f.methods[t] = function(e) {
                            return this.$vm[t](e);
                        };
                    }), i ? [ f, c, u ] : n ? f : [ f, u ];
                }(t, {
                    isPage: Vt,
                    initRelation: zt
                }, e);
            }
            var Ce = [ "onShow", "onHide", "onUnload" ];
            function Ie(t) {
                return Component(function(t) {
                    return function(t) {
                        var e = Oe(t, !0), n = (0, a.default)(e, 2), r = n[0], i = n[1];
                        return ne(r.methods, Ce, i), r.methods.onLoad = function(t) {
                            this.options = t;
                            var e = Object.assign({}, t);
                            delete e.__id__, this.$page = {
                                fullPath: "/" + (this.route || this.is) + Ee(e)
                            }, this.$vm.$mp.query = t, this.$vm.__call_hook("onLoad", t);
                        }, re(r.methods, t, [ "onReady" ]), function(t, e) {
                            e && Object.keys(e).forEach(function(n) {
                                var r = n.match(Xt);
                                if (r) {
                                    var i = r[1];
                                    t[n] = e[n], t[i] = e[i];
                                }
                            });
                        }(r.methods, i.methods), r;
                    }(t);
                }(t));
            }
            function Re(t) {
                return Component(Oe(t));
            }
            function Le(e) {
                var n = Ae(e), r = getApp({
                    allowDefault: !0
                });
                e.$scope = r;
                var i = r.globalData;
                if (i && Object.keys(n.globalData).forEach(function(t) {
                    A(i, t) || (i[t] = n.globalData[t]);
                }), Object.keys(n).forEach(function(t) {
                    A(r, t) || (r[t] = n[t]);
                }), b(n.onShow) && t.onAppShow && t.onAppShow(function() {
                    for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    e.__call_hook("onShow", n);
                }), b(n.onHide) && t.onAppHide && t.onAppHide(function() {
                    for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    e.__call_hook("onHide", n);
                }), b(n.onLaunch)) {
                    var o = t.getLaunchOptionsSync && t.getLaunchOptionsSync();
                    e.__call_hook("onLaunch", o);
                }
                return e;
            }
            function Ne(e) {
                var n = Ae(e);
                if (b(n.onShow) && t.onAppShow && t.onAppShow(function() {
                    for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    e.__call_hook("onShow", n);
                }), b(n.onHide) && t.onAppHide && t.onAppHide(function() {
                    for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    e.__call_hook("onHide", n);
                }), b(n.onLaunch)) {
                    var r = t.getLaunchOptionsSync && t.getLaunchOptionsSync();
                    e.__call_hook("onLaunch", r);
                }
                return e;
            }
            Ce.push.apply(Ce, [ "onPullDownRefresh", "onReachBottom", "onAddToFavorites", "onShareTimeline", "onShareAppMessage", "onPageScroll", "onResize", "onTabItemTap" ]), 
            [ "vibrate", "preloadPage", "unPreloadPage", "loadSubPackage" ].forEach(function(t) {
                yt[t] = !1;
            }), [].forEach(function(e) {
                var n = yt[e] && yt[e].name ? yt[e].name : e;
                t.canIUse(n) || (yt[e] = !1);
            });
            var je = {};
            "undefined" != typeof Proxy ? je = new Proxy({}, {
                get: function(e, n) {
                    return A(e, n) ? e[n] : ct[n] ? ct[n] : Ft[n] ? J(n, Ft[n]) : Tt[n] ? J(n, Tt[n]) : At[n] ? J(n, At[n]) : Ct[n] ? Ct[n] : J(n, xt(n, t[n]));
                },
                set: function(t, e, n) {
                    return t[e] = n, !0;
                }
            }) : (Object.keys(ct).forEach(function(t) {
                je[t] = ct[t];
            }), Object.keys(At).forEach(function(t) {
                je[t] = J(t, At[t]);
            }), Object.keys(Tt).forEach(function(t) {
                je[t] = J(t, At[t]);
            }), Object.keys(Ct).forEach(function(t) {
                je[t] = Ct[t];
            }), Object.keys(Ft).forEach(function(t) {
                je[t] = J(t, Ft[t]);
            }), Object.keys(t).forEach(function(e) {
                (A(t, e) || A(yt, e)) && (je[e] = J(e, xt(e, t[e])));
            })), t.createApp = Se, t.createPage = Ie, t.createComponent = Re, t.createSubpackageApp = Le, 
            t.createPlugin = Ne;
            var De = je;
            e.default = De;
        }).call(this, n("bc2e").default, n("c8ba"));
    },
    "57e5": function(t, e, n) {},
    "5a43": function(t, e) {
        t.exports = function(t, e) {
            (null == e || e > t.length) && (e = t.length);
            for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
            return r;
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    "5bc3": function(t, e, n) {
        var r = n("a395");
        function i(t, e) {
            for (var n = 0; n < e.length; n++) {
                var i = e[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
                Object.defineProperty(t, r(i.key), i);
            }
        }
        t.exports = function(t, e, n) {
            return e && i(t.prototype, e), n && i(t, n), Object.defineProperty(t, "prototype", {
                writable: !1
            }), t;
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    "5ccf": function(t, e, n) {
        var r = n("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = r(n("2eee")), o = r(n("c973")), a = r(n("ebd0")), s = r(n("1123")), u = {
            data: function() {
                return {
                    medi_mix_player: "",
                    pageRoute: ""
                };
            },
            computed: {
                medi_mix_useBgm: function() {
                    return this.medi_mix_player && this.medi_mix_player.useBgm;
                },
                medi_mix_progress: {
                    get: function() {
                        return this.medi_mix_player && this.medi_mix_player.progress || 0;
                    },
                    set: function() {}
                },
                medi_mix_playing: function() {
                    return this.medi_mix_player && this.medi_mix_player.playing || 0;
                },
                medi_mix_loading: function() {
                    return this.medi_mix_player && this.medi_mix_player.loading || 0;
                },
                medi_mix_playComplete: function() {
                    return this.medi_mix_player && this.medi_mix_player.playComplete || 0;
                },
                medi_mix_fullComplete: function() {
                    return this.medi_mix_player && this.medi_mix_player.mediComplete || 0;
                },
                medi_mix_duration: function() {
                    return this.medi_mix_player && this.medi_mix_player.duration || 0;
                },
                medi_mix_record: function() {
                    return this.medi_mix_player && this.medi_mix_player.record || 0;
                },
                medi_mix_allPlayTime: function() {
                    return this.medi_mix_player && this.medi_mix_player.allPlayTime || 0;
                },
                medi_mix_mediInfo: function() {
                    return this.medi_mix_player && this.medi_mix_player.mediInfo;
                },
                medi_mix_mediTimes: function() {
                    return this.medi_mix_player && this.medi_mix_player.mediTimes;
                },
                medi_mix_polyVid: function() {
                    return this.medi_mix_player && this.medi_mix_player.polyVid || 0;
                },
                medi_mix_voiceInfo: function() {
                    return this.medi_mix_player && this.medi_mix_player.mediInfo || {};
                },
                medi_mix_Type: function() {
                    return this.medi_mix_player && this.medi_mix_player.playType;
                }
            },
            created: function() {},
            methods: {
                medi_mix_getPlayer: function() {
                    return (0, a.default)();
                },
                bookPlayerBar_initPlayer: function() {
                    var t = (0, a.default)();
                    console.log(t), t && (this.medi_mix_player = t);
                },
                resetPlayer: function() {
                    (0, a.default)("reset");
                },
                medi_mix_initPlayer: function(t) {
                    var e = arguments, n = this;
                    return (0, o.default)(i.default.mark(function r() {
                        var o, s, u, c;
                        return i.default.wrap(function(r) {
                            for (;;) switch (r.prev = r.next) {
                              case 0:
                                if (o = e.length > 1 && void 0 !== e[1] ? e[1] : 0, s = e.length > 2 && void 0 !== e[2] && e[2], 
                                u = getCurrentPages(), n.pageRoute = u.pop().route.split("/").pop(), console.log(n.pageRoute), 
                                console.log("进入页面初始化创建播放器", t, o), t) {
                                    r.next = 9;
                                    break;
                                }
                                return console.info("没有可创建的练习ID"), r.abrupt("return");

                              case 9:
                                (c = (0, a.default)(n.pageRoute)) ? 1 * c.mediId == 1 * t ? (console.info("练习Id相同，无需新建"), 
                                n.medi_mix_player = c, c.mediComplete && [ "practiceToPlay", "voicePlay" ].includes(n.pageRoute) ? (n.medi_mix_setMediComplete(!1), 
                                console.log("进入播放页，重新播放"), c.play(0), c.pause()) : [ "practiceToPlay", "voicePlay" ].includes(n.pageRoute) && s && c.playComplete && (console.log("详情页进入+播放完成，重新播放"), 
                                c.play(0), c.pause())) : (c.changeMediId(t, o), n.medi_mix_player = c) : (console.log("没有播放器，直接新建", n.pageRoute), 
                                n.medi_mix_player = c = (0, a.default)(n.pageRoute, t, o)), console.log("设置endMediHandler", n.medi_mix_player), 
                                n.medi_mix_player.endMediHandler = function(t, e) {
                                    console.log(e), e || [ "practiceToPlay", "voicePlay" ].includes(getCurrentPages().pop().route.split("/").pop()) ? n.medi_mix_goMediComplete(t) : n.medi_mix_setMediComplete(!0);
                                };

                              case 13:
                              case "end":
                                return r.stop();
                            }
                        }, r);
                    }))();
                },
                medi_mix_goMediComplete: function(t) {
                    "practice" === this.medi_mix_Type ? s.default.commit("common/setCompleteShare", {
                        type: "practice",
                        meditatingId: this.medi_mix_getPlayer().mediId,
                        title: this.medi_mix_mediInfo.title
                    }) : s.default.commit("common/setCompleteShare", {
                        type: "voice",
                        meditatingId: this.medi_mix_getPlayer().mediId,
                        title: this.medi_mix_voiceInfo.title
                    }), this.$navTo.push({
                        name: "practiceComplete",
                        params: {
                            meditatingId: this.medi_mix_getPlayer().mediId,
                            learnTime: t || (0, a.default)().getStayTime(),
                            count: (0, a.default)().mediTimes || 0
                        }
                    });
                },
                medi_mix_play: function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    console.log(this.medi_mix_getPlayer()), this.medi_mix_getPlayer().play(t, e), this.medi_mix_setMediComplete(!1);
                },
                medi_mix_replay: function() {
                    this.medi_mix_getPlayer().replay(), this.medi_mix_setMediComplete(!1);
                },
                medi_mix_pause: function() {
                    console.log("冥想暂停"), this.medi_mix_getPlayer() && this.medi_mix_getPlayer().pause();
                },
                medi_mix_stop: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
                    this.medi_mix_getPlayer().stop(t);
                },
                medi_mix_seek: function(t) {
                    this.medi_mix_getPlayer() && (t < 0 ? t = 0 : t > this.medi_mix_getPlayer().mediInfo.duration && (t = this.medi_mix_getPlayer().mediInfo.duration), 
                    this.medi_mix_getPlayer().seek(t), this.medi_mix_setMediComplete(!1));
                },
                medi_mix_BGMtoggle: function() {
                    this.medi_mix_getPlayer().toggleBGM();
                },
                medi_mix_BGMpause: function() {
                    this.medi_mix_getPlayer().pauseBGM();
                },
                medi_mix_setMediComplete: function(t) {
                    var e = (0, a.default)();
                    console.log("set mediComplete player", e), e && (console.log("set mediComplete", t), 
                    void 0 !== t ? (e.mediComplete = t, t && e.clearSeekHistory()) : (e.mediComplete = !0, 
                    e.clearSeekHistory()));
                },
                medi_mix_getStorageMediInfo: function() {
                    return null;
                }
            }
        };
        e.default = u;
    },
    "62e4": function(t, e) {
        t.exports = function(t) {
            return t.webpackPolyfill || (t.deprecate = function() {}, t.paths = [], t.children || (t.children = []), 
            Object.defineProperty(t, "loaded", {
                enumerable: !0,
                get: function() {
                    return t.l;
                }
            }), Object.defineProperty(t, "id", {
                enumerable: !0,
                get: function() {
                    return t.i;
                }
            }), t.webpackPolyfill = 1), t;
        };
    },
    6403: function(t, e, n) {
        var r;
        function i(t) {
            return t.type === r.Tag || t.type === r.Script || t.type === r.Style;
        }
        n.r(e), n.d(e, "ElementType", function() {
            return r;
        }), n.d(e, "isTag", function() {
            return i;
        }), n.d(e, "Root", function() {
            return o;
        }), n.d(e, "Text", function() {
            return a;
        }), n.d(e, "Directive", function() {
            return s;
        }), n.d(e, "Comment", function() {
            return u;
        }), n.d(e, "Script", function() {
            return c;
        }), n.d(e, "Style", function() {
            return l;
        }), n.d(e, "Tag", function() {
            return f;
        }), n.d(e, "CDATA", function() {
            return d;
        }), n.d(e, "Doctype", function() {
            return h;
        }), function(t) {
            t.Root = "root", t.Text = "text", t.Directive = "directive", t.Comment = "comment", 
            t.Script = "script", t.Style = "style", t.Tag = "tag", t.CDATA = "cdata", t.Doctype = "doctype";
        }(r || (r = {}));
        var o = r.Root, a = r.Text, s = r.Directive, u = r.Comment, c = r.Script, l = r.Style, f = r.Tag, d = r.CDATA, h = r.Doctype;
    },
    6613: function(t, e, n) {
        var r = n("5a43");
        t.exports = function(t, e) {
            if (t) {
                if ("string" == typeof t) return r(t, e);
                var n = Object.prototype.toString.call(t).slice(8, -1);
                return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? r(t, e) : void 0;
            }
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    "66fd": function(t, e, n) {
        n.r(e), function(t) {
            var n = Object.freeze({});
            function r(t) {
                return null == t;
            }
            function i(t) {
                return null != t;
            }
            function o(t) {
                return !0 === t;
            }
            function a(t) {
                return "string" == typeof t || "number" == typeof t || "symbol" === _typeof3(t) || "boolean" == typeof t;
            }
            function s(t) {
                return null !== t && "object" === _typeof3(t);
            }
            var u = Object.prototype.toString;
            function c(t) {
                return "[object Object]" === u.call(t);
            }
            function l(t) {
                var e = parseFloat(String(t));
                return e >= 0 && Math.floor(e) === e && isFinite(t);
            }
            function f(t) {
                return i(t) && "function" == typeof t.then && "function" == typeof t.catch;
            }
            function d(t) {
                return null == t ? "" : Array.isArray(t) || c(t) && t.toString === u ? JSON.stringify(t, null, 2) : String(t);
            }
            function h(t) {
                var e = parseFloat(t);
                return isNaN(e) ? t : e;
            }
            function p(t, e) {
                for (var n = Object.create(null), r = t.split(","), i = 0; i < r.length; i++) n[r[i]] = !0;
                return e ? function(t) {
                    return n[t.toLowerCase()];
                } : function(t) {
                    return n[t];
                };
            }
            p("slot,component", !0);
            var _ = p("key,ref,slot,slot-scope,is");
            function m(t, e) {
                if (t.length) {
                    var n = t.indexOf(e);
                    if (n > -1) return t.splice(n, 1);
                }
            }
            var y = Object.prototype.hasOwnProperty;
            function g(t, e) {
                return y.call(t, e);
            }
            function v(t) {
                var e = Object.create(null);
                return function(n) {
                    return e[n] || (e[n] = t(n));
                };
            }
            var b = /-(\w)/g, w = v(function(t) {
                return t.replace(b, function(t, e) {
                    return e ? e.toUpperCase() : "";
                });
            }), x = v(function(t) {
                return t.charAt(0).toUpperCase() + t.slice(1);
            }), A = /\B([A-Z])/g, S = v(function(t) {
                return t.replace(A, "-$1").toLowerCase();
            }), T = Function.prototype.bind ? function(t, e) {
                return t.bind(e);
            } : function(t, e) {
                function n(n) {
                    var r = arguments.length;
                    return r ? r > 1 ? t.apply(e, arguments) : t.call(e, n) : t.call(e);
                }
                return n._length = t.length, n;
            };
            function P(t, e) {
                e = e || 0;
                for (var n = t.length - e, r = new Array(n); n--; ) r[n] = t[n + e];
                return r;
            }
            function M(t, e) {
                for (var n in e) t[n] = e[n];
                return t;
            }
            function k(t) {
                for (var e = {}, n = 0; n < t.length; n++) t[n] && M(e, t[n]);
                return e;
            }
            function E(t, e, n) {}
            var O = function(t, e, n) {
                return !1;
            }, C = function(t) {
                return t;
            };
            function I(t, e) {
                if (t === e) return !0;
                var n = s(t), r = s(e);
                if (!n || !r) return !n && !r && String(t) === String(e);
                try {
                    var i = Array.isArray(t), o = Array.isArray(e);
                    if (i && o) return t.length === e.length && t.every(function(t, n) {
                        return I(t, e[n]);
                    });
                    if (t instanceof Date && e instanceof Date) return t.getTime() === e.getTime();
                    if (i || o) return !1;
                    var a = Object.keys(t), u = Object.keys(e);
                    return a.length === u.length && a.every(function(n) {
                        return I(t[n], e[n]);
                    });
                } catch (t) {
                    return !1;
                }
            }
            function R(t, e) {
                for (var n = 0; n < t.length; n++) if (I(t[n], e)) return n;
                return -1;
            }
            function L(t) {
                var e = !1;
                return function() {
                    e || (e = !0, t.apply(this, arguments));
                };
            }
            var N = [ "component", "directive", "filter" ], j = [ "beforeCreate", "created", "beforeMount", "mounted", "beforeUpdate", "updated", "beforeDestroy", "destroyed", "activated", "deactivated", "errorCaptured", "serverPrefetch" ], D = {
                optionMergeStrategies: Object.create(null),
                silent: !1,
                productionTip: !1,
                devtools: !1,
                performance: !1,
                errorHandler: null,
                warnHandler: null,
                ignoredElements: [],
                keyCodes: Object.create(null),
                isReservedTag: O,
                isReservedAttr: O,
                isUnknownElement: O,
                getTagNamespace: E,
                parsePlatformTagName: C,
                mustUseProp: O,
                async: !0,
                _lifecycleHooks: j
            };
            function B(t) {
                var e = (t + "").charCodeAt(0);
                return 36 === e || 95 === e;
            }
            function U(t, e, n, r) {
                Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !!r,
                    writable: !0,
                    configurable: !0
                });
            }
            var F, H = new RegExp("[^" + /a-zA-Z\u00B7\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u037D\u037F-\u1FFF\u200C-\u200D\u203F-\u2040\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD/.source + ".$_\\d]"), $ = "__proto__" in {}, V = "undefined" != typeof window, z = "undefined" != typeof WXEnvironment && !!WXEnvironment.platform, Y = z && WXEnvironment.platform.toLowerCase(), G = V && window.navigator.userAgent.toLowerCase(), W = G && /msie|trident/.test(G), K = (G && G.indexOf("msie 9.0"), 
            G && G.indexOf("edge/"), G && G.indexOf("android"), G && /iphone|ipad|ipod|ios/.test(G) || "ios" === Y), X = (G && /chrome\/\d+/.test(G), 
            G && /phantomjs/.test(G), G && G.match(/firefox\/(\d+)/), {}.watch);
            if (V) try {
                var J = {};
                Object.defineProperty(J, "passive", {
                    get: function() {}
                }), window.addEventListener("test-passive", null, J);
            } catch (t) {}
            var Q = function() {
                return void 0 === F && (F = !V && !z && void 0 !== t && t.process && "server" === t.process.env.VUE_ENV), 
                F;
            }, q = V && window.__VUE_DEVTOOLS_GLOBAL_HOOK__;
            function Z(t) {
                return "function" == typeof t && /native code/.test(t.toString());
            }
            var tt, et = "undefined" != typeof Symbol && Z(Symbol) && "undefined" != typeof Reflect && Z(Reflect.ownKeys);
            tt = "undefined" != typeof Set && Z(Set) ? Set : function() {
                function t() {
                    this.set = Object.create(null);
                }
                return t.prototype.has = function(t) {
                    return !0 === this.set[t];
                }, t.prototype.add = function(t) {
                    this.set[t] = !0;
                }, t.prototype.clear = function() {
                    this.set = Object.create(null);
                }, t;
            }();
            var nt = E, rt = 0, it = function() {
                this.id = rt++, this.subs = [];
            };
            function ot(t) {
                it.SharedObject.targetStack.push(t), it.SharedObject.target = t, it.target = t;
            }
            function at() {
                it.SharedObject.targetStack.pop(), it.SharedObject.target = it.SharedObject.targetStack[it.SharedObject.targetStack.length - 1], 
                it.target = it.SharedObject.target;
            }
            it.prototype.addSub = function(t) {
                this.subs.push(t);
            }, it.prototype.removeSub = function(t) {
                m(this.subs, t);
            }, it.prototype.depend = function() {
                it.SharedObject.target && it.SharedObject.target.addDep(this);
            }, it.prototype.notify = function() {
                for (var t = this.subs.slice(), e = 0, n = t.length; e < n; e++) t[e].update();
            }, (it.SharedObject = {}).target = null, it.SharedObject.targetStack = [];
            var st = function(t, e, n, r, i, o, a, s) {
                this.tag = t, this.data = e, this.children = n, this.text = r, this.elm = i, this.ns = void 0, 
                this.context = o, this.fnContext = void 0, this.fnOptions = void 0, this.fnScopeId = void 0, 
                this.key = e && e.key, this.componentOptions = a, this.componentInstance = void 0, 
                this.parent = void 0, this.raw = !1, this.isStatic = !1, this.isRootInsert = !0, 
                this.isComment = !1, this.isCloned = !1, this.isOnce = !1, this.asyncFactory = s, 
                this.asyncMeta = void 0, this.isAsyncPlaceholder = !1;
            }, ut = {
                child: {
                    configurable: !0
                }
            };
            ut.child.get = function() {
                return this.componentInstance;
            }, Object.defineProperties(st.prototype, ut);
            var ct = function(t) {
                void 0 === t && (t = "");
                var e = new st();
                return e.text = t, e.isComment = !0, e;
            };
            function lt(t) {
                return new st(void 0, void 0, void 0, String(t));
            }
            var ft = Array.prototype, dt = Object.create(ft);
            [ "push", "pop", "shift", "unshift", "splice", "sort", "reverse" ].forEach(function(t) {
                var e = ft[t];
                U(dt, t, function() {
                    for (var n = [], r = arguments.length; r--; ) n[r] = arguments[r];
                    var i, o = e.apply(this, n), a = this.__ob__;
                    switch (t) {
                      case "push":
                      case "unshift":
                        i = n;
                        break;

                      case "splice":
                        i = n.slice(2);
                    }
                    return i && a.observeArray(i), a.dep.notify(), o;
                });
            });
            var ht = Object.getOwnPropertyNames(dt), pt = !0;
            function _t(t) {
                pt = t;
            }
            var mt = function(t) {
                this.value = t, this.dep = new it(), this.vmCount = 0, U(t, "__ob__", this), Array.isArray(t) ? ($ ? t.push !== t.__proto__.push ? yt(t, dt, ht) : function(t, e) {
                    t.__proto__ = e;
                }(t, dt) : yt(t, dt, ht), this.observeArray(t)) : this.walk(t);
            };
            function yt(t, e, n) {
                for (var r = 0, i = n.length; r < i; r++) {
                    var o = n[r];
                    U(t, o, e[o]);
                }
            }
            function gt(t, e) {
                var n;
                if (s(t) && !(t instanceof st)) return g(t, "__ob__") && t.__ob__ instanceof mt ? n = t.__ob__ : !pt || Q() || !Array.isArray(t) && !c(t) || !Object.isExtensible(t) || t._isVue || t.__v_isMPComponent || (n = new mt(t)), 
                e && n && n.vmCount++, n;
            }
            function vt(t, e, n, r, i) {
                var o = new it(), a = Object.getOwnPropertyDescriptor(t, e);
                if (!a || !1 !== a.configurable) {
                    var s = a && a.get, u = a && a.set;
                    s && !u || 2 !== arguments.length || (n = t[e]);
                    var c = !i && gt(n);
                    Object.defineProperty(t, e, {
                        enumerable: !0,
                        configurable: !0,
                        get: function() {
                            var e = s ? s.call(t) : n;
                            return it.SharedObject.target && (o.depend(), c && (c.dep.depend(), Array.isArray(e) && xt(e))), 
                            e;
                        },
                        set: function(e) {
                            var r = s ? s.call(t) : n;
                            e === r || e != e && r != r || s && !u || (u ? u.call(t, e) : n = e, c = !i && gt(e), 
                            o.notify());
                        }
                    });
                }
            }
            function bt(t, e, n) {
                if (Array.isArray(t) && l(e)) return t.length = Math.max(t.length, e), t.splice(e, 1, n), 
                n;
                if (e in t && !(e in Object.prototype)) return t[e] = n, n;
                var r = t.__ob__;
                return t._isVue || r && r.vmCount ? n : r ? (vt(r.value, e, n), r.dep.notify(), 
                n) : (t[e] = n, n);
            }
            function wt(t, e) {
                if (Array.isArray(t) && l(e)) t.splice(e, 1); else {
                    var n = t.__ob__;
                    t._isVue || n && n.vmCount || g(t, e) && (delete t[e], n && n.dep.notify());
                }
            }
            function xt(t) {
                for (var e = void 0, n = 0, r = t.length; n < r; n++) (e = t[n]) && e.__ob__ && e.__ob__.dep.depend(), 
                Array.isArray(e) && xt(e);
            }
            mt.prototype.walk = function(t) {
                for (var e = Object.keys(t), n = 0; n < e.length; n++) vt(t, e[n]);
            }, mt.prototype.observeArray = function(t) {
                for (var e = 0, n = t.length; e < n; e++) gt(t[e]);
            };
            var At = D.optionMergeStrategies;
            function St(t, e) {
                if (!e) return t;
                for (var n, r, i, o = et ? Reflect.ownKeys(e) : Object.keys(e), a = 0; a < o.length; a++) "__ob__" !== (n = o[a]) && (r = t[n], 
                i = e[n], g(t, n) ? r !== i && c(r) && c(i) && St(r, i) : bt(t, n, i));
                return t;
            }
            function Tt(t, e, n) {
                return n ? function() {
                    var r = "function" == typeof e ? e.call(n, n) : e, i = "function" == typeof t ? t.call(n, n) : t;
                    return r ? St(r, i) : i;
                } : e ? t ? function() {
                    return St("function" == typeof e ? e.call(this, this) : e, "function" == typeof t ? t.call(this, this) : t);
                } : e : t;
            }
            function Pt(t, e) {
                var n = e ? t ? t.concat(e) : Array.isArray(e) ? e : [ e ] : t;
                return n ? function(t) {
                    for (var e = [], n = 0; n < t.length; n++) -1 === e.indexOf(t[n]) && e.push(t[n]);
                    return e;
                }(n) : n;
            }
            function Mt(t, e, n, r) {
                var i = Object.create(t || null);
                return e ? M(i, e) : i;
            }
            At.data = function(t, e, n) {
                return n ? Tt(t, e, n) : e && "function" != typeof e ? t : Tt(t, e);
            }, j.forEach(function(t) {
                At[t] = Pt;
            }), N.forEach(function(t) {
                At[t + "s"] = Mt;
            }), At.watch = function(t, e, n, r) {
                if (t === X && (t = void 0), e === X && (e = void 0), !e) return Object.create(t || null);
                if (!t) return e;
                var i = {};
                for (var o in M(i, t), e) {
                    var a = i[o], s = e[o];
                    a && !Array.isArray(a) && (a = [ a ]), i[o] = a ? a.concat(s) : Array.isArray(s) ? s : [ s ];
                }
                return i;
            }, At.props = At.methods = At.inject = At.computed = function(t, e, n, r) {
                if (!t) return e;
                var i = Object.create(null);
                return M(i, t), e && M(i, e), i;
            }, At.provide = Tt;
            var kt = function(t, e) {
                return void 0 === e ? t : e;
            };
            function Et(t, e, n) {
                if ("function" == typeof e && (e = e.options), function(t, e) {
                    var n = t.props;
                    if (n) {
                        var r, i, o = {};
                        if (Array.isArray(n)) for (r = n.length; r--; ) "string" == typeof (i = n[r]) && (o[w(i)] = {
                            type: null
                        }); else if (c(n)) for (var a in n) i = n[a], o[w(a)] = c(i) ? i : {
                            type: i
                        };
                        t.props = o;
                    }
                }(e), function(t, e) {
                    var n = t.inject;
                    if (n) {
                        var r = t.inject = {};
                        if (Array.isArray(n)) for (var i = 0; i < n.length; i++) r[n[i]] = {
                            from: n[i]
                        }; else if (c(n)) for (var o in n) {
                            var a = n[o];
                            r[o] = c(a) ? M({
                                from: o
                            }, a) : {
                                from: a
                            };
                        }
                    }
                }(e), function(t) {
                    var e = t.directives;
                    if (e) for (var n in e) {
                        var r = e[n];
                        "function" == typeof r && (e[n] = {
                            bind: r,
                            update: r
                        });
                    }
                }(e), !e._base && (e.extends && (t = Et(t, e.extends, n)), e.mixins)) for (var r = 0, i = e.mixins.length; r < i; r++) t = Et(t, e.mixins[r], n);
                var o, a = {};
                for (o in t) s(o);
                for (o in e) g(t, o) || s(o);
                function s(r) {
                    var i = At[r] || kt;
                    a[r] = i(t[r], e[r], n, r);
                }
                return a;
            }
            function Ot(t, e, n, r) {
                if ("string" == typeof n) {
                    var i = t[e];
                    if (g(i, n)) return i[n];
                    var o = w(n);
                    if (g(i, o)) return i[o];
                    var a = x(o);
                    return g(i, a) ? i[a] : i[n] || i[o] || i[a];
                }
            }
            function Ct(t, e, n, r) {
                var i = e[t], o = !g(n, t), a = n[t], s = Lt(Boolean, i.type);
                if (s > -1) if (o && !g(i, "default")) a = !1; else if ("" === a || a === S(t)) {
                    var u = Lt(String, i.type);
                    (u < 0 || s < u) && (a = !0);
                }
                if (void 0 === a) {
                    a = function(t, e, n) {
                        if (g(e, "default")) {
                            var r = e.default;
                            return t && t.$options.propsData && void 0 === t.$options.propsData[n] && void 0 !== t._props[n] ? t._props[n] : "function" == typeof r && "Function" !== It(e.type) ? r.call(t) : r;
                        }
                    }(r, i, t);
                    var c = pt;
                    _t(!0), gt(a), _t(c);
                }
                return a;
            }
            function It(t) {
                var e = t && t.toString().match(/^\s*function (\w+)/);
                return e ? e[1] : "";
            }
            function Rt(t, e) {
                return It(t) === It(e);
            }
            function Lt(t, e) {
                if (!Array.isArray(e)) return Rt(e, t) ? 0 : -1;
                for (var n = 0, r = e.length; n < r; n++) if (Rt(e[n], t)) return n;
                return -1;
            }
            function Nt(t, e, n) {
                ot();
                try {
                    if (e) for (var r = e; r = r.$parent; ) {
                        var i = r.$options.errorCaptured;
                        if (i) for (var o = 0; o < i.length; o++) try {
                            if (!1 === i[o].call(r, t, e, n)) return;
                        } catch (t) {
                            Dt(t, r, "errorCaptured hook");
                        }
                    }
                    Dt(t, e, n);
                } finally {
                    at();
                }
            }
            function jt(t, e, n, r, i) {
                var o;
                try {
                    (o = n ? t.apply(e, n) : t.call(e)) && !o._isVue && f(o) && !o._handled && (o.catch(function(t) {
                        return Nt(t, r, i + " (Promise/async)");
                    }), o._handled = !0);
                } catch (t) {
                    Nt(t, r, i);
                }
                return o;
            }
            function Dt(t, e, n) {
                if (D.errorHandler) try {
                    return D.errorHandler.call(null, t, e, n);
                } catch (e) {
                    e !== t && Bt(e, null, "config.errorHandler");
                }
                Bt(t, e, n);
            }
            function Bt(t, e, n) {
                if (!V && !z || "undefined" == typeof console) throw t;
                console.error(t);
            }
            var Ut, Ft = [], Ht = !1;
            function $t() {
                Ht = !1;
                var t = Ft.slice(0);
                Ft.length = 0;
                for (var e = 0; e < t.length; e++) t[e]();
            }
            if ("undefined" != typeof Promise && Z(Promise)) {
                var Vt = Promise.resolve();
                Ut = function() {
                    Vt.then($t), K && setTimeout(E);
                };
            } else if (W || "undefined" == typeof MutationObserver || !Z(MutationObserver) && "[object MutationObserverConstructor]" !== MutationObserver.toString()) Ut = "undefined" != typeof setImmediate && Z(setImmediate) ? function() {
                setImmediate($t);
            } : function() {
                setTimeout($t, 0);
            }; else {
                var zt = 1, Yt = new MutationObserver($t), Gt = document.createTextNode(String(zt));
                Yt.observe(Gt, {
                    characterData: !0
                }), Ut = function() {
                    zt = (zt + 1) % 2, Gt.data = String(zt);
                };
            }
            function Wt(t, e) {
                var n;
                if (Ft.push(function() {
                    if (t) try {
                        t.call(e);
                    } catch (t) {
                        Nt(t, e, "nextTick");
                    } else n && n(e);
                }), Ht || (Ht = !0, Ut()), !t && "undefined" != typeof Promise) return new Promise(function(t) {
                    n = t;
                });
            }
            var Kt = new tt();
            function Xt(t) {
                (function t(e, n) {
                    var r, i, o = Array.isArray(e);
                    if (!(!o && !s(e) || Object.isFrozen(e) || e instanceof st)) {
                        if (e.__ob__) {
                            var a = e.__ob__.dep.id;
                            if (n.has(a)) return;
                            n.add(a);
                        }
                        if (o) for (r = e.length; r--; ) t(e[r], n); else for (r = (i = Object.keys(e)).length; r--; ) t(e[i[r]], n);
                    }
                })(t, Kt), Kt.clear();
            }
            var Jt = v(function(t) {
                var e = "&" === t.charAt(0), n = "~" === (t = e ? t.slice(1) : t).charAt(0), r = "!" === (t = n ? t.slice(1) : t).charAt(0);
                return {
                    name: t = r ? t.slice(1) : t,
                    once: n,
                    capture: r,
                    passive: e
                };
            });
            function Qt(t, e) {
                function n() {
                    var t = arguments, r = n.fns;
                    if (!Array.isArray(r)) return jt(r, null, arguments, e, "v-on handler");
                    for (var i = r.slice(), o = 0; o < i.length; o++) jt(i[o], null, t, e, "v-on handler");
                }
                return n.fns = t, n;
            }
            function qt(t, e, n, o) {
                var a = e.options.mpOptions && e.options.mpOptions.properties;
                if (r(a)) return n;
                var s = e.options.mpOptions.externalClasses || [], u = t.attrs, c = t.props;
                if (i(u) || i(c)) for (var l in a) {
                    var f = S(l);
                    (Zt(n, c, l, f, !0) || Zt(n, u, l, f, !1)) && n[l] && -1 !== s.indexOf(f) && o[w(n[l])] && (n[l] = o[w(n[l])]);
                }
                return n;
            }
            function Zt(t, e, n, r, o) {
                if (i(e)) {
                    if (g(e, n)) return t[n] = e[n], o || delete e[n], !0;
                    if (g(e, r)) return t[n] = e[r], o || delete e[r], !0;
                }
                return !1;
            }
            function te(t) {
                return a(t) ? [ lt(t) ] : Array.isArray(t) ? function t(e, n) {
                    var s, u, c, l, f = [];
                    for (s = 0; s < e.length; s++) r(u = e[s]) || "boolean" == typeof u || (l = f[c = f.length - 1], 
                    Array.isArray(u) ? u.length > 0 && (ee((u = t(u, (n || "") + "_" + s))[0]) && ee(l) && (f[c] = lt(l.text + u[0].text), 
                    u.shift()), f.push.apply(f, u)) : a(u) ? ee(l) ? f[c] = lt(l.text + u) : "" !== u && f.push(lt(u)) : ee(u) && ee(l) ? f[c] = lt(l.text + u.text) : (o(e._isVList) && i(u.tag) && r(u.key) && i(n) && (u.key = "__vlist" + n + "_" + s + "__"), 
                    f.push(u)));
                    return f;
                }(t) : void 0;
            }
            function ee(t) {
                return i(t) && i(t.text) && function(t) {
                    return !1 === t;
                }(t.isComment);
            }
            function ne(t) {
                var e = t.$options.provide;
                e && (t._provided = "function" == typeof e ? e.call(t) : e);
            }
            function re(t) {
                var e = ie(t.$options.inject, t);
                e && (_t(!1), Object.keys(e).forEach(function(n) {
                    vt(t, n, e[n]);
                }), _t(!0));
            }
            function ie(t, e) {
                if (t) {
                    for (var n = Object.create(null), r = et ? Reflect.ownKeys(t) : Object.keys(t), i = 0; i < r.length; i++) {
                        var o = r[i];
                        if ("__ob__" !== o) {
                            for (var a = t[o].from, s = e; s; ) {
                                if (s._provided && g(s._provided, a)) {
                                    n[o] = s._provided[a];
                                    break;
                                }
                                s = s.$parent;
                            }
                            if (!s && "default" in t[o]) {
                                var u = t[o].default;
                                n[o] = "function" == typeof u ? u.call(e) : u;
                            }
                        }
                    }
                    return n;
                }
            }
            function oe(t, e) {
                if (!t || !t.length) return {};
                for (var n = {}, r = 0, i = t.length; r < i; r++) {
                    var o = t[r], a = o.data;
                    if (a && a.attrs && a.attrs.slot && delete a.attrs.slot, o.context !== e && o.fnContext !== e || !a || null == a.slot) o.asyncMeta && o.asyncMeta.data && "page" === o.asyncMeta.data.slot ? (n.page || (n.page = [])).push(o) : (n.default || (n.default = [])).push(o); else {
                        var s = a.slot, u = n[s] || (n[s] = []);
                        "template" === o.tag ? u.push.apply(u, o.children || []) : u.push(o);
                    }
                }
                for (var c in n) n[c].every(ae) && delete n[c];
                return n;
            }
            function ae(t) {
                return t.isComment && !t.asyncFactory || " " === t.text;
            }
            function se(t, e, r) {
                var i, o = Object.keys(e).length > 0, a = t ? !!t.$stable : !o, s = t && t.$key;
                if (t) {
                    if (t._normalized) return t._normalized;
                    if (a && r && r !== n && s === r.$key && !o && !r.$hasNormal) return r;
                    for (var u in i = {}, t) t[u] && "$" !== u[0] && (i[u] = ue(e, u, t[u]));
                } else i = {};
                for (var c in e) c in i || (i[c] = ce(e, c));
                return t && Object.isExtensible(t) && (t._normalized = i), U(i, "$stable", a), U(i, "$key", s), 
                U(i, "$hasNormal", o), i;
            }
            function ue(t, e, n) {
                var r = function() {
                    var t = arguments.length ? n.apply(null, arguments) : n({});
                    return (t = t && "object" === _typeof3(t) && !Array.isArray(t) ? [ t ] : te(t)) && (0 === t.length || 1 === t.length && t[0].isComment) ? void 0 : t;
                };
                return n.proxy && Object.defineProperty(t, e, {
                    get: r,
                    enumerable: !0,
                    configurable: !0
                }), r;
            }
            function ce(t, e) {
                return function() {
                    return t[e];
                };
            }
            function le(t, e) {
                var n, r, o, a, u;
                if (Array.isArray(t) || "string" == typeof t) for (n = new Array(t.length), r = 0, 
                o = t.length; r < o; r++) n[r] = e(t[r], r, r, r); else if ("number" == typeof t) for (n = new Array(t), 
                r = 0; r < t; r++) n[r] = e(r + 1, r, r, r); else if (s(t)) if (et && t[Symbol.iterator]) {
                    n = [];
                    for (var c = t[Symbol.iterator](), l = c.next(); !l.done; ) n.push(e(l.value, n.length, r, r++)), 
                    l = c.next();
                } else for (a = Object.keys(t), n = new Array(a.length), r = 0, o = a.length; r < o; r++) u = a[r], 
                n[r] = e(t[u], u, r, r);
                return i(n) || (n = []), n._isVList = !0, n;
            }
            function fe(t, e, n, r) {
                var i, o = this.$scopedSlots[t];
                o ? (n = n || {}, r && (n = M(M({}, r), n)), i = o(n, this, n._i) || e) : i = this.$slots[t] || e;
                var a = n && n.slot;
                return a ? this.$createElement("template", {
                    slot: a
                }, i) : i;
            }
            function de(t) {
                return Ot(this.$options, "filters", t) || C;
            }
            function he(t, e) {
                return Array.isArray(t) ? -1 === t.indexOf(e) : t !== e;
            }
            function pe(t, e, n, r, i) {
                var o = D.keyCodes[e] || n;
                return i && r && !D.keyCodes[e] ? he(i, r) : o ? he(o, t) : r ? S(r) !== e : void 0;
            }
            function _e(t, e, n, r, i) {
                if (n && s(n)) {
                    var o;
                    Array.isArray(n) && (n = k(n));
                    var a = function(a) {
                        if ("class" === a || "style" === a || _(a)) o = t; else {
                            var s = t.attrs && t.attrs.type;
                            o = r || D.mustUseProp(e, s, a) ? t.domProps || (t.domProps = {}) : t.attrs || (t.attrs = {});
                        }
                        var u = w(a), c = S(a);
                        u in o || c in o || (o[a] = n[a], !i) || ((t.on || (t.on = {}))["update:" + a] = function(t) {
                            n[a] = t;
                        });
                    };
                    for (var u in n) a(u);
                }
                return t;
            }
            function me(t, e) {
                var n = this._staticTrees || (this._staticTrees = []), r = n[t];
                return r && !e || ge(r = n[t] = this.$options.staticRenderFns[t].call(this._renderProxy, null, this), "__static__" + t, !1), 
                r;
            }
            function ye(t, e, n) {
                return ge(t, "__once__" + e + (n ? "_" + n : ""), !0), t;
            }
            function ge(t, e, n) {
                if (Array.isArray(t)) for (var r = 0; r < t.length; r++) t[r] && "string" != typeof t[r] && ve(t[r], e + "_" + r, n); else ve(t, e, n);
            }
            function ve(t, e, n) {
                t.isStatic = !0, t.key = e, t.isOnce = n;
            }
            function be(t, e) {
                if (e && c(e)) {
                    var n = t.on = t.on ? M({}, t.on) : {};
                    for (var r in e) {
                        var i = n[r], o = e[r];
                        n[r] = i ? [].concat(i, o) : o;
                    }
                }
                return t;
            }
            function we(t, e, n, r) {
                e = e || {
                    $stable: !n
                };
                for (var i = 0; i < t.length; i++) {
                    var o = t[i];
                    Array.isArray(o) ? we(o, e, n) : o && (o.proxy && (o.fn.proxy = !0), e[o.key] = o.fn);
                }
                return r && (e.$key = r), e;
            }
            function xe(t, e) {
                for (var n = 0; n < e.length; n += 2) {
                    var r = e[n];
                    "string" == typeof r && r && (t[e[n]] = e[n + 1]);
                }
                return t;
            }
            function Ae(t, e) {
                return "string" == typeof t ? e + t : t;
            }
            function Se(t) {
                t._o = ye, t._n = h, t._s = d, t._l = le, t._t = fe, t._q = I, t._i = R, t._m = me, 
                t._f = de, t._k = pe, t._b = _e, t._v = lt, t._e = ct, t._u = we, t._g = be, t._d = xe, 
                t._p = Ae;
            }
            function Te(t, e, r, i, a) {
                var s, u = this, c = a.options;
                g(i, "_uid") ? (s = Object.create(i))._original = i : (s = i, i = i._original);
                var l = o(c._compiled), f = !l;
                this.data = t, this.props = e, this.children = r, this.parent = i, this.listeners = t.on || n, 
                this.injections = ie(c.inject, i), this.slots = function() {
                    return u.$slots || se(t.scopedSlots, u.$slots = oe(r, i)), u.$slots;
                }, Object.defineProperty(this, "scopedSlots", {
                    enumerable: !0,
                    get: function() {
                        return se(t.scopedSlots, this.slots());
                    }
                }), l && (this.$options = c, this.$slots = this.slots(), this.$scopedSlots = se(t.scopedSlots, this.$slots)), 
                c._scopeId ? this._c = function(t, e, n, r) {
                    var o = Ie(s, t, e, n, r, f);
                    return o && !Array.isArray(o) && (o.fnScopeId = c._scopeId, o.fnContext = i), o;
                } : this._c = function(t, e, n, r) {
                    return Ie(s, t, e, n, r, f);
                };
            }
            function Pe(t, e, n, r, i) {
                var o = function(t) {
                    var e = new st(t.tag, t.data, t.children && t.children.slice(), t.text, t.elm, t.context, t.componentOptions, t.asyncFactory);
                    return e.ns = t.ns, e.isStatic = t.isStatic, e.key = t.key, e.isComment = t.isComment, 
                    e.fnContext = t.fnContext, e.fnOptions = t.fnOptions, e.fnScopeId = t.fnScopeId, 
                    e.asyncMeta = t.asyncMeta, e.isCloned = !0, e;
                }(t);
                return o.fnContext = n, o.fnOptions = r, e.slot && ((o.data || (o.data = {})).slot = e.slot), 
                o;
            }
            function Me(t, e) {
                for (var n in e) t[w(n)] = e[n];
            }
            Se(Te.prototype);
            var ke = {
                init: function(t, e) {
                    if (t.componentInstance && !t.componentInstance._isDestroyed && t.data.keepAlive) {
                        var n = t;
                        ke.prepatch(n, n);
                    } else {
                        (t.componentInstance = function(t, e) {
                            var n = {
                                _isComponent: !0,
                                _parentVnode: t,
                                parent: e
                            }, r = t.data.inlineTemplate;
                            return i(r) && (n.render = r.render, n.staticRenderFns = r.staticRenderFns), new t.componentOptions.Ctor(n);
                        }(t, He)).$mount(e ? t.elm : void 0, e);
                    }
                },
                prepatch: function(t, e) {
                    var r = e.componentOptions;
                    !function(t, e, r, i, o) {
                        var a = i.data.scopedSlots, s = t.$scopedSlots, u = !!(a && !a.$stable || s !== n && !s.$stable || a && t.$scopedSlots.$key !== a.$key), c = !!(o || t.$options._renderChildren || u);
                        if (t.$options._parentVnode = i, t.$vnode = i, t._vnode && (t._vnode.parent = i), 
                        t.$options._renderChildren = o, t.$attrs = i.data.attrs || n, t.$listeners = r || n, 
                        e && t.$options.props) {
                            _t(!1);
                            for (var l = t._props, f = t.$options._propKeys || [], d = 0; d < f.length; d++) {
                                var h = f[d], p = t.$options.props;
                                l[h] = Ct(h, p, e, t);
                            }
                            _t(!0), t.$options.propsData = e;
                        }
                        t._$updateProperties && t._$updateProperties(t), r = r || n;
                        var _ = t.$options._parentListeners;
                        t.$options._parentListeners = r, Fe(t, r, _), c && (t.$slots = oe(o, i.context), 
                        t.$forceUpdate());
                    }(e.componentInstance = t.componentInstance, r.propsData, r.listeners, e, r.children);
                },
                insert: function(t) {
                    var e = t.context, n = t.componentInstance;
                    n._isMounted || (ze(n, "onServiceCreated"), ze(n, "onServiceAttached"), n._isMounted = !0, 
                    ze(n, "mounted")), t.data.keepAlive && (e._isMounted ? function(t) {
                        t._inactive = !1, Ge.push(t);
                    }(n) : Ve(n, !0));
                },
                destroy: function(t) {
                    var e = t.componentInstance;
                    e._isDestroyed || (t.data.keepAlive ? function t(e, n) {
                        if (!(n && (e._directInactive = !0, $e(e)) || e._inactive)) {
                            e._inactive = !0;
                            for (var r = 0; r < e.$children.length; r++) t(e.$children[r]);
                            ze(e, "deactivated");
                        }
                    }(e, !0) : e.$destroy());
                }
            }, Ee = Object.keys(ke);
            function Oe(t, e, a, u, c) {
                if (!r(t)) {
                    var l = a.$options._base;
                    if (s(t) && (t = l.extend(t)), "function" == typeof t) {
                        var d;
                        if (r(t.cid) && void 0 === (t = function(t, e) {
                            if (o(t.error) && i(t.errorComp)) return t.errorComp;
                            if (i(t.resolved)) return t.resolved;
                            var n = Le;
                            if (n && i(t.owners) && -1 === t.owners.indexOf(n) && t.owners.push(n), o(t.loading) && i(t.loadingComp)) return t.loadingComp;
                            if (n && !i(t.owners)) {
                                var a = t.owners = [ n ], u = !0, c = null, l = null;
                                n.$on("hook:destroyed", function() {
                                    return m(a, n);
                                });
                                var d = function(t) {
                                    for (var e = 0, n = a.length; e < n; e++) a[e].$forceUpdate();
                                    t && (a.length = 0, null !== c && (clearTimeout(c), c = null), null !== l && (clearTimeout(l), 
                                    l = null));
                                }, h = L(function(n) {
                                    t.resolved = Ne(n, e), u ? a.length = 0 : d(!0);
                                }), p = L(function(e) {
                                    i(t.errorComp) && (t.error = !0, d(!0));
                                }), _ = t(h, p);
                                return s(_) && (f(_) ? r(t.resolved) && _.then(h, p) : f(_.component) && (_.component.then(h, p), 
                                i(_.error) && (t.errorComp = Ne(_.error, e)), i(_.loading) && (t.loadingComp = Ne(_.loading, e), 
                                0 === _.delay ? t.loading = !0 : c = setTimeout(function() {
                                    c = null, r(t.resolved) && r(t.error) && (t.loading = !0, d(!1));
                                }, _.delay || 200)), i(_.timeout) && (l = setTimeout(function() {
                                    l = null, r(t.resolved) && p(null);
                                }, _.timeout)))), u = !1, t.loading ? t.loadingComp : t.resolved;
                            }
                        }(d = t, l))) return function(t, e, n, r, i) {
                            var o = ct();
                            return o.asyncFactory = t, o.asyncMeta = {
                                data: e,
                                context: n,
                                children: r,
                                tag: i
                            }, o;
                        }(d, e, a, u, c);
                        e = e || {}, fn(t), i(e.model) && function(t, e) {
                            var n = t.model && t.model.prop || "value", r = t.model && t.model.event || "input";
                            (e.attrs || (e.attrs = {}))[n] = e.model.value;
                            var o = e.on || (e.on = {}), a = o[r], s = e.model.callback;
                            i(a) ? (Array.isArray(a) ? -1 === a.indexOf(s) : a !== s) && (o[r] = [ s ].concat(a)) : o[r] = s;
                        }(t.options, e);
                        var h = function(t, e, n, o) {
                            var a = e.options.props;
                            if (r(a)) return qt(t, e, {}, o);
                            var s = {}, u = t.attrs, c = t.props;
                            if (i(u) || i(c)) for (var l in a) {
                                var f = S(l);
                                Zt(s, c, l, f, !0) || Zt(s, u, l, f, !1);
                            }
                            return qt(t, e, s, o);
                        }(e, t, 0, a);
                        if (o(t.options.functional)) return function(t, e, r, o, a) {
                            var s = t.options, u = {}, c = s.props;
                            if (i(c)) for (var l in c) u[l] = Ct(l, c, e || n); else i(r.attrs) && Me(u, r.attrs), 
                            i(r.props) && Me(u, r.props);
                            var f = new Te(r, u, a, o, t), d = s.render.call(null, f._c, f);
                            if (d instanceof st) return Pe(d, r, f.parent, s);
                            if (Array.isArray(d)) {
                                for (var h = te(d) || [], p = new Array(h.length), _ = 0; _ < h.length; _++) p[_] = Pe(h[_], r, f.parent, s);
                                return p;
                            }
                        }(t, h, e, a, u);
                        var p = e.on;
                        if (e.on = e.nativeOn, o(t.options.abstract)) {
                            var _ = e.slot;
                            e = {}, _ && (e.slot = _);
                        }
                        !function(t) {
                            for (var e = t.hook || (t.hook = {}), n = 0; n < Ee.length; n++) {
                                var r = Ee[n], i = e[r], o = ke[r];
                                i === o || i && i._merged || (e[r] = i ? Ce(o, i) : o);
                            }
                        }(e);
                        var y = t.options.name || c;
                        return new st("vue-component-" + t.cid + (y ? "-" + y : ""), e, void 0, void 0, void 0, a, {
                            Ctor: t,
                            propsData: h,
                            listeners: p,
                            tag: c,
                            children: u
                        }, d);
                    }
                }
            }
            function Ce(t, e) {
                var n = function(n, r) {
                    t(n, r), e(n, r);
                };
                return n._merged = !0, n;
            }
            function Ie(t, e, n, u, c, l) {
                return (Array.isArray(n) || a(n)) && (c = u, u = n, n = void 0), o(l) && (c = 2), 
                function(t, e, n, a, u) {
                    if (i(n) && i(n.__ob__)) return ct();
                    if (i(n) && i(n.is) && (e = n.is), !e) return ct();
                    var c, l, f;
                    (Array.isArray(a) && "function" == typeof a[0] && ((n = n || {}).scopedSlots = {
                        default: a[0]
                    }, a.length = 0), 2 === u ? a = te(a) : 1 === u && (a = function(t) {
                        for (var e = 0; e < t.length; e++) if (Array.isArray(t[e])) return Array.prototype.concat.apply([], t);
                        return t;
                    }(a)), "string" == typeof e) ? (l = t.$vnode && t.$vnode.ns || D.getTagNamespace(e), 
                    c = D.isReservedTag(e) ? new st(D.parsePlatformTagName(e), n, a, void 0, void 0, t) : n && n.pre || !i(f = Ot(t.$options, "components", e)) ? new st(e, n, a, void 0, void 0, t) : Oe(f, n, t, a, e)) : c = Oe(e, n, t, a);
                    return Array.isArray(c) ? c : i(c) ? (i(l) && function t(e, n, a) {
                        if (e.ns = n, "foreignObject" === e.tag && (n = void 0, a = !0), i(e.children)) for (var s = 0, u = e.children.length; s < u; s++) {
                            var c = e.children[s];
                            i(c.tag) && (r(c.ns) || o(a) && "svg" !== c.tag) && t(c, n, a);
                        }
                    }(c, l), i(n) && function(t) {
                        s(t.style) && Xt(t.style), s(t.class) && Xt(t.class);
                    }(n), c) : ct();
                }(t, e, n, u, c);
            }
            var Re, Le = null;
            function Ne(t, e) {
                return (t.__esModule || et && "Module" === t[Symbol.toStringTag]) && (t = t.default), 
                s(t) ? e.extend(t) : t;
            }
            function je(t) {
                return t.isComment && t.asyncFactory;
            }
            function De(t, e) {
                Re.$on(t, e);
            }
            function Be(t, e) {
                Re.$off(t, e);
            }
            function Ue(t, e) {
                var n = Re;
                return function r() {
                    var i = e.apply(null, arguments);
                    null !== i && n.$off(t, r);
                };
            }
            function Fe(t, e, n) {
                Re = t, function(t, e, n, i, a, s) {
                    var u, c, l, f;
                    for (u in t) c = t[u], l = e[u], f = Jt(u), r(c) || (r(l) ? (r(c.fns) && (c = t[u] = Qt(c, s)), 
                    o(f.once) && (c = t[u] = a(f.name, c, f.capture)), n(f.name, c, f.capture, f.passive, f.params)) : c !== l && (l.fns = c, 
                    t[u] = l));
                    for (u in e) r(t[u]) && i((f = Jt(u)).name, e[u], f.capture);
                }(e, n || {}, De, Be, Ue, t), Re = void 0;
            }
            var He = null;
            function $e(t) {
                for (;t && (t = t.$parent); ) if (t._inactive) return !0;
                return !1;
            }
            function Ve(t, e) {
                if (e) {
                    if (t._directInactive = !1, $e(t)) return;
                } else if (t._directInactive) return;
                if (t._inactive || null === t._inactive) {
                    t._inactive = !1;
                    for (var n = 0; n < t.$children.length; n++) Ve(t.$children[n]);
                    ze(t, "activated");
                }
            }
            function ze(t, e) {
                ot();
                var n = t.$options[e], r = e + " hook";
                if (n) for (var i = 0, o = n.length; i < o; i++) jt(n[i], t, null, t, r);
                t._hasHookEvent && t.$emit("hook:" + e), at();
            }
            var Ye = [], Ge = [], We = {}, Ke = !1, Xe = !1, Je = 0, Qe = Date.now;
            if (V && !W) {
                var qe = window.performance;
                qe && "function" == typeof qe.now && Qe() > document.createEvent("Event").timeStamp && (Qe = function() {
                    return qe.now();
                });
            }
            function Ze() {
                var t, e;
                for (Qe(), Xe = !0, Ye.sort(function(t, e) {
                    return t.id - e.id;
                }), Je = 0; Je < Ye.length; Je++) (t = Ye[Je]).before && t.before(), e = t.id, We[e] = null, 
                t.run();
                var n = Ge.slice(), r = Ye.slice();
                Je = Ye.length = Ge.length = 0, We = {}, Ke = Xe = !1, function(t) {
                    for (var e = 0; e < t.length; e++) t[e]._inactive = !0, Ve(t[e], !0);
                }(n), function(t) {
                    for (var e = t.length; e--; ) {
                        var n = t[e], r = n.vm;
                        r._watcher === n && r._isMounted && !r._isDestroyed && ze(r, "updated");
                    }
                }(r), q && D.devtools && q.emit("flush");
            }
            var tn = 0, en = function(t, e, n, r, i) {
                this.vm = t, i && (t._watcher = this), t._watchers.push(this), r ? (this.deep = !!r.deep, 
                this.user = !!r.user, this.lazy = !!r.lazy, this.sync = !!r.sync, this.before = r.before) : this.deep = this.user = this.lazy = this.sync = !1, 
                this.cb = n, this.id = ++tn, this.active = !0, this.dirty = this.lazy, this.deps = [], 
                this.newDeps = [], this.depIds = new tt(), this.newDepIds = new tt(), this.expression = "", 
                "function" == typeof e ? this.getter = e : (this.getter = function(t) {
                    if (!H.test(t)) {
                        var e = t.split(".");
                        return function(t) {
                            for (var n = 0; n < e.length; n++) {
                                if (!t) return;
                                t = t[e[n]];
                            }
                            return t;
                        };
                    }
                }(e), this.getter || (this.getter = E)), this.value = this.lazy ? void 0 : this.get();
            };
            en.prototype.get = function() {
                var t;
                ot(this);
                var e = this.vm;
                try {
                    t = this.getter.call(e, e);
                } catch (t) {
                    if (!this.user) throw t;
                    Nt(t, e, 'getter for watcher "' + this.expression + '"');
                } finally {
                    this.deep && Xt(t), at(), this.cleanupDeps();
                }
                return t;
            }, en.prototype.addDep = function(t) {
                var e = t.id;
                this.newDepIds.has(e) || (this.newDepIds.add(e), this.newDeps.push(t), this.depIds.has(e) || t.addSub(this));
            }, en.prototype.cleanupDeps = function() {
                for (var t = this.deps.length; t--; ) {
                    var e = this.deps[t];
                    this.newDepIds.has(e.id) || e.removeSub(this);
                }
                var n = this.depIds;
                this.depIds = this.newDepIds, this.newDepIds = n, this.newDepIds.clear(), n = this.deps, 
                this.deps = this.newDeps, this.newDeps = n, this.newDeps.length = 0;
            }, en.prototype.update = function() {
                this.lazy ? this.dirty = !0 : this.sync ? this.run() : function(t) {
                    var e = t.id;
                    if (null == We[e]) {
                        if (We[e] = !0, Xe) {
                            for (var n = Ye.length - 1; n > Je && Ye[n].id > t.id; ) n--;
                            Ye.splice(n + 1, 0, t);
                        } else Ye.push(t);
                        Ke || (Ke = !0, Wt(Ze));
                    }
                }(this);
            }, en.prototype.run = function() {
                if (this.active) {
                    var t = this.get();
                    if (t !== this.value || s(t) || this.deep) {
                        var e = this.value;
                        if (this.value = t, this.user) try {
                            this.cb.call(this.vm, t, e);
                        } catch (t) {
                            Nt(t, this.vm, 'callback for watcher "' + this.expression + '"');
                        } else this.cb.call(this.vm, t, e);
                    }
                }
            }, en.prototype.evaluate = function() {
                this.value = this.get(), this.dirty = !1;
            }, en.prototype.depend = function() {
                for (var t = this.deps.length; t--; ) this.deps[t].depend();
            }, en.prototype.teardown = function() {
                if (this.active) {
                    this.vm._isBeingDestroyed || m(this.vm._watchers, this);
                    for (var t = this.deps.length; t--; ) this.deps[t].removeSub(this);
                    this.active = !1;
                }
            };
            var nn = {
                enumerable: !0,
                configurable: !0,
                get: E,
                set: E
            };
            function rn(t, e, n) {
                nn.get = function() {
                    return this[e][n];
                }, nn.set = function(t) {
                    this[e][n] = t;
                }, Object.defineProperty(t, n, nn);
            }
            var on = {
                lazy: !0
            };
            function an(t, e, n) {
                var r = !Q();
                "function" == typeof n ? (nn.get = r ? sn(e) : un(n), nn.set = E) : (nn.get = n.get ? r && !1 !== n.cache ? sn(e) : un(n.get) : E, 
                nn.set = n.set || E), Object.defineProperty(t, e, nn);
            }
            function sn(t) {
                return function() {
                    var e = this._computedWatchers && this._computedWatchers[t];
                    if (e) return e.dirty && e.evaluate(), it.SharedObject.target && e.depend(), e.value;
                };
            }
            function un(t) {
                return function() {
                    return t.call(this, this);
                };
            }
            function cn(t, e, n, r) {
                return c(n) && (r = n, n = n.handler), "string" == typeof n && (n = t[n]), t.$watch(e, n, r);
            }
            var ln = 0;
            function fn(t) {
                var e = t.options;
                if (t.super) {
                    var n = fn(t.super);
                    if (n !== t.superOptions) {
                        t.superOptions = n;
                        var r = function(t) {
                            var e, n = t.options, r = t.sealedOptions;
                            for (var i in n) n[i] !== r[i] && (e || (e = {}), e[i] = n[i]);
                            return e;
                        }(t);
                        r && M(t.extendOptions, r), (e = t.options = Et(n, t.extendOptions)).name && (e.components[e.name] = t);
                    }
                }
                return e;
            }
            function dn(t) {
                this._init(t);
            }
            function hn(t) {
                return t && (t.Ctor.options.name || t.tag);
            }
            function pn(t, e) {
                return Array.isArray(t) ? t.indexOf(e) > -1 : "string" == typeof t ? t.split(",").indexOf(e) > -1 : !!function(t) {
                    return "[object RegExp]" === u.call(t);
                }(t) && t.test(e);
            }
            function _n(t, e) {
                var n = t.cache, r = t.keys, i = t._vnode;
                for (var o in n) {
                    var a = n[o];
                    if (a) {
                        var s = hn(a.componentOptions);
                        s && !e(s) && mn(n, o, r, i);
                    }
                }
            }
            function mn(t, e, n, r) {
                var i = t[e];
                !i || r && i.tag === r.tag || i.componentInstance.$destroy(), t[e] = null, m(n, e);
            }
            (function(t) {
                t.prototype._init = function(t) {
                    var e = this;
                    e._uid = ln++, e._isVue = !0, t && t._isComponent ? function(t, e) {
                        var n = t.$options = Object.create(t.constructor.options), r = e._parentVnode;
                        n.parent = e.parent, n._parentVnode = r;
                        var i = r.componentOptions;
                        n.propsData = i.propsData, n._parentListeners = i.listeners, n._renderChildren = i.children, 
                        n._componentTag = i.tag, e.render && (n.render = e.render, n.staticRenderFns = e.staticRenderFns);
                    }(e, t) : e.$options = Et(fn(e.constructor), t || {}, e), e._renderProxy = e, e._self = e, 
                    function(t) {
                        var e = t.$options, n = e.parent;
                        if (n && !e.abstract) {
                            for (;n.$options.abstract && n.$parent; ) n = n.$parent;
                            n.$children.push(t);
                        }
                        t.$parent = n, t.$root = n ? n.$root : t, t.$children = [], t.$refs = {}, t._watcher = null, 
                        t._inactive = null, t._directInactive = !1, t._isMounted = !1, t._isDestroyed = !1, 
                        t._isBeingDestroyed = !1;
                    }(e), function(t) {
                        t._events = Object.create(null), t._hasHookEvent = !1;
                        var e = t.$options._parentListeners;
                        e && Fe(t, e);
                    }(e), function(t) {
                        t._vnode = null, t._staticTrees = null;
                        var e = t.$options, r = t.$vnode = e._parentVnode, i = r && r.context;
                        t.$slots = oe(e._renderChildren, i), t.$scopedSlots = n, t._c = function(e, n, r, i) {
                            return Ie(t, e, n, r, i, !1);
                        }, t.$createElement = function(e, n, r, i) {
                            return Ie(t, e, n, r, i, !0);
                        };
                        var o = r && r.data;
                        vt(t, "$attrs", o && o.attrs || n, null, !0), vt(t, "$listeners", e._parentListeners || n, null, !0);
                    }(e), ze(e, "beforeCreate"), !e._$fallback && re(e), function(t) {
                        t._watchers = [];
                        var e = t.$options;
                        e.props && function(t, e) {
                            var n = t.$options.propsData || {}, r = t._props = {}, i = t.$options._propKeys = [];
                            !t.$parent || _t(!1);
                            var o = function(o) {
                                i.push(o);
                                var a = Ct(o, e, n, t);
                                vt(r, o, a), o in t || rn(t, "_props", o);
                            };
                            for (var a in e) o(a);
                            _t(!0);
                        }(t, e.props), e.methods && function(t, e) {
                            for (var n in t.$options.props, e) t[n] = "function" != typeof e[n] ? E : T(e[n], t);
                        }(t, e.methods), e.data ? function(t) {
                            var e = t.$options.data;
                            c(e = t._data = "function" == typeof e ? function(t, e) {
                                ot();
                                try {
                                    return t.call(e, e);
                                } catch (t) {
                                    return Nt(t, e, "data()"), {};
                                } finally {
                                    at();
                                }
                            }(e, t) : e || {}) || (e = {});
                            for (var n = Object.keys(e), r = t.$options.props, i = (t.$options.methods, n.length); i--; ) {
                                var o = n[i];
                                r && g(r, o) || B(o) || rn(t, "_data", o);
                            }
                            gt(e, !0);
                        }(t) : gt(t._data = {}, !0), e.computed && function(t, e) {
                            var n = t._computedWatchers = Object.create(null), r = Q();
                            for (var i in e) {
                                var o = e[i], a = "function" == typeof o ? o : o.get;
                                r || (n[i] = new en(t, a || E, E, on)), i in t || an(t, i, o);
                            }
                        }(t, e.computed), e.watch && e.watch !== X && function(t, e) {
                            for (var n in e) {
                                var r = e[n];
                                if (Array.isArray(r)) for (var i = 0; i < r.length; i++) cn(t, n, r[i]); else cn(t, n, r);
                            }
                        }(t, e.watch);
                    }(e), !e._$fallback && ne(e), !e._$fallback && ze(e, "created"), e.$options.el && e.$mount(e.$options.el);
                };
            })(dn), function(t) {
                Object.defineProperty(t.prototype, "$data", {
                    get: function() {
                        return this._data;
                    }
                }), Object.defineProperty(t.prototype, "$props", {
                    get: function() {
                        return this._props;
                    }
                }), t.prototype.$set = bt, t.prototype.$delete = wt, t.prototype.$watch = function(t, e, n) {
                    if (c(e)) return cn(this, t, e, n);
                    (n = n || {}).user = !0;
                    var r = new en(this, t, e, n);
                    if (n.immediate) try {
                        e.call(this, r.value);
                    } catch (t) {
                        Nt(t, this, 'callback for immediate watcher "' + r.expression + '"');
                    }
                    return function() {
                        r.teardown();
                    };
                };
            }(dn), function(t) {
                var e = /^hook:/;
                t.prototype.$on = function(t, n) {
                    var r = this;
                    if (Array.isArray(t)) for (var i = 0, o = t.length; i < o; i++) r.$on(t[i], n); else (r._events[t] || (r._events[t] = [])).push(n), 
                    e.test(t) && (r._hasHookEvent = !0);
                    return r;
                }, t.prototype.$once = function(t, e) {
                    var n = this;
                    function r() {
                        n.$off(t, r), e.apply(n, arguments);
                    }
                    return r.fn = e, n.$on(t, r), n;
                }, t.prototype.$off = function(t, e) {
                    var n = this;
                    if (!arguments.length) return n._events = Object.create(null), n;
                    if (Array.isArray(t)) {
                        for (var r = 0, i = t.length; r < i; r++) n.$off(t[r], e);
                        return n;
                    }
                    var o, a = n._events[t];
                    if (!a) return n;
                    if (!e) return n._events[t] = null, n;
                    for (var s = a.length; s--; ) if ((o = a[s]) === e || o.fn === e) {
                        a.splice(s, 1);
                        break;
                    }
                    return n;
                }, t.prototype.$emit = function(t) {
                    var e = this, n = e._events[t];
                    if (n) {
                        n = n.length > 1 ? P(n) : n;
                        for (var r = P(arguments, 1), i = 'event handler for "' + t + '"', o = 0, a = n.length; o < a; o++) jt(n[o], e, r, e, i);
                    }
                    return e;
                };
            }(dn), function(t) {
                t.prototype._update = function(t, e) {
                    var n = this, r = n.$el, i = n._vnode, o = function(t) {
                        var e = He;
                        return He = t, function() {
                            He = e;
                        };
                    }(n);
                    n._vnode = t, n.$el = i ? n.__patch__(i, t) : n.__patch__(n.$el, t, e, !1), o(), 
                    r && (r.__vue__ = null), n.$el && (n.$el.__vue__ = n), n.$vnode && n.$parent && n.$vnode === n.$parent._vnode && (n.$parent.$el = n.$el);
                }, t.prototype.$forceUpdate = function() {
                    this._watcher && this._watcher.update();
                }, t.prototype.$destroy = function() {
                    var t = this;
                    if (!t._isBeingDestroyed) {
                        ze(t, "beforeDestroy"), t._isBeingDestroyed = !0;
                        var e = t.$parent;
                        !e || e._isBeingDestroyed || t.$options.abstract || m(e.$children, t), t._watcher && t._watcher.teardown();
                        for (var n = t._watchers.length; n--; ) t._watchers[n].teardown();
                        t._data.__ob__ && t._data.__ob__.vmCount--, t._isDestroyed = !0, t.__patch__(t._vnode, null), 
                        ze(t, "destroyed"), t.$off(), t.$el && (t.$el.__vue__ = null), t.$vnode && (t.$vnode.parent = null);
                    }
                };
            }(dn), function(t) {
                Se(t.prototype), t.prototype.$nextTick = function(t) {
                    return Wt(t, this);
                }, t.prototype._render = function() {
                    var t, e = this, n = e.$options, r = n.render, i = n._parentVnode;
                    i && (e.$scopedSlots = se(i.data.scopedSlots, e.$slots, e.$scopedSlots)), e.$vnode = i;
                    try {
                        Le = e, t = r.call(e._renderProxy, e.$createElement);
                    } catch (n) {
                        Nt(n, e, "render"), t = e._vnode;
                    } finally {
                        Le = null;
                    }
                    return Array.isArray(t) && 1 === t.length && (t = t[0]), t instanceof st || (t = ct()), 
                    t.parent = i, t;
                };
            }(dn);
            var yn = [ String, RegExp, Array ], gn = {
                KeepAlive: {
                    name: "keep-alive",
                    abstract: !0,
                    props: {
                        include: yn,
                        exclude: yn,
                        max: [ String, Number ]
                    },
                    created: function() {
                        this.cache = Object.create(null), this.keys = [];
                    },
                    destroyed: function() {
                        for (var t in this.cache) mn(this.cache, t, this.keys);
                    },
                    mounted: function() {
                        var t = this;
                        this.$watch("include", function(e) {
                            _n(t, function(t) {
                                return pn(e, t);
                            });
                        }), this.$watch("exclude", function(e) {
                            _n(t, function(t) {
                                return !pn(e, t);
                            });
                        });
                    },
                    render: function() {
                        var t = this.$slots.default, e = function(t) {
                            if (Array.isArray(t)) for (var e = 0; e < t.length; e++) {
                                var n = t[e];
                                if (i(n) && (i(n.componentOptions) || je(n))) return n;
                            }
                        }(t), n = e && e.componentOptions;
                        if (n) {
                            var r = hn(n), o = this.include, a = this.exclude;
                            if (o && (!r || !pn(o, r)) || a && r && pn(a, r)) return e;
                            var s = this.cache, u = this.keys, c = null == e.key ? n.Ctor.cid + (n.tag ? "::" + n.tag : "") : e.key;
                            s[c] ? (e.componentInstance = s[c].componentInstance, m(u, c), u.push(c)) : (s[c] = e, 
                            u.push(c), this.max && u.length > parseInt(this.max) && mn(s, u[0], u, this._vnode)), 
                            e.data.keepAlive = !0;
                        }
                        return e || t && t[0];
                    }
                }
            };
            (function(t) {
                var e = {
                    get: function() {
                        return D;
                    }
                };
                Object.defineProperty(t, "config", e), t.util = {
                    warn: nt,
                    extend: M,
                    mergeOptions: Et,
                    defineReactive: vt
                }, t.set = bt, t.delete = wt, t.nextTick = Wt, t.observable = function(t) {
                    return gt(t), t;
                }, t.options = Object.create(null), N.forEach(function(e) {
                    t.options[e + "s"] = Object.create(null);
                }), t.options._base = t, M(t.options.components, gn), function(t) {
                    t.use = function(t) {
                        var e = this._installedPlugins || (this._installedPlugins = []);
                        if (e.indexOf(t) > -1) return this;
                        var n = P(arguments, 1);
                        return n.unshift(this), "function" == typeof t.install ? t.install.apply(t, n) : "function" == typeof t && t.apply(null, n), 
                        e.push(t), this;
                    };
                }(t), function(t) {
                    t.mixin = function(t) {
                        return this.options = Et(this.options, t), this;
                    };
                }(t), function(t) {
                    t.cid = 0;
                    var e = 1;
                    t.extend = function(t) {
                        t = t || {};
                        var n = this, r = n.cid, i = t._Ctor || (t._Ctor = {});
                        if (i[r]) return i[r];
                        var o = t.name || n.options.name, a = function(t) {
                            this._init(t);
                        };
                        return (a.prototype = Object.create(n.prototype)).constructor = a, a.cid = e++, 
                        a.options = Et(n.options, t), a.super = n, a.options.props && function(t) {
                            var e = t.options.props;
                            for (var n in e) rn(t.prototype, "_props", n);
                        }(a), a.options.computed && function(t) {
                            var e = t.options.computed;
                            for (var n in e) an(t.prototype, n, e[n]);
                        }(a), a.extend = n.extend, a.mixin = n.mixin, a.use = n.use, N.forEach(function(t) {
                            a[t] = n[t];
                        }), o && (a.options.components[o] = a), a.superOptions = n.options, a.extendOptions = t, 
                        a.sealedOptions = M({}, a.options), i[r] = a, a;
                    };
                }(t), function(t) {
                    N.forEach(function(e) {
                        t[e] = function(t, n) {
                            return n ? ("component" === e && c(n) && (n.name = n.name || t, n = this.options._base.extend(n)), 
                            "directive" === e && "function" == typeof n && (n = {
                                bind: n,
                                update: n
                            }), this.options[e + "s"][t] = n, n) : this.options[e + "s"][t];
                        };
                    });
                }(t);
            })(dn), Object.defineProperty(dn.prototype, "$isServer", {
                get: Q
            }), Object.defineProperty(dn.prototype, "$ssrContext", {
                get: function() {
                    return this.$vnode && this.$vnode.ssrContext;
                }
            }), Object.defineProperty(dn, "FunctionalRenderContext", {
                value: Te
            }), dn.version = "2.6.11";
            var vn = "[object Array]", bn = "[object Object]";
            function wn(t, e, n) {
                t[e] = n;
            }
            function xn(t) {
                return Object.prototype.toString.call(t);
            }
            function An(t) {
                if (t.__next_tick_callbacks && t.__next_tick_callbacks.length) {
                    if (Object({
                        VUE_APP_DARK_MODE: "false",
                        VUE_APP_NAME: "冥想星球",
                        VUE_APP_PLATFORM: "mp-weixin",
                        NODE_ENV: "production",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG) {
                        var e = t.$scope;
                        console.log("[" + +new Date() + "][" + (e.is || e.route) + "][" + t._uid + "]:flushCallbacks[" + t.__next_tick_callbacks.length + "]");
                    }
                    var n = t.__next_tick_callbacks.slice(0);
                    t.__next_tick_callbacks.length = 0;
                    for (var r = 0; r < n.length; r++) n[r]();
                }
            }
            function Sn(t, e) {
                return e && (e._isVue || e.__v_isMPComponent) ? {} : e;
            }
            function Tn() {}
            var Pn = v(function(t) {
                var e = {}, n = /:(.+)/;
                return t.split(/;(?![^(]*\))/g).forEach(function(t) {
                    if (t) {
                        var r = t.split(n);
                        r.length > 1 && (e[r[0].trim()] = r[1].trim());
                    }
                }), e;
            }), Mn = [ "createSelectorQuery", "createIntersectionObserver", "selectAllComponents", "selectComponent" ], kn = [ "onLaunch", "onShow", "onHide", "onUniNViewMessage", "onPageNotFound", "onThemeChange", "onError", "onUnhandledRejection", "onInit", "onLoad", "onReady", "onUnload", "onPullDownRefresh", "onReachBottom", "onTabItemTap", "onAddToFavorites", "onShareTimeline", "onShareAppMessage", "onResize", "onPageScroll", "onNavigationBarButtonTap", "onBackPress", "onNavigationBarSearchInputChanged", "onNavigationBarSearchInputConfirmed", "onNavigationBarSearchInputClicked", "onPageShow", "onPageHide", "onPageResize", "onUploadDouyinVideo" ];
            dn.prototype.__patch__ = function(t, e) {
                var n = this;
                if (null !== e && ("page" === this.mpType || "component" === this.mpType)) {
                    var r = this.$scope, i = Object.create(null);
                    try {
                        i = function(t) {
                            var e = Object.create(null);
                            [].concat(Object.keys(t._data || {}), Object.keys(t._computedWatchers || {})).reduce(function(e, n) {
                                return e[n] = t[n], e;
                            }, e);
                            var n = t.__composition_api_state__ || t.__secret_vfa_state__, r = n && n.rawBindings;
                            return r && Object.keys(r).forEach(function(n) {
                                e[n] = t[n];
                            }), Object.assign(e, t.$mp.data || {}), Array.isArray(t.$options.behaviors) && -1 !== t.$options.behaviors.indexOf("uni://form-field") && (e.name = t.name, 
                            e.value = t.value), JSON.parse(JSON.stringify(e, Sn));
                        }(this);
                    } catch (t) {
                        console.error(t);
                    }
                    i.__webviewId__ = r.data.__webviewId__;
                    var o = Object.create(null);
                    Object.keys(i).forEach(function(t) {
                        o[t] = r.data[t];
                    });
                    var a = !1 === this.$shouldDiffData ? i : function(t, e) {
                        var n = {};
                        return function t(e, n) {
                            if (e !== n) {
                                var r = xn(e), i = xn(n);
                                if (r == bn && i == bn) {
                                    if (Object.keys(e).length >= Object.keys(n).length) for (var o in n) {
                                        var a = e[o];
                                        void 0 === a ? e[o] = null : t(a, n[o]);
                                    }
                                } else r == vn && i == vn && e.length >= n.length && n.forEach(function(n, r) {
                                    t(e[r], n);
                                });
                            }
                        }(t, e), function t(e, n, r, i) {
                            if (e !== n) {
                                var o = xn(e), a = xn(n);
                                if (o == bn) if (a != bn || Object.keys(e).length < Object.keys(n).length) wn(i, r, e); else {
                                    var s = function(o) {
                                        var a = e[o], s = n[o], u = xn(a), c = xn(s);
                                        if (u != vn && u != bn) a !== n[o] && function(t, e) {
                                            return "[object Null]" !== t && "[object Undefined]" !== t || "[object Null]" !== e && "[object Undefined]" !== e;
                                        }(u, c) && wn(i, ("" == r ? "" : r + ".") + o, a); else if (u == vn) c != vn || a.length < s.length ? wn(i, ("" == r ? "" : r + ".") + o, a) : a.forEach(function(e, n) {
                                            t(e, s[n], ("" == r ? "" : r + ".") + o + "[" + n + "]", i);
                                        }); else if (u == bn) if (c != bn || Object.keys(a).length < Object.keys(s).length) wn(i, ("" == r ? "" : r + ".") + o, a); else for (var l in a) t(a[l], s[l], ("" == r ? "" : r + ".") + o + "." + l, i);
                                    };
                                    for (var u in e) s(u);
                                } else o == vn ? a != vn || e.length < n.length ? wn(i, r, e) : e.forEach(function(e, o) {
                                    t(e, n[o], r + "[" + o + "]", i);
                                }) : wn(i, r, e);
                            }
                        }(t, e, "", n), n;
                    }(i, o);
                    Object.keys(a).length ? (Object({
                        VUE_APP_DARK_MODE: "false",
                        VUE_APP_NAME: "冥想星球",
                        VUE_APP_PLATFORM: "mp-weixin",
                        NODE_ENV: "production",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG && console.log("[" + +new Date() + "][" + (r.is || r.route) + "][" + this._uid + "]差量更新", JSON.stringify(a)), 
                    this.__next_tick_pending = !0, r.setData(a, function() {
                        n.__next_tick_pending = !1, An(n);
                    })) : An(this);
                }
            }, dn.prototype.$mount = function(t, e) {
                return function(t, e, n) {
                    return t.mpType ? ("app" === t.mpType && (t.$options.render = Tn), t.$options.render || (t.$options.render = Tn), 
                    !t._$fallback && ze(t, "beforeMount"), new en(t, function() {
                        t._update(t._render(), n);
                    }, E, {
                        before: function() {
                            t._isMounted && !t._isDestroyed && ze(t, "beforeUpdate");
                        }
                    }, !0), n = !1, t) : t;
                }(this, 0, e);
            }, function(t) {
                var e = t.extend;
                t.extend = function(t) {
                    var n = (t = t || {}).methods;
                    return n && Object.keys(n).forEach(function(e) {
                        -1 !== kn.indexOf(e) && (t[e] = n[e], delete n[e]);
                    }), e.call(this, t);
                };
                var n = t.config.optionMergeStrategies, r = n.created;
                kn.forEach(function(t) {
                    n[t] = r;
                }), t.prototype.__lifecycle_hooks__ = kn;
            }(dn), function(t) {
                t.config.errorHandler = function(e, n, r) {
                    t.util.warn("Error in " + r + ': "' + e.toString() + '"', n), console.error(e);
                    var i = "function" == typeof getApp && getApp();
                    i && i.onError && i.onError(e);
                };
                var e = t.prototype.$emit;
                t.prototype.$emit = function(t) {
                    if (this.$scope && t) {
                        var n = this.$scope._triggerEvent || this.$scope.triggerEvent;
                        if (n) try {
                            n.call(this.$scope, t, {
                                __args__: P(arguments, 1)
                            });
                        } catch (t) {}
                    }
                    return e.apply(this, arguments);
                }, t.prototype.$nextTick = function(t) {
                    return function(t, e) {
                        if (!t.__next_tick_pending && !function(t) {
                            return Ye.find(function(e) {
                                return t._watcher === e;
                            });
                        }(t)) {
                            if (Object({
                                VUE_APP_DARK_MODE: "false",
                                VUE_APP_NAME: "冥想星球",
                                VUE_APP_PLATFORM: "mp-weixin",
                                NODE_ENV: "production",
                                BASE_URL: "/"
                            }).VUE_APP_DEBUG) {
                                var n = t.$scope;
                                console.log("[" + +new Date() + "][" + (n.is || n.route) + "][" + t._uid + "]:nextVueTick");
                            }
                            return Wt(e, t);
                        }
                        if (Object({
                            VUE_APP_DARK_MODE: "false",
                            VUE_APP_NAME: "冥想星球",
                            VUE_APP_PLATFORM: "mp-weixin",
                            NODE_ENV: "production",
                            BASE_URL: "/"
                        }).VUE_APP_DEBUG) {
                            var r = t.$scope;
                            console.log("[" + +new Date() + "][" + (r.is || r.route) + "][" + t._uid + "]:nextMPTick");
                        }
                        var i;
                        if (t.__next_tick_callbacks || (t.__next_tick_callbacks = []), t.__next_tick_callbacks.push(function() {
                            if (e) try {
                                e.call(t);
                            } catch (e) {
                                Nt(e, t, "nextTick");
                            } else i && i(t);
                        }), !e && "undefined" != typeof Promise) return new Promise(function(t) {
                            i = t;
                        });
                    }(this, t);
                }, Mn.forEach(function(e) {
                    t.prototype[e] = function(t) {
                        return this.$scope && this.$scope[e] ? this.$scope[e](t) : "undefined" != typeof my ? "createSelectorQuery" === e ? my.createSelectorQuery(t) : "createIntersectionObserver" === e ? my.createIntersectionObserver(t) : void 0 : void 0;
                    };
                }), t.prototype.__init_provide = ne, t.prototype.__init_injections = re, t.prototype.__call_hook = function(t, e) {
                    var n = this;
                    ot();
                    var r, i = n.$options[t], o = t + " hook";
                    if (i) for (var a = 0, s = i.length; a < s; a++) r = jt(i[a], n, e ? [ e ] : null, n, o);
                    return n._hasHookEvent && n.$emit("hook:" + t, e), at(), r;
                }, t.prototype.__set_model = function(e, n, r, i) {
                    Array.isArray(i) && (-1 !== i.indexOf("trim") && (r = r.trim()), -1 !== i.indexOf("number") && (r = this._n(r))), 
                    e || (e = this), t.set(e, n, r);
                }, t.prototype.__set_sync = function(e, n, r) {
                    e || (e = this), t.set(e, n, r);
                }, t.prototype.__get_orig = function(t) {
                    return c(t) && t.$orig || t;
                }, t.prototype.__get_value = function(t, e) {
                    return function t(e, n) {
                        var r = n.split("."), i = r[0];
                        return 0 === i.indexOf("__$n") && (i = parseInt(i.replace("__$n", ""))), 1 === r.length ? e[i] : t(e[i], r.slice(1).join("."));
                    }(e || this, t);
                }, t.prototype.__get_class = function(t, e) {
                    return function(t, e) {
                        return i(t) || i(e) ? function(t, e) {
                            return t ? e ? t + " " + e : t : e || "";
                        }(t, function t(e) {
                            return Array.isArray(e) ? function(e) {
                                for (var n, r = "", o = 0, a = e.length; o < a; o++) i(n = t(e[o])) && "" !== n && (r && (r += " "), 
                                r += n);
                                return r;
                            }(e) : s(e) ? function(t) {
                                var e = "";
                                for (var n in t) t[n] && (e && (e += " "), e += n);
                                return e;
                            }(e) : "string" == typeof e ? e : "";
                        }(e)) : "";
                    }(e, t);
                }, t.prototype.__get_style = function(t, e) {
                    if (!t && !e) return "";
                    var n = function(t) {
                        return Array.isArray(t) ? k(t) : "string" == typeof t ? Pn(t) : t;
                    }(t), r = e ? M(e, n) : n;
                    return Object.keys(r).map(function(t) {
                        return S(t) + ":" + r[t];
                    }).join(";");
                }, t.prototype.__map = function(t, e) {
                    var n, r, i, o, a;
                    if (Array.isArray(t)) {
                        for (n = new Array(t.length), r = 0, i = t.length; r < i; r++) n[r] = e(t[r], r);
                        return n;
                    }
                    if (s(t)) {
                        for (o = Object.keys(t), n = Object.create(null), r = 0, i = o.length; r < i; r++) n[a = o[r]] = e(t[a], a, r);
                        return n;
                    }
                    if ("number" == typeof t) {
                        for (n = new Array(t), r = 0, i = t; r < i; r++) n[r] = e(r, r);
                        return n;
                    }
                    return [];
                };
            }(dn), e.default = dn;
        }.call(this, n("c8ba"));
    },
    "6b58": function(t, e, n) {
        var r = n("7037").default, i = n("3c96");
        t.exports = function(t, e) {
            if (e && ("object" === r(e) || "function" == typeof e)) return e;
            if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
            return i(t);
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    "6e5b": function e5b(module, exports, __webpack_require__) {
        (function(wx, module) {
            var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__, _typeof = __webpack_require__("7037"), e;
            window, e = function() {
                return function(t) {
                    var e = {};
                    function n(r) {
                        if (e[r]) return e[r].exports;
                        var i = e[r] = {
                            i: r,
                            l: !1,
                            exports: {}
                        };
                        return t[r].call(i.exports, i, i.exports, n), i.l = !0, i.exports;
                    }
                    return n.m = t, n.c = e, n.d = function(t, e, r) {
                        n.o(t, e) || Object.defineProperty(t, e, {
                            enumerable: !0,
                            get: r
                        });
                    }, n.r = function(t) {
                        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
                            value: "Module"
                        }), Object.defineProperty(t, "__esModule", {
                            value: !0
                        });
                    }, n.t = function(t, e) {
                        if (1 & e && (t = n(t)), 8 & e) return t;
                        if (4 & e && "object" == _typeof(t) && t && t.__esModule) return t;
                        var r = Object.create(null);
                        if (n.r(r), Object.defineProperty(r, "default", {
                            enumerable: !0,
                            value: t
                        }), 2 & e && "string" != typeof t) for (var i in t) n.d(r, i, function(e) {
                            return t[e];
                        }.bind(null, i));
                        return r;
                    }, n.n = function(t) {
                        var e = t && t.__esModule ? function() {
                            return t.default;
                        } : function() {
                            return t;
                        };
                        return n.d(e, "a", e), e;
                    }, n.o = function(t, e) {
                        return Object.prototype.hasOwnProperty.call(t, e);
                    }, n.p = "", n(n.s = 5);
                }([ function(t, e, n) {
                    (function(r) {
                        var i;
                        !function(r, o) {
                            t.exports = function(r) {
                                var o, a = r.Base64;
                                if (void 0 !== t && t.exports) if ("undefined" != typeof navigator && "ReactNative" == navigator.product) ; else try {
                                    o = n(9).Buffer;
                                } catch (t) {}
                                var s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", u = function(t) {
                                    for (var e = {}, n = 0, r = t.length; n < r; n++) e[t.charAt(n)] = n;
                                    return e;
                                }(s), c = String.fromCharCode, l = function(t) {
                                    if (t.length < 2) return (e = t.charCodeAt(0)) < 128 ? t : e < 2048 ? c(192 | e >>> 6) + c(128 | 63 & e) : c(224 | e >>> 12 & 15) + c(128 | e >>> 6 & 63) + c(128 | 63 & e);
                                    var e = 65536 + 1024 * (t.charCodeAt(0) - 55296) + (t.charCodeAt(1) - 56320);
                                    return c(240 | e >>> 18 & 7) + c(128 | e >>> 12 & 63) + c(128 | e >>> 6 & 63) + c(128 | 63 & e);
                                }, f = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g, d = function(t) {
                                    return t.replace(f, l);
                                }, h = function(t) {
                                    var e = [ 0, 2, 1 ][t.length % 3], n = t.charCodeAt(0) << 16 | (t.length > 1 ? t.charCodeAt(1) : 0) << 8 | (t.length > 2 ? t.charCodeAt(2) : 0);
                                    return [ s.charAt(n >>> 18), s.charAt(n >>> 12 & 63), e >= 2 ? "=" : s.charAt(n >>> 6 & 63), e >= 1 ? "=" : s.charAt(63 & n) ].join("");
                                }, p = r.btoa ? function(t) {
                                    return r.btoa(t);
                                } : function(t) {
                                    return t.replace(/[\s\S]{1,3}/g, h);
                                }, _ = o ? o.from && Uint8Array && o.from !== Uint8Array.from ? function(t) {
                                    return (t.constructor === o.constructor ? t : o.from(t)).toString("base64");
                                } : function(t) {
                                    return (t.constructor === o.constructor ? t : new o(t)).toString("base64");
                                } : function(t) {
                                    return p(d(t));
                                }, m = function(t, e) {
                                    return e ? _(String(t)).replace(/[+\/]/g, function(t) {
                                        return "+" == t ? "-" : "_";
                                    }).replace(/=/g, "") : _(String(t));
                                }, y = new RegExp([ "[À-ß][-¿]", "[à-ï][-¿]{2}", "[ð-÷][-¿]{3}" ].join("|"), "g"), g = function(t) {
                                    switch (t.length) {
                                      case 4:
                                        var e = ((7 & t.charCodeAt(0)) << 18 | (63 & t.charCodeAt(1)) << 12 | (63 & t.charCodeAt(2)) << 6 | 63 & t.charCodeAt(3)) - 65536;
                                        return c(55296 + (e >>> 10)) + c(56320 + (1023 & e));

                                      case 3:
                                        return c((15 & t.charCodeAt(0)) << 12 | (63 & t.charCodeAt(1)) << 6 | 63 & t.charCodeAt(2));

                                      default:
                                        return c((31 & t.charCodeAt(0)) << 6 | 63 & t.charCodeAt(1));
                                    }
                                }, v = function(t) {
                                    return t.replace(y, g);
                                }, b = function(t) {
                                    var e = t.length, n = e % 4, r = (e > 0 ? u[t.charAt(0)] << 18 : 0) | (e > 1 ? u[t.charAt(1)] << 12 : 0) | (e > 2 ? u[t.charAt(2)] << 6 : 0) | (e > 3 ? u[t.charAt(3)] : 0), i = [ c(r >>> 16), c(r >>> 8 & 255), c(255 & r) ];
                                    return i.length -= [ 0, 0, 2, 1 ][n], i.join("");
                                }, w = r.atob ? function(t) {
                                    return r.atob(t);
                                } : function(t) {
                                    return t.replace(/[\s\S]{1,4}/g, b);
                                }, x = o ? o.from && Uint8Array && o.from !== Uint8Array.from ? function(t) {
                                    return (t.constructor === o.constructor ? t : o.from(t, "base64")).toString();
                                } : function(t) {
                                    return (t.constructor === o.constructor ? t : new o(t, "base64")).toString();
                                } : function(t) {
                                    return v(w(t));
                                }, A = function(t) {
                                    return x(String(t).replace(/[-_]/g, function(t) {
                                        return "-" == t ? "+" : "/";
                                    }).replace(/[^A-Za-z0-9\+\/]/g, ""));
                                };
                                if (r.Base64 = {
                                    VERSION: "2.4.8",
                                    atob: w,
                                    btoa: p,
                                    fromBase64: A,
                                    toBase64: m,
                                    utob: d,
                                    encode: m,
                                    encodeURI: function(t) {
                                        return m(t, !0);
                                    },
                                    btou: v,
                                    decode: A,
                                    noConflict: function() {
                                        var t = r.Base64;
                                        return r.Base64 = a, t;
                                    }
                                }, "function" == typeof Object.defineProperty) {
                                    var S = function(t) {
                                        return {
                                            value: t,
                                            enumerable: !1,
                                            writable: !0,
                                            configurable: !0
                                        };
                                    };
                                    r.Base64.extendString = function() {
                                        Object.defineProperty(String.prototype, "fromBase64", S(function() {
                                            return A(this);
                                        })), Object.defineProperty(String.prototype, "toBase64", S(function(t) {
                                            return m(this, t);
                                        })), Object.defineProperty(String.prototype, "toBase64URI", S(function() {
                                            return m(this, !0);
                                        }));
                                    };
                                }
                                return r.Meteor && (Base64 = r.Base64), void 0 !== t && t.exports ? t.exports.Base64 = r.Base64 : void 0 === (i = function() {
                                    return r.Base64;
                                }.apply(e, [])) || (t.exports = i), {
                                    Base64: r.Base64
                                };
                            }(r);
                        }("undefined" != typeof self ? self : "undefined" != typeof window ? window : void 0 !== r ? r : this);
                    }).call(this, n(3));
                }, function(module, exports, __webpack_require__) {
                    (function(process) {
                        var Module;
                        Module || (Module = (void 0 !== Module ? Module : null) || {});
                        var moduleOverrides = {};
                        for (var key in Module) Module.hasOwnProperty(key) && (moduleOverrides[key] = Module[key]);
                        var ENVIRONMENT_IS_WEB = !1, ENVIRONMENT_IS_WORKER = !1, ENVIRONMENT_IS_NODE = !1, ENVIRONMENT_IS_SHELL = !1, nodeFS, nodePath;
                        if (Module.ENVIRONMENT) if ("WEB" === Module.ENVIRONMENT) ENVIRONMENT_IS_WEB = !0; else if ("WORKER" === Module.ENVIRONMENT) ENVIRONMENT_IS_WORKER = !0; else if ("NODE" === Module.ENVIRONMENT) ENVIRONMENT_IS_NODE = !0; else {
                            if ("SHELL" !== Module.ENVIRONMENT) throw new Error("The provided Module['ENVIRONMENT'] value is not valid. It must be one of: WEB|WORKER|NODE|SHELL.");
                            ENVIRONMENT_IS_SHELL = !0;
                        } else ENVIRONMENT_IS_WEB = "object" == ("undefined" == typeof window ? "undefined" : _typeof(window)), 
                        ENVIRONMENT_IS_WORKER = "function" == typeof importScripts, ENVIRONMENT_IS_NODE = "object" == _typeof(process) && !ENVIRONMENT_IS_WEB && !ENVIRONMENT_IS_WORKER, 
                        ENVIRONMENT_IS_SHELL = !ENVIRONMENT_IS_WEB && !ENVIRONMENT_IS_NODE && !ENVIRONMENT_IS_WORKER;
                        if (ENVIRONMENT_IS_SHELL = !1, ENVIRONMENT_IS_NODE) Module.print || (Module.print = console.log), 
                        Module.printErr || (Module.printErr = console.warn), Module.read = function(t, e) {
                            t = nodePath.normalize(t);
                            var n = nodeFS.readFileSync(t);
                            return e ? n : n.toString();
                        }, Module.readBinary = function(t) {
                            var e = Module.read(t, !0);
                            return e.buffer || (e = new Uint8Array(e)), assert(e.buffer), e;
                        }, Module.load = function(t) {
                            globalEval(read(t));
                        }, Module.thisProgram || (process.argv.length > 1 ? Module.thisProgram = process.argv[1].replace(/\\/g, "/") : Module.thisProgram = "unknown-program"), 
                        Module.arguments = process.argv.slice(2), module.exports = Module, process.on("uncaughtException", function(t) {
                            if (!(t instanceof ExitStatus)) throw t;
                        }), Module.inspect = function() {
                            return "[Emscripten Module object]";
                        }; else if (ENVIRONMENT_IS_SHELL) Module.print || (Module.print = print), "undefined" != typeof printErr && (Module.printErr = printErr), 
                        "undefined" != typeof read ? Module.read = read : Module.read = function() {
                            throw "no read() available";
                        }, Module.readBinary = function(t) {
                            if ("function" == typeof readbuffer) return new Uint8Array(readbuffer(t));
                            var e = read(t, "binary");
                            return assert("object" == _typeof(e)), e;
                        }, "undefined" != typeof scriptArgs ? Module.arguments = scriptArgs : void 0 !== arguments && (Module.arguments = arguments), 
                        "function" == typeof quit && (Module.quit = function(t, e) {
                            quit(t);
                        }); else if (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER) {
                            if (Module.read = function(t) {
                                var e = new XMLHttpRequest();
                                return e.open("GET", t, !1), e.send(null), e.responseText;
                            }, ENVIRONMENT_IS_WORKER && (Module.readBinary = function(t) {
                                var e = new XMLHttpRequest();
                                return e.open("GET", t, !1), e.responseType = "arraybuffer", e.send(null), new Uint8Array(e.response);
                            }), Module.readAsync = function(t, e, n) {
                                var r = new XMLHttpRequest();
                                r.open("GET", t, !0), r.responseType = "arraybuffer", r.onload = function() {
                                    200 == r.status || 0 == r.status && r.response ? e(r.response) : n();
                                }, r.onerror = n, r.send(null);
                            }, void 0 !== arguments && (Module.arguments = arguments), "undefined" != typeof console) Module.print || (Module.print = function(t) {
                                console.log(t);
                            }), Module.printErr || (Module.printErr = function(t) {
                                console.warn(t);
                            }); else {
                                var TRY_USE_DUMP = !1;
                                Module.print || (Module.print = TRY_USE_DUMP && "undefined" != typeof dump ? function(t) {
                                    dump(t);
                                } : function(t) {});
                            }
                            ENVIRONMENT_IS_WORKER && (Module.load = importScripts), void 0 === Module.setWindowTitle && (Module.setWindowTitle = function(t) {
                                document.title = t;
                            });
                        }
                        function globalEval(t) {
                            eval.call(null, t);
                        }
                        for (var key in !Module.load && Module.read && (Module.load = function(t) {
                            globalEval(Module.read(t));
                        }), Module.print || (Module.print = function() {}), Module.printErr || (Module.printErr = Module.print), 
                        Module.arguments || (Module.arguments = []), Module.thisProgram || (Module.thisProgram = "./this.program"), 
                        Module.quit || (Module.quit = function(t, e) {
                            throw e;
                        }), Module.print = Module.print, Module.printErr = Module.printErr, Module.preRun = [], 
                        Module.postRun = [], moduleOverrides) moduleOverrides.hasOwnProperty(key) && (Module[key] = moduleOverrides[key]);
                        moduleOverrides = void 0;
                        var Runtime = {
                            setTempRet0: function(t) {
                                return tempRet0 = t, t;
                            },
                            getTempRet0: function() {
                                return tempRet0;
                            },
                            stackSave: function() {
                                return STACKTOP;
                            },
                            stackRestore: function(t) {
                                STACKTOP = t;
                            },
                            getNativeTypeSize: function(t) {
                                switch (t) {
                                  case "i1":
                                  case "i8":
                                    return 1;

                                  case "i16":
                                    return 2;

                                  case "i32":
                                    return 4;

                                  case "i64":
                                    return 8;

                                  case "float":
                                    return 4;

                                  case "double":
                                    return 8;

                                  default:
                                    if ("*" === t[t.length - 1]) return Runtime.QUANTUM_SIZE;
                                    if ("i" === t[0]) {
                                        var e = parseInt(t.substr(1));
                                        return assert(e % 8 == 0), e / 8;
                                    }
                                    return 0;
                                }
                            },
                            getNativeFieldSize: function(t) {
                                return Math.max(Runtime.getNativeTypeSize(t), Runtime.QUANTUM_SIZE);
                            },
                            STACK_ALIGN: 16,
                            prepVararg: function(t, e) {
                                return "double" === e || "i64" === e ? 7 & t && (assert(4 == (7 & t)), t += 4) : assert(0 == (3 & t)), 
                                t;
                            },
                            getAlignSize: function(t, e, n) {
                                return n || "i64" != t && "double" != t ? t ? Math.min(e || (t ? Runtime.getNativeFieldSize(t) : 0), Runtime.QUANTUM_SIZE) : Math.min(e, 8) : 8;
                            },
                            dynCall: function(t, e, n) {
                                return n && n.length ? (assert(n.length == t.length - 1), assert("dynCall_" + t in Module, "bad function pointer type - no table for sig '" + t + "'"), 
                                Module["dynCall_" + t].apply(null, [ e ].concat(n))) : (assert(1 == t.length), assert("dynCall_" + t in Module, "bad function pointer type - no table for sig '" + t + "'"), 
                                Module["dynCall_" + t].call(null, e));
                            },
                            functionPointers: [],
                            addFunction: function(t) {
                                for (var e = 0; e < Runtime.functionPointers.length; e++) if (!Runtime.functionPointers[e]) return Runtime.functionPointers[e] = t, 
                                2 * (1 + e);
                                throw "Finished up all reserved function pointers. Use a higher value for RESERVED_FUNCTION_POINTERS.";
                            },
                            removeFunction: function(t) {
                                Runtime.functionPointers[(t - 2) / 2] = null;
                            },
                            warnOnce: function(t) {
                                Runtime.warnOnce.shown || (Runtime.warnOnce.shown = {}), Runtime.warnOnce.shown[t] || (Runtime.warnOnce.shown[t] = 1, 
                                Module.printErr(t));
                            },
                            funcWrappers: {},
                            getFuncWrapper: function(t, e) {
                                if (t) {
                                    assert(e), Runtime.funcWrappers[e] || (Runtime.funcWrappers[e] = {});
                                    var n = Runtime.funcWrappers[e];
                                    return n[t] || (1 === e.length ? n[t] = function() {
                                        return Runtime.dynCall(e, t);
                                    } : 2 === e.length ? n[t] = function(n) {
                                        return Runtime.dynCall(e, t, [ n ]);
                                    } : n[t] = function() {
                                        return Runtime.dynCall(e, t, Array.prototype.slice.call(arguments));
                                    }), n[t];
                                }
                            },
                            getCompilerSetting: function(t) {
                                throw "You must build with -s RETAIN_COMPILER_SETTINGS=1 for Runtime.getCompilerSetting or emscripten_get_compiler_setting to work";
                            },
                            stackAlloc: function(t) {
                                var e = STACKTOP;
                                return assert((0 | (STACKTOP = 15 + (STACKTOP = STACKTOP + t | 0) & -16)) < (0 | STACK_MAX) | 0), 
                                e;
                            },
                            staticAlloc: function(t) {
                                var e = STATICTOP;
                                return STATICTOP = 15 + (STATICTOP = STATICTOP + (assert(!staticSealed), t) | 0) & -16, 
                                e;
                            },
                            dynamicAlloc: function(t) {
                                assert(DYNAMICTOP_PTR);
                                var e = HEAP32[DYNAMICTOP_PTR >> 2], n = -16 & (e + t + 15 | 0);
                                return HEAP32[DYNAMICTOP_PTR >> 2] = n, n >= TOTAL_MEMORY && !enlargeMemory() ? (HEAP32[DYNAMICTOP_PTR >> 2] = e, 
                                0) : e;
                            },
                            alignMemory: function(t, e) {
                                return Math.ceil(t / (e || 16)) * (e || 16);
                            },
                            makeBigInt: function(t, e, n) {
                                return n ? +(t >>> 0) + 4294967296 * +(e >>> 0) : +(t >>> 0) + 4294967296 * +(0 | e);
                            },
                            GLOBAL_BASE: 8,
                            QUANTUM_SIZE: 4,
                            __dummy__: 0
                        };
                        Module.Runtime = Runtime;
                        var ABORT = 0, EXITSTATUS = 0;
                        function assert(t, e) {
                            t || abort("Assertion failed: " + e);
                        }
                        var globalScope = this, cwrap, ccall;
                        function getCFunc(ident) {
                            var func = Module["_" + ident];
                            if (!func) try {
                                func = eval("_" + ident);
                            } catch (t) {}
                            return assert(func, "Cannot call unknown function " + ident + " (perhaps LLVM optimizations or closure removed it?)"), 
                            func;
                        }
                        function setValue(t, e, n, r) {
                            switch ("*" === (n = n || "i8").charAt(n.length - 1) && (n = "i32"), n) {
                              case "i1":
                              case "i8":
                                HEAP8[t >> 0] = e;
                                break;

                              case "i16":
                                HEAP16[t >> 1] = e;
                                break;

                              case "i32":
                                HEAP32[t >> 2] = e;
                                break;

                              case "i64":
                                tempI64 = [ e >>> 0, (tempDouble = e, +Math_abs(tempDouble) >= 1 ? tempDouble > 0 ? (0 | Math_min(+Math_floor(tempDouble / 4294967296), 4294967295)) >>> 0 : ~~+Math_ceil((tempDouble - +(~~tempDouble >>> 0)) / 4294967296) >>> 0 : 0) ], 
                                HEAP32[t >> 2] = tempI64[0], HEAP32[t + 4 >> 2] = tempI64[1];
                                break;

                              case "float":
                                HEAPF32[t >> 2] = e;
                                break;

                              case "double":
                                HEAPF64[t >> 3] = e;
                                break;

                              default:
                                abort("invalid type for setValue: " + n);
                            }
                        }
                        function getValue(t, e, n) {
                            switch ("*" === (e = e || "i8").charAt(e.length - 1) && (e = "i32"), e) {
                              case "i1":
                              case "i8":
                                return HEAP8[t >> 0];

                              case "i16":
                                return HEAP16[t >> 1];

                              case "i32":
                              case "i64":
                                return HEAP32[t >> 2];

                              case "float":
                                return HEAPF32[t >> 2];

                              case "double":
                                return HEAPF64[t >> 3];

                              default:
                                abort("invalid type for setValue: " + e);
                            }
                            return null;
                        }
                        !function() {
                            var JSfuncs = {
                                stackSave: function() {
                                    Runtime.stackSave();
                                },
                                stackRestore: function() {
                                    Runtime.stackRestore();
                                },
                                arrayToC: function(t) {
                                    var e = Runtime.stackAlloc(t.length);
                                    return writeArrayToMemory(t, e), e;
                                },
                                stringToC: function(t) {
                                    var e = 0;
                                    if (null != t && 0 !== t) {
                                        var n = 1 + (t.length << 2);
                                        stringToUTF8(t, e = Runtime.stackAlloc(n), n);
                                    }
                                    return e;
                                }
                            }, toC = {
                                string: JSfuncs.stringToC,
                                array: JSfuncs.arrayToC
                            };
                            ccall = function(t, e, n, r, i) {
                                var o = getCFunc(t), a = [], s = 0;
                                if (assert("array" !== e, 'Return type should not be "array".'), r) for (var u = 0; u < r.length; u++) {
                                    var c = toC[n[u]];
                                    c ? (0 === s && (s = Runtime.stackSave()), a[u] = c(r[u])) : a[u] = r[u];
                                }
                                var l = o.apply(null, a);
                                if (i && i.async || "object" != ("undefined" == typeof EmterpreterAsync ? "undefined" : _typeof(EmterpreterAsync)) || assert(!EmterpreterAsync.state, "cannot start async op with normal JS calling ccall"), 
                                i && i.async && assert(!e, "async ccalls cannot return values"), "string" === e && (l = Pointer_stringify(l)), 
                                0 !== s) {
                                    if (i && i.async) return void EmterpreterAsync.asyncFinalizers.push(function() {
                                        Runtime.stackRestore(s);
                                    });
                                    Runtime.stackRestore(s);
                                }
                                return l;
                            };
                            var sourceRegex = /^function\s*[a-zA-Z$_0-9]*\s*\(([^)]*)\)\s*{\s*([^*]*?)[\s;]*(?:return\s*(.*?)[;\s]*)?}$/;
                            function parseJSFunc(t) {
                                var e = t.toString().match(sourceRegex).slice(1);
                                return {
                                    arguments: e[0],
                                    body: e[1],
                                    returnValue: e[2]
                                };
                            }
                            var JSsource = null;
                            function ensureJSsource() {
                                if (!JSsource) for (var t in JSsource = {}, JSfuncs) JSfuncs.hasOwnProperty(t) && (JSsource[t] = parseJSFunc(JSfuncs[t]));
                            }
                            cwrap = function cwrap(ident, returnType, argTypes) {
                                argTypes = argTypes || [];
                                var cfunc = getCFunc(ident), numericArgs = argTypes.every(function(t) {
                                    return "number" === t;
                                }), numericRet = "string" !== returnType;
                                if (numericRet && numericArgs) return cfunc;
                                var argNames = argTypes.map(function(t, e) {
                                    return "$" + e;
                                }), funcstr = "(function(" + argNames.join(",") + ") {", nargs = argTypes.length;
                                if (!numericArgs) {
                                    ensureJSsource(), funcstr += "var stack = " + JSsource.stackSave.body + ";";
                                    for (var i = 0; i < nargs; i++) {
                                        var arg = argNames[i], type = argTypes[i];
                                        if ("number" !== type) {
                                            var convertCode = JSsource[type + "ToC"];
                                            funcstr += "var " + convertCode.arguments + " = " + arg + ";", funcstr += convertCode.body + ";", 
                                            funcstr += arg + "=(" + convertCode.returnValue + ");";
                                        }
                                    }
                                }
                                var cfuncname = parseJSFunc(function() {
                                    return cfunc;
                                }).returnValue;
                                if (funcstr += "var ret = " + cfuncname + "(" + argNames.join(",") + ");", !numericRet) {
                                    var strgfy = parseJSFunc(function() {
                                        return Pointer_stringify;
                                    }).returnValue;
                                    funcstr += "ret = " + strgfy + "(ret);";
                                }
                                return funcstr += "if (typeof EmterpreterAsync === 'object') { assert(!EmterpreterAsync.state, 'cannot start async op with normal JS calling cwrap') }", 
                                numericArgs || (ensureJSsource(), funcstr += JSsource.stackRestore.body.replace("()", "(stack)") + ";"), 
                                funcstr += "return ret})", eval(funcstr);
                            };
                        }(), Module.ccall = ccall, Module.cwrap = cwrap, Module.setValue = setValue, Module.getValue = getValue;
                        var ALLOC_NORMAL = 0, ALLOC_STACK = 1, ALLOC_STATIC = 2, ALLOC_DYNAMIC = 3, ALLOC_NONE = 4;
                        function allocate(t, e, n, r) {
                            var i, o;
                            "number" == typeof t ? (i = !0, o = t) : (i = !1, o = t.length);
                            var a, s = "string" == typeof e ? e : null;
                            if (a = n == ALLOC_NONE ? r : [ "function" == typeof _malloc ? _malloc : Runtime.staticAlloc, Runtime.stackAlloc, Runtime.staticAlloc, Runtime.dynamicAlloc ][void 0 === n ? ALLOC_STATIC : n](Math.max(o, s ? 1 : e.length)), 
                            i) {
                                var u;
                                for (r = a, assert(0 == (3 & a)), u = a + (-4 & o); r < u; r += 4) HEAP32[r >> 2] = 0;
                                for (u = a + o; r < u; ) HEAP8[r++ >> 0] = 0;
                                return a;
                            }
                            if ("i8" === s) return t.subarray || t.slice ? HEAPU8.set(t, a) : HEAPU8.set(new Uint8Array(t), a), 
                            a;
                            for (var c, l, f, d = 0; d < o; ) {
                                var h = t[d];
                                "function" == typeof h && (h = Runtime.getFunctionIndex(h)), 0 !== (c = s || e[d]) ? (assert(c, "Must know what type to store in allocate!"), 
                                "i64" == c && (c = "i32"), setValue(a + d, h, c), f !== c && (l = Runtime.getNativeTypeSize(c), 
                                f = c), d += l) : d++;
                            }
                            return a;
                        }
                        function getMemory(t) {
                            return staticSealed ? runtimeInitialized ? _malloc(t) : Runtime.dynamicAlloc(t) : Runtime.staticAlloc(t);
                        }
                        function Pointer_stringify(t, e) {
                            if (0 === e || !t) return "";
                            for (var n, r = 0, i = 0; assert(t + i < TOTAL_MEMORY), r |= n = HEAPU8[t + i >> 0], 
                            (0 != n || e) && (i++, !e || i != e); ) ;
                            e || (e = i);
                            var o = "";
                            if (r < 128) {
                                for (var a; e > 0; ) a = String.fromCharCode.apply(String, HEAPU8.subarray(t, t + Math.min(e, 1024))), 
                                o = o ? o + a : a, t += 1024, e -= 1024;
                                return o;
                            }
                            return Module.UTF8ToString(t);
                        }
                        function AsciiToString(t) {
                            for (var e = ""; ;) {
                                var n = HEAP8[t++ >> 0];
                                if (!n) return e;
                                e += String.fromCharCode(n);
                            }
                        }
                        function stringToAscii(t, e) {
                            return writeAsciiToMemory(t, e, !1);
                        }
                        Module.ALLOC_NORMAL = ALLOC_NORMAL, Module.ALLOC_STACK = ALLOC_STACK, Module.ALLOC_STATIC = ALLOC_STATIC, 
                        Module.ALLOC_DYNAMIC = ALLOC_DYNAMIC, Module.ALLOC_NONE = ALLOC_NONE, Module.allocate = allocate, 
                        Module.getMemory = getMemory, Module.Pointer_stringify = Pointer_stringify, Module.AsciiToString = AsciiToString, 
                        Module.stringToAscii = stringToAscii;
                        var UTF8Decoder = "undefined" != typeof TextDecoder ? new TextDecoder("utf8") : void 0;
                        function UTF8ArrayToString(t, e) {
                            for (var n = e; t[n]; ) ++n;
                            if (n - e > 16 && t.subarray && UTF8Decoder) return UTF8Decoder.decode(t.subarray(e, n));
                            for (var r, i, o, a, s, u = ""; ;) {
                                if (!(r = t[e++])) return u;
                                if (128 & r) if (i = 63 & t[e++], 192 != (224 & r)) if (o = 63 & t[e++], 224 == (240 & r) ? r = (15 & r) << 12 | i << 6 | o : (a = 63 & t[e++], 
                                240 == (248 & r) ? r = (7 & r) << 18 | i << 12 | o << 6 | a : (s = 63 & t[e++], 
                                r = 248 == (252 & r) ? (3 & r) << 24 | i << 18 | o << 12 | a << 6 | s : (1 & r) << 30 | i << 24 | o << 18 | a << 12 | s << 6 | 63 & t[e++])), 
                                r < 65536) u += String.fromCharCode(r); else {
                                    var c = r - 65536;
                                    u += String.fromCharCode(55296 | c >> 10, 56320 | 1023 & c);
                                } else u += String.fromCharCode((31 & r) << 6 | i); else u += String.fromCharCode(r);
                            }
                        }
                        function UTF8ToString(t) {
                            return UTF8ArrayToString(HEAPU8, t);
                        }
                        function stringToUTF8Array(t, e, n, r) {
                            if (!(r > 0)) return 0;
                            for (var i = n, o = n + r - 1, a = 0; a < t.length; ++a) {
                                var s = t.charCodeAt(a);
                                if (s >= 55296 && s <= 57343 && (s = 65536 + ((1023 & s) << 10) | 1023 & t.charCodeAt(++a)), 
                                s <= 127) {
                                    if (n >= o) break;
                                    e[n++] = s;
                                } else if (s <= 2047) {
                                    if (n + 1 >= o) break;
                                    e[n++] = 192 | s >> 6, e[n++] = 128 | 63 & s;
                                } else if (s <= 65535) {
                                    if (n + 2 >= o) break;
                                    e[n++] = 224 | s >> 12, e[n++] = 128 | s >> 6 & 63, e[n++] = 128 | 63 & s;
                                } else if (s <= 2097151) {
                                    if (n + 3 >= o) break;
                                    e[n++] = 240 | s >> 18, e[n++] = 128 | s >> 12 & 63, e[n++] = 128 | s >> 6 & 63, 
                                    e[n++] = 128 | 63 & s;
                                } else if (s <= 67108863) {
                                    if (n + 4 >= o) break;
                                    e[n++] = 248 | s >> 24, e[n++] = 128 | s >> 18 & 63, e[n++] = 128 | s >> 12 & 63, 
                                    e[n++] = 128 | s >> 6 & 63, e[n++] = 128 | 63 & s;
                                } else {
                                    if (n + 5 >= o) break;
                                    e[n++] = 252 | s >> 30, e[n++] = 128 | s >> 24 & 63, e[n++] = 128 | s >> 18 & 63, 
                                    e[n++] = 128 | s >> 12 & 63, e[n++] = 128 | s >> 6 & 63, e[n++] = 128 | 63 & s;
                                }
                            }
                            return e[n] = 0, n - i;
                        }
                        function stringToUTF8(t, e, n) {
                            return assert("number" == typeof n, "stringToUTF8(str, outPtr, maxBytesToWrite) is missing the third parameter that specifies the length of the output buffer!"), 
                            stringToUTF8Array(t, HEAPU8, e, n);
                        }
                        function lengthBytesUTF8(t) {
                            for (var e = 0, n = 0; n < t.length; ++n) {
                                var r = t.charCodeAt(n);
                                r >= 55296 && r <= 57343 && (r = 65536 + ((1023 & r) << 10) | 1023 & t.charCodeAt(++n)), 
                                r <= 127 ? ++e : e += r <= 2047 ? 2 : r <= 65535 ? 3 : r <= 2097151 ? 4 : r <= 67108863 ? 5 : 6;
                            }
                            return e;
                        }
                        Module.UTF8ArrayToString = UTF8ArrayToString, Module.UTF8ToString = UTF8ToString, 
                        Module.stringToUTF8Array = stringToUTF8Array, Module.stringToUTF8 = stringToUTF8, 
                        Module.lengthBytesUTF8 = lengthBytesUTF8;
                        var UTF16Decoder = "undefined" != typeof TextDecoder ? new TextDecoder("utf-16le") : void 0;
                        function UTF16ToString(t) {
                            assert(t % 2 == 0, "Pointer passed to UTF16ToString must be aligned to two bytes!");
                            for (var e = t, n = e >> 1; HEAP16[n]; ) ++n;
                            if ((e = n << 1) - t > 32 && UTF16Decoder) return UTF16Decoder.decode(HEAPU8.subarray(t, e));
                            for (var r = 0, i = ""; ;) {
                                var o = HEAP16[t + 2 * r >> 1];
                                if (0 == o) return i;
                                ++r, i += String.fromCharCode(o);
                            }
                        }
                        function stringToUTF16(t, e, n) {
                            if (assert(e % 2 == 0, "Pointer passed to stringToUTF16 must be aligned to two bytes!"), 
                            assert("number" == typeof n, "stringToUTF16(str, outPtr, maxBytesToWrite) is missing the third parameter that specifies the length of the output buffer!"), 
                            void 0 === n && (n = 2147483647), n < 2) return 0;
                            for (var r = e, i = (n -= 2) < 2 * t.length ? n / 2 : t.length, o = 0; o < i; ++o) {
                                var a = t.charCodeAt(o);
                                HEAP16[e >> 1] = a, e += 2;
                            }
                            return HEAP16[e >> 1] = 0, e - r;
                        }
                        function lengthBytesUTF16(t) {
                            return 2 * t.length;
                        }
                        function UTF32ToString(t) {
                            assert(t % 4 == 0, "Pointer passed to UTF32ToString must be aligned to four bytes!");
                            for (var e = 0, n = ""; ;) {
                                var r = HEAP32[t + 4 * e >> 2];
                                if (0 == r) return n;
                                if (++e, r >= 65536) {
                                    var i = r - 65536;
                                    n += String.fromCharCode(55296 | i >> 10, 56320 | 1023 & i);
                                } else n += String.fromCharCode(r);
                            }
                        }
                        function stringToUTF32(t, e, n) {
                            if (assert(e % 4 == 0, "Pointer passed to stringToUTF32 must be aligned to four bytes!"), 
                            assert("number" == typeof n, "stringToUTF32(str, outPtr, maxBytesToWrite) is missing the third parameter that specifies the length of the output buffer!"), 
                            void 0 === n && (n = 2147483647), n < 4) return 0;
                            for (var r = e, i = r + n - 4, o = 0; o < t.length; ++o) {
                                var a = t.charCodeAt(o);
                                if (a >= 55296 && a <= 57343 && (a = 65536 + ((1023 & a) << 10) | 1023 & t.charCodeAt(++o)), 
                                HEAP32[e >> 2] = a, (e += 4) + 4 > i) break;
                            }
                            return HEAP32[e >> 2] = 0, e - r;
                        }
                        function lengthBytesUTF32(t) {
                            for (var e = 0, n = 0; n < t.length; ++n) {
                                var r = t.charCodeAt(n);
                                r >= 55296 && r <= 57343 && ++n, e += 4;
                            }
                            return e;
                        }
                        function demangle(t) {
                            var e = Module.___cxa_demangle || Module.__cxa_demangle;
                            if (e) {
                                try {
                                    var n = t.substr(1), r = lengthBytesUTF8(n) + 1, i = _malloc(r);
                                    stringToUTF8(n, i, r);
                                    var o = _malloc(4), a = e(i, 0, 0, o);
                                    if (0 === getValue(o, "i32") && a) return Pointer_stringify(a);
                                } catch (t) {} finally {
                                    i && _free(i), o && _free(o), a && _free(a);
                                }
                                return t;
                            }
                            return Runtime.warnOnce("warning: build with  -s DEMANGLE_SUPPORT=1  to link in libcxxabi demangling"), 
                            t;
                        }
                        function demangleAll(t) {
                            return t.replace(/__Z[\w\d_]+/g, function(t) {
                                var e = demangle(t);
                                return t === e ? t : t + " [" + e + "]";
                            });
                        }
                        function jsStackTrace() {
                            var t = new Error();
                            if (!t.stack) {
                                try {
                                    throw new Error(0);
                                } catch (e) {
                                    t = e;
                                }
                                if (!t.stack) return "(no stack trace available)";
                            }
                            return t.stack.toString();
                        }
                        function stackTrace() {
                            var t = jsStackTrace();
                            return Module.extraStackTrace && (t += "\n" + Module.extraStackTrace()), demangleAll(t);
                        }
                        Module.stackTrace = stackTrace;
                        var PAGE_SIZE = 16384, WASM_PAGE_SIZE = 65536, ASMJS_PAGE_SIZE = 16777216, MIN_TOTAL_MEMORY = 16777216, HEAP, buffer, HEAP8, HEAPU8, HEAP16, HEAPU16, HEAP32, HEAPU32, HEAPF32, HEAPF64, STATIC_BASE, STATICTOP, staticSealed, STACK_BASE, STACKTOP, STACK_MAX, DYNAMIC_BASE, DYNAMICTOP_PTR;
                        function alignUp(t, e) {
                            return t % e > 0 && (t += e - t % e), t;
                        }
                        function updateGlobalBuffer(t) {
                            Module.buffer = buffer = t;
                        }
                        function updateGlobalBufferViews() {
                            Module.HEAP8 = HEAP8 = new Int8Array(buffer), Module.HEAP16 = HEAP16 = new Int16Array(buffer), 
                            Module.HEAP32 = HEAP32 = new Int32Array(buffer), Module.HEAPU8 = HEAPU8 = new Uint8Array(buffer), 
                            Module.HEAPU16 = HEAPU16 = new Uint16Array(buffer), Module.HEAPU32 = HEAPU32 = new Uint32Array(buffer), 
                            Module.HEAPF32 = HEAPF32 = new Float32Array(buffer), Module.HEAPF64 = HEAPF64 = new Float64Array(buffer);
                        }
                        function writeStackCookie() {
                            assert(0 == (3 & STACK_MAX)), HEAPU32[(STACK_MAX >> 2) - 1] = 34821223, HEAPU32[(STACK_MAX >> 2) - 2] = 2310721022;
                        }
                        function checkStackCookie() {
                            if (34821223 == HEAPU32[(STACK_MAX >> 2) - 1] && 2310721022 == HEAPU32[(STACK_MAX >> 2) - 2] || abort("Stack overflow! Stack cookie has been overwritten, expected hex dwords 0x89BACDFE and 0x02135467, but received 0x" + HEAPU32[(STACK_MAX >> 2) - 2].toString(16) + " " + HEAPU32[(STACK_MAX >> 2) - 1].toString(16)), 
                            1668509029 !== HEAP32[0]) throw "Runtime error: The application has corrupted its heap memory area (address zero)!";
                        }
                        function abortStackOverflow(t) {
                            abort("Stack overflow! Attempted to allocate " + t + " bytes on the stack, but stack has only " + (STACK_MAX - Module.asm.stackSave() + t) + " bytes available!");
                        }
                        function abortOnCannotGrowMemory() {
                            abort("Cannot enlarge memory arrays. Either (1) compile with  -s TOTAL_MEMORY=X  with X higher than the current value " + TOTAL_MEMORY + ", (2) compile with  -s ALLOW_MEMORY_GROWTH=1  which allows increasing the size at runtime but prevents some optimizations, (3) set Module.TOTAL_MEMORY to a higher value before the program runs, or (4) if you want malloc to return NULL (0) instead of this abort, compile with  -s ABORTING_MALLOC=0 ");
                        }
                        function enlargeMemory() {
                            abortOnCannotGrowMemory();
                        }
                        STATIC_BASE = STATICTOP = STACK_BASE = STACKTOP = STACK_MAX = DYNAMIC_BASE = DYNAMICTOP_PTR = 0, 
                        staticSealed = !1;
                        var TOTAL_STACK = Module.TOTAL_STACK || 5242880, TOTAL_MEMORY = Module.TOTAL_MEMORY || 16777216;
                        function getTotalMemory() {
                            return TOTAL_MEMORY;
                        }
                        if (TOTAL_MEMORY < TOTAL_STACK && Module.printErr("TOTAL_MEMORY should be larger than TOTAL_STACK, was " + TOTAL_MEMORY + "! (TOTAL_STACK=" + TOTAL_STACK + ")"), 
                        assert("undefined" != typeof Int32Array && "undefined" != typeof Float64Array && void 0 !== Int32Array.prototype.subarray && void 0 !== Int32Array.prototype.set, "JS engine does not provide full typed array support"), 
                        Module.buffer ? (buffer = Module.buffer, assert(buffer.byteLength === TOTAL_MEMORY, "provided buffer should be " + TOTAL_MEMORY + " bytes, but it is " + buffer.byteLength)) : (buffer = new ArrayBuffer(TOTAL_MEMORY), 
                        assert(buffer.byteLength === TOTAL_MEMORY)), updateGlobalBufferViews(), HEAP32[0] = 1668509029, 
                        HEAP16[1] = 25459, 115 !== HEAPU8[2] || 99 !== HEAPU8[3]) throw "Runtime error: expected the system to be little-endian!";
                        function callRuntimeCallbacks(t) {
                            for (;t.length > 0; ) {
                                var e = t.shift();
                                if ("function" != typeof e) {
                                    var n = e.func;
                                    "number" == typeof n ? void 0 === e.arg ? Module.dynCall_v(n) : Module.dynCall_vi(n, e.arg) : n(void 0 === e.arg ? null : e.arg);
                                } else e();
                            }
                        }
                        Module.HEAP = HEAP, Module.buffer = buffer, Module.HEAP8 = HEAP8, Module.HEAP16 = HEAP16, 
                        Module.HEAP32 = HEAP32, Module.HEAPU8 = HEAPU8, Module.HEAPU16 = HEAPU16, Module.HEAPU32 = HEAPU32, 
                        Module.HEAPF32 = HEAPF32, Module.HEAPF64 = HEAPF64;
                        var __ATPRERUN__ = [], __ATINIT__ = [], __ATMAIN__ = [], __ATEXIT__ = [], __ATPOSTRUN__ = [], runtimeInitialized = !1, runtimeExited = !1;
                        function preRun() {
                            if (Module.preRun) for ("function" == typeof Module.preRun && (Module.preRun = [ Module.preRun ]); Module.preRun.length; ) addOnPreRun(Module.preRun.shift());
                            callRuntimeCallbacks(__ATPRERUN__);
                        }
                        function ensureInitRuntime() {
                            checkStackCookie(), runtimeInitialized || (runtimeInitialized = !0, callRuntimeCallbacks(__ATINIT__));
                        }
                        function preMain() {
                            checkStackCookie(), callRuntimeCallbacks(__ATMAIN__);
                        }
                        function exitRuntime() {
                            checkStackCookie(), callRuntimeCallbacks(__ATEXIT__), runtimeExited = !0;
                        }
                        function postRun() {
                            if (checkStackCookie(), Module.postRun) for ("function" == typeof Module.postRun && (Module.postRun = [ Module.postRun ]); Module.postRun.length; ) addOnPostRun(Module.postRun.shift());
                            callRuntimeCallbacks(__ATPOSTRUN__);
                        }
                        function addOnPreRun(t) {
                            __ATPRERUN__.unshift(t);
                        }
                        function addOnInit(t) {
                            __ATINIT__.unshift(t);
                        }
                        function addOnPreMain(t) {
                            __ATMAIN__.unshift(t);
                        }
                        function addOnExit(t) {
                            __ATEXIT__.unshift(t);
                        }
                        function addOnPostRun(t) {
                            __ATPOSTRUN__.unshift(t);
                        }
                        function intArrayFromString(t, e, n) {
                            var r = n > 0 ? n : lengthBytesUTF8(t) + 1, i = new Array(r), o = stringToUTF8Array(t, i, 0, i.length);
                            return e && (i.length = o), i;
                        }
                        function intArrayToString(t) {
                            for (var e = [], n = 0; n < t.length; n++) {
                                var r = t[n];
                                r > 255 && (assert(!1, "Character code " + r + " (" + String.fromCharCode(r) + ")  at offset " + n + " not in 0x00-0xFF."), 
                                r &= 255), e.push(String.fromCharCode(r));
                            }
                            return e.join("");
                        }
                        function writeStringToMemory(t, e, n) {
                            var r, i;
                            Runtime.warnOnce("writeStringToMemory is deprecated and should not be called! Use stringToUTF8() instead!"), 
                            n && (i = e + lengthBytesUTF8(t), r = HEAP8[i]), stringToUTF8(t, e, 1 / 0), n && (HEAP8[i] = r);
                        }
                        function writeArrayToMemory(t, e) {
                            assert(t.length >= 0, "writeArrayToMemory array must have a length (should be an array or typed array)"), 
                            HEAP8.set(t, e);
                        }
                        function writeAsciiToMemory(t, e, n) {
                            for (var r = 0; r < t.length; ++r) assert(t.charCodeAt(r) == t.charCodeAt(r) & 255), 
                            HEAP8[e++ >> 0] = t.charCodeAt(r);
                            n || (HEAP8[e >> 0] = 0);
                        }
                        function unSign(t, e, n) {
                            return t >= 0 ? t : e <= 32 ? 2 * Math.abs(1 << e - 1) + t : Math.pow(2, e) + t;
                        }
                        function reSign(t, e, n) {
                            if (t <= 0) return t;
                            var r = e <= 32 ? Math.abs(1 << e - 1) : Math.pow(2, e - 1);
                            return t >= r && (e <= 32 || t > r) && (t = -2 * r + t), t;
                        }
                        Module.addOnPreRun = addOnPreRun, Module.addOnInit = addOnInit, Module.addOnPreMain = addOnPreMain, 
                        Module.addOnExit = addOnExit, Module.addOnPostRun = addOnPostRun, Module.intArrayFromString = intArrayFromString, 
                        Module.intArrayToString = intArrayToString, Module.writeStringToMemory = writeStringToMemory, 
                        Module.writeArrayToMemory = writeArrayToMemory, Module.writeAsciiToMemory = writeAsciiToMemory, 
                        Math.imul && -5 === Math.imul(4294967295, 5) || (Math.imul = function(t, e) {
                            var n = 65535 & t, r = 65535 & e;
                            return n * r + ((t >>> 16) * r + n * (e >>> 16) << 16) | 0;
                        }), Math.imul = Math.imul, Math.clz32 || (Math.clz32 = function(t) {
                            t >>>= 0;
                            for (var e = 0; e < 32; e++) if (t & 1 << 31 - e) return e;
                            return 32;
                        }), Math.clz32 = Math.clz32, Math.trunc || (Math.trunc = function(t) {
                            return t < 0 ? Math.ceil(t) : Math.floor(t);
                        }), Math.trunc = Math.trunc;
                        var Math_abs = Math.abs, Math_cos = Math.cos, Math_sin = Math.sin, Math_tan = Math.tan, Math_acos = Math.acos, Math_asin = Math.asin, Math_atan = Math.atan, Math_atan2 = Math.atan2, Math_exp = Math.exp, Math_log = Math.log, Math_sqrt = Math.sqrt, Math_ceil = Math.ceil, Math_floor = Math.floor, Math_pow = Math.pow, Math_imul = Math.imul, Math_fround = Math.fround, Math_round = Math.round, Math_min = Math.min, Math_clz32 = Math.clz32, Math_trunc = Math.trunc, runDependencies = 0, runDependencyWatcher = null, dependenciesFulfilled = null, runDependencyTracking = {};
                        function getUniqueRunDependency(t) {
                            for (var e = t; ;) {
                                if (!runDependencyTracking[t]) return t;
                                t = e + Math.random();
                            }
                            return t;
                        }
                        function addRunDependency(t) {
                            runDependencies++, Module.monitorRunDependencies && Module.monitorRunDependencies(runDependencies), 
                            t ? (assert(!runDependencyTracking[t]), runDependencyTracking[t] = 1, null === runDependencyWatcher && "undefined" != typeof setInterval && (runDependencyWatcher = setInterval(function() {
                                if (ABORT) return clearInterval(runDependencyWatcher), void (runDependencyWatcher = null);
                                var t = !1;
                                for (var e in runDependencyTracking) t || (t = !0, Module.printErr("still waiting on run dependencies:")), 
                                Module.printErr("dependency: " + e);
                                t && Module.printErr("(end of list)");
                            }, 1e4))) : Module.printErr("warning: run dependency added without ID");
                        }
                        function removeRunDependency(t) {
                            if (runDependencies--, Module.monitorRunDependencies && Module.monitorRunDependencies(runDependencies), 
                            t ? (assert(runDependencyTracking[t]), delete runDependencyTracking[t]) : Module.printErr("warning: run dependency removed without ID"), 
                            0 == runDependencies && (null !== runDependencyWatcher && (clearInterval(runDependencyWatcher), 
                            runDependencyWatcher = null), dependenciesFulfilled)) {
                                var e = dependenciesFulfilled;
                                dependenciesFulfilled = null, e();
                            }
                        }
                        Module.addRunDependency = addRunDependency, Module.removeRunDependency = removeRunDependency, 
                        Module.preloadedImages = {}, Module.preloadedAudios = {};
                        var memoryInitializer = null, FS = {
                            error: function() {
                                abort("Filesystem support (FS) was not included. The problem is that you are using files from JS, but files were not used from C/C++, so filesystem support was not auto-included. You can force-include filesystem support with  -s FORCE_FILESYSTEM=1");
                            },
                            init: function() {
                                FS.error();
                            },
                            createDataFile: function() {
                                FS.error();
                            },
                            createPreloadedFile: function() {
                                FS.error();
                            },
                            createLazyFile: function() {
                                FS.error();
                            },
                            open: function() {
                                FS.error();
                            },
                            mkdev: function() {
                                FS.error();
                            },
                            registerDevice: function() {
                                FS.error();
                            },
                            analyzePath: function() {
                                FS.error();
                            },
                            loadFilesFromDB: function() {
                                FS.error();
                            },
                            ErrnoError: function() {
                                FS.error();
                            }
                        };
                        Module.FS_createDataFile = FS.createDataFile, Module.FS_createPreloadedFile = FS.createPreloadedFile;
                        var ASM_CONSTS = [];
                        STATIC_BASE = Runtime.GLOBAL_BASE, STATICTOP = STATIC_BASE + 5872, __ATINIT__.push(), 
                        allocate([ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 3, 0, 0, 0, 233, 18, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 252, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 141, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54, 108, 216, 171, 77, 154, 47, 94, 188, 99, 198, 151, 53, 106, 212, 179, 125, 250, 239, 197, 145, 57, 114, 228, 211, 189, 97, 194, 159, 37, 74, 148, 51, 102, 204, 131, 29, 58, 116, 232, 203, 141, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54, 108, 216, 171, 77, 154, 47, 94, 188, 99, 198, 151, 53, 106, 212, 179, 125, 250, 239, 197, 145, 57, 114, 228, 211, 189, 97, 194, 159, 37, 74, 148, 51, 102, 204, 131, 29, 58, 116, 232, 203, 141, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54, 108, 216, 171, 77, 154, 47, 94, 188, 99, 198, 151, 53, 106, 212, 179, 125, 250, 239, 197, 145, 57, 114, 228, 211, 189, 97, 194, 159, 37, 74, 148, 51, 102, 204, 131, 29, 58, 116, 232, 203, 141, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54, 108, 216, 171, 77, 154, 47, 94, 188, 99, 198, 151, 53, 106, 212, 179, 125, 250, 239, 197, 145, 57, 114, 228, 211, 189, 97, 194, 159, 37, 74, 148, 51, 102, 204, 131, 29, 58, 116, 232, 203, 141, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54, 108, 216, 171, 77, 154, 47, 94, 188, 99, 198, 151, 53, 106, 212, 179, 125, 250, 239, 197, 145, 57, 114, 228, 211, 189, 97, 194, 159, 37, 74, 148, 51, 102, 204, 131, 29, 58, 116, 232, 203, 99, 124, 119, 123, 242, 107, 111, 197, 48, 1, 103, 43, 254, 215, 171, 118, 202, 130, 201, 125, 250, 89, 71, 240, 173, 212, 162, 175, 156, 164, 114, 192, 183, 253, 147, 38, 54, 63, 247, 204, 52, 165, 229, 241, 113, 216, 49, 21, 4, 199, 35, 195, 24, 150, 5, 154, 7, 18, 128, 226, 235, 39, 178, 117, 9, 131, 44, 26, 27, 110, 90, 160, 82, 59, 214, 179, 41, 227, 47, 132, 83, 209, 0, 237, 32, 252, 177, 91, 106, 203, 190, 57, 74, 76, 88, 207, 208, 239, 170, 251, 67, 77, 51, 133, 69, 249, 2, 127, 80, 60, 159, 168, 81, 163, 64, 143, 146, 157, 56, 245, 188, 182, 218, 33, 16, 255, 243, 210, 205, 12, 19, 236, 95, 151, 68, 23, 196, 167, 126, 61, 100, 93, 25, 115, 96, 129, 79, 220, 34, 42, 144, 136, 70, 238, 184, 20, 222, 94, 11, 219, 224, 50, 58, 10, 73, 6, 36, 92, 194, 211, 172, 98, 145, 149, 228, 121, 231, 200, 55, 109, 141, 213, 78, 169, 108, 86, 244, 234, 101, 122, 174, 8, 186, 120, 37, 46, 28, 166, 180, 198, 232, 221, 116, 31, 75, 189, 139, 138, 112, 62, 181, 102, 72, 3, 246, 14, 97, 53, 87, 185, 134, 193, 29, 158, 225, 248, 152, 17, 105, 217, 142, 148, 155, 30, 135, 233, 206, 85, 40, 223, 140, 161, 137, 13, 191, 230, 66, 104, 65, 153, 45, 15, 176, 84, 187, 22, 82, 9, 106, 213, 48, 54, 165, 56, 191, 64, 163, 158, 129, 243, 215, 251, 124, 227, 57, 130, 155, 47, 255, 135, 52, 142, 67, 68, 196, 222, 233, 203, 84, 123, 148, 50, 166, 194, 35, 61, 238, 76, 149, 11, 66, 250, 195, 78, 8, 46, 161, 102, 40, 217, 36, 178, 118, 91, 162, 73, 109, 139, 209, 37, 114, 248, 246, 100, 134, 104, 152, 22, 212, 164, 92, 204, 93, 101, 182, 146, 108, 112, 72, 80, 253, 237, 185, 218, 94, 21, 70, 87, 167, 141, 157, 132, 144, 216, 171, 0, 140, 188, 211, 10, 247, 228, 88, 5, 184, 179, 69, 6, 208, 44, 30, 143, 202, 63, 15, 2, 193, 175, 189, 3, 1, 19, 138, 107, 58, 145, 17, 65, 79, 103, 220, 234, 151, 242, 207, 206, 240, 180, 230, 115, 150, 172, 116, 34, 231, 173, 53, 133, 226, 249, 55, 232, 28, 117, 223, 110, 71, 241, 26, 113, 29, 41, 197, 137, 111, 183, 98, 14, 170, 24, 190, 27, 252, 86, 62, 75, 198, 210, 121, 32, 154, 219, 192, 254, 120, 205, 90, 244, 31, 221, 168, 51, 136, 7, 199, 49, 177, 18, 16, 89, 39, 128, 236, 95, 96, 81, 127, 169, 25, 181, 74, 13, 45, 229, 122, 159, 147, 201, 156, 239, 160, 224, 59, 77, 174, 42, 245, 176, 200, 235, 187, 60, 131, 83, 153, 97, 23, 43, 4, 126, 186, 119, 214, 38, 225, 105, 20, 99, 85, 33, 12, 125, 128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 62, 0, 0, 0, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 0, 0, 0, 0, 0, 0, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 107, 51, 52, 98, 98, 103, 98, 107, 106, 34, 49, 102, 52, 107, 101, 37, 48, 50, 88, 0, 96, 55, 51, 52, 98, 99, 103, 98, 107, 106, 54, 49, 101, 52, 97, 101, 49, 107, 48, 54, 54, 97, 106, 48, 100, 98, 49, 52, 49, 96, 49, 101, 84, 33, 34, 25, 13, 1, 2, 3, 17, 75, 28, 12, 16, 4, 11, 29, 18, 30, 39, 104, 110, 111, 112, 113, 98, 32, 5, 6, 15, 19, 20, 21, 26, 8, 22, 7, 40, 36, 23, 24, 9, 10, 14, 27, 31, 37, 35, 131, 130, 125, 38, 42, 43, 60, 61, 62, 63, 67, 71, 74, 77, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 99, 100, 101, 102, 103, 105, 106, 107, 108, 114, 115, 116, 121, 122, 123, 124, 0, 73, 108, 108, 101, 103, 97, 108, 32, 98, 121, 116, 101, 32, 115, 101, 113, 117, 101, 110, 99, 101, 0, 68, 111, 109, 97, 105, 110, 32, 101, 114, 114, 111, 114, 0, 82, 101, 115, 117, 108, 116, 32, 110, 111, 116, 32, 114, 101, 112, 114, 101, 115, 101, 110, 116, 97, 98, 108, 101, 0, 78, 111, 116, 32, 97, 32, 116, 116, 121, 0, 80, 101, 114, 109, 105, 115, 115, 105, 111, 110, 32, 100, 101, 110, 105, 101, 100, 0, 79, 112, 101, 114, 97, 116, 105, 111, 110, 32, 110, 111, 116, 32, 112, 101, 114, 109, 105, 116, 116, 101, 100, 0, 78, 111, 32, 115, 117, 99, 104, 32, 102, 105, 108, 101, 32, 111, 114, 32, 100, 105, 114, 101, 99, 116, 111, 114, 121, 0, 78, 111, 32, 115, 117, 99, 104, 32, 112, 114, 111, 99, 101, 115, 115, 0, 70, 105, 108, 101, 32, 101, 120, 105, 115, 116, 115, 0, 86, 97, 108, 117, 101, 32, 116, 111, 111, 32, 108, 97, 114, 103, 101, 32, 102, 111, 114, 32, 100, 97, 116, 97, 32, 116, 121, 112, 101, 0, 78, 111, 32, 115, 112, 97, 99, 101, 32, 108, 101, 102, 116, 32, 111, 110, 32, 100, 101, 118, 105, 99, 101, 0, 79, 117, 116, 32, 111, 102, 32, 109, 101, 109, 111, 114, 121, 0, 82, 101, 115, 111, 117, 114, 99, 101, 32, 98, 117, 115, 121, 0, 73, 110, 116, 101, 114, 114, 117, 112, 116, 101, 100, 32, 115, 121, 115, 116, 101, 109, 32, 99, 97, 108, 108, 0, 82, 101, 115, 111, 117, 114, 99, 101, 32, 116, 101, 109, 112, 111, 114, 97, 114, 105, 108, 121, 32, 117, 110, 97, 118, 97, 105, 108, 97, 98, 108, 101, 0, 73, 110, 118, 97, 108, 105, 100, 32, 115, 101, 101, 107, 0, 67, 114, 111, 115, 115, 45, 100, 101, 118, 105, 99, 101, 32, 108, 105, 110, 107, 0, 82, 101, 97, 100, 45, 111, 110, 108, 121, 32, 102, 105, 108, 101, 32, 115, 121, 115, 116, 101, 109, 0, 68, 105, 114, 101, 99, 116, 111, 114, 121, 32, 110, 111, 116, 32, 101, 109, 112, 116, 121, 0, 67, 111, 110, 110, 101, 99, 116, 105, 111, 110, 32, 114, 101, 115, 101, 116, 32, 98, 121, 32, 112, 101, 101, 114, 0, 79, 112, 101, 114, 97, 116, 105, 111, 110, 32, 116, 105, 109, 101, 100, 32, 111, 117, 116, 0, 67, 111, 110, 110, 101, 99, 116, 105, 111, 110, 32, 114, 101, 102, 117, 115, 101, 100, 0, 72, 111, 115, 116, 32, 105, 115, 32, 100, 111, 119, 110, 0, 72, 111, 115, 116, 32, 105, 115, 32, 117, 110, 114, 101, 97, 99, 104, 97, 98, 108, 101, 0, 65, 100, 100, 114, 101, 115, 115, 32, 105, 110, 32, 117, 115, 101, 0, 66, 114, 111, 107, 101, 110, 32, 112, 105, 112, 101, 0, 73, 47, 79, 32, 101, 114, 114, 111, 114, 0, 78, 111, 32, 115, 117, 99, 104, 32, 100, 101, 118, 105, 99, 101, 32, 111, 114, 32, 97, 100, 100, 114, 101, 115, 115, 0, 66, 108, 111, 99, 107, 32, 100, 101, 118, 105, 99, 101, 32, 114, 101, 113, 117, 105, 114, 101, 100, 0, 78, 111, 32, 115, 117, 99, 104, 32, 100, 101, 118, 105, 99, 101, 0, 78, 111, 116, 32, 97, 32, 100, 105, 114, 101, 99, 116, 111, 114, 121, 0, 73, 115, 32, 97, 32, 100, 105, 114, 101, 99, 116, 111, 114, 121, 0, 84, 101, 120, 116, 32, 102, 105, 108, 101, 32, 98, 117, 115, 121, 0, 69, 120, 101, 99, 32, 102, 111, 114, 109, 97, 116, 32, 101, 114, 114, 111, 114, 0, 73, 110, 118, 97, 108, 105, 100, 32, 97, 114, 103, 117, 109, 101, 110, 116, 0, 65, 114, 103, 117, 109, 101, 110, 116, 32, 108, 105, 115, 116, 32, 116, 111, 111, 32, 108, 111, 110, 103, 0, 83, 121, 109, 98, 111, 108, 105, 99, 32, 108, 105, 110, 107, 32, 108, 111, 111, 112, 0, 70, 105, 108, 101, 110, 97, 109, 101, 32, 116, 111, 111, 32, 108, 111, 110, 103, 0, 84, 111, 111, 32, 109, 97, 110, 121, 32, 111, 112, 101, 110, 32, 102, 105, 108, 101, 115, 32, 105, 110, 32, 115, 121, 115, 116, 101, 109, 0, 78, 111, 32, 102, 105, 108, 101, 32, 100, 101, 115, 99, 114, 105, 112, 116, 111, 114, 115, 32, 97, 118, 97, 105, 108, 97, 98, 108, 101, 0, 66, 97, 100, 32, 102, 105, 108, 101, 32, 100, 101, 115, 99, 114, 105, 112, 116, 111, 114, 0, 78, 111, 32, 99, 104, 105, 108, 100, 32, 112, 114, 111, 99, 101, 115, 115, 0, 66, 97, 100, 32, 97, 100, 100, 114, 101, 115, 115, 0, 70, 105, 108, 101, 32, 116, 111, 111, 32, 108, 97, 114, 103, 101, 0, 84, 111, 111, 32, 109, 97, 110, 121, 32, 108, 105, 110, 107, 115, 0, 78, 111, 32, 108, 111, 99, 107, 115, 32, 97, 118, 97, 105, 108, 97, 98, 108, 101, 0, 82, 101, 115, 111, 117, 114, 99, 101, 32, 100, 101, 97, 100, 108, 111, 99, 107, 32, 119, 111, 117, 108, 100, 32, 111, 99, 99, 117, 114, 0, 83, 116, 97, 116, 101, 32, 110, 111, 116, 32, 114, 101, 99, 111, 118, 101, 114, 97, 98, 108, 101, 0, 80, 114, 101, 118, 105, 111, 117, 115, 32, 111, 119, 110, 101, 114, 32, 100, 105, 101, 100, 0, 79, 112, 101, 114, 97, 116, 105, 111, 110, 32, 99, 97, 110, 99, 101, 108, 101, 100, 0, 70, 117, 110, 99, 116, 105, 111, 110, 32, 110, 111, 116, 32, 105, 109, 112, 108, 101, 109, 101, 110, 116, 101, 100, 0, 78, 111, 32, 109, 101, 115, 115, 97, 103, 101, 32, 111, 102, 32, 100, 101, 115, 105, 114, 101, 100, 32, 116, 121, 112, 101, 0, 73, 100, 101, 110, 116, 105, 102, 105, 101, 114, 32, 114, 101, 109, 111, 118, 101, 100, 0, 68, 101, 118, 105, 99, 101, 32, 110, 111, 116, 32, 97, 32, 115, 116, 114, 101, 97, 109, 0, 78, 111, 32, 100, 97, 116, 97, 32, 97, 118, 97, 105, 108, 97, 98, 108, 101, 0, 68, 101, 118, 105, 99, 101, 32, 116, 105, 109, 101, 111, 117, 116, 0, 79, 117, 116, 32, 111, 102, 32, 115, 116, 114, 101, 97, 109, 115, 32, 114, 101, 115, 111, 117, 114, 99, 101, 115, 0, 76, 105, 110, 107, 32, 104, 97, 115, 32, 98, 101, 101, 110, 32, 115, 101, 118, 101, 114, 101, 100, 0, 80, 114, 111, 116, 111, 99, 111, 108, 32, 101, 114, 114, 111, 114, 0, 66, 97, 100, 32, 109, 101, 115, 115, 97, 103, 101, 0, 70, 105, 108, 101, 32, 100, 101, 115, 99, 114, 105, 112, 116, 111, 114, 32, 105, 110, 32, 98, 97, 100, 32, 115, 116, 97, 116, 101, 0, 78, 111, 116, 32, 97, 32, 115, 111, 99, 107, 101, 116, 0, 68, 101, 115, 116, 105, 110, 97, 116, 105, 111, 110, 32, 97, 100, 100, 114, 101, 115, 115, 32, 114, 101, 113, 117, 105, 114, 101, 100, 0, 77, 101, 115, 115, 97, 103, 101, 32, 116, 111, 111, 32, 108, 97, 114, 103, 101, 0, 80, 114, 111, 116, 111, 99, 111, 108, 32, 119, 114, 111, 110, 103, 32, 116, 121, 112, 101, 32, 102, 111, 114, 32, 115, 111, 99, 107, 101, 116, 0, 80, 114, 111, 116, 111, 99, 111, 108, 32, 110, 111, 116, 32, 97, 118, 97, 105, 108, 97, 98, 108, 101, 0, 80, 114, 111, 116, 111, 99, 111, 108, 32, 110, 111, 116, 32, 115, 117, 112, 112, 111, 114, 116, 101, 100, 0, 83, 111, 99, 107, 101, 116, 32, 116, 121, 112, 101, 32, 110, 111, 116, 32, 115, 117, 112, 112, 111, 114, 116, 101, 100, 0, 78, 111, 116, 32, 115, 117, 112, 112, 111, 114, 116, 101, 100, 0, 80, 114, 111, 116, 111, 99, 111, 108, 32, 102, 97, 109, 105, 108, 121, 32, 110, 111, 116, 32, 115, 117, 112, 112, 111, 114, 116, 101, 100, 0, 65, 100, 100, 114, 101, 115, 115, 32, 102, 97, 109, 105, 108, 121, 32, 110, 111, 116, 32, 115, 117, 112, 112, 111, 114, 116, 101, 100, 32, 98, 121, 32, 112, 114, 111, 116, 111, 99, 111, 108, 0, 65, 100, 100, 114, 101, 115, 115, 32, 110, 111, 116, 32, 97, 118, 97, 105, 108, 97, 98, 108, 101, 0, 78, 101, 116, 119, 111, 114, 107, 32, 105, 115, 32, 100, 111, 119, 110, 0, 78, 101, 116, 119, 111, 114, 107, 32, 117, 110, 114, 101, 97, 99, 104, 97, 98, 108, 101, 0, 67, 111, 110, 110, 101, 99, 116, 105, 111, 110, 32, 114, 101, 115, 101, 116, 32, 98, 121, 32, 110, 101, 116, 119, 111, 114, 107, 0, 67, 111, 110, 110, 101, 99, 116, 105, 111, 110, 32, 97, 98, 111, 114, 116, 101, 100, 0, 78, 111, 32, 98, 117, 102, 102, 101, 114, 32, 115, 112, 97, 99, 101, 32, 97, 118, 97, 105, 108, 97, 98, 108, 101, 0, 83, 111, 99, 107, 101, 116, 32, 105, 115, 32, 99, 111, 110, 110, 101, 99, 116, 101, 100, 0, 83, 111, 99, 107, 101, 116, 32, 110, 111, 116, 32, 99, 111, 110, 110, 101, 99, 116, 101, 100, 0, 67, 97, 110, 110, 111, 116, 32, 115, 101, 110, 100, 32, 97, 102, 116, 101, 114, 32, 115, 111, 99, 107, 101, 116, 32, 115, 104, 117, 116, 100, 111, 119, 110, 0, 79, 112, 101, 114, 97, 116, 105, 111, 110, 32, 97, 108, 114, 101, 97, 100, 121, 32, 105, 110, 32, 112, 114, 111, 103, 114, 101, 115, 115, 0, 79, 112, 101, 114, 97, 116, 105, 111, 110, 32, 105, 110, 32, 112, 114, 111, 103, 114, 101, 115, 115, 0, 83, 116, 97, 108, 101, 32, 102, 105, 108, 101, 32, 104, 97, 110, 100, 108, 101, 0, 82, 101, 109, 111, 116, 101, 32, 73, 47, 79, 32, 101, 114, 114, 111, 114, 0, 81, 117, 111, 116, 97, 32, 101, 120, 99, 101, 101, 100, 101, 100, 0, 78, 111, 32, 109, 101, 100, 105, 117, 109, 32, 102, 111, 117, 110, 100, 0, 87, 114, 111, 110, 103, 32, 109, 101, 100, 105, 117, 109, 32, 116, 121, 112, 101, 0, 78, 111, 32, 101, 114, 114, 111, 114, 32, 105, 110, 102, 111, 114, 109, 97, 116, 105, 111, 110, 0, 0, 17, 0, 10, 0, 17, 17, 17, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 0, 17, 0, 15, 10, 17, 17, 17, 3, 10, 7, 0, 1, 19, 9, 11, 11, 0, 0, 9, 6, 11, 0, 0, 11, 0, 6, 17, 0, 0, 0, 17, 17, 17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 0, 17, 0, 10, 10, 17, 17, 17, 0, 10, 0, 0, 2, 0, 9, 11, 0, 0, 0, 9, 0, 11, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 0, 0, 0, 12, 0, 0, 0, 0, 9, 12, 0, 0, 0, 0, 0, 12, 0, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 4, 13, 0, 0, 0, 0, 9, 14, 0, 0, 0, 0, 0, 14, 0, 0, 14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 0, 0, 0, 0, 15, 0, 0, 0, 0, 9, 16, 0, 0, 0, 0, 0, 16, 0, 0, 16, 0, 0, 18, 0, 0, 0, 18, 18, 18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 0, 0, 0, 18, 18, 18, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 10, 0, 0, 0, 0, 9, 11, 0, 0, 0, 0, 0, 11, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 0, 0, 0, 12, 0, 0, 0, 0, 9, 12, 0, 0, 0, 0, 0, 12, 0, 0, 12, 0, 0, 45, 43, 32, 32, 32, 48, 88, 48, 120, 0, 40, 110, 117, 108, 108, 41, 0, 45, 48, 88, 43, 48, 88, 32, 48, 88, 45, 48, 120, 43, 48, 120, 32, 48, 120, 0, 105, 110, 102, 0, 73, 78, 70, 0, 110, 97, 110, 0, 78, 65, 78, 0, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70, 46, 0 ], "i8", ALLOC_NONE, Runtime.GLOBAL_BASE);
                        var tempDoublePtr = STATICTOP;
                        function copyTempFloat(t) {
                            HEAP8[tempDoublePtr] = HEAP8[t], HEAP8[tempDoublePtr + 1] = HEAP8[t + 1], HEAP8[tempDoublePtr + 2] = HEAP8[t + 2], 
                            HEAP8[tempDoublePtr + 3] = HEAP8[t + 3];
                        }
                        function copyTempDouble(t) {
                            HEAP8[tempDoublePtr] = HEAP8[t], HEAP8[tempDoublePtr + 1] = HEAP8[t + 1], HEAP8[tempDoublePtr + 2] = HEAP8[t + 2], 
                            HEAP8[tempDoublePtr + 3] = HEAP8[t + 3], HEAP8[tempDoublePtr + 4] = HEAP8[t + 4], 
                            HEAP8[tempDoublePtr + 5] = HEAP8[t + 5], HEAP8[tempDoublePtr + 6] = HEAP8[t + 6], 
                            HEAP8[tempDoublePtr + 7] = HEAP8[t + 7];
                        }
                        function ___lock() {}
                        function ___unlock() {}
                        STATICTOP += 16, assert(tempDoublePtr % 8 == 0);
                        var SYSCALLS = {
                            varargs: 0,
                            get: function(t) {
                                return SYSCALLS.varargs += 4, HEAP32[SYSCALLS.varargs - 4 >> 2];
                            },
                            getStr: function() {
                                return Pointer_stringify(SYSCALLS.get());
                            },
                            get64: function() {
                                var t = SYSCALLS.get(), e = SYSCALLS.get();
                                return assert(t >= 0 ? 0 === e : -1 === e), t;
                            },
                            getZero: function() {
                                assert(0 === SYSCALLS.get());
                            }
                        };
                        function ___syscall6(t, e) {
                            SYSCALLS.varargs = e;
                            try {
                                var n = SYSCALLS.getStreamFromFD();
                                return FS.close(n), 0;
                            } catch (t) {
                                return void 0 !== FS && t instanceof FS.ErrnoError || abort(t), -t.errno;
                            }
                        }
                        var cttz_i8 = allocate([ 8, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 7, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0 ], "i8", ALLOC_STATIC);
                        function ___setErrNo(t) {
                            return Module.___errno_location ? HEAP32[Module.___errno_location() >> 2] = t : Module.printErr("failed to set errno from JS"), 
                            t;
                        }
                        function _emscripten_memcpy_big(t, e, n) {
                            return HEAPU8.set(HEAPU8.subarray(e, e + n), t), t;
                        }
                        function ___syscall140(t, e) {
                            SYSCALLS.varargs = e;
                            try {
                                var n = SYSCALLS.getStreamFromFD(), r = (SYSCALLS.get(), SYSCALLS.get()), i = SYSCALLS.get(), o = SYSCALLS.get(), a = r;
                                return FS.llseek(n, a, o), HEAP32[i >> 2] = n.position, n.getdents && 0 === a && 0 === o && (n.getdents = null), 
                                0;
                            } catch (t) {
                                return void 0 !== FS && t instanceof FS.ErrnoError || abort(t), -t.errno;
                            }
                        }
                        function ___syscall146(t, e) {
                            SYSCALLS.varargs = e;
                            try {
                                var n = SYSCALLS.get(), r = SYSCALLS.get(), i = SYSCALLS.get(), o = 0;
                                ___syscall146.buffer || (___syscall146.buffers = [ null, [], [] ], ___syscall146.printChar = function(t, e) {
                                    var n = ___syscall146.buffers[t];
                                    assert(n), 0 === e || 10 === e ? ((1 === t ? Module.print : Module.printErr)(UTF8ArrayToString(n, 0)), 
                                    n.length = 0) : n.push(e);
                                });
                                for (var a = 0; a < i; a++) {
                                    for (var s = HEAP32[r + 8 * a >> 2], u = HEAP32[r + (8 * a + 4) >> 2], c = 0; c < u; c++) ___syscall146.printChar(n, HEAPU8[s + c]);
                                    o += u;
                                }
                                return o;
                            } catch (t) {
                                return void 0 !== FS && t instanceof FS.ErrnoError || abort(t), -t.errno;
                            }
                        }
                        function ___syscall54(t, e) {
                            SYSCALLS.varargs = e;
                            try {
                                return 0;
                            } catch (t) {
                                return void 0 !== FS && t instanceof FS.ErrnoError || abort(t), -t.errno;
                            }
                        }
                        function nullFunc_ii(t) {
                            Module.printErr("Invalid function pointer called with signature 'ii'. Perhaps this is an invalid value (e.g. caused by calling a virtual method on a NULL pointer)? Or calling a function with an incorrect type, which will fail? (it is worth building your source files with -Werror (warnings are errors), as warnings can indicate undefined behavior which can cause this)"), 
                            Module.printErr("Build with ASSERTIONS=2 for more info."), abort(t);
                        }
                        function nullFunc_iiii(t) {
                            Module.printErr("Invalid function pointer called with signature 'iiii'. Perhaps this is an invalid value (e.g. caused by calling a virtual method on a NULL pointer)? Or calling a function with an incorrect type, which will fail? (it is worth building your source files with -Werror (warnings are errors), as warnings can indicate undefined behavior which can cause this)"), 
                            Module.printErr("Build with ASSERTIONS=2 for more info."), abort(t);
                        }
                        function invoke_ii(t, e) {
                            try {
                                return Module.dynCall_ii(t, e);
                            } catch (t) {
                                if ("number" != typeof t && "longjmp" !== t) throw t;
                                Module.setThrew(1, 0);
                            }
                        }
                        function invoke_iiii(t, e, n, r) {
                            try {
                                return Module.dynCall_iiii(t, e, n, r);
                            } catch (t) {
                                if ("number" != typeof t && "longjmp" !== t) throw t;
                                Module.setThrew(1, 0);
                            }
                        }
                        __ATEXIT__.push(function() {
                            var t = Module._fflush;
                            t && t(0);
                            var e = ___syscall146.printChar;
                            if (e) {
                                var n = ___syscall146.buffers;
                                n[1].length && e(1, 10), n[2].length && e(2, 10);
                            }
                        }), DYNAMICTOP_PTR = allocate(1, "i32", ALLOC_STATIC), STACK_BASE = STACKTOP = Runtime.alignMemory(STATICTOP), 
                        STACK_MAX = STACK_BASE + TOTAL_STACK, DYNAMIC_BASE = Runtime.alignMemory(STACK_MAX), 
                        HEAP32[DYNAMICTOP_PTR >> 2] = DYNAMIC_BASE, staticSealed = !0, assert(DYNAMIC_BASE < TOTAL_MEMORY, "TOTAL_MEMORY not big enough for stack"), 
                        Module.asmGlobalArg = {
                            Math: Math,
                            Int8Array: Int8Array,
                            Int16Array: Int16Array,
                            Int32Array: Int32Array,
                            Uint8Array: Uint8Array,
                            Uint16Array: Uint16Array,
                            Uint32Array: Uint32Array,
                            Float32Array: Float32Array,
                            Float64Array: Float64Array,
                            NaN: NaN,
                            Infinity: 1 / 0
                        }, Module.asmLibraryArg = {
                            abort: abort,
                            assert: assert,
                            enlargeMemory: enlargeMemory,
                            getTotalMemory: getTotalMemory,
                            abortOnCannotGrowMemory: abortOnCannotGrowMemory,
                            abortStackOverflow: abortStackOverflow,
                            nullFunc_ii: nullFunc_ii,
                            nullFunc_iiii: nullFunc_iiii,
                            invoke_ii: invoke_ii,
                            invoke_iiii: invoke_iiii,
                            ___lock: ___lock,
                            ___syscall6: ___syscall6,
                            ___setErrNo: ___setErrNo,
                            ___syscall140: ___syscall140,
                            _emscripten_memcpy_big: _emscripten_memcpy_big,
                            ___syscall54: ___syscall54,
                            ___unlock: ___unlock,
                            ___syscall146: ___syscall146,
                            DYNAMICTOP_PTR: DYNAMICTOP_PTR,
                            tempDoublePtr: tempDoublePtr,
                            ABORT: ABORT,
                            STACKTOP: STACKTOP,
                            STACK_MAX: STACK_MAX,
                            cttz_i8: cttz_i8
                        };
                        var asm = function(t, e, n) {
                            var r = new t.Int8Array(n), i = new t.Int16Array(n), o = new t.Int32Array(n), a = (new t.Uint8Array(n), 
                            new t.Uint16Array(n), new t.Uint32Array(n), new t.Float32Array(n), new t.Float64Array(n)), s = 0 | e.DYNAMICTOP_PTR, u = 0 | e.tempDoublePtr, c = (e.ABORT, 
                            0 | e.STACKTOP), l = 0 | e.STACK_MAX, f = 0 | e.cttz_i8, d = 0, h = (t.NaN, t.Infinity, 
                            0), p = (t.Math.floor, t.Math.abs, t.Math.sqrt, t.Math.pow, t.Math.cos, t.Math.sin, 
                            t.Math.tan, t.Math.acos, t.Math.asin, t.Math.atan, t.Math.atan2, t.Math.exp, t.Math.log, 
                            t.Math.ceil, t.Math.imul), _ = (t.Math.min, t.Math.max, t.Math.clz32), m = (e.abort, 
                            e.assert, e.enlargeMemory), y = e.getTotalMemory, g = e.abortOnCannotGrowMemory, v = e.abortStackOverflow, b = e.nullFunc_ii, w = e.nullFunc_iiii, x = (e.invoke_ii, 
                            e.invoke_iiii, e.___lock), A = e.___syscall6, S = e.___setErrNo, T = e.___syscall140, P = e._emscripten_memcpy_big, M = e.___syscall54, k = e.___unlock, E = e.___syscall146;
                            function O(t, e) {
                                t |= 0, e |= 0;
                                var n, i, o, a = 0, s = 0;
                                for (o = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), n = t, i = e, s = 0; (0 | 255 & s) < 16; ) a = 0 | r[(i + (255 & s) | 0) >> 0], 
                                r[(n + (255 & s) | 0) >> 0] = a, s = s + 1 << 24 >> 24;
                                c = o;
                            }
                            function C() {
                                var t, e = 0, n = 0;
                                for (t = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), e = 0, L(10), e = 9; n = (0 | 255 & e) > 0, 
                                j(), D(), n; ) L(e), B(), e = e + -1 << 24 >> 24;
                                L(0), c = t;
                            }
                            function I(t) {
                                t |= 0;
                                var e, n, i = 0, a = 0, s = 0, u = 0, f = 0;
                                for (n = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), e = t, u = 0; (0 | 255 & u) < 16; ) f = 0 | o[1020], 
                                i = 255 & (0 | r[(f + (255 & u) | 0) >> 0]), s = 255 & (255 & (0 | r[(a = e + (255 & u) | 0) >> 0]) ^ i), 
                                r[a >> 0] = s, u = u + 1 << 24 >> 24;
                                c = n;
                            }
                            function R(t) {
                                var e, n;
                                return t |= 0, n = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), e = 0 | r[(759 + (255 & t) | 0) >> 0], 
                                c = n, 0 | e;
                            }
                            function L(t) {
                                t |= 0;
                                var e, n, i = 0, a = 0, s = 0, u = 0, f = 0, d = 0;
                                for (n = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), e = t, i = 0; (0 | 255 & i) < 4; ) {
                                    for (u = 0; (0 | 255 & u) < 4; ) a = 255 & (0 | r[(4656 + ((((255 & e) << 2 << 2) + ((255 & i) << 2) | 0) + (255 & u) | 0) | 0) >> 0]), 
                                    s = 0 | o[1018], d = 255 & (255 & (0 | r[(f = (s + ((255 & i) << 2) | 0) + (255 & u) | 0) >> 0]) ^ a), 
                                    r[f >> 0] = d, u = u + 1 << 24 >> 24;
                                    i = i + 1 << 24 >> 24;
                                }
                                c = n;
                            }
                            function N(t) {
                                var e, n;
                                return t |= 0, n = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), c = n, 0 | 255 & ((255 & (e = t)) << 1 ^ (27 * (1 & (255 & e) >> 7) | 0));
                            }
                            function j() {
                                var t, e, n, i, a, s, u, f, d, h, p, _, m, y, g, b, w, x, A, S, T, P, M, k, E, O, C, I, R, L, N, j, D, B, U, F, H, $ = 0;
                                H = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), t = 0 | o[1018], $ = 0 | r[(1 + (t + 12 | 0) | 0) >> 0], 
                                S = 0 | o[1018], B = 0 | r[(1 + (S + 8 | 0) | 0) >> 0], F = 0 | o[1018], r[(1 + (F + 12 | 0) | 0) >> 0] = B, 
                                e = 0 | o[1018], n = 0 | r[(1 + (e + 4 | 0) | 0) >> 0], i = 0 | o[1018], r[(1 + (i + 8 | 0) | 0) >> 0] = n, 
                                a = 0 | o[1018], s = 0 | r[(a + 1 | 0) >> 0], u = 0 | o[1018], r[(1 + (u + 4 | 0) | 0) >> 0] = s, 
                                f = $, d = 0 | o[1018], r[(d + 1 | 0) >> 0] = f, h = 0 | o[1018], $ = 0 | r[(h + 2 | 0) >> 0], 
                                p = 0 | o[1018], _ = 0 | r[(2 + (p + 8 | 0) | 0) >> 0], m = 0 | o[1018], r[(m + 2 | 0) >> 0] = _, 
                                y = $, g = 0 | o[1018], r[(2 + (g + 8 | 0) | 0) >> 0] = y, b = 0 | o[1018], $ = 0 | r[(2 + (b + 4 | 0) | 0) >> 0], 
                                w = 0 | o[1018], x = 0 | r[(2 + (w + 12 | 0) | 0) >> 0], A = 0 | o[1018], r[(2 + (A + 4 | 0) | 0) >> 0] = x, 
                                T = $, P = 0 | o[1018], r[(2 + (P + 12 | 0) | 0) >> 0] = T, M = 0 | o[1018], $ = 0 | r[(M + 3 | 0) >> 0], 
                                k = 0 | o[1018], E = 0 | r[(3 + (k + 4 | 0) | 0) >> 0], O = 0 | o[1018], r[(O + 3 | 0) >> 0] = E, 
                                C = 0 | o[1018], I = 0 | r[(3 + (C + 8 | 0) | 0) >> 0], R = 0 | o[1018], r[(3 + (R + 4 | 0) | 0) >> 0] = I, 
                                L = 0 | o[1018], N = 0 | r[(3 + (L + 12 | 0) | 0) >> 0], j = 0 | o[1018], r[(3 + (j + 8 | 0) | 0) >> 0] = N, 
                                D = $, U = 0 | o[1018], r[(3 + (U + 12 | 0) | 0) >> 0] = D, c = H;
                            }
                            function D() {
                                var t, e = 0, n = 0, i = 0, a = 0, s = 0;
                                for (t = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), e = 0; (0 | 255 & e) < 4; ) {
                                    for (n = 0; (0 | 255 & n) < 4; ) s = 0 | o[1018], i = 0 | U(0 | r[((s + ((255 & n) << 2) | 0) + (255 & e) | 0) >> 0]), 
                                    a = 0 | o[1018], r[((a + ((255 & n) << 2) | 0) + (255 & e) | 0) >> 0] = i, n = n + 1 << 24 >> 24;
                                    e = e + 1 << 24 >> 24;
                                }
                                c = t;
                            }
                            function B() {
                                var t, e = 0, n = 0, i = 0, a = 0, s = 0, u = 0, f = 0, d = 0, h = 0, p = 0, _ = 0, m = 0, y = 0, g = 0, b = 0, w = 0, x = 0, A = 0, S = 0, T = 0, P = 0, M = 0, k = 0, E = 0, O = 0, C = 0, I = 0, R = 0, L = 0, j = 0, D = 0, B = 0, U = 0, F = 0, H = 0, $ = 0, V = 0, z = 0, Y = 0, G = 0, W = 0, K = 0, X = 0, J = 0, Q = 0, q = 0, Z = 0, tt = 0, et = 0, nt = 0, rt = 0, it = 0, ot = 0, at = 0, st = 0, ut = 0, ct = 0, lt = 0, ft = 0, dt = 0, ht = 0;
                                for (t = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), e = 0; (0 | e) < 4; ) lt = 0 | o[1018], 
                                n = 0 | r[(lt + (e << 2) | 0) >> 0], a = 0 | o[1018], x = 0 | r[(1 + (a + (e << 2) | 0) | 0) >> 0], 
                                y = 0 | o[1018], L = 0 | r[(2 + (y + (e << 2) | 0) | 0) >> 0], S = 0 | o[1018], 
                                W = 0 | r[(3 + (S + (e << 2) | 0) | 0) >> 0], et = 0 ^ 255 & (0 | N(n)) ^ 255 & (0 | N(0 | N(n))) ^ 255 & (0 | N(0 | N(0 | N(n)))), 
                                N(0 | N(0 | N(0 | N(n)))), ut = 0 ^ et, ct = 255 & x ^ 255 & (0 | N(x)), N(0 | N(x)), 
                                ft = 0 ^ ct ^ 255 & (0 | N(0 | N(0 | N(x)))), N(0 | N(0 | N(0 | N(x)))), dt = 0 ^ ut ^ ft, 
                                ht = 255 & L, N(L), i = 0 ^ ht ^ 255 & (0 | N(0 | N(L))) ^ 255 & (0 | N(0 | N(0 | N(L)))), 
                                N(0 | N(0 | N(0 | N(L)))), s = 0 ^ dt ^ i, u = 255 & W, N(W), f = 0 ^ u, N(0 | N(W)), 
                                d = 0 ^ f ^ 255 & (0 | N(0 | N(0 | N(W)))), N(0 | N(0 | N(0 | N(W)))), h = 255 & (0 ^ s ^ d), 
                                p = 0 | o[1018], r[(p + (e << 2) | 0) >> 0] = h, _ = 255 & n, N(n), m = 0 ^ _, N(0 | N(n)), 
                                g = 0 ^ m ^ 255 & (0 | N(0 | N(0 | N(n)))), N(0 | N(0 | N(0 | N(n)))), b = 0 ^ g, 
                                w = 0 ^ 255 & (0 | N(x)) ^ 255 & (0 | N(0 | N(x))) ^ 255 & (0 | N(0 | N(0 | N(x)))), 
                                N(0 | N(0 | N(0 | N(x)))), A = 0 ^ b ^ w, T = 255 & L ^ 255 & (0 | N(L)), N(0 | N(L)), 
                                P = 0 ^ T ^ 255 & (0 | N(0 | N(0 | N(L)))), N(0 | N(0 | N(0 | N(L)))), M = 0 ^ A ^ P, 
                                k = 255 & W, N(W), E = 0 ^ k ^ 255 & (0 | N(0 | N(W))) ^ 255 & (0 | N(0 | N(0 | N(W)))), 
                                N(0 | N(0 | N(0 | N(W)))), O = 255 & (0 ^ M ^ E), C = 0 | o[1018], r[(1 + (C + (e << 2) | 0) | 0) >> 0] = O, 
                                I = 255 & n, N(n), R = 0 ^ I ^ 255 & (0 | N(0 | N(n))) ^ 255 & (0 | N(0 | N(0 | N(n)))), 
                                N(0 | N(0 | N(0 | N(n)))), j = 0 ^ R, D = 255 & x, N(x), B = 0 ^ D, N(0 | N(x)), 
                                U = 0 ^ B ^ 255 & (0 | N(0 | N(0 | N(x)))), N(0 | N(0 | N(0 | N(x)))), F = 0 ^ j ^ U, 
                                H = 0 ^ 255 & (0 | N(L)) ^ 255 & (0 | N(0 | N(L))) ^ 255 & (0 | N(0 | N(0 | N(L)))), 
                                N(0 | N(0 | N(0 | N(L)))), $ = 0 ^ F ^ H, V = 255 & W ^ 255 & (0 | N(W)), N(0 | N(W)), 
                                z = 0 ^ V ^ 255 & (0 | N(0 | N(0 | N(W)))), N(0 | N(0 | N(0 | N(W)))), Y = 255 & (0 ^ $ ^ z), 
                                G = 0 | o[1018], r[(2 + (G + (e << 2) | 0) | 0) >> 0] = Y, K = 255 & n ^ 255 & (0 | N(n)), 
                                N(0 | N(n)), X = 0 ^ K ^ 255 & (0 | N(0 | N(0 | N(n)))), N(0 | N(0 | N(0 | N(n)))), 
                                J = 0 ^ X, Q = 255 & x, N(x), q = 0 ^ Q ^ 255 & (0 | N(0 | N(x))) ^ 255 & (0 | N(0 | N(0 | N(x)))), 
                                N(0 | N(0 | N(0 | N(x)))), Z = 0 ^ J ^ q, tt = 255 & L, N(L), nt = 0 ^ tt, N(0 | N(L)), 
                                rt = 0 ^ nt ^ 255 & (0 | N(0 | N(0 | N(L)))), N(0 | N(0 | N(0 | N(L)))), it = 0 ^ Z ^ rt, 
                                ot = 0 ^ 255 & (0 | N(W)) ^ 255 & (0 | N(0 | N(W))) ^ 255 & (0 | N(0 | N(0 | N(W)))), 
                                N(0 | N(0 | N(0 | N(W)))), at = 255 & (0 ^ it ^ ot), st = 0 | o[1018], r[(3 + (st + (e << 2) | 0) | 0) >> 0] = at, 
                                e = e + 1 | 0;
                                c = t;
                            }
                            function U(t) {
                                var e, n;
                                return t |= 0, n = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), e = 0 | r[(1015 + (255 & t) | 0) >> 0], 
                                c = n, 0 | e;
                            }
                            function F(t, e, n) {
                                t |= 0, e |= 0, n |= 0;
                                var r, i, a, s, u, f, d, h, p, _, m, y = 0, g = 0, b = 0, w = 0;
                                if (m = c, (0 | (c = c + 32 | 0)) >= (0 | l) && v(32), h = e, p = n, b = 0, w = 0, 
                                _ = 64 - (w = 63 & (0 | o[(s = t) >> 2]) >>> 3) | 0, r = p << 3, a = (0 | o[(i = s) >> 2]) + r | 0, 
                                o[i >> 2] = a, (0 | o[s >> 2]) >>> 0 < p << 3 >>> 0 && (g = 1 + (0 | o[(y = s + 4 | 0) >> 2]) | 0, 
                                o[y >> 2] = g), u = p >>> 29, d = (0 | o[(f = s + 4 | 0) >> 2]) + u | 0, o[f >> 2] = d, 
                                !(p >>> 0 >= _ >>> 0)) return St(0 | (s + 24 | 0) + w, 0 | h + (b = 0), 0 | p - b), 
                                void (c = m);
                                for (St(0 | (s + 24 | 0) + w, 0 | h, 0 | _), H(s + 8 | 0, s + 24 | 0), b = _; (b + 64 | 0) >>> 0 <= p >>> 0; ) H(s + 8 | 0, h + b | 0), 
                                b = b + 64 | 0;
                                St(0 | (s + 24 | 0) + (w = 0), 0 | h + b, 0 | p - b), c = m;
                            }
                            function H(t, e) {
                                t |= 0, e |= 0;
                                var n, i, a, s, u, f, d, h, p, _, m, y, g, b, w, x, A = 0, S = 0, T = 0, P = 0;
                                x = c, (0 | (c = c + 288 | 0)) >= (0 | l) && v(288), w = x, b = e, A = 0 | o[(g = t) >> 2], 
                                S = 0 | o[(g + 4 | 0) >> 2], T = 0 | o[(g + 8 | 0) >> 2], P = 0 | o[(g + 12 | 0) >> 2], 
                                function(t, e, n) {
                                    t |= 0, e |= 0;
                                    var i, a, s, u = 0, f = 0, d = 0;
                                    for (s = c, (0 | (c = c + 32 | 0)) >= (0 | l) && v(32), i = t, a = e, f = 0, d = 0; d >>> 0 < 64; ) u = 255 & (0 | r[(a + d | 0) >> 0]) | (255 & (0 | r[(a + (d + 1 | 0) | 0) >> 0])) << 8 | (255 & (0 | r[(a + (d + 2 | 0) | 0) >> 0])) << 16 | (255 & (0 | r[(a + (d + 3 | 0) | 0) >> 0])) << 24, 
                                    o[(i + (f << 2) | 0) >> 2] = u, f = f + 1 | 0, d = d + 4 | 0;
                                    c = s;
                                }(w, b), S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = (S = S + ((((T = (T = (T = T + (606105819 + (((P = (P = (P = P + ((((A = (A = (A = A + (((S & T | (-1 ^ S) & P) + (0 | o[w >> 2]) | 0) - 680876936 | 0) | 0) << 7 | A >>> 25) + S | 0) & S | (-1 ^ A) & T) + (0 | o[(w + 4 | 0) >> 2]) | 0) - 389564586 | 0) | 0) << 12 | P >>> 20) + A | 0) & A | (-1 ^ P) & S) + (0 | o[(w + 8 | 0) >> 2]) | 0) | 0) | 0) << 17 | T >>> 15) + P | 0) & P | (-1 ^ T) & A) + (0 | o[(w + 12 | 0) >> 2]) | 0) - 1044525330 | 0) | 0) << 22 | S >>> 10) + T | 0) + ((((T = (T = (T = T + ((((P = (P = (P = P + (1200080426 + (((A = (A = (A = A + (((S & T | (-1 ^ S) & P) + (0 | o[(w + 16 | 0) >> 2]) | 0) - 176418897 | 0) | 0) << 7 | A >>> 25) + S | 0) & S | (-1 ^ A) & T) + (0 | o[(w + 20 | 0) >> 2]) | 0) | 0) | 0) << 12 | P >>> 20) + A | 0) & A | (-1 ^ P) & S) + (0 | o[(w + 24 | 0) >> 2]) | 0) - 1473231341 | 0) | 0) << 17 | T >>> 15) + P | 0) & P | (-1 ^ T) & A) + (0 | o[(w + 28 | 0) >> 2]) | 0) - 45705983 | 0) | 0) << 22 | S >>> 10) + T | 0) + ((((T = (T = (T = T + ((((P = (P = (P = P + ((((A = (A = (A = A + (1770035416 + ((S & T | (-1 ^ S) & P) + (0 | o[(w + 32 | 0) >> 2]) | 0) | 0) | 0) << 7 | A >>> 25) + S | 0) & S | (-1 ^ A) & T) + (0 | o[(w + 36 | 0) >> 2]) | 0) - 1958414417 | 0) | 0) << 12 | P >>> 20) + A | 0) & A | (-1 ^ P) & S) + (0 | o[(w + 40 | 0) >> 2]) | 0) - 42063 | 0) | 0) << 17 | T >>> 15) + P | 0) & P | (-1 ^ T) & A) + (0 | o[(w + 44 | 0) >> 2]) | 0) - 1990404162 | 0) | 0) << 22 | S >>> 10) + T | 0) + (1236535329 + (((T = (T = (T = T + ((((P = (P = (P = P + ((((A = (A = (A = A + (1804603682 + ((S & T | (-1 ^ S) & P) + (0 | o[(w + 48 | 0) >> 2]) | 0) | 0) | 0) << 7 | A >>> 25) + S | 0) & S | (-1 ^ A) & T) + (0 | o[(w + 52 | 0) >> 2]) | 0) - 40341101 | 0) | 0) << 12 | P >>> 20) + A | 0) & A | (-1 ^ P) & S) + (0 | o[(w + 56 | 0) >> 2]) | 0) - 1502002290 | 0) | 0) << 17 | T >>> 15) + P | 0) & P | (-1 ^ T) & A) + (0 | o[(w + 60 | 0) >> 2]) | 0) | 0) | 0) << 22 | S >>> 10) + T | 0) + ((((T = (T = (T = T + (643717713 + (((P = (P = (P = P + ((((A = (A = (A = A + (((S & P | T & (-1 ^ P)) + (0 | o[(w + 4 | 0) >> 2]) | 0) - 165796510 | 0) | 0) << 5 | A >>> 27) + S | 0) & T | S & (-1 ^ T)) + (0 | o[(w + 24 | 0) >> 2]) | 0) - 1069501632 | 0) | 0) << 9 | P >>> 23) + A | 0) & S | A & (-1 ^ S)) + (0 | o[(w + 44 | 0) >> 2]) | 0) | 0) | 0) << 14 | T >>> 18) + P | 0) & A | P & (-1 ^ A)) + (0 | o[w >> 2]) | 0) - 373897302 | 0) | 0) << 20 | S >>> 12) + T | 0) + ((((T = (T = (T = T + ((((P = (P = (P = P + (38016083 + (((A = (A = (A = A + (((S & P | T & (-1 ^ P)) + (0 | o[(w + 20 | 0) >> 2]) | 0) - 701558691 | 0) | 0) << 5 | A >>> 27) + S | 0) & T | S & (-1 ^ T)) + (0 | o[(w + 40 | 0) >> 2]) | 0) | 0) | 0) << 9 | P >>> 23) + A | 0) & S | A & (-1 ^ S)) + (0 | o[(w + 60 | 0) >> 2]) | 0) - 660478335 | 0) | 0) << 14 | T >>> 18) + P | 0) & A | P & (-1 ^ A)) + (0 | o[(w + 16 | 0) >> 2]) | 0) - 405537848 | 0) | 0) << 20 | S >>> 12) + T | 0) + (1163531501 + (((T = (T = (T = T + ((((P = (P = (P = P + ((((A = (A = (A = A + (568446438 + ((S & P | T & (-1 ^ P)) + (0 | o[(w + 36 | 0) >> 2]) | 0) | 0) | 0) << 5 | A >>> 27) + S | 0) & T | S & (-1 ^ T)) + (0 | o[(w + 56 | 0) >> 2]) | 0) - 1019803690 | 0) | 0) << 9 | P >>> 23) + A | 0) & S | A & (-1 ^ S)) + (0 | o[(w + 12 | 0) >> 2]) | 0) - 187363961 | 0) | 0) << 14 | T >>> 18) + P | 0) & A | P & (-1 ^ A)) + (0 | o[(w + 32 | 0) >> 2]) | 0) | 0) | 0) << 20 | S >>> 12) + T | 0) + ((((T = (T = (T = T + (1735328473 + (((P = (P = (P = P + ((((A = (A = (A = A + (((S & P | T & (-1 ^ P)) + (0 | o[(w + 52 | 0) >> 2]) | 0) - 1444681467 | 0) | 0) << 5 | A >>> 27) + S | 0) & T | S & (-1 ^ T)) + (0 | o[(w + 8 | 0) >> 2]) | 0) - 51403784 | 0) | 0) << 9 | P >>> 23) + A | 0) & S | A & (-1 ^ S)) + (0 | o[(w + 28 | 0) >> 2]) | 0) | 0) | 0) << 14 | T >>> 18) + P | 0) & A | P & (-1 ^ A)) + (0 | o[(w + 48 | 0) >> 2]) | 0) - 1926607734 | 0) | 0) << 20 | S >>> 12) + T | 0) + ((((T = (T = (T = T + (1839030562 + (((P = (P = (P = P + ((((A = (A = (A = A + (((S ^ T ^ P) + (0 | o[(w + 20 | 0) >> 2]) | 0) - 378558 | 0) | 0) << 4 | A >>> 28) + S | 0) ^ S ^ T) + (0 | o[(w + 32 | 0) >> 2]) | 0) - 2022574463 | 0) | 0) << 11 | P >>> 21) + A | 0) ^ A ^ S) + (0 | o[(w + 44 | 0) >> 2]) | 0) | 0) | 0) << 16 | T >>> 16) + P | 0) ^ P ^ A) + (0 | o[(w + 56 | 0) >> 2]) | 0) - 35309556 | 0) | 0) << 23 | S >>> 9) + T | 0) + ((((T = (T = (T = T + ((((P = (P = (P = P + (1272893353 + (((A = (A = (A = A + (((S ^ T ^ P) + (0 | o[(w + 4 | 0) >> 2]) | 0) - 1530992060 | 0) | 0) << 4 | A >>> 28) + S | 0) ^ S ^ T) + (0 | o[(w + 16 | 0) >> 2]) | 0) | 0) | 0) << 11 | P >>> 21) + A | 0) ^ A ^ S) + (0 | o[(w + 28 | 0) >> 2]) | 0) - 155497632 | 0) | 0) << 16 | T >>> 16) + P | 0) ^ P ^ A) + (0 | o[(w + 40 | 0) >> 2]) | 0) - 1094730640 | 0) | 0) << 23 | S >>> 9) + T | 0) + (76029189 + (((T = (T = (T = T + ((((P = (P = (P = P + ((((A = (A = (A = A + (681279174 + ((S ^ T ^ P) + (0 | o[(w + 52 | 0) >> 2]) | 0) | 0) | 0) << 4 | A >>> 28) + S | 0) ^ S ^ T) + (0 | o[w >> 2]) | 0) - 358537222 | 0) | 0) << 11 | P >>> 21) + A | 0) ^ A ^ S) + (0 | o[(w + 12 | 0) >> 2]) | 0) - 722521979 | 0) | 0) << 16 | T >>> 16) + P | 0) ^ P ^ A) + (0 | o[(w + 24 | 0) >> 2]) | 0) | 0) | 0) << 23 | S >>> 9) + T | 0) + ((((T = (T = (T = T + (530742520 + (((P = (P = (P = P + ((((A = (A = (A = A + (((S ^ T ^ P) + (0 | o[(w + 36 | 0) >> 2]) | 0) - 640364487 | 0) | 0) << 4 | A >>> 28) + S | 0) ^ S ^ T) + (0 | o[(w + 48 | 0) >> 2]) | 0) - 421815835 | 0) | 0) << 11 | P >>> 21) + A | 0) ^ A ^ S) + (0 | o[(w + 60 | 0) >> 2]) | 0) | 0) | 0) << 16 | T >>> 16) + P | 0) ^ P ^ A) + (0 | o[(w + 8 | 0) >> 2]) | 0) - 995338651 | 0) | 0) << 23 | S >>> 9) + T | 0) + ((((P = (P = (P = P + (1126891415 + ((S ^ ((A = (A = (A = A + (((T ^ (S | -1 ^ P)) + (0 | o[w >> 2]) | 0) - 198630844 | 0) | 0) << 6 | A >>> 26) + S | 0) | -1 ^ T)) + (0 | o[(w + 28 | 0) >> 2]) | 0) | 0) | 0) << 10 | P >>> 22) + A | 0) ^ ((T = (T = (T = T + (((A ^ (P | -1 ^ S)) + (0 | o[(w + 56 | 0) >> 2]) | 0) - 1416354905 | 0) | 0) << 15 | T >>> 17) + P | 0) | -1 ^ A)) + (0 | o[(w + 20 | 0) >> 2]) | 0) - 57434055 | 0) | 0) << 21 | S >>> 11) + T | 0) + ((((P = (P = (P = P + (((S ^ ((A = (A = (A = A + (1700485571 + ((T ^ (S | -1 ^ P)) + (0 | o[(w + 48 | 0) >> 2]) | 0) | 0) | 0) << 6 | A >>> 26) + S | 0) | -1 ^ T)) + (0 | o[(w + 12 | 0) >> 2]) | 0) - 1894986606 | 0) | 0) << 10 | P >>> 22) + A | 0) ^ ((T = (T = (T = T + (((A ^ (P | -1 ^ S)) + (0 | o[(w + 40 | 0) >> 2]) | 0) - 1051523 | 0) | 0) << 15 | T >>> 17) + P | 0) | -1 ^ A)) + (0 | o[(w + 4 | 0) >> 2]) | 0) - 2054922799 | 0) | 0) << 21 | S >>> 11) + T | 0) + (1309151649 + (((P = (P = (P = P + (((S ^ ((A = (A = (A = A + (1873313359 + ((T ^ (S | -1 ^ P)) + (0 | o[(w + 32 | 0) >> 2]) | 0) | 0) | 0) << 6 | A >>> 26) + S | 0) | -1 ^ T)) + (0 | o[(w + 60 | 0) >> 2]) | 0) - 30611744 | 0) | 0) << 10 | P >>> 22) + A | 0) ^ ((T = (T = (T = T + (((A ^ (P | -1 ^ S)) + (0 | o[(w + 24 | 0) >> 2]) | 0) - 1560198380 | 0) | 0) << 15 | T >>> 17) + P | 0) | -1 ^ A)) + (0 | o[(w + 52 | 0) >> 2]) | 0) | 0) | 0) << 21 | S >>> 11) + T | 0) + ((((P = (P = (P = P + (((S ^ ((A = (A = (A = A + (((T ^ (S | -1 ^ P)) + (0 | o[(w + 16 | 0) >> 2]) | 0) - 145523070 | 0) | 0) << 6 | A >>> 26) + S | 0) | -1 ^ T)) + (0 | o[(w + 44 | 0) >> 2]) | 0) - 1120210379 | 0) | 0) << 10 | P >>> 22) + A | 0) ^ ((T = (T = (T = T + (718787259 + ((A ^ (P | -1 ^ S)) + (0 | o[(w + 8 | 0) >> 2]) | 0) | 0) | 0) << 15 | T >>> 17) + P | 0) | -1 ^ A)) + (0 | o[(w + 36 | 0) >> 2]) | 0) - 343485551 | 0) | 0) << 21 | S >>> 11) + T | 0, 
                                n = A, a = (0 | o[(i = g) >> 2]) + n | 0, o[i >> 2] = a, s = S, f = (0 | o[(u = g + 4 | 0) >> 2]) + s | 0, 
                                o[u >> 2] = f, d = T, p = (0 | o[(h = g + 8 | 0) >> 2]) + d | 0, o[h >> 2] = p, 
                                _ = P, y = (0 | o[(m = g + 12 | 0) >> 2]) + _ | 0, o[m >> 2] = y, c = x;
                            }
                            function $(t, e, n) {
                                t |= 0, e |= 0, n |= 0;
                                var i, a, s, u, f = 0, d = 0, h = 0, p = 0, _ = 0, m = 0;
                                for (u = c, (0 | (c = c + 32 | 0)) >= (0 | l) && v(32), i = t, a = e, s = n, _ = 0, 
                                m = 0; m >>> 0 < s >>> 0; ) f = 255 & (0 | o[(a + (_ << 2) | 0) >> 2]), r[(i + m | 0) >> 0] = f, 
                                d = 255 & (0 | o[(a + (_ << 2) | 0) >> 2]) >>> 8, r[(i + (m + 1 | 0) | 0) >> 0] = d, 
                                h = 255 & (0 | o[(a + (_ << 2) | 0) >> 2]) >>> 16, r[(i + (m + 2 | 0) | 0) >> 0] = h, 
                                p = 255 & (0 | o[(a + (_ << 2) | 0) >> 2]) >>> 24, r[(i + (m + 3 | 0) | 0) >> 0] = p, 
                                _ = _ + 1 | 0, m = m + 4 | 0;
                                c = u;
                            }
                            function V(t) {
                                t |= 0;
                                var e, n = 0;
                                return e = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), (0 | 255 & (n = t)) >= 97 && (0 | 255 & n) <= 122 && (n = 255 & ((255 & n) - 32 | 0)), 
                                c = e, 0 | n;
                            }
                            function z(t) {
                                t |= 0;
                                var e, n, r, i, a, s, u, f, d, h, p, _, m = 0, y = 0, g = 0, b = 0, w = 0, x = 0, A = 0, S = 0, T = 0, P = 0, M = 0, k = 0, E = 0, O = 0, C = 0, I = 0, R = 0, L = 0, N = 0, j = 0, D = 0, B = 0, U = 0, F = 0, H = 0, $ = 0, V = 0, z = 0, Y = 0, G = 0, W = 0, K = 0, X = 0, J = 0, Q = 0, q = 0, Z = 0, tt = 0, et = 0, nt = 0, rt = 0, it = 0, ot = 0, at = 0, st = 0, ut = 0, ct = 0, lt = 0, ft = 0, dt = 0, ht = 0, pt = 0, _t = 0, mt = 0, yt = 0, gt = 0, vt = 0, bt = 0, wt = 0, At = 0, St = 0, Tt = 0, Pt = 0, Mt = 0, kt = 0, Et = 0, Ot = 0, Ct = 0, It = 0, Rt = 0, Lt = 0, Nt = 0, jt = 0, Dt = 0, Bt = 0, Ut = 0, Ft = 0, Ht = 0, $t = 0, Vt = 0, zt = 0, Yt = 0, Gt = 0, Wt = 0, Kt = 0, Xt = 0, Jt = 0, Qt = 0, qt = 0, Zt = 0, te = 0, ee = 0, ne = 0, re = 0, ie = 0, oe = 0, ae = 0, se = 0, ue = 0, ce = 0, le = 0, fe = 0, de = 0, he = 0, pe = 0, _e = 0, me = 0, ye = 0, ge = 0, ve = 0, be = 0, we = 0, xe = 0, Ae = 0, Se = 0, Te = 0, Pe = 0, Me = 0, ke = 0, Ee = 0, Oe = 0, Ce = 0, Ie = 0, Re = 0, Le = 0, Ne = 0, je = 0, De = 0, Be = 0, Ue = 0, Fe = 0, He = 0, $e = 0, Ve = 0, ze = 0, Ye = 0, Ge = 0, We = 0, Ke = 0, Xe = 0, Je = 0, Qe = 0, qe = 0, Ze = 0, tn = 0, en = 0, nn = 0, rn = 0, on = 0, an = 0, sn = 0, un = 0, cn = 0, ln = 0, fn = 0, dn = 0, hn = 0, pn = 0, _n = 0, mn = 0, yn = 0, gn = 0, vn = 0, bn = 0, wn = 0, xn = 0, An = 0, Sn = 0, Tn = 0, Pn = 0, Mn = 0, kn = 0, En = 0, On = 0, Cn = 0, In = 0, Rn = 0, Ln = 0, Nn = 0, jn = 0, Dn = 0, Bn = 0, Un = 0, Fn = 0, Hn = 0, $n = 0, Vn = 0, zn = 0, Yn = 0, Gn = 0, Wn = 0, Kn = 0, Xn = 0, Jn = 0, Qn = 0, qn = 0, Zn = 0, tr = 0, er = 0, nr = 0, rr = 0, ir = 0, or = 0, ar = 0, sr = 0, ur = 0, cr = 0, lr = 0, fr = 0, dr = 0, hr = 0, pr = 0, _r = 0, mr = 0, yr = 0, gr = 0, vr = 0, br = 0, wr = 0, xr = 0, Ar = 0, Sr = 0, Tr = 0, Pr = 0, Mr = 0, kr = 0, Er = 0, Or = 0, Cr = 0, Ir = 0, Rr = 0, Lr = 0, Nr = 0, jr = 0, Dr = 0, Br = 0, Ur = 0, Fr = 0, Hr = 0, $r = 0, Vr = 0, zr = 0, Yr = 0, Gr = 0, Wr = 0, Kr = 0, Xr = 0, Jr = 0, Qr = 0, qr = 0, Zr = 0, ti = 0, ei = 0, ni = 0, ri = 0, ii = 0, oi = 0, ai = 0, si = 0, ui = 0, ci = 0, li = 0, fi = 0, di = 0, hi = 0, pi = 0, _i = 0, mi = 0, yi = 0, gi = 0, vi = 0, bi = 0, wi = 0, xi = 0, Ai = 0, Si = 0, Ti = 0, Pi = 0, Mi = 0, ki = 0, Ei = 0, Oi = 0, Ci = 0, Ii = 0, Ri = 0, Li = 0, Ni = 0, ji = 0, Di = 0, Bi = 0, Ui = 0, Fi = 0, Hi = 0, $i = 0, Vi = 0, zi = 0, Yi = 0, Gi = 0, Wi = 0, Ki = 0, Xi = 0, Ji = 0, Qi = 0, qi = 0, Zi = 0, to = 0, eo = 0, no = 0, ro = 0, io = 0, oo = 0, ao = 0, so = 0, uo = 0, co = 0, lo = 0, fo = 0, ho = 0, po = 0, _o = 0, mo = 0, yo = 0, go = 0, vo = 0, bo = 0, wo = 0, xo = 0, Ao = 0, So = 0, To = 0, Po = 0, Mo = 0, ko = 0, Eo = 0, Oo = 0, Co = 0, Io = 0, Ro = 0, Lo = 0, No = 0, jo = 0, Do = 0, Bo = 0, Uo = 0, Fo = 0, Ho = 0, $o = 0, Vo = 0, zo = 0, Yo = 0, Go = 0, Wo = 0, Ko = 0, Xo = 0, Jo = 0, Qo = 0, qo = 0, Zo = 0, ta = 0, ea = 0, na = 0, ra = 0, ia = 0, oa = 0, aa = 0, sa = 0, ua = 0, ca = 0, la = 0, fa = 0, da = 0, ha = 0, pa = 0, _a = 0, ma = 0, ya = 0, ga = 0, va = 0, ba = 0, wa = 0, xa = 0, Aa = 0, Sa = 0, Ta = 0, Pa = 0, Ma = 0, ka = 0, Ea = 0, Oa = 0, Ca = 0, Ia = 0, Ra = 0, La = 0, Na = 0, ja = 0, Da = 0, Ba = 0, Ua = 0, Fa = 0, Ha = 0, $a = 0, Va = 0, za = 0, Ya = 0, Ga = 0, Wa = 0, Ka = 0, Xa = 0, Ja = 0, Qa = 0, qa = 0, Za = 0, ts = 0, es = 0, ns = 0, rs = 0, is = 0, os = 0, as = 0, ss = 0, us = 0, cs = 0, ls = 0, fs = 0, ds = 0, hs = 0, ps = 0, _s = 0, ms = 0, ys = 0, gs = 0, vs = 0, bs = 0, ws = 0, xs = 0, As = 0, Ss = 0, Ts = 0;
                                _ = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), e = _, n = t >>> 0 < 245;
                                do {
                                    if (n) {
                                        if (go = (Pi = t >>> 0 < 11 ? 16 : -8 & (t + 11 | 0)) >>> 3, 0 != (0 | 3 & (Za = (la = 0 | o[1021]) >>> go))) return we = 0 | o[(me = 8 + (ce = 4124 + ((qt = (1 ^ 1 & Za) + go | 0) << 1 << 2) | 0) | 0) >> 2], 
                                        (0 | ce) == (0 | (Ee = 0 | o[(Se = we + 8 | 0) >> 2])) ? (We = la & (-1 ^ 1 << qt), 
                                        o[1021] = We) : (o[(Ee + 12 | 0) >> 2] = ce, o[me >> 2] = Ee), nn = 3 | (qe = qt << 3), 
                                        o[(we + 4 | 0) >> 2] = nn, xn = 1 | o[(mn = 4 + (we + qe | 0) | 0) >> 2], o[mn >> 2] = xn, 
                                        c = _, 0 | Se;
                                        if (Pi >>> 0 > (kn = 0 | o[1023]) >>> 0) {
                                            if (0 != (0 | Za)) return to = 0 | o[(Ji = 8 + (Gi = 4124 + ((Ui = ((jr = 8 & (Tr = (yr = ((or = Za << go & ((Gn = 2 << go) | 0 - Gn | 0)) & (0 - or | 0)) - 1 | 0) >>> (wr = 16 & yr >>> 12)) >>> 5) | wr | (Qr = 4 & ($r = Tr >>> jr) >>> 2) | (li = 2 & (ii = $r >>> Qr) >>> 1) | (Mi = 1 & (yi = ii >>> li) >>> 1)) + (yi >>> Mi) | 0) << 1 << 2) | 0) | 0) >> 2], 
                                            (0 | Gi) == (0 | (fo = 0 | o[(so = to + 8 | 0) >> 2])) ? (Lo = la & (-1 ^ 1 << Ui), 
                                            o[1021] = Lo, ts = Lo) : (o[(fo + 12 | 0) >> 2] = Gi, o[Ji >> 2] = fo, ts = la), 
                                            Go = (Ui << 3) - Pi | 0, Zo = 3 | Pi, o[(to + 4 | 0) >> 2] = Zo, fa = 1 | Go, o[(4 + (sa = to + Pi | 0) | 0) >> 2] = fa, 
                                            o[(sa + Go | 0) >> 2] = Go, 0 == (0 | kn) || (Aa = 0 | o[1026], Da = 4124 + ((Pa = kn >>> 3) << 1 << 2) | 0, 
                                            0 == (0 | ts & ($a = 1 << Pa)) ? (ss = ts | $a, o[1021] = ss, C = Da, Lt = Da + 8 | 0) : (C = 0 | o[(fs = Da + 8 | 0) >> 2], 
                                            Lt = fs), o[Lt >> 2] = Aa, o[(C + 12 | 0) >> 2] = Aa, o[(Aa + 8 | 0) >> 2] = C, 
                                            o[(Aa + 12 | 0) >> 2] = Da), o[1023] = Go, o[1026] = sa, c = _, 0 | so;
                                            if (0 == (0 | (Ss = 0 | o[1022]))) O = Pi; else {
                                                if (Yt = 0 | o[(4388 + ((((Bt = 8 & (Dt = (Nt = (Ss & (0 - Ss | 0)) - 1 | 0) >>> (jt = 16 & Nt >>> 12)) >>> 5) | jt | (Ft = 4 & (Ut = Dt >>> Bt) >>> 2) | ($t = 2 & (Ht = Ut >>> Ft) >>> 1) | (zt = 1 & (Vt = Ht >>> $t) >>> 1)) + (Vt >>> zt) | 0) << 2) | 0) >> 2], 
                                                Gt = (-8 & (0 | o[(Yt + 4 | 0) >> 2])) - Pi | 0, Wt = 0 | o[(Yt + 16 | 0) >> 2], 
                                                0 == (0 | (Kt = 0 | o[((Yt + 16 | 0) + ((1 & 0 == (0 | Wt)) << 2) | 0) >> 2]))) P = Yt, 
                                                k = Gt; else for (M = Yt, E = Gt, Xt = Kt; ;) {
                                                    if (y = (Qt = (Jt = (-8 & (0 | o[(Xt + 4 | 0) >> 2])) - Pi | 0) >>> 0 < E >>> 0) ? Jt : E, 
                                                    m = Qt ? Xt : M, Zt = 0 | o[(Xt + 16 | 0) >> 2], 0 == (0 | (te = 0 | o[((Xt + 16 | 0) + ((1 & 0 == (0 | Zt)) << 2) | 0) >> 2]))) {
                                                        P = m, k = y;
                                                        break;
                                                    }
                                                    M = m, E = y, Xt = te;
                                                }
                                                if (P >>> 0 < (ee = P + Pi | 0) >>> 0) {
                                                    ne = 0 | o[(P + 24 | 0) >> 2], ie = (0 | (re = 0 | o[(P + 12 | 0) >> 2])) == (0 | P);
                                                    do {
                                                        if (ie) {
                                                            if (0 == (0 | (se = 0 | o[(ae = P + 20 | 0) >> 2]))) {
                                                                if (0 == (0 | (le = 0 | o[(ue = P + 16 | 0) >> 2]))) {
                                                                    ht = 0;
                                                                    break;
                                                                }
                                                                Z = le, tt = ue;
                                                            } else Z = se, tt = ae;
                                                            for (;;) if (0 == (0 | (de = 0 | o[(fe = Z + 20 | 0) >> 2]))) {
                                                                if (0 == (0 | (pe = 0 | o[(he = Z + 16 | 0) >> 2]))) break;
                                                                Z = pe, tt = he;
                                                            } else Z = de, tt = fe;
                                                            o[tt >> 2] = 0, ht = Z;
                                                        } else oe = 0 | o[(P + 8 | 0) >> 2], o[(oe + 12 | 0) >> 2] = re, o[(re + 8 | 0) >> 2] = oe, 
                                                        ht = re;
                                                    } while (0);
                                                    _e = 0 == (0 | ne);
                                                    do {
                                                        if (!_e) {
                                                            if (ye = 0 | o[(P + 28 | 0) >> 2], (0 | P) == (0 | o[(ge = 4388 + (ye << 2) | 0) >> 2])) {
                                                                if (o[ge >> 2] = ht, 0 == (0 | ht)) {
                                                                    ve = Ss & (-1 ^ 1 << ye), o[1022] = ve;
                                                                    break;
                                                                }
                                                            } else if (be = 0 | o[(ne + 16 | 0) >> 2], o[((ne + 16 | 0) + ((1 & (0 | be) != (0 | P)) << 2) | 0) >> 2] = ht, 
                                                            0 == (0 | ht)) break;
                                                            o[(ht + 24 | 0) >> 2] = ne, 0 == (0 | (xe = 0 | o[(P + 16 | 0) >> 2])) || (o[(ht + 16 | 0) >> 2] = xe, 
                                                            o[(xe + 24 | 0) >> 2] = ht), 0 == (0 | (Ae = 0 | o[(P + 20 | 0) >> 2])) || (o[(ht + 20 | 0) >> 2] = Ae, 
                                                            o[(Ae + 24 | 0) >> 2] = ht);
                                                        }
                                                    } while (0);
                                                    return k >>> 0 < 16 ? (Pe = 3 | (Te = k + Pi | 0), o[(P + 4 | 0) >> 2] = Pe, ke = 1 | o[(Me = 4 + (P + Te | 0) | 0) >> 2], 
                                                    o[Me >> 2] = ke) : (Oe = 3 | Pi, o[(P + 4 | 0) >> 2] = Oe, Ce = 1 | k, o[(ee + 4 | 0) >> 2] = Ce, 
                                                    o[(ee + k | 0) >> 2] = k, 0 == (0 | kn) || (Ie = 0 | o[1026], Le = 4124 + ((Re = kn >>> 3) << 1 << 2) | 0, 
                                                    0 == (0 | la & (Ne = 1 << Re)) ? (je = la | Ne, o[1021] = je, w = Le, Rt = Le + 8 | 0) : (w = 0 | o[(De = Le + 8 | 0) >> 2], 
                                                    Rt = De), o[Rt >> 2] = Ie, o[(w + 12 | 0) >> 2] = Ie, o[(Ie + 8 | 0) >> 2] = w, 
                                                    o[(Ie + 12 | 0) >> 2] = Le), o[1023] = k, o[1026] = ee), c = _, 0 | P + 8;
                                                }
                                                O = Pi;
                                            }
                                        } else O = Pi;
                                    } else if (t >>> 0 > 4294967231) O = -1; else if (Ue = -8 & (Be = t + 11 | 0), 0 == (0 | (Fe = 0 | o[1022]))) O = Ue; else {
                                        He = 0 - Ue | 0, W = 0 == (0 | ($e = Be >>> 8)) ? 0 : Ue >>> 0 > 16777215 ? 31 : 1 & Ue >>> (7 + (Xe = (14 - ((Ye = 4 & (520192 + (ze = $e << (Ve = 8 & ($e + 1048320 | 0) >>> 16)) | 0) >>> 16) | Ve | (Ke = 2 & (245760 + (Ge = ze << Ye) | 0) >>> 16)) | 0) + (Ge << Ke >>> 15) | 0) | 0) | Xe << 1, 
                                        Qe = 0 == (0 | (Je = 0 | o[(4388 + (W << 2) | 0) >> 2]));
                                        t: do {
                                            if (Qe) dt = 0, _t = 0, mt = He, Ts = 57; else for ($ = 0, Y = He, G = Je, X = Ue << (31 == (0 | W) ? 0 : 25 - (W >>> 1) | 0), 
                                            Q = 0; ;) {
                                                if ((Ze = (-8 & (0 | o[(G + 4 | 0) >> 2])) - Ue | 0) >>> 0 < Y >>> 0) {
                                                    if (0 == (0 | Ze)) {
                                                        bt = G, St = 0, Mt = G, Ts = 61;
                                                        break t;
                                                    }
                                                    it = G, ot = Ze;
                                                } else it = $, ot = Y;
                                                if (at = 0 == (0 | (tn = 0 | o[(G + 20 | 0) >> 2])) | (0 | tn) == (0 | (en = 0 | o[((G + 16 | 0) + (X >>> 31 << 2) | 0) >> 2])) ? Q : tn, 
                                                K = X << (1 & (1 ^ (rn = 0 == (0 | en)))), rn) {
                                                    dt = at, _t = it, mt = ot, Ts = 57;
                                                    break;
                                                }
                                                $ = it, Y = ot, G = en, X = K, Q = at;
                                            }
                                        } while (0);
                                        if (57 == (0 | Ts)) {
                                            if (0 == (0 | dt) & 0 == (0 | _t)) {
                                                if (0 == (0 | (an = Fe & ((on = 2 << W) | 0 - on | 0)))) {
                                                    O = Ue;
                                                    break;
                                                }
                                                vt = 0, Pt = 0 | o[(4388 + ((((ln = 8 & (cn = (sn = (an & (0 - an | 0)) - 1 | 0) >>> (un = 16 & sn >>> 12)) >>> 5) | un | (dn = 4 & (fn = cn >>> ln) >>> 2) | (pn = 2 & (hn = fn >>> dn) >>> 1) | (yn = 1 & (_n = hn >>> pn) >>> 1)) + (_n >>> yn) | 0) << 2) | 0) >> 2];
                                            } else vt = _t, Pt = dt;
                                            0 == (0 | Pt) ? (gt = vt, At = mt) : (bt = vt, St = mt, Mt = Pt, Ts = 61);
                                        }
                                        if (61 == (0 | Ts)) for (;;) {
                                            if (Ts = 0, g = (vn = (gn = (-8 & (0 | o[(Mt + 4 | 0) >> 2])) - Ue | 0) >>> 0 < St >>> 0) ? gn : St, 
                                            Tt = vn ? Mt : bt, bn = 0 | o[(Mt + 16 | 0) >> 2], 0 == (0 | (wn = 0 | o[((Mt + 16 | 0) + ((1 & 0 == (0 | bn)) << 2) | 0) >> 2]))) {
                                                gt = Tt, At = g;
                                                break;
                                            }
                                            bt = Tt, St = g, Mt = wn, Ts = 61;
                                        }
                                        if (0 == (0 | gt)) O = Ue; else {
                                            if (At >>> 0 < ((0 | o[1023]) - Ue | 0) >>> 0) {
                                                if (!(gt >>> 0 < (An = gt + Ue | 0) >>> 0)) return c = _, 0;
                                                Sn = 0 | o[(gt + 24 | 0) >> 2], Pn = (0 | (Tn = 0 | o[(gt + 12 | 0) >> 2])) == (0 | gt);
                                                do {
                                                    if (Pn) {
                                                        if (0 == (0 | (On = 0 | o[(En = gt + 20 | 0) >> 2]))) {
                                                            if (0 == (0 | (In = 0 | o[(Cn = gt + 16 | 0) >> 2]))) {
                                                                yt = 0;
                                                                break;
                                                            }
                                                            st = In, ut = Cn;
                                                        } else st = On, ut = En;
                                                        for (;;) if (0 == (0 | (Ln = 0 | o[(Rn = st + 20 | 0) >> 2]))) {
                                                            if (0 == (0 | (jn = 0 | o[(Nn = st + 16 | 0) >> 2]))) break;
                                                            st = jn, ut = Nn;
                                                        } else st = Ln, ut = Rn;
                                                        o[ut >> 2] = 0, yt = st;
                                                    } else Mn = 0 | o[(gt + 8 | 0) >> 2], o[(Mn + 12 | 0) >> 2] = Tn, o[(Tn + 8 | 0) >> 2] = Mn, 
                                                    yt = Tn;
                                                } while (0);
                                                Dn = 0 == (0 | Sn);
                                                do {
                                                    if (Dn) _r = Fe; else {
                                                        if (Bn = 0 | o[(gt + 28 | 0) >> 2], (0 | gt) == (0 | o[(Un = 4388 + (Bn << 2) | 0) >> 2])) {
                                                            if (o[Un >> 2] = yt, 0 == (0 | yt)) {
                                                                Fn = Fe & (-1 ^ 1 << Bn), o[1022] = Fn, _r = Fn;
                                                                break;
                                                            }
                                                        } else if (Hn = 0 | o[(Sn + 16 | 0) >> 2], o[((Sn + 16 | 0) + ((1 & (0 | Hn) != (0 | gt)) << 2) | 0) >> 2] = yt, 
                                                        0 == (0 | yt)) {
                                                            _r = Fe;
                                                            break;
                                                        }
                                                        o[(yt + 24 | 0) >> 2] = Sn, 0 == (0 | ($n = 0 | o[(gt + 16 | 0) >> 2])) || (o[(yt + 16 | 0) >> 2] = $n, 
                                                        o[($n + 24 | 0) >> 2] = yt), 0 == (0 | (Vn = 0 | o[(gt + 20 | 0) >> 2])) || (o[(yt + 20 | 0) >> 2] = Vn, 
                                                        o[(Vn + 24 | 0) >> 2] = yt), _r = Fe;
                                                    }
                                                } while (0);
                                                zn = At >>> 0 < 16;
                                                do {
                                                    if (zn) Wn = 3 | (Yn = At + Ue | 0), o[(gt + 4 | 0) >> 2] = Wn, Xn = 1 | o[(Kn = 4 + (gt + Yn | 0) | 0) >> 2], 
                                                    o[Kn >> 2] = Xn; else {
                                                        if (Jn = 3 | Ue, o[(gt + 4 | 0) >> 2] = Jn, Qn = 1 | At, o[(An + 4 | 0) >> 2] = Qn, 
                                                        o[(An + At | 0) >> 2] = At, qn = At >>> 3, At >>> 0 < 256) {
                                                            Zn = 4124 + (qn << 1 << 2) | 0, 0 == (0 | (tr = 0 | o[1021]) & (er = 1 << qn)) ? (nr = tr | er, 
                                                            o[1021] = nr, q = Zn, It = Zn + 8 | 0) : (q = 0 | o[(rr = Zn + 8 | 0) >> 2], It = rr), 
                                                            o[It >> 2] = An, o[(q + 12 | 0) >> 2] = An, o[(An + 8 | 0) >> 2] = q, o[(An + 12 | 0) >> 2] = Zn;
                                                            break;
                                                        }
                                                        if (dr = 4388 + ((J = 0 == (0 | (ir = At >>> 8)) ? 0 : At >>> 0 > 16777215 ? 31 : 1 & At >>> (7 + (fr = (14 - ((ur = 4 & (520192 + (sr = ir << (ar = 8 & (ir + 1048320 | 0) >>> 16)) | 0) >>> 16) | ar | (lr = 2 & (245760 + (cr = sr << ur) | 0) >>> 16)) | 0) + (cr << lr >>> 15) | 0) | 0) | fr << 1) << 2) | 0, 
                                                        o[(An + 28 | 0) >> 2] = J, o[(4 + (hr = An + 16 | 0) | 0) >> 2] = 0, o[hr >> 2] = 0, 
                                                        0 == (0 | _r & (pr = 1 << J))) {
                                                            mr = _r | pr, o[1022] = mr, o[dr >> 2] = An, o[(An + 24 | 0) >> 2] = dr, o[(An + 12 | 0) >> 2] = An, 
                                                            o[(An + 8 | 0) >> 2] = An;
                                                            break;
                                                        }
                                                        for (V = At << (31 == (0 | J) ? 0 : 25 - (J >>> 1) | 0), z = 0 | o[dr >> 2]; ;) {
                                                            if ((0 | -8 & (0 | o[(z + 4 | 0) >> 2])) == (0 | At)) {
                                                                Ts = 97;
                                                                break;
                                                            }
                                                            if (vr = V << 1, 0 == (0 | (br = 0 | o[(gr = (z + 16 | 0) + (V >>> 31 << 2) | 0) >> 2]))) {
                                                                Ts = 96;
                                                                break;
                                                            }
                                                            V = vr, z = br;
                                                        }
                                                        if (96 == (0 | Ts)) {
                                                            o[gr >> 2] = An, o[(An + 24 | 0) >> 2] = z, o[(An + 12 | 0) >> 2] = An, o[(An + 8 | 0) >> 2] = An;
                                                            break;
                                                        }
                                                        if (97 == (0 | Ts)) {
                                                            Ar = 0 | o[(xr = z + 8 | 0) >> 2], o[(Ar + 12 | 0) >> 2] = An, o[xr >> 2] = An, 
                                                            o[(An + 8 | 0) >> 2] = Ar, o[(An + 12 | 0) >> 2] = z, o[(An + 24 | 0) >> 2] = 0;
                                                            break;
                                                        }
                                                    }
                                                } while (0);
                                                return c = _, 0 | gt + 8;
                                            }
                                            O = Ue;
                                        }
                                    }
                                } while (0);
                                if (!((r = 0 | o[1023]) >>> 0 < O >>> 0)) return Sr = r - O | 0, Pr = 0 | o[1026], 
                                Sr >>> 0 > 15 ? (Mr = Pr + O | 0, o[1026] = Mr, o[1023] = Sr, kr = 1 | Sr, o[(Mr + 4 | 0) >> 2] = kr, 
                                o[(Mr + Sr | 0) >> 2] = Sr, Er = 3 | O, o[(Pr + 4 | 0) >> 2] = Er) : (o[1023] = 0, 
                                o[1026] = 0, Or = 3 | r, o[(Pr + 4 | 0) >> 2] = Or, Ir = 1 | o[(Cr = 4 + (Pr + r | 0) | 0) >> 2], 
                                o[Cr >> 2] = Ir), c = _, 0 | Pr + 8;
                                if ((i = 0 | o[1024]) >>> 0 > O >>> 0) return Rr = i - O | 0, o[1024] = Rr, Nr = (Lr = 0 | o[1027]) + O | 0, 
                                o[1027] = Nr, Dr = 1 | Rr, o[(Nr + 4 | 0) >> 2] = Dr, Br = 3 | O, o[(Lr + 4 | 0) >> 2] = Br, 
                                c = _, 0 | Lr + 8;
                                if (0 == (0 | o[1139]) ? (o[1141] = 4096, o[1140] = 4096, o[1142] = -1, o[1143] = -1, 
                                o[1144] = 0, o[1132] = 0, Ur = 1431655768 ^ -16 & e, o[e >> 2] = Ur, o[1139] = Ur, 
                                Fr = 4096) : Fr = 0 | o[1141], a = O + 48 | 0, !((d = (u = Fr + (s = O + 47 | 0) | 0) & (f = 0 - Fr | 0)) >>> 0 > O >>> 0)) return c = _, 
                                0;
                                if (0 != (0 | (h = 0 | o[1131])) && (Vr = (Hr = 0 | o[1129]) + d | 0) >>> 0 <= Hr >>> 0 | Vr >>> 0 > h >>> 0) return c = _, 
                                0;
                                p = 0 == (0 | 4 & (0 | o[1132]));
                                t: do {
                                    if (p) {
                                        Yr = 0 == (0 | (zr = 0 | o[1027]));
                                        e: do {
                                            if (Yr) Ts = 118; else {
                                                for (S = 4532; (Gr = 0 | o[S >> 2]) >>> 0 > zr >>> 0 || !((Gr + (0 | o[(Wr = S + 4 | 0) >> 2]) | 0) >>> 0 > zr >>> 0); ) {
                                                    if (0 == (0 | (Kr = 0 | o[(S + 8 | 0) >> 2]))) {
                                                        Ts = 118;
                                                        break e;
                                                    }
                                                    S = Kr;
                                                }
                                                if ((oi = (u - i | 0) & f) >>> 0 < 2147483647) if ((0 | (ai = 0 | xt(0 | oi))) == (0 | (0 | o[S >> 2]) + (0 | o[Wr >> 2]))) {
                                                    if (-1 != (0 | ai)) {
                                                        kt = oi, Et = ai, Ts = 135;
                                                        break t;
                                                    }
                                                    ct = oi;
                                                } else lt = ai, ft = oi, Ts = 126; else ct = 0;
                                            }
                                        } while (0);
                                        do {
                                            if (118 == (0 | Ts)) if (-1 == (0 | (Xr = 0 | xt(0)))) ct = 0; else if (Jr = Xr, 
                                            ei = (b = (0 == (0 | (Zr = (qr = 0 | o[1140]) - 1 | 0) & Jr) ? 0 : ((Zr + Jr | 0) & (0 - qr | 0)) - Jr | 0) + d | 0) + (ti = 0 | o[1129]) | 0, 
                                            b >>> 0 > O >>> 0 & b >>> 0 < 2147483647) {
                                                if (0 != (0 | (ni = 0 | o[1131])) && ei >>> 0 <= ti >>> 0 | ei >>> 0 > ni >>> 0) {
                                                    ct = 0;
                                                    break;
                                                }
                                                if ((0 | (ri = 0 | xt(0 | b))) == (0 | Xr)) {
                                                    kt = b, Et = Xr, Ts = 135;
                                                    break t;
                                                }
                                                lt = ri, ft = b, Ts = 126;
                                            } else ct = 0;
                                        } while (0);
                                        do {
                                            if (126 == (0 | Ts)) {
                                                if (si = 0 - ft | 0, !(a >>> 0 > ft >>> 0 & ft >>> 0 < 2147483647 & -1 != (0 | lt))) {
                                                    if (-1 == (0 | lt)) {
                                                        ct = 0;
                                                        break;
                                                    }
                                                    kt = ft, Et = lt, Ts = 135;
                                                    break t;
                                                }
                                                if (!((ci = ((s - ft | 0) + (ui = 0 | o[1141]) | 0) & (0 - ui | 0)) >>> 0 < 2147483647)) {
                                                    kt = ft, Et = lt, Ts = 135;
                                                    break t;
                                                }
                                                if (-1 == (0 | xt(0 | ci))) {
                                                    xt(0 | si), ct = 0;
                                                    break;
                                                }
                                                kt = ci + ft | 0, Et = lt, Ts = 135;
                                                break t;
                                            }
                                        } while (0);
                                        fi = 4 | o[1132], o[1132] = fi, wt = ct, Ts = 133;
                                    } else wt = 0, Ts = 133;
                                } while (0);
                                if (133 == (0 | Ts) && d >>> 0 < 2147483647 && (-1 == (0 | (di = 0 | xt(0 | d))) | 1 ^ (_i = (pi = (hi = 0 | xt(0)) - di | 0) >>> 0 > (O + 40 | 0) >>> 0) | 1 ^ di >>> 0 < hi >>> 0 & -1 != (0 | di) & -1 != (0 | hi) || (kt = _i ? pi : wt, 
                                Et = di, Ts = 135)), 135 == (0 | Ts)) {
                                    mi = (0 | o[1129]) + kt | 0, o[1129] = mi, mi >>> 0 > (0 | o[1130]) >>> 0 && (o[1130] = mi), 
                                    vi = 0 == (0 | (gi = 0 | o[1027]));
                                    do {
                                        if (vi) {
                                            for (0 == (0 | (bi = 0 | o[1025])) | Et >>> 0 < bi >>> 0 && (o[1025] = Et), o[1133] = Et, 
                                            o[1134] = kt, o[1136] = 0, wi = 0 | o[1139], o[1030] = wi, o[1029] = -1, T = 0; o[(12 + (xi = 4124 + (T << 1 << 2) | 0) | 0) >> 2] = xi, 
                                            o[(xi + 8 | 0) >> 2] = xi, 32 != (0 | (Ai = T + 1 | 0)); ) T = Ai;
                                            ki = Et + (Ti = 0 == (0 | 7 & (Si = Et + 8 | 0)) ? 0 : 7 & (0 - Si | 0)) | 0, Ei = (kt + -40 | 0) - Ti | 0, 
                                            o[1027] = ki, o[1024] = Ei, Oi = 1 | Ei, o[(ki + 4 | 0) >> 2] = Oi, o[(4 + (ki + Ei | 0) | 0) >> 2] = 40, 
                                            Ci = 0 | o[1143], o[1028] = Ci;
                                        } else {
                                            for (j = 4532; ;) {
                                                if ((0 | Et) == (0 | (Ii = 0 | o[j >> 2]) + (Li = 0 | o[(Ri = j + 4 | 0) >> 2]))) {
                                                    Ts = 145;
                                                    break;
                                                }
                                                if (0 == (0 | (Ni = 0 | o[(j + 8 | 0) >> 2]))) break;
                                                j = Ni;
                                            }
                                            if (145 == (0 | Ts) && 0 == (0 | 8 & (0 | o[(j + 12 | 0) >> 2])) && gi >>> 0 < Et >>> 0 & gi >>> 0 >= Ii >>> 0) {
                                                ji = Li + kt | 0, o[Ri >> 2] = ji, Fi = gi + (Bi = 0 == (0 | 7 & (Di = gi + 8 | 0)) ? 0 : 7 & (0 - Di | 0)) | 0, 
                                                Hi = (0 | o[1024]) + (kt - Bi | 0) | 0, o[1027] = Fi, o[1024] = Hi, $i = 1 | Hi, 
                                                o[(Fi + 4 | 0) >> 2] = $i, o[(4 + (Fi + Hi | 0) | 0) >> 2] = 40, Vi = 0 | o[1143], 
                                                o[1028] = Vi;
                                                break;
                                            }
                                            for (Et >>> 0 < (0 | o[1025]) >>> 0 && (o[1025] = Et), zi = Et + kt | 0, et = 4532; ;) {
                                                if ((0 | o[et >> 2]) == (0 | zi)) {
                                                    Ts = 153;
                                                    break;
                                                }
                                                if (0 == (0 | (Yi = 0 | o[(et + 8 | 0) >> 2]))) break;
                                                et = Yi;
                                            }
                                            if (153 == (0 | Ts) && 0 == (0 | 8 & (0 | o[(et + 12 | 0) >> 2]))) {
                                                o[et >> 2] = Et, Ki = (0 | o[(Wi = et + 4 | 0) >> 2]) + kt | 0, o[Wi >> 2] = Ki, 
                                                eo = (Qi = Et + (0 == (0 | 7 & (Xi = Et + 8 | 0)) ? 0 : 7 & (0 - Xi | 0)) | 0) + O | 0, 
                                                no = ((Zi = zi + (0 == (0 | 7 & (qi = zi + 8 | 0)) ? 0 : 7 & (0 - qi | 0)) | 0) - Qi | 0) - O | 0, 
                                                ro = 3 | O, o[(Qi + 4 | 0) >> 2] = ro, io = (0 | Zi) == (0 | gi);
                                                do {
                                                    if (io) oo = (0 | o[1024]) + no | 0, o[1024] = oo, o[1027] = eo, ao = 1 | oo, o[(eo + 4 | 0) >> 2] = ao; else {
                                                        if ((0 | Zi) == (0 | o[1026])) {
                                                            uo = (0 | o[1023]) + no | 0, o[1023] = uo, o[1026] = eo, co = 1 | uo, o[(eo + 4 | 0) >> 2] = co, 
                                                            o[(eo + uo | 0) >> 2] = uo;
                                                            break;
                                                        }
                                                        if (1 == (0 | 3 & (lo = 0 | o[(Zi + 4 | 0) >> 2]))) {
                                                            ho = -8 & lo, po = lo >>> 3, _o = lo >>> 0 < 256;
                                                            t: do {
                                                                if (_o) {
                                                                    if (mo = 0 | o[(Zi + 8 | 0) >> 2], (0 | (yo = 0 | o[(Zi + 12 | 0) >> 2])) == (0 | mo)) {
                                                                        vo = -1 ^ 1 << po, bo = (0 | o[1021]) & vo, o[1021] = bo;
                                                                        break;
                                                                    }
                                                                    o[(mo + 12 | 0) >> 2] = yo, o[(yo + 8 | 0) >> 2] = mo;
                                                                    break;
                                                                }
                                                                wo = 0 | o[(Zi + 24 | 0) >> 2], Ao = (0 | (xo = 0 | o[(Zi + 12 | 0) >> 2])) == (0 | Zi);
                                                                do {
                                                                    if (Ao) {
                                                                        if (0 == (0 | (Mo = 0 | o[(Po = 4 + (To = Zi + 16 | 0) | 0) >> 2]))) {
                                                                            if (0 == (0 | (ko = 0 | o[To >> 2]))) {
                                                                                pt = 0;
                                                                                break;
                                                                            }
                                                                            nt = ko, rt = To;
                                                                        } else nt = Mo, rt = Po;
                                                                        for (;;) if (0 == (0 | (Oo = 0 | o[(Eo = nt + 20 | 0) >> 2]))) {
                                                                            if (0 == (0 | (Io = 0 | o[(Co = nt + 16 | 0) >> 2]))) break;
                                                                            nt = Io, rt = Co;
                                                                        } else nt = Oo, rt = Eo;
                                                                        o[rt >> 2] = 0, pt = nt;
                                                                    } else So = 0 | o[(Zi + 8 | 0) >> 2], o[(So + 12 | 0) >> 2] = xo, o[(xo + 8 | 0) >> 2] = So, 
                                                                    pt = xo;
                                                                } while (0);
                                                                if (0 == (0 | wo)) break;
                                                                Ro = 0 | o[(Zi + 28 | 0) >> 2], jo = (0 | Zi) == (0 | o[(No = 4388 + (Ro << 2) | 0) >> 2]);
                                                                do {
                                                                    if (jo) {
                                                                        if (o[No >> 2] = pt, 0 != (0 | pt)) break;
                                                                        Do = -1 ^ 1 << Ro, Bo = (0 | o[1022]) & Do, o[1022] = Bo;
                                                                        break t;
                                                                    }
                                                                    if (Uo = 0 | o[(wo + 16 | 0) >> 2], o[((wo + 16 | 0) + ((1 & (0 | Uo) != (0 | Zi)) << 2) | 0) >> 2] = pt, 
                                                                    0 == (0 | pt)) break t;
                                                                } while (0);
                                                                if (o[(pt + 24 | 0) >> 2] = wo, 0 == (0 | (Ho = 0 | o[(Fo = Zi + 16 | 0) >> 2])) || (o[(pt + 16 | 0) >> 2] = Ho, 
                                                                o[(Ho + 24 | 0) >> 2] = pt), 0 == (0 | ($o = 0 | o[(Fo + 4 | 0) >> 2]))) break;
                                                                o[(pt + 20 | 0) >> 2] = $o, o[($o + 24 | 0) >> 2] = pt;
                                                            } while (0);
                                                            x = Zi + ho | 0, D = ho + no | 0;
                                                        } else x = Zi, D = no;
                                                        if (zo = -2 & (0 | o[(Vo = x + 4 | 0) >> 2]), o[Vo >> 2] = zo, Yo = 1 | D, o[(eo + 4 | 0) >> 2] = Yo, 
                                                        o[(eo + D | 0) >> 2] = D, Wo = D >>> 3, D >>> 0 < 256) {
                                                            Ko = 4124 + (Wo << 1 << 2) | 0, 0 == (0 | (Xo = 0 | o[1021]) & (Jo = 1 << Wo)) ? (Qo = Xo | Jo, 
                                                            o[1021] = Qo, F = Ko, Ct = Ko + 8 | 0) : (F = 0 | o[(qo = Ko + 8 | 0) >> 2], Ct = qo), 
                                                            o[Ct >> 2] = eo, o[(F + 12 | 0) >> 2] = eo, o[(eo + 8 | 0) >> 2] = F, o[(eo + 12 | 0) >> 2] = Ko;
                                                            break;
                                                        }
                                                        ea = 0 == (0 | (ta = D >>> 8));
                                                        do {
                                                            if (ea) H = 0; else {
                                                                if (D >>> 0 > 16777215) {
                                                                    H = 31;
                                                                    break;
                                                                }
                                                                H = 1 & D >>> (7 + (ua = (14 - ((ia = 4 & (520192 + (ra = ta << (na = 8 & (ta + 1048320 | 0) >>> 16)) | 0) >>> 16) | na | (aa = 2 & (245760 + (oa = ra << ia) | 0) >>> 16)) | 0) + (oa << aa >>> 15) | 0) | 0) | ua << 1;
                                                            }
                                                        } while (0);
                                                        if (ca = 4388 + (H << 2) | 0, o[(eo + 28 | 0) >> 2] = H, o[(4 + (da = eo + 16 | 0) | 0) >> 2] = 0, 
                                                        o[da >> 2] = 0, 0 == (0 | (ha = 0 | o[1022]) & (pa = 1 << H))) {
                                                            _a = ha | pa, o[1022] = _a, o[ca >> 2] = eo, o[(eo + 24 | 0) >> 2] = ca, o[(eo + 12 | 0) >> 2] = eo, 
                                                            o[(eo + 8 | 0) >> 2] = eo;
                                                            break;
                                                        }
                                                        for (B = D << (31 == (0 | H) ? 0 : 25 - (H >>> 1) | 0), U = 0 | o[ca >> 2]; ;) {
                                                            if ((0 | -8 & (0 | o[(U + 4 | 0) >> 2])) == (0 | D)) {
                                                                Ts = 194;
                                                                break;
                                                            }
                                                            if (ya = B << 1, 0 == (0 | (ga = 0 | o[(ma = (U + 16 | 0) + (B >>> 31 << 2) | 0) >> 2]))) {
                                                                Ts = 193;
                                                                break;
                                                            }
                                                            B = ya, U = ga;
                                                        }
                                                        if (193 == (0 | Ts)) {
                                                            o[ma >> 2] = eo, o[(eo + 24 | 0) >> 2] = U, o[(eo + 12 | 0) >> 2] = eo, o[(eo + 8 | 0) >> 2] = eo;
                                                            break;
                                                        }
                                                        if (194 == (0 | Ts)) {
                                                            ba = 0 | o[(va = U + 8 | 0) >> 2], o[(ba + 12 | 0) >> 2] = eo, o[va >> 2] = eo, 
                                                            o[(eo + 8 | 0) >> 2] = ba, o[(eo + 12 | 0) >> 2] = U, o[(eo + 24 | 0) >> 2] = 0;
                                                            break;
                                                        }
                                                    }
                                                } while (0);
                                                return c = _, 0 | Qi + 8;
                                            }
                                            for (A = 4532; (wa = 0 | o[A >> 2]) >>> 0 > gi >>> 0 || !((xa = wa + (0 | o[(A + 4 | 0) >> 2]) | 0) >>> 0 > gi >>> 0); ) A = 0 | o[(A + 8 | 0) >> 2];
                                            for (Oa = (Ea = (Ma = (Sa = xa + -47 | 0) + (0 == (0 | 7 & (Ta = Sa + 8 | 0)) ? 0 : 7 & (0 - Ta | 0)) | 0) >>> 0 < (ka = gi + 16 | 0) >>> 0 ? gi : Ma) + 8 | 0, 
                                            Ca = Ea + 24 | 0, La = Et + (Ra = 0 == (0 | 7 & (Ia = Et + 8 | 0)) ? 0 : 7 & (0 - Ia | 0)) | 0, 
                                            Na = (kt + -40 | 0) - Ra | 0, o[1027] = La, o[1024] = Na, ja = 1 | Na, o[(La + 4 | 0) >> 2] = ja, 
                                            o[(4 + (La + Na | 0) | 0) >> 2] = 40, Ba = 0 | o[1143], o[1028] = Ba, o[(Ua = Ea + 4 | 0) >> 2] = 27, 
                                            o[Oa >> 2] = 0 | o[1133], o[Oa + 4 >> 2] = 0 | o[1134], o[Oa + 8 >> 2] = 0 | o[1135], 
                                            o[Oa + 12 >> 2] = 0 | o[1136], o[1133] = Et, o[1134] = kt, o[1136] = 0, o[1135] = Oa, 
                                            Ha = Ca; o[(Fa = Ha + 4 | 0) >> 2] = 7, (Ha + 8 | 0) >>> 0 < xa >>> 0; ) Ha = Fa;
                                            if ((0 | Ea) != (0 | gi)) {
                                                if (Va = Ea - gi | 0, za = -2 & (0 | o[Ua >> 2]), o[Ua >> 2] = za, Ya = 1 | Va, 
                                                o[(gi + 4 | 0) >> 2] = Ya, o[Ea >> 2] = Va, Ga = Va >>> 3, Va >>> 0 < 256) {
                                                    Wa = 4124 + (Ga << 1 << 2) | 0, 0 == (0 | (Ka = 0 | o[1021]) & (Xa = 1 << Ga)) ? (Ja = Ka | Xa, 
                                                    o[1021] = Ja, L = Wa, Ot = Wa + 8 | 0) : (L = 0 | o[(Qa = Wa + 8 | 0) >> 2], Ot = Qa), 
                                                    o[Ot >> 2] = gi, o[(L + 12 | 0) >> 2] = gi, o[(gi + 8 | 0) >> 2] = L, o[(gi + 12 | 0) >> 2] = Wa;
                                                    break;
                                                }
                                                if (us = 4388 + ((N = 0 == (0 | (qa = Va >>> 8)) ? 0 : Va >>> 0 > 16777215 ? 31 : 1 & Va >>> (7 + (as = (14 - ((rs = 4 & (520192 + (ns = qa << (es = 8 & (qa + 1048320 | 0) >>> 16)) | 0) >>> 16) | es | (os = 2 & (245760 + (is = ns << rs) | 0) >>> 16)) | 0) + (is << os >>> 15) | 0) | 0) | as << 1) << 2) | 0, 
                                                o[(gi + 28 | 0) >> 2] = N, o[(gi + 20 | 0) >> 2] = 0, o[ka >> 2] = 0, 0 == (0 | (cs = 0 | o[1022]) & (ls = 1 << N))) {
                                                    ds = cs | ls, o[1022] = ds, o[us >> 2] = gi, o[(gi + 24 | 0) >> 2] = us, o[(gi + 12 | 0) >> 2] = gi, 
                                                    o[(gi + 8 | 0) >> 2] = gi;
                                                    break;
                                                }
                                                for (I = Va << (31 == (0 | N) ? 0 : 25 - (N >>> 1) | 0), R = 0 | o[us >> 2]; ;) {
                                                    if ((0 | -8 & (0 | o[(R + 4 | 0) >> 2])) == (0 | Va)) {
                                                        Ts = 216;
                                                        break;
                                                    }
                                                    if (ps = I << 1, 0 == (0 | (_s = 0 | o[(hs = (R + 16 | 0) + (I >>> 31 << 2) | 0) >> 2]))) {
                                                        Ts = 215;
                                                        break;
                                                    }
                                                    I = ps, R = _s;
                                                }
                                                if (215 == (0 | Ts)) {
                                                    o[hs >> 2] = gi, o[(gi + 24 | 0) >> 2] = R, o[(gi + 12 | 0) >> 2] = gi, o[(gi + 8 | 0) >> 2] = gi;
                                                    break;
                                                }
                                                if (216 == (0 | Ts)) {
                                                    ys = 0 | o[(ms = R + 8 | 0) >> 2], o[(ys + 12 | 0) >> 2] = gi, o[ms >> 2] = gi, 
                                                    o[(gi + 8 | 0) >> 2] = ys, o[(gi + 12 | 0) >> 2] = R, o[(gi + 24 | 0) >> 2] = 0;
                                                    break;
                                                }
                                            }
                                        }
                                    } while (0);
                                    if ((gs = 0 | o[1024]) >>> 0 > O >>> 0) return vs = gs - O | 0, o[1024] = vs, ws = (bs = 0 | o[1027]) + O | 0, 
                                    o[1027] = ws, xs = 1 | vs, o[(ws + 4 | 0) >> 2] = xs, As = 3 | O, o[(bs + 4 | 0) >> 2] = As, 
                                    c = _, 0 | bs + 8;
                                }
                                return o[72 >> 2] = 12, c = _, 0;
                            }
                            function Y(t) {
                                var e, n, r, i, a, s, u, c, l, f, d, h, p, _, m, y, g = 0, v = 0, b = 0, w = 0, x = 0, A = 0, S = 0, T = 0, P = 0, M = 0, k = 0, E = 0, O = 0, C = 0, I = 0, R = 0, L = 0, N = 0, j = 0, D = 0, B = 0, U = 0, F = 0, H = 0, $ = 0, V = 0, z = 0, Y = 0, G = 0, W = 0, K = 0, X = 0, J = 0, Q = 0, q = 0, Z = 0, tt = 0, et = 0, nt = 0, rt = 0, it = 0, ot = 0, at = 0, st = 0, ut = 0, ct = 0, lt = 0, ft = 0, dt = 0, ht = 0, pt = 0, _t = 0, mt = 0, yt = 0, gt = 0, vt = 0, bt = 0, wt = 0, xt = 0, At = 0, St = 0, Tt = 0, Pt = 0, Mt = 0, kt = 0, Et = 0, Ot = 0, Ct = 0, It = 0, Rt = 0, Lt = 0, Nt = 0, jt = 0, Dt = 0, Bt = 0, Ut = 0, Ft = 0, Ht = 0, $t = 0, Vt = 0, zt = 0, Yt = 0, Gt = 0, Wt = 0, Kt = 0, Xt = 0, Jt = 0, Qt = 0, qt = 0, Zt = 0, te = 0, ee = 0, ne = 0, re = 0, ie = 0, oe = 0, ae = 0, se = 0, ue = 0, ce = 0, le = 0, fe = 0, de = 0, he = 0, pe = 0, _e = 0;
                                if (0 != (0 | (t |= 0))) {
                                    r = t + -8 | 0, f = 0 | o[1025], p = r + (h = -8 & (d = 0 | o[(t + -4 | 0) >> 2])) | 0, 
                                    y = 0 == (0 | 1 & d);
                                    do {
                                        if (y) {
                                            if (L = 0 | o[r >> 2], 0 == (0 | 3 & d)) return;
                                            if (ot = L + h | 0, (tt = r + (0 - L | 0) | 0) >>> 0 < f >>> 0) return;
                                            if ((0 | tt) == (0 | o[1026])) {
                                                if (3 != (0 | 3 & (oe = 0 | o[(ie = p + 4 | 0) >> 2]))) {
                                                    S = tt, T = ot, le = tt;
                                                    break;
                                                }
                                                return ae = tt + ot | 0, se = tt + 4 | 0, ue = 1 | ot, ce = -2 & oe, o[1023] = ot, 
                                                o[ie >> 2] = ce, o[se >> 2] = ue, void (o[ae >> 2] = ot);
                                            }
                                            if (bt = L >>> 3, L >>> 0 < 256) {
                                                if (Mt = 0 | o[(tt + 8 | 0) >> 2], (0 | (Et = 0 | o[(tt + 12 | 0) >> 2])) == (0 | Mt)) {
                                                    jt = -1 ^ 1 << bt, Dt = (0 | o[1021]) & jt, o[1021] = Dt, S = tt, T = ot, le = tt;
                                                    break;
                                                }
                                                o[(Mt + 12 | 0) >> 2] = Et, o[(Et + 8 | 0) >> 2] = Mt, S = tt, T = ot, le = tt;
                                                break;
                                            }
                                            Bt = 0 | o[(tt + 24 | 0) >> 2], Ft = (0 | (Ut = 0 | o[(tt + 12 | 0) >> 2])) == (0 | tt);
                                            do {
                                                if (Ft) {
                                                    if (0 == (0 | (zt = 0 | o[(Vt = 4 + ($t = tt + 16 | 0) | 0) >> 2]))) {
                                                        if (0 == (0 | (Yt = 0 | o[$t >> 2]))) {
                                                            C = 0;
                                                            break;
                                                        }
                                                        P = Yt, M = $t;
                                                    } else P = zt, M = Vt;
                                                    for (;;) if (0 == (0 | (Wt = 0 | o[(Gt = P + 20 | 0) >> 2]))) {
                                                        if (0 == (0 | (Xt = 0 | o[(Kt = P + 16 | 0) >> 2]))) break;
                                                        P = Xt, M = Kt;
                                                    } else P = Wt, M = Gt;
                                                    o[M >> 2] = 0, C = P;
                                                } else Ht = 0 | o[(tt + 8 | 0) >> 2], o[(Ht + 12 | 0) >> 2] = Ut, o[(Ut + 8 | 0) >> 2] = Ht, 
                                                C = Ut;
                                            } while (0);
                                            if (0 == (0 | Bt)) S = tt, T = ot, le = tt; else {
                                                if (Jt = 0 | o[(tt + 28 | 0) >> 2], (0 | tt) == (0 | o[(Qt = 4388 + (Jt << 2) | 0) >> 2])) {
                                                    if (o[Qt >> 2] = C, 0 == (0 | C)) {
                                                        qt = -1 ^ 1 << Jt, Zt = (0 | o[1022]) & qt, o[1022] = Zt, S = tt, T = ot, le = tt;
                                                        break;
                                                    }
                                                } else if (te = 0 | o[(Bt + 16 | 0) >> 2], o[((Bt + 16 | 0) + ((1 & (0 | te) != (0 | tt)) << 2) | 0) >> 2] = C, 
                                                0 == (0 | C)) {
                                                    S = tt, T = ot, le = tt;
                                                    break;
                                                }
                                                o[(C + 24 | 0) >> 2] = Bt, 0 == (0 | (ne = 0 | o[(ee = tt + 16 | 0) >> 2])) || (o[(C + 16 | 0) >> 2] = ne, 
                                                o[(ne + 24 | 0) >> 2] = C), 0 == (0 | (re = 0 | o[(ee + 4 | 0) >> 2])) ? (S = tt, 
                                                T = ot, le = tt) : (o[(C + 20 | 0) >> 2] = re, o[(re + 24 | 0) >> 2] = C, S = tt, 
                                                T = ot, le = tt);
                                            }
                                        } else S = r, T = h, le = r;
                                    } while (0);
                                    if (le >>> 0 < p >>> 0 && 0 != (0 | 1 & (m = 0 | o[(_ = p + 4 | 0) >> 2]))) {
                                        if (0 == (0 | 2 & m)) {
                                            if (fe = (0 | p) == (0 | o[1027]), de = 0 | o[1026], fe) {
                                                if (he = (0 | o[1024]) + T | 0, o[1024] = he, o[1027] = S, pe = 1 | he, o[(S + 4 | 0) >> 2] = pe, 
                                                (0 | S) != (0 | de)) return;
                                                return o[1026] = 0, void (o[1023] = 0);
                                            }
                                            if ((0 | p) == (0 | de)) return N = (0 | o[1023]) + T | 0, o[1023] = N, o[1026] = le, 
                                            j = 1 | N, o[(S + 4 | 0) >> 2] = j, void (o[(le + N | 0) >> 2] = N);
                                            D = (-8 & m) + T | 0, B = m >>> 3, U = m >>> 0 < 256;
                                            do {
                                                if (U) {
                                                    if (F = 0 | o[(p + 8 | 0) >> 2], (0 | (H = 0 | o[(p + 12 | 0) >> 2])) == (0 | F)) {
                                                        $ = -1 ^ 1 << B, V = (0 | o[1021]) & $, o[1021] = V;
                                                        break;
                                                    }
                                                    o[(F + 12 | 0) >> 2] = H, o[(H + 8 | 0) >> 2] = F;
                                                    break;
                                                }
                                                z = 0 | o[(p + 24 | 0) >> 2], G = (0 | (Y = 0 | o[(p + 12 | 0) >> 2])) == (0 | p);
                                                do {
                                                    if (G) {
                                                        if (0 == (0 | (J = 0 | o[(X = 4 + (K = p + 16 | 0) | 0) >> 2]))) {
                                                            if (0 == (0 | (Q = 0 | o[K >> 2]))) {
                                                                I = 0;
                                                                break;
                                                            }
                                                            k = Q, E = K;
                                                        } else k = J, E = X;
                                                        for (;;) if (0 == (0 | (Z = 0 | o[(q = k + 20 | 0) >> 2]))) {
                                                            if (0 == (0 | (nt = 0 | o[(et = k + 16 | 0) >> 2]))) break;
                                                            k = nt, E = et;
                                                        } else k = Z, E = q;
                                                        o[E >> 2] = 0, I = k;
                                                    } else W = 0 | o[(p + 8 | 0) >> 2], o[(W + 12 | 0) >> 2] = Y, o[(Y + 8 | 0) >> 2] = W, 
                                                    I = Y;
                                                } while (0);
                                                if (0 != (0 | z)) {
                                                    if (rt = 0 | o[(p + 28 | 0) >> 2], (0 | p) == (0 | o[(it = 4388 + (rt << 2) | 0) >> 2])) {
                                                        if (o[it >> 2] = I, 0 == (0 | I)) {
                                                            at = -1 ^ 1 << rt, st = (0 | o[1022]) & at, o[1022] = st;
                                                            break;
                                                        }
                                                    } else if (ut = 0 | o[(z + 16 | 0) >> 2], o[((z + 16 | 0) + ((1 & (0 | ut) != (0 | p)) << 2) | 0) >> 2] = I, 
                                                    0 == (0 | I)) break;
                                                    o[(I + 24 | 0) >> 2] = z, 0 == (0 | (lt = 0 | o[(ct = p + 16 | 0) >> 2])) || (o[(I + 16 | 0) >> 2] = lt, 
                                                    o[(lt + 24 | 0) >> 2] = I), 0 == (0 | (ft = 0 | o[(ct + 4 | 0) >> 2])) || (o[(I + 20 | 0) >> 2] = ft, 
                                                    o[(ft + 24 | 0) >> 2] = I);
                                                }
                                            } while (0);
                                            if (dt = 1 | D, o[(S + 4 | 0) >> 2] = dt, o[(le + D | 0) >> 2] = D, (0 | S) == (0 | o[1026])) return void (o[1023] = D);
                                            O = D;
                                        } else ht = -2 & m, o[_ >> 2] = ht, pt = 1 | T, o[(S + 4 | 0) >> 2] = pt, o[(le + T | 0) >> 2] = T, 
                                        O = T;
                                        if (e = O >>> 3, O >>> 0 < 256) return _t = 4124 + (e << 1 << 2) | 0, 0 == (0 | (mt = 0 | o[1021]) & (yt = 1 << e)) ? (gt = mt | yt, 
                                        o[1021] = gt, A = _t, R = _t + 8 | 0) : (A = 0 | o[(vt = _t + 8 | 0) >> 2], R = vt), 
                                        o[R >> 2] = S, o[(A + 12 | 0) >> 2] = S, o[(S + 8 | 0) >> 2] = A, void (o[(S + 12 | 0) >> 2] = _t);
                                        i = 4388 + ((x = 0 == (0 | (n = O >>> 8)) ? 0 : O >>> 0 > 16777215 ? 31 : 1 & O >>> (7 + (Pt = (14 - ((At = 4 & (520192 + (xt = n << (wt = 8 & (n + 1048320 | 0) >>> 16)) | 0) >>> 16) | wt | (Tt = 2 & (245760 + (St = xt << At) | 0) >>> 16)) | 0) + (St << Tt >>> 15) | 0) | 0) | Pt << 1) << 2) | 0, 
                                        o[(S + 28 | 0) >> 2] = x, a = S + 16 | 0, o[(S + 20 | 0) >> 2] = 0, o[a >> 2] = 0, 
                                        c = 0 == (0 | (s = 0 | o[1022]) & (u = 1 << x));
                                        do {
                                            if (c) kt = s | u, o[1022] = kt, o[i >> 2] = S, o[(S + 24 | 0) >> 2] = i, o[(S + 12 | 0) >> 2] = S, 
                                            o[(S + 8 | 0) >> 2] = S; else {
                                                for (b = O << (31 == (0 | x) ? 0 : 25 - (x >>> 1) | 0), w = 0 | o[i >> 2]; ;) {
                                                    if ((0 | -8 & (0 | o[(w + 4 | 0) >> 2])) == (0 | O)) {
                                                        _e = 73;
                                                        break;
                                                    }
                                                    if (Ct = b << 1, 0 == (0 | (It = 0 | o[(Ot = (w + 16 | 0) + (b >>> 31 << 2) | 0) >> 2]))) {
                                                        _e = 72;
                                                        break;
                                                    }
                                                    b = Ct, w = It;
                                                }
                                                if (72 == (0 | _e)) {
                                                    o[Ot >> 2] = S, o[(S + 24 | 0) >> 2] = w, o[(S + 12 | 0) >> 2] = S, o[(S + 8 | 0) >> 2] = S;
                                                    break;
                                                }
                                                if (73 == (0 | _e)) {
                                                    Lt = 0 | o[(Rt = w + 8 | 0) >> 2], o[(Lt + 12 | 0) >> 2] = S, o[Rt >> 2] = S, o[(S + 8 | 0) >> 2] = Lt, 
                                                    o[(S + 12 | 0) >> 2] = w, o[(S + 24 | 0) >> 2] = 0;
                                                    break;
                                                }
                                            }
                                        } while (0);
                                        if (l = (0 | o[1029]) - 1 | 0, o[1029] = l, 0 == (0 | l)) {
                                            for (v = 4540; Nt = 8 + (g = 0 | o[v >> 2]) | 0, 0 != (0 | g); ) v = Nt;
                                            o[1029] = -1;
                                        }
                                    }
                                }
                            }
                            function G(t, e, n) {
                                t |= 0, e |= 0, n |= 0;
                                var r, i, a, s, u, f, d, h, p, _, m, y, g, b, w, x = 0, A = 0, S = 0, T = 0, P = 0, M = 0, k = 0, O = 0, C = 0, I = 0, R = 0, L = 0, N = 0, j = 0, D = 0, B = 0, U = 0, F = 0, H = 0, $ = 0, V = 0;
                                w = c, (0 | (c = c + 48 | 0)) >= (0 | l) && v(48), b = w + 16 | 0, g = w, d = w + 32 | 0, 
                                p = 0 | o[(h = t + 28 | 0) >> 2], o[d >> 2] = p, _ = d + 4 | 0, y = (0 | o[(m = t + 20 | 0) >> 2]) - p | 0, 
                                o[_ >> 2] = y, o[(d + 8 | 0) >> 2] = e, o[(d + 12 | 0) >> 2] = n, r = y + n | 0, 
                                a = 0 | o[(i = t + 60 | 0) >> 2], s = d, o[g >> 2] = a, o[(g + 4 | 0) >> 2] = s, 
                                o[(g + 8 | 0) >> 2] = 2, f = (0 | r) == (0 | (u = 0 | W(0 | E(146, 0 | g))));
                                t: do {
                                    if (f) V = 3; else {
                                        for (A = 2, S = r, T = d, I = u; !((0 | I) < 0); ) {
                                            if (L = S - I | 0, k = (j = I >>> 0 > (N = 0 | o[(T + 4 | 0) >> 2]) >>> 0) ? T + 8 | 0 : T, 
                                            M = (j << 31 >> 31) + A | 0, x = I - (j ? N : 0) | 0, D = (0 | o[k >> 2]) + x | 0, 
                                            o[k >> 2] = D, U = (0 | o[(B = k + 4 | 0) >> 2]) - x | 0, o[B >> 2] = U, F = 0 | o[i >> 2], 
                                            H = k, o[b >> 2] = F, o[(b + 4 | 0) >> 2] = H, o[(b + 8 | 0) >> 2] = M, (0 | L) == (0 | ($ = 0 | W(0 | E(146, 0 | b))))) {
                                                V = 3;
                                                break t;
                                            }
                                            A = M, S = L, T = k, I = $;
                                        }
                                        o[(t + 16 | 0) >> 2] = 0, o[h >> 2] = 0, o[m >> 2] = 0, R = 32 | o[t >> 2], o[t >> 2] = R, 
                                        P = 2 == (0 | A) ? 0 : n - (0 | o[(T + 4 | 0) >> 2]) | 0;
                                    }
                                } while (0);
                                return 3 == (0 | V) && (C = (O = 0 | o[(t + 44 | 0) >> 2]) + (0 | o[(t + 48 | 0) >> 2]) | 0, 
                                o[(t + 16 | 0) >> 2] = C, o[h >> 2] = O, o[m >> 2] = O, P = n), c = w, 0 | P;
                            }
                            function W(t) {
                                var e = 0, n = 0;
                                return (t |= 0) >>> 0 > 4294963200 ? (n = 0 - t | 0, o[72 >> 2] = n, e = -1) : e = t, 
                                0 | e;
                            }
                            function K() {
                                return 72;
                            }
                            function X(t) {
                                var e, n, i = 0, a = 0, s = 0, u = 0, c = 0, l = 0, f = 0, d = 0, h = 0, p = 0, _ = 0, m = 0, y = 0;
                                n = 0 == (0 | 3 & (e = t |= 0));
                                t: do {
                                    if (n) a = t, y = 4; else for (s = t, p = e; ;) {
                                        if ((0 | r[s >> 0]) << 24 >> 24 == 0) {
                                            l = p;
                                            break t;
                                        }
                                        if (0 == (0 | 3 & (m = _ = s + 1 | 0))) {
                                            a = _, y = 4;
                                            break;
                                        }
                                        s = _, p = m;
                                    }
                                } while (0);
                                if (4 == (0 | y)) {
                                    for (i = a; d = i + 4 | 0, 0 == (0 | (-2139062144 ^ -2139062144 & (f = 0 | o[i >> 2])) & (f + -16843009 | 0)); ) i = d;
                                    if ((255 & f) << 24 >> 24 == 0) u = i; else for (c = i; ;) {
                                        if ((0 | r[(h = c + 1 | 0) >> 0]) << 24 >> 24 == 0) {
                                            u = h;
                                            break;
                                        }
                                        c = h;
                                    }
                                    l = u;
                                }
                                return 0 | l - e;
                            }
                            function J(t) {
                                return 0 | function(t, e) {
                                    t |= 0, e |= 0;
                                    var n = 0, i = 0, a = 0, s = 0, u = 0, c = 0, l = 0, f = 0, d = 0;
                                    for (a = 0; ;) {
                                        if ((0 | 255 & (0 | r[(1644 + a | 0) >> 0])) == (0 | t)) {
                                            d = 2;
                                            break;
                                        }
                                        if (87 == (0 | (f = a + 1 | 0))) {
                                            i = 1732, u = 87, d = 5;
                                            break;
                                        }
                                        a = f;
                                    }
                                    if (2 == (0 | d) && (0 == (0 | a) ? n = 1732 : (i = 1732, u = a, d = 5)), 5 == (0 | d)) for (;;) {
                                        for (d = 0, s = i; c = s + 1 | 0, (0 | r[s >> 0]) << 24 >> 24 != 0; ) s = c;
                                        if (0 == (0 | (l = u + -1 | 0))) {
                                            n = c;
                                            break;
                                        }
                                        i = c, u = l, d = 5;
                                    }
                                    return 0 | function(t, e) {
                                        return 0 | function(t, e) {
                                            t |= 0;
                                            var n = 0, i = 0;
                                            return 0 == (0 | (e |= 0)) ? n = 0 : (i = 0 | function(t, e, n) {
                                                e |= 0, n |= 0;
                                                var i, a, s, u, c, l = 0, f = 0, d = 0, h = 0, p = 0, _ = 0, m = 0, y = 0, g = 0, v = 0, b = 0, w = 0, x = 0, A = 0, S = 0, T = 0, P = 0, M = 0, k = 0, E = 0;
                                                u = 1794895138 + (0 | o[(t |= 0) >> 2]) | 0, c = 0 | Q(0 | o[(t + 8 | 0) >> 2], u), 
                                                i = 0 | Q(0 | o[(t + 12 | 0) >> 2], u), a = 0 | Q(0 | o[(t + 16 | 0) >> 2], u), 
                                                s = c >>> 0 < e >>> 2 >>> 0;
                                                t: do {
                                                    if (s) if (i >>> 0 < (_ = e - (c << 2) | 0) >>> 0 & a >>> 0 < _ >>> 0) if (0 == (0 | 3 & (a | i))) {
                                                        for (m = i >>> 2, y = a >>> 2, l = 0, f = c; ;) {
                                                            if (x = 0 | Q(0 | o[(t + ((w = (b = (v = l + (g = f >>> 1) | 0) << 1) + m | 0) << 2) | 0) >> 2], u), 
                                                            !((A = 0 | Q(0 | o[(t + ((w + 1 | 0) << 2) | 0) >> 2], u)) >>> 0 < e >>> 0 & x >>> 0 < (e - A | 0) >>> 0)) {
                                                                p = 0;
                                                                break t;
                                                            }
                                                            if ((0 | r[(t + (A + x | 0) | 0) >> 0]) << 24 >> 24 != 0) {
                                                                p = 0;
                                                                break t;
                                                            }
                                                            if (0 == (0 | (S = 0 | q(n, t + A | 0)))) break;
                                                            if (h = (E = (0 | S) < 0) ? g : f - g | 0, d = E ? l : v, 1 == (0 | f)) {
                                                                p = 0;
                                                                break t;
                                                            }
                                                            l = d, f = h;
                                                        }
                                                        P = 0 | Q(0 | o[(t + ((T = b + y | 0) << 2) | 0) >> 2], u), (M = 0 | Q(0 | o[(t + ((T + 1 | 0) << 2) | 0) >> 2], u)) >>> 0 < e >>> 0 & P >>> 0 < (e - M | 0) >>> 0 ? (k = t + M | 0, 
                                                        p = (0 | r[(t + (M + P | 0) | 0) >> 0]) << 24 >> 24 == 0 ? k : 0) : p = 0;
                                                    } else p = 0; else p = 0; else p = 0;
                                                } while (0);
                                                return 0 | p;
                                            }(0 | o[e >> 2], 0 | o[(e + 4 | 0) >> 2], t), n = i), 0 | (0 != (0 | n) ? n : t);
                                        }(t |= 0, e |= 0);
                                    }(n, 0 | o[(e + 20 | 0) >> 2]);
                                }(t |= 0, 0 | o[49]);
                            }
                            function Q(t, e) {
                                var n, r;
                                return n = 0 == (0 | (e |= 0)), r = 0 | Tt(0 | (t |= 0)), 0 | (n ? t : r);
                            }
                            function q(t, e) {
                                e |= 0;
                                var n, i, o = 0, a = 0, s = 0, u = 0, c = 0, l = 0, f = 0, d = 0;
                                if ((n = 0 | r[(t |= 0) >> 0]) << 24 >> 24 == 0 | n << 24 >> 24 != (i = 0 | r[e >> 0]) << 24 >> 24) s = i, 
                                u = n; else for (o = e, a = t; ;) {
                                    if (l = o + 1 | 0, (f = 0 | r[(c = a + 1 | 0) >> 0]) << 24 >> 24 == 0 | f << 24 >> 24 != (d = 0 | r[l >> 0]) << 24 >> 24) {
                                        s = d, u = f;
                                        break;
                                    }
                                    o = l, a = c;
                                }
                                return 0 | (255 & u) - (255 & s);
                            }
                            function Z(t, e, n) {
                                var i, a, s, u = 0, c = 0, l = 0, f = 0, d = 0, h = 0, _ = 0, m = 0, y = 0, g = 0, v = 0, b = 0, w = 0, x = 0, A = 0, S = 0, T = 0, P = 0, M = 0, k = 0, E = 0, O = 0, C = 0, I = 0, R = 0, L = 0, N = 0, j = 0;
                                i = 255 & (e |= 0), s = (a = 0 != (0 | (n |= 0))) & 0 != (0 | 3 & (t |= 0));
                                t: do {
                                    if (s) for (N = 255 & e, f = t, _ = n; ;) {
                                        if ((0 | r[f >> 0]) << 24 >> 24 == N << 24 >> 24) {
                                            l = f, h = _, j = 6;
                                            break t;
                                        }
                                        if (!((P = 0 != (0 | (T = _ + -1 | 0))) & 0 != (0 | 3 & (S = f + 1 | 0)))) {
                                            c = S, d = T, A = P, j = 5;
                                            break;
                                        }
                                        f = S, _ = T;
                                    } else c = t, d = n, A = a, j = 5;
                                } while (0);
                                5 == (0 | j) && (A ? (l = c, h = d, j = 6) : (b = c, x = 0));
                                t: do {
                                    if (6 == (0 | j)) if ((0 | r[l >> 0]) << 24 >> 24 == (M = 255 & e) << 24 >> 24) b = l, 
                                    x = h; else {
                                        k = 0 | p(i, 16843009), E = h >>> 0 > 3;
                                        e: do {
                                            if (E) {
                                                for (m = l, g = h; 0 == (0 | (-2139062144 ^ -2139062144 & (O = (0 | o[m >> 2]) ^ k)) & (O + -16843009 | 0)); ) {
                                                    if (C = m + 4 | 0, !((I = g + -4 | 0) >>> 0 > 3)) {
                                                        u = C, y = I, j = 11;
                                                        break e;
                                                    }
                                                    m = C, g = I;
                                                }
                                                v = m, w = g;
                                            } else u = l, y = h, j = 11;
                                        } while (0);
                                        if (11 == (0 | j)) {
                                            if (0 == (0 | y)) {
                                                b = u, x = 0;
                                                break;
                                            }
                                            v = u, w = y;
                                        }
                                        for (;;) {
                                            if ((0 | r[v >> 0]) << 24 >> 24 == M << 24 >> 24) {
                                                b = v, x = w;
                                                break t;
                                            }
                                            if (R = v + 1 | 0, 0 == (0 | (L = w + -1 | 0))) {
                                                b = R, x = 0;
                                                break;
                                            }
                                            v = R, w = L;
                                        }
                                    }
                                } while (0);
                                return 0 | (0 != (0 | x) ? b : 0);
                            }
                            function tt(t, e, n) {
                                var i, a, s;
                                return t |= 0, e |= 0, n |= 0, s = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), 
                                o[(i = s) >> 2] = n, a = 0 | function(t, e, n) {
                                    return 0 | function(t, e, n, i) {
                                        t |= 0, n |= 0, i |= 0;
                                        var a, s, u, f, d, h = 0, p = 0, _ = 0, m = 0, y = 0, g = 0, b = 0, w = 0, x = 0, A = 0;
                                        s = c, (0 | (c = c + 128 | 0)) >= (0 | l) && v(128), A = 380, u = (x = a = s) + 124 | 0;
                                        do {
                                            o[x >> 2] = 0 | o[A >> 2], x = x + 4 | 0, A = A + 4 | 0;
                                        } while ((0 | x) < (0 | u));
                                        return h = (d = 2147483647) >>> 0 > (p = -2 - (f = t) | 0) >>> 0 ? p : d, o[(a + 48 | 0) >> 2] = h, 
                                        o[(_ = a + 20 | 0) >> 2] = f, o[(a + 44 | 0) >> 2] = f, m = f + h | 0, o[(y = a + 16 | 0) >> 2] = m, 
                                        o[(a + 28 | 0) >> 2] = m, g = 0 | function(t, e, n) {
                                            t |= 0, e |= 0, n |= 0;
                                            var i, a, s, u, f, d, h, p = 0, _ = 0, m = 0, y = 0, g = 0, b = 0, w = 0, x = 0, A = 0, S = 0, T = 0, P = 0, M = 0, k = 0, E = 0, O = 0, C = 0, I = 0, R = 0;
                                            d = c, (0 | (c = c + 224 | 0)) >= (0 | l) && v(224), i = d + 120 | 0, s = d, u = d + 136 | 0, 
                                            h = 40 + (R = a = d + 80 | 0) | 0;
                                            do {
                                                o[R >> 2] = 0, R = R + 4 | 0;
                                            } while ((0 | R) < (0 | h));
                                            return f = 0 | o[n >> 2], o[i >> 2] = f, (0 | et(0, e, i, s, a)) < 0 ? _ = -1 : (o[(t + 76 | 0) >> 2], 
                                            b = 32 & (g = 0 | o[t >> 2]), (0 | r[(t + 74 | 0) >> 0]) << 24 >> 24 < 1 && (w = -33 & g, 
                                            o[t >> 2] = w), 0 == (0 | o[(x = t + 48 | 0) >> 2]) ? (S = 0 | o[(A = t + 44 | 0) >> 2], 
                                            o[A >> 2] = u, o[(T = t + 28 | 0) >> 2] = u, o[(P = t + 20 | 0) >> 2] = u, o[x >> 2] = 80, 
                                            M = u + 80 | 0, o[(k = t + 16 | 0) >> 2] = M, E = 0 | et(t, e, i, s, a), 0 == (0 | S) ? m = E : (O = 0 | o[(t + 36 | 0) >> 2], 
                                            kt[7 & O](t, 0, 0), p = 0 == (0 | o[P >> 2]) ? -1 : E, o[A >> 2] = S, o[x >> 2] = 0, 
                                            o[k >> 2] = 0, o[T >> 2] = 0, o[P >> 2] = 0, m = p)) : m = 0 | et(t, e, i, s, a), 
                                            y = 0 == (0 | 32 & (C = 0 | o[t >> 2])) ? m : -1, I = C | b, o[t >> 2] = I, _ = y), 
                                            c = d, 0 | _;
                                        }(a, n, i), 0 == (0 | h) || (b = 0 | o[_ >> 2], w = 0 | o[y >> 2], r[(b + (((0 | b) == (0 | w)) << 31 >> 31) | 0) >> 0] = 0), 
                                        c = s, 0 | g;
                                    }(t |= 0, 0, e |= 0, n |= 0);
                                }(t, e, i), c = s, 0 | a;
                            }
                            function et(t, e, n, s, u) {
                                t |= 0, e |= 0, n |= 0, s |= 0, u |= 0;
                                var f, d, p, _, m, y, g, b, w, x, A, S = 0, T = 0, P = 0, M = 0, k = 0, E = 0, O = 0, C = 0, I = 0, R = 0, L = 0, N = 0, j = 0, D = 0, B = 0, U = 0, F = 0, H = 0, $ = 0, V = 0, z = 0, Y = 0, G = 0, W = 0, K = 0, X = 0, Q = 0, q = 0, tt = 0, et = 0, ft = 0, dt = 0, ht = 0, _t = 0, mt = 0, yt = 0, gt = 0, vt = 0, bt = 0, wt = 0, xt = 0, At = 0, St = 0, Tt = 0, Pt = 0, Mt = 0, kt = 0, Et = 0, Ot = 0, Ct = 0, It = 0, Rt = 0, Lt = 0, Nt = 0, jt = 0, Dt = 0, Bt = 0, Ut = 0, Ft = 0, Ht = 0, $t = 0, Vt = 0, zt = 0, Yt = 0, Gt = 0, Wt = 0, Kt = 0, Xt = 0, Jt = 0, Qt = 0, qt = 0, Zt = 0, te = 0, ee = 0, ne = 0, re = 0, ie = 0, oe = 0, ae = 0, se = 0, ue = 0, ce = 0, le = 0, fe = 0, de = 0, he = 0, pe = 0, _e = 0, me = 0, ye = 0, ge = 0, ve = 0, be = 0, we = 0, xe = 0, Ae = 0, Se = 0, Te = 0, Pe = 0, Me = 0, ke = 0, Ee = 0, Oe = 0, Ce = 0, Ie = 0, Re = 0, Le = 0, Ne = 0, je = 0, De = 0, Be = 0, Ue = 0, Fe = 0, He = 0, $e = 0, Ve = 0, ze = 0, Ye = 0, Ge = 0, We = 0, Ke = 0, Xe = 0, Je = 0, Qe = 0, qe = 0, Ze = 0, tn = 0, en = 0, nn = 0, rn = 0, on = 0, an = 0, sn = 0, un = 0, cn = 0, ln = 0, fn = 0, dn = 0, hn = 0, pn = 0, _n = 0, mn = 0, yn = 0, gn = 0, vn = 0, bn = 0, wn = 0, xn = 0, An = 0, Sn = 0, Tn = 0, Pn = 0, Mn = 0, kn = 0, En = 0, On = 0, Cn = 0, In = 0, Rn = 0, Ln = 0, Nn = 0, jn = 0, Dn = 0, Bn = 0, Un = 0, Fn = 0, Hn = 0, $n = 0, Vn = 0, zn = 0, Yn = 0, Gn = 0, Wn = 0, Kn = 0, Xn = 0, Jn = 0, Qn = 0, qn = 0;
                                A = c, (0 | (c = c + 64 | 0)) >= (0 | l) && v(64), g = A, b = A + 24 | 0, w = A + 8 | 0, 
                                x = A + 20 | 0, o[(y = A + 16 | 0) >> 2] = e, f = 0 != (0 | t), p = d = b + 40 | 0, 
                                _ = b + 39 | 0, m = w + 4 | 0, L = 0, N = 0, z = 0, be = e;
                                t: for (;;) {
                                    Qt = (0 | N) > -1;
                                    do {
                                        if (Qt) {
                                            if ((0 | L) > (0 | 2147483647 - N)) {
                                                o[18] = 75, tt = -1;
                                                break;
                                            }
                                            tt = L + N | 0;
                                            break;
                                        }
                                        tt = N;
                                    } while (0);
                                    if ((ge = 0 | r[be >> 0]) << 24 >> 24 == 0) {
                                        qn = 87;
                                        break;
                                    }
                                    Ee = ge, Be = be;
                                    e: for (;;) {
                                        switch (Ee << 24 >> 24) {
                                          case 37:
                                            D = Be, Ye = Be, qn = 9;
                                            break e;

                                          case 0:
                                            j = Be, yn = Be;
                                            break e;
                                        }
                                        Re = Be + 1 | 0, o[y >> 2] = Re, Ee = 0 | r[Re >> 0], Be = Re;
                                    }
                                    e: do {
                                        if (9 == (0 | qn)) for (;;) {
                                            if (qn = 0, (0 | r[(Ye + 1 | 0) >> 0]) << 24 >> 24 != 37) {
                                                j = D, yn = Ye;
                                                break e;
                                            }
                                            if (rn = D + 1 | 0, an = Ye + 2 | 0, o[y >> 2] = an, (0 | r[an >> 0]) << 24 >> 24 != 37) {
                                                j = rn, yn = an;
                                                break;
                                            }
                                            D = rn, Ye = an, qn = 9;
                                        }
                                    } while (0);
                                    if (_n = j - be | 0, f && nt(t, be, _n), 0 == (0 | _n)) {
                                        (zn = ((0 | r[(mn = yn + 1 | 0) >> 0]) << 24 >> 24) - 48 | 0) >>> 0 < 10 ? (U = (gn = (0 | r[(yn + 2 | 0) >> 0]) << 24 >> 24 == 36) ? zn : -1, 
                                        _t = gn ? 1 : z, Xn = gn ? yn + 3 | 0 : mn) : (U = -1, _t = z, Xn = mn), o[y >> 2] = Xn, 
                                        wn = (bn = ((vn = 0 | r[Xn >> 0]) << 24 >> 24) - 32 | 0) >>> 0 < 32;
                                        e: do {
                                            if (wn) for (V = 0, dn = vn, An = bn, Jn = Xn; ;) {
                                                if (0 == (0 | 75913 & (xn = 1 << An))) {
                                                    $ = V, It = dn, En = Jn;
                                                    break e;
                                                }
                                                if (Sn = xn | V, Tn = Jn + 1 | 0, o[y >> 2] = Tn, !((Mn = ((Pn = 0 | r[Tn >> 0]) << 24 >> 24) - 32 | 0) >>> 0 < 32)) {
                                                    $ = Sn, It = Pn, En = Tn;
                                                    break;
                                                }
                                                V = Sn, dn = Pn, An = Mn, Jn = Tn;
                                            } else $ = 0, It = vn, En = Xn;
                                        } while (0);
                                        if (It << 24 >> 24 == 42) {
                                            if ((Gn = ((0 | r[(kn = En + 1 | 0) >> 0]) << 24 >> 24) - 48 | 0) >>> 0 < 10 && (0 | r[(En + 2 | 0) >> 0]) << 24 >> 24 == 36 ? (o[(u + (Gn << 2) | 0) >> 2] = 10, 
                                            On = 0 | r[kn >> 0], In = 0 | o[(Cn = s + (((On << 24 >> 24) - 48 | 0) << 3) | 0) >> 2], 
                                            o[(Cn + 4 | 0) >> 2], H = In, St = 1, Qn = En + 3 | 0) : qn = 23, 23 == (0 | qn)) {
                                                if (qn = 0, 0 != (0 | _t)) {
                                                    T = -1;
                                                    break;
                                                }
                                                f ? (Fn = 0 | o[n >> 2], Ln = 0 | o[(Rn = -4 & (Fn + 3 | 0)) >> 2], $n = Rn + 4 | 0, 
                                                o[n >> 2] = $n, H = Ln, St = 0, Qn = kn) : (H = 0, St = 0, Qn = kn);
                                            }
                                            o[y >> 2] = Qn, ft = (Nn = (0 | H) < 0) ? 0 - H | 0 : H, dt = Nn ? 8192 | $ : $, 
                                            Pt = St, Dn = Qn;
                                        } else {
                                            if ((0 | (jn = 0 | rt(y))) < 0) {
                                                T = -1;
                                                break;
                                            }
                                            ft = jn, dt = $, Pt = _t, Dn = 0 | o[y >> 2];
                                        }
                                        Bn = (0 | r[Dn >> 0]) << 24 >> 24 == 46;
                                        do {
                                            if (Bn) {
                                                if ((0 | r[(Dn + 1 | 0) >> 0]) << 24 >> 24 != 42) {
                                                    Ht = Dn + 1 | 0, o[y >> 2] = Ht, F = 0 | rt(y), Rt = 0 | o[y >> 2];
                                                    break;
                                                }
                                                if ((Yn = ((0 | r[(Un = Dn + 2 | 0) >> 0]) << 24 >> 24) - 48 | 0) >>> 0 < 10 && (0 | r[(Dn + 3 | 0) >> 0]) << 24 >> 24 == 36) {
                                                    o[(u + (Yn << 2) | 0) >> 2] = 10, Nt = 0 | r[Un >> 0], Dt = 0 | o[(jt = s + (((Nt << 24 >> 24) - 48 | 0) << 3) | 0) >> 2], 
                                                    o[(jt + 4 | 0) >> 2], Bt = Dn + 4 | 0, o[y >> 2] = Bt, F = Dt, Rt = Bt;
                                                    break;
                                                }
                                                if (0 != (0 | Pt)) {
                                                    T = -1;
                                                    break t;
                                                }
                                                f ? (Hn = 0 | o[n >> 2], Ft = 0 | o[(Ut = -4 & (Hn + 3 | 0)) >> 2], Vn = Ut + 4 | 0, 
                                                o[n >> 2] = Vn, hn = Ft) : hn = 0, o[y >> 2] = Un, F = hn, Rt = Un;
                                            } else F = -1, Rt = Dn;
                                        } while (0);
                                        for (B = 0, $t = Rt; ;) {
                                            if ((((0 | r[$t >> 0]) << 24 >> 24) - 65 | 0) >>> 0 > 57) {
                                                T = -1;
                                                break t;
                                            }
                                            if (Vt = $t + 1 | 0, o[y >> 2] = Vt, zt = 0 | r[$t >> 0], !(((Gt = 255 & (Yt = 0 | r[((3536 + (58 * B | 0) | 0) + ((zt << 24 >> 24) - 65 | 0) | 0) >> 0])) - 1 | 0) >>> 0 < 8)) break;
                                            B = Gt, $t = Vt;
                                        }
                                        if (Yt << 24 >> 24 == 0) {
                                            T = -1;
                                            break;
                                        }
                                        Wt = Yt << 24 >> 24 == 19, Kt = (0 | U) > -1;
                                        do {
                                            if (Wt) {
                                                if (Kt) {
                                                    T = -1;
                                                    break t;
                                                }
                                                qn = 49;
                                            } else {
                                                if (Kt) {
                                                    o[(u + (U << 2) | 0) >> 2] = Gt, Jt = 0 | o[(Xt = s + (U << 3) | 0) >> 2], qt = 0 | o[(Xt + 4 | 0) >> 2], 
                                                    o[(Zt = g) >> 2] = Jt, o[(Zt + 4 | 0) >> 2] = qt, qn = 49;
                                                    break;
                                                }
                                                if (!f) {
                                                    T = 0;
                                                    break t;
                                                }
                                                it(g, Gt, n);
                                            }
                                        } while (0);
                                        if (49 != (0 | qn) || (qn = 0, f)) {
                                            E = 0 != (0 | B) & 3 == (0 | 15 & (te = (0 | r[$t >> 0]) << 24 >> 24)) ? -33 & te : te, 
                                            ee = -65537 & dt, ht = 0 == (0 | 8192 & dt) ? dt : ee;
                                            e: do {
                                                switch (0 | E) {
                                                  case 110:
                                                    switch ((255 & B) << 24 >> 24) {
                                                      case 0:
                                                        re = 0 | o[g >> 2], o[re >> 2] = tt, L = 0, N = tt, z = Pt, be = Vt;
                                                        continue t;

                                                      case 1:
                                                        ie = 0 | o[g >> 2], o[ie >> 2] = tt, L = 0, N = tt, z = Pt, be = Vt;
                                                        continue t;

                                                      case 2:
                                                        oe = ((0 | tt) < 0) << 31 >> 31, ae = 0 | o[g >> 2], o[(se = ae) >> 2] = tt, o[(se + 4 | 0) >> 2] = oe, 
                                                        L = 0, N = tt, z = Pt, be = Vt;
                                                        continue t;

                                                      case 3:
                                                        ue = 65535 & tt, ce = 0 | o[g >> 2], i[ce >> 1] = ue, L = 0, N = tt, z = Pt, be = Vt;
                                                        continue t;

                                                      case 4:
                                                        le = 255 & tt, fe = 0 | o[g >> 2], r[fe >> 0] = le, L = 0, N = tt, z = Pt, be = Vt;
                                                        continue t;

                                                      case 6:
                                                        de = 0 | o[g >> 2], o[de >> 2] = tt, L = 0, N = tt, z = Pt, be = Vt;
                                                        continue t;

                                                      case 7:
                                                        he = ((0 | tt) < 0) << 31 >> 31, pe = 0 | o[g >> 2], o[(_e = pe) >> 2] = tt, o[(_e + 4 | 0) >> 2] = he, 
                                                        L = 0, N = tt, z = Pt, be = Vt;
                                                        continue t;

                                                      default:
                                                        L = 0, N = tt, z = Pt, be = Vt;
                                                        continue t;
                                                    }
                                                    break;

                                                  case 112:
                                                    K = 120, et = F >>> 0 > 8 ? F : 8, Tt = 8 | ht, qn = 61;
                                                    break;

                                                  case 88:
                                                  case 120:
                                                    K = E, et = F, Tt = ht, qn = 61;
                                                    break;

                                                  case 111:
                                                    P = Se = 0 | at(xe = 0 | o[(we = g) >> 2], Ae = 0 | o[(we + 4 | 0) >> 2], d), W = 0, 
                                                    X = 4e3, xt = 0 == (0 | 8 & ht) | (0 | F) > (0 | (Te = p - Se | 0)) ? F : Te + 1 | 0, 
                                                    Et = ht, je = xe, De = Ae, qn = 67;
                                                    break;

                                                  case 105:
                                                  case 100:
                                                    if (Me = 0 | o[(Pe = g) >> 2], (0 | (ke = 0 | o[(Pe + 4 | 0) >> 2])) < 0) {
                                                        Oe = 0 | pt(0, 0, 0 | Me, 0 | ke), Ce = h, o[(Ie = g) >> 2] = Oe, o[(Ie + 4 | 0) >> 2] = Ce, 
                                                        k = 1, O = 4e3, Le = Oe, Ne = Ce, qn = 66;
                                                        break e;
                                                    }
                                                    k = 1 & 0 != (0 | 2049 & ht), O = 0 == (0 | 2048 & ht) ? 0 == (0 | 1 & ht) ? 4e3 : 4002 : 4001, 
                                                    Le = Me, Ne = ke, qn = 66;
                                                    break e;

                                                  case 117:
                                                    k = 0, O = 4e3, Le = 0 | o[(ne = g) >> 2], Ne = 0 | o[(ne + 4 | 0) >> 2], qn = 66;
                                                    break;

                                                  case 99:
                                                    $e = 0 | o[(He = g) >> 2], o[(He + 4 | 0) >> 2], Ve = 255 & $e, r[_ >> 0] = Ve, 
                                                    mt = _, yt = 0, gt = 4e3, wt = d, Ot = 1, Ct = ee;
                                                    break;

                                                  case 109:
                                                    Y = 0 | J(0 | o[18]), qn = 71;
                                                    break;

                                                  case 115:
                                                    Y = 0 != (0 | (ze = 0 | o[g >> 2])) ? ze : 4010, qn = 71;
                                                    break;

                                                  case 67:
                                                    Xe = 0 | o[(Ke = g) >> 2], o[(Ke + 4 | 0) >> 2], o[w >> 2] = Xe, o[m >> 2] = 0, 
                                                    o[g >> 2] = w, kt = -1, pn = w, qn = 75;
                                                    break;

                                                  case 83:
                                                    Lt = 0 | o[g >> 2], 0 == (0 | F) ? (ut(t, 32, ft, 0, ht), I = 0, qn = 84) : (kt = F, 
                                                    pn = Lt, qn = 75);
                                                    break;

                                                  case 65:
                                                  case 71:
                                                  case 70:
                                                  case 69:
                                                  case 97:
                                                  case 103:
                                                  case 102:
                                                  case 101:
                                                    L = 0 | lt(t, +a[g >> 3], ft, F, ht, E), N = tt, z = Pt, be = Vt;
                                                    continue t;

                                                  default:
                                                    mt = be, yt = 0, gt = 4e3, wt = d, Ot = F, Ct = ht;
                                                }
                                            } while (0);
                                            e: do {
                                                if (61 == (0 | qn)) qn = 0, P = 0 | ot(ye = 0 | o[(me = g) >> 2], ve = 0 | o[(me + 4 | 0) >> 2], d, 32 & K), 
                                                W = (Kn = 0 == (0 | 8 & Tt) | 0 == (0 | ye) & 0 == (0 | ve)) ? 0 : 2, X = Kn ? 4e3 : 4e3 + (K >> 4) | 0, 
                                                xt = et, Et = Tt, je = ye, De = ve, qn = 67; else if (66 == (0 | qn)) qn = 0, P = 0 | st(Le, Ne, d), 
                                                W = k, X = O, xt = F, Et = ht, je = Le, De = Ne, qn = 67; else if (71 == (0 | qn)) qn = 0, 
                                                mt = Y, yt = 0, gt = 4e3, wt = (We = 0 == (0 | (Ge = 0 | Z(Y, 0, F)))) ? Y + F | 0 : Ge, 
                                                Ot = We ? F : Ge - Y | 0, Ct = ee; else if (75 == (0 | qn)) {
                                                    for (qn = 0, M = pn, R = 0, q = 0; ;) {
                                                        if (0 == (0 | (Je = 0 | o[M >> 2]))) {
                                                            C = R, bt = q;
                                                            break;
                                                        }
                                                        if ((0 | (Qe = 0 | ct(x, Je))) < 0 | Qe >>> 0 > (kt - R | 0) >>> 0) {
                                                            C = R, bt = Qe;
                                                            break;
                                                        }
                                                        if (qe = M + 4 | 0, !(kt >>> 0 > (Ze = Qe + R | 0) >>> 0)) {
                                                            C = Ze, bt = Qe;
                                                            break;
                                                        }
                                                        M = qe, R = Ze, q = Qe;
                                                    }
                                                    if ((0 | bt) < 0) {
                                                        T = -1;
                                                        break t;
                                                    }
                                                    if (ut(t, 32, ft, C, ht), 0 == (0 | C)) I = 0, qn = 84; else for (G = pn, Q = 0; ;) {
                                                        if (0 == (0 | (tn = 0 | o[G >> 2]))) {
                                                            I = C, qn = 84;
                                                            break e;
                                                        }
                                                        if ((0 | (nn = (en = 0 | ct(x, tn)) + Q | 0)) > (0 | C)) {
                                                            I = C, qn = 84;
                                                            break e;
                                                        }
                                                        if (on = G + 4 | 0, nt(t, x, en), !(nn >>> 0 < C >>> 0)) {
                                                            I = C, qn = 84;
                                                            break;
                                                        }
                                                        G = on, Q = nn;
                                                    }
                                                }
                                            } while (0);
                                            if (67 == (0 | qn)) qn = 0, Fe = (1 & (1 ^ (Ue = 0 != (0 | je) | 0 != (0 | De)))) + (p - P | 0) | 0, 
                                            mt = (Wn = 0 != (0 | xt) | Ue) ? P : d, yt = W, gt = X, wt = d, Ot = Wn ? (0 | xt) > (0 | Fe) ? xt : Fe : xt, 
                                            Ct = (0 | xt) > -1 ? -65537 & Et : Et; else if (84 == (0 | qn)) {
                                                qn = 0, ut(t, 32, ft, I, 8192 ^ ht), L = (0 | ft) > (0 | I) ? ft : I, N = tt, z = Pt, 
                                                be = Vt;
                                                continue;
                                            }
                                            ut(t, 32, At = (0 | ft) < (0 | (un = (S = (0 | Ot) < (0 | (sn = wt - mt | 0)) ? sn : Ot) + yt | 0)) ? un : ft, un, Ct), 
                                            nt(t, gt, yt), ut(t, 48, At, un, 65536 ^ Ct), ut(t, 48, S, sn, 0), nt(t, mt, sn), 
                                            ut(t, 32, At, un, 8192 ^ Ct), L = At, N = tt, z = Pt, be = Vt;
                                        } else L = 0, N = tt, z = Pt, be = Vt;
                                    } else L = _n, N = tt, be = yn, z = z;
                                }
                                t: do {
                                    if (87 == (0 | qn)) if (0 == (0 | t)) if (0 == (0 | z)) T = 0; else {
                                        for (vt = 1; ;) {
                                            if (0 == (0 | (cn = 0 | o[(u + (vt << 2) | 0) >> 2]))) {
                                                Mt = vt;
                                                break;
                                            }
                                            if (it(s + (vt << 3) | 0, cn, n), !((0 | (ln = vt + 1 | 0)) < 10)) {
                                                T = 1;
                                                break t;
                                            }
                                            vt = ln;
                                        }
                                        for (;;) {
                                            if (fn = Mt + 1 | 0, 0 != (0 | o[(u + (Mt << 2) | 0) >> 2])) {
                                                T = -1;
                                                break t;
                                            }
                                            if (!((0 | fn) < 10)) {
                                                T = 1;
                                                break;
                                            }
                                            Mt = fn;
                                        }
                                    } else T = tt;
                                } while (0);
                                return c = A, 0 | T;
                            }
                            function nt(t, e, n) {
                                e |= 0, n |= 0, 0 == (0 | 32 & (0 | o[(t |= 0) >> 2])) && function(t, e, n) {
                                    t |= 0, e |= 0;
                                    var i, a, s = 0, u = 0, c = 0, l = 0, f = 0, d = 0, h = 0, p = 0, _ = 0, m = 0, y = 0, g = 0, v = 0, b = 0;
                                    0 == (0 | (a = 0 | o[(i = 16 + (n |= 0) | 0) >> 2])) ? 0 == (0 | function(t) {
                                        var e, n, i, a, s = 0, u = 0, c = 0, l = 0;
                                        return i = 255 & (255 + (n = (0 | r[(e = 74 + (t |= 0) | 0) >> 0]) << 24 >> 24) | 0 | n), 
                                        r[e >> 0] = i, 0 == (0 | 8 & (a = 0 | o[t >> 2])) ? (o[(t + 8 | 0) >> 2] = 0, o[(t + 4 | 0) >> 2] = 0, 
                                        c = 0 | o[(t + 44 | 0) >> 2], o[(t + 28 | 0) >> 2] = c, o[(t + 20 | 0) >> 2] = c, 
                                        l = c + (0 | o[(t + 48 | 0) >> 2]) | 0, o[(t + 16 | 0) >> 2] = l, s = 0) : (u = 32 | a, 
                                        o[t >> 2] = u, s = -1), 0 | s;
                                    }(n)) && (f = 0 | o[i >> 2], b = 5) : (f = a, b = 5);
                                    t: do {
                                        if (5 == (0 | b)) {
                                            if (d = l = 0 | o[(v = n + 20 | 0) >> 2], (f - l | 0) >>> 0 < e >>> 0) {
                                                h = 0 | o[(n + 36 | 0) >> 2], kt[7 & h](n, t, e);
                                                break;
                                            }
                                            p = (0 | r[(n + 75 | 0) >> 0]) << 24 >> 24 > -1;
                                            e: do {
                                                if (p) {
                                                    for (s = e; ;) {
                                                        if (0 == (0 | s)) {
                                                            u = t, c = e, y = d;
                                                            break e;
                                                        }
                                                        if ((0 | r[(t + (_ = s + -1 | 0) | 0) >> 0]) << 24 >> 24 == 10) break;
                                                        s = _;
                                                    }
                                                    if (m = 0 | o[(n + 36 | 0) >> 2], (0 | kt[7 & m](n, t, s)) >>> 0 < s >>> 0) break t;
                                                    u = t + s | 0, c = e - s | 0, y = 0 | o[v >> 2];
                                                } else u = t, c = e, y = d;
                                            } while (0);
                                            St(0 | y, 0 | u, 0 | c), g = (0 | o[v >> 2]) + c | 0, o[v >> 2] = g;
                                        }
                                    } while (0);
                                }(e, n, t);
                            }
                            function rt(t) {
                                var e, n, i = 0, a = 0, s = 0, u = 0, c = 0, l = 0, f = 0;
                                if (e = 0 | o[(t |= 0) >> 2], (n = ((0 | r[e >> 0]) << 24 >> 24) - 48 | 0) >>> 0 < 10) for (a = 0, 
                                c = e, f = n; ;) {
                                    if (s = f + (10 * a | 0) | 0, u = c + 1 | 0, o[t >> 2] = u, !((l = ((0 | r[u >> 0]) << 24 >> 24) - 48 | 0) >>> 0 < 10)) {
                                        i = s;
                                        break;
                                    }
                                    a = s, c = u, f = l;
                                } else i = 0;
                                return 0 | i;
                            }
                            function it(t, e, n) {
                                t |= 0, n |= 0;
                                var r, i = 0, s = 0, u = 0, c = 0, l = 0, f = 0, d = 0, h = 0, p = 0, _ = 0, m = 0, y = 0, g = 0, v = 0, b = 0, w = 0, x = 0, A = 0, S = 0, T = 0, P = 0, M = 0, k = 0, E = 0, O = 0, C = 0, I = 0, R = 0, L = 0, N = 0, j = 0, D = 0, B = 0, U = 0, F = 0, H = 0, $ = 0, V = 0, z = 0, Y = 0, G = 0, W = 0, K = 0, X = 0, J = 0, Q = 0, q = 0, Z = 0, tt = 0, et = 0, nt = 0, rt = 0, it = 0, ot = 0, at = 0, st = 0;
                                r = (e |= 0) >>> 0 > 20;
                                t: do {
                                    if (!r) switch (0 | e) {
                                      case 9:
                                        $ = 0 | o[n >> 2], u = 0 | o[(B = -4 & ($ + 3 | 0)) >> 2], q = B + 4 | 0, o[n >> 2] = q, 
                                        o[t >> 2] = u;
                                        break t;

                                      case 10:
                                        G = 0 | o[n >> 2], p = 0 | o[(h = -4 & (G + 3 | 0)) >> 2], ot = h + 4 | 0, o[n >> 2] = ot, 
                                        _ = ((0 | p) < 0) << 31 >> 31, o[(m = t) >> 2] = p, o[(m + 4 | 0) >> 2] = _;
                                        break t;

                                      case 11:
                                        J = 0 | o[n >> 2], g = 0 | o[(y = -4 & (J + 3 | 0)) >> 2], at = y + 4 | 0, o[n >> 2] = at, 
                                        o[(v = t) >> 2] = g, o[(v + 4 | 0) >> 2] = 0;
                                        break t;

                                      case 12:
                                        Q = 0 | o[n >> 2], x = 0 | o[(w = b = -8 & (Q + 7 | 0)) >> 2], A = 0 | o[(w + 4 | 0) >> 2], 
                                        st = b + 8 | 0, o[n >> 2] = st, o[(S = t) >> 2] = x, o[(S + 4 | 0) >> 2] = A;
                                        break t;

                                      case 13:
                                        V = 0 | o[n >> 2], P = 0 | o[(T = -4 & (V + 3 | 0)) >> 2], Z = T + 4 | 0, o[n >> 2] = Z, 
                                        k = ((0 | (M = (65535 & P) << 16 >> 16)) < 0) << 31 >> 31, o[(E = t) >> 2] = M, 
                                        o[(E + 4 | 0) >> 2] = k;
                                        break t;

                                      case 14:
                                        z = 0 | o[n >> 2], C = 0 | o[(O = -4 & (z + 3 | 0)) >> 2], tt = O + 4 | 0, o[n >> 2] = tt, 
                                        s = 65535 & C, o[(I = t) >> 2] = s, o[(I + 4 | 0) >> 2] = 0;
                                        break t;

                                      case 15:
                                        Y = 0 | o[n >> 2], L = 0 | o[(R = -4 & (Y + 3 | 0)) >> 2], et = R + 4 | 0, o[n >> 2] = et, 
                                        j = ((0 | (N = (255 & L) << 24 >> 24)) < 0) << 31 >> 31, o[(D = t) >> 2] = N, o[(D + 4 | 0) >> 2] = j;
                                        break t;

                                      case 16:
                                        W = 0 | o[n >> 2], F = 0 | o[(U = -4 & (W + 3 | 0)) >> 2], nt = U + 4 | 0, o[n >> 2] = nt, 
                                        i = 255 & F, o[(H = t) >> 2] = i, o[(H + 4 | 0) >> 2] = 0;
                                        break t;

                                      case 17:
                                        K = 0 | o[n >> 2], l = +a[(c = -8 & (K + 7 | 0)) >> 3], rt = c + 8 | 0, o[n >> 2] = rt, 
                                        a[t >> 3] = l;
                                        break t;

                                      case 18:
                                        X = 0 | o[n >> 2], d = +a[(f = -8 & (X + 7 | 0)) >> 3], it = f + 8 | 0, o[n >> 2] = it, 
                                        a[t >> 3] = d;
                                        break t;

                                      default:
                                        break t;
                                    }
                                } while (0);
                            }
                            function ot(t, e, n, i) {
                                n |= 0, i |= 0;
                                var o = 0, a = 0, s = 0, u = 0, c = 0, l = 0, f = 0, d = 0;
                                if (0 == (0 | (t |= 0)) & 0 == (0 | (e |= 0))) o = n; else for (a = n, c = e, d = t; ;) {
                                    if (s = 255 & (255 & (0 | r[(4052 + (15 & d) | 0) >> 0]) | i), r[(u = a + -1 | 0) >> 0] = s, 
                                    0 == (0 | (l = 0 | yt(0 | d, 0 | c, 4))) & 0 == (0 | (f = h))) {
                                        o = u;
                                        break;
                                    }
                                    a = u, c = f, d = l;
                                }
                                return 0 | o;
                            }
                            function at(t, e, n) {
                                n |= 0;
                                var i = 0, o = 0, a = 0, s = 0, u = 0, c = 0, l = 0, f = 0;
                                if (0 == (0 | (t |= 0)) & 0 == (0 | (e |= 0))) i = n; else for (o = n, s = e, l = t; ;) {
                                    if (f = 48 | 7 & l, r[(a = o + -1 | 0) >> 0] = f, 0 == (0 | (u = 0 | yt(0 | l, 0 | s, 3))) & 0 == (0 | (c = h))) {
                                        i = a;
                                        break;
                                    }
                                    o = a, s = c, l = u;
                                }
                                return 0 | i;
                            }
                            function st(t, e, n) {
                                n |= 0;
                                var i = 0, o = 0, a = 0, s = 0, u = 0, c = 0, l = 0, f = 0, d = 0, p = 0, _ = 0, m = 0, y = 0, g = 0, v = 0;
                                if ((e |= 0) >>> 0 > 0 | 0 == (0 | e) & (t |= 0) >>> 0 > 4294967295) {
                                    for (s = n, g = t, v = e; l = 48 | 255 & (0 | At(0 | g, 0 | v, 10, 0)), r[(f = s + -1 | 0) >> 0] = l, 
                                    d = 0 | wt(0 | g, 0 | v, 10, 0), p = h, v >>> 0 > 9 | 9 == (0 | v) & g >>> 0 > 4294967295; ) s = f, 
                                    g = d, v = p;
                                    i = d, a = f;
                                } else i = t, a = n;
                                if (0 == (0 | i)) u = a; else for (o = i, c = a; ;) {
                                    if (_ = 255 & (48 | (o >>> 0) % 10 & -1), r[(m = c + -1 | 0) >> 0] = _, y = (o >>> 0) / 10 & -1, 
                                    o >>> 0 < 10) {
                                        u = m;
                                        break;
                                    }
                                    o = y, c = m;
                                }
                                return 0 | u;
                            }
                            function ut(t, e, n, r, i) {
                                t |= 0, e |= 0, n |= 0, r |= 0, i |= 0;
                                var o, a, s = 0, u = 0, f = 0, d = 0, h = 0;
                                if (a = c, (0 | (c = c + 256 | 0)) >= (0 | l) && v(256), o = a, (0 | n) > (0 | r) & 0 == (0 | 73728 & i)) {
                                    if (mt(0 | o, 0 | e, 0 | ((h = n - r | 0) >>> 0 < 256 ? h : 256)), h >>> 0 > 255) {
                                        for (f = n - r | 0, u = h; nt(t, o, 256), (d = u + -256 | 0) >>> 0 > 255; ) u = d;
                                        s = 255 & f;
                                    } else s = h;
                                    nt(t, o, s);
                                }
                                c = a;
                            }
                            function ct(t, e) {
                                return 0 | (0 == (0 | (t |= 0)) ? 0 : 0 | function(t, e, n) {
                                    e |= 0;
                                    var i, a = 0, s = 0, u = 0, c = 0, l = 0, f = 0, d = 0, h = 0, p = 0, _ = 0, m = 0, y = 0, g = 0, v = 0, b = 0, w = 0, x = 0, A = 0, S = 0;
                                    i = 0 == (0 | (t |= 0));
                                    do {
                                        if (!i) {
                                            if (e >>> 0 < 128) {
                                                b = 255 & e, r[t >> 0] = b, a = 1;
                                                break;
                                            }
                                            if (S = 0 | o[49], 0 == (0 | o[S >> 2])) {
                                                if (57216 == (0 | -128 & e)) {
                                                    s = 255 & e, r[t >> 0] = s, a = 1;
                                                    break;
                                                }
                                                o[18] = 84, a = -1;
                                                break;
                                            }
                                            if (e >>> 0 < 2048) {
                                                u = 255 & (192 | e >>> 6), c = t + 1 | 0, r[t >> 0] = u, l = 255 & (128 | 63 & e), 
                                                r[c >> 0] = l, a = 2;
                                                break;
                                            }
                                            if (e >>> 0 < 55296 | 57344 == (0 | -8192 & e)) {
                                                f = 255 & (224 | e >>> 12), d = t + 1 | 0, r[t >> 0] = f, h = 255 & (128 | 63 & e >>> 6), 
                                                p = t + 2 | 0, r[d >> 0] = h, _ = 255 & (128 | 63 & e), r[p >> 0] = _, a = 3;
                                                break;
                                            }
                                            if ((e + -65536 | 0) >>> 0 < 1048576) {
                                                m = 255 & (240 | e >>> 18), y = t + 1 | 0, r[t >> 0] = m, g = 255 & (128 | 63 & e >>> 12), 
                                                v = t + 2 | 0, r[y >> 0] = g, w = 255 & (128 | 63 & e >>> 6), x = t + 3 | 0, r[v >> 0] = w, 
                                                A = 255 & (128 | 63 & e), r[x >> 0] = A, a = 4;
                                                break;
                                            }
                                            o[18] = 84, a = -1;
                                            break;
                                        }
                                        a = 1;
                                    } while (0);
                                    return 0 | a;
                                }(t, e |= 0));
                            }
                            function lt(t, e, n, i, a, s) {
                                t |= 0, e = +e, n |= 0, i |= 0, a |= 0, s |= 0;
                                var u, f, d, _, m, y, g, b, w, x = 0, A = 0, S = 0, T = 0, P = 0, M = 0, k = 0, E = 0, O = 0, C = 0, I = 0, R = 0, L = 0, N = 0, j = 0, D = 0, B = 0, U = 0, F = 0, H = 0, $ = 0, V = 0, z = 0, Y = 0, G = 0, W = 0, K = 0, X = 0, J = 0, Q = 0, q = 0, Z = 0, tt = 0, et = 0, rt = 0, it = 0, ot = 0, at = 0, ct = 0, lt = 0, ht = 0, pt = 0, yt = 0, vt = 0, bt = 0, xt = 0, St = 0, Tt = 0, Pt = 0, Mt = 0, kt = 0, Et = 0, Ot = 0, Ct = 0, It = 0, Rt = 0, Lt = 0, Nt = 0, jt = 0, Dt = 0, Bt = 0, Ut = 0, Ft = 0, Ht = 0, $t = 0, Vt = 0, zt = 0, Yt = 0, Gt = 0, Wt = 0, Kt = 0, Xt = 0, Jt = 0, Qt = 0, qt = 0, Zt = 0, te = 0, ee = 0, ne = 0, re = 0, ie = 0, oe = 0, ae = 0, se = 0, ue = 0, ce = 0, le = 0, fe = 0, de = 0, he = 0, pe = 0, _e = 0, me = 0, ye = 0, ge = 0, ve = 0, be = 0, we = 0, xe = 0, Ae = 0, Se = 0, Te = 0, Pe = 0, Me = 0, ke = 0, Ee = 0, Oe = 0, Ce = 0, Ie = 0, Re = 0, Le = 0, Ne = 0, je = 0, De = 0, Be = 0, Ue = 0, Fe = 0, He = 0, $e = 0, Ve = 0, ze = 0, Ye = 0, Ge = 0, We = 0, Ke = 0, Xe = 0, Je = 0, Qe = 0, qe = 0, Ze = 0, tn = 0, en = 0, nn = 0, rn = 0, on = 0, an = 0, sn = 0, un = 0, cn = 0, ln = 0, fn = 0, dn = 0, hn = 0, pn = 0, _n = 0, mn = 0, yn = 0, gn = 0, vn = 0, bn = 0, wn = 0, xn = 0, An = 0, Sn = 0, Tn = 0, Pn = 0, Mn = 0, kn = 0, En = 0, On = 0, Cn = 0, In = 0, Rn = 0, Ln = 0, Nn = 0, jn = 0, Dn = 0, Bn = 0, Un = 0, Fn = 0, Hn = 0, $n = 0, Vn = 0, zn = 0, Yn = 0, Gn = 0, Wn = 0, Kn = 0, Xn = 0, Jn = 0, Qn = 0, qn = 0, Zn = 0, tr = 0, er = 0, nr = 0, rr = 0, ir = 0, or = 0, ar = 0, sr = 0, ur = 0, cr = 0, lr = 0, fr = 0, dr = 0, hr = 0, pr = 0, _r = 0, mr = 0, yr = 0, gr = 0, vr = 0, br = 0, wr = 0, xr = 0, Ar = 0, Sr = 0, Tr = 0, Pr = 0, Mr = 0, kr = 0, Er = 0, Or = 0, Cr = 0, Ir = 0, Rr = 0, Lr = 0, Nr = 0, jr = 0, Dr = 0, Br = 0, Ur = 0, Fr = 0, Hr = 0;
                                w = c, (0 | (c = c + 560 | 0)) >= (0 | l) && v(560), m = w + 8 | 0, b = g = w + 524 | 0, 
                                u = w + 512 | 0, o[(y = w) >> 2] = 0, f = u + 12 | 0, ft(e), (0 | h) < 0 ? (O = -e, 
                                V = 1, z = 4017) : (O = e, V = 1 & 0 != (0 | 2049 & a), z = 0 == (0 | 2048 & a) ? 0 == (0 | 1 & a) ? 4018 : 4023 : 4020), 
                                ft(O), _ = (d = 2146435072 & h) >>> 0 < 2146435072 | !1 & 2146435072 == (0 | d);
                                do {
                                    if (_) {
                                        if ((hr = 0 != (or = 2 * +dt(O, y))) && (vr = (0 | o[y >> 2]) - 1 | 0, o[y >> 2] = vr), 
                                        97 == (0 | (br = 32 | s))) {
                                            Y = 0 == (0 | (wr = 32 & s)) ? z : z + 9 | 0, xr = 2 | V, Sr = i >>> 0 > 11 | 0 == (0 | (Ar = 12 - i | 0));
                                            do {
                                                if (!Sr) {
                                                    for (U = 8, lt = Ar; Pr = 16 * U, 0 != (0 | (Tr = lt + -1 | 0)); ) U = Pr, lt = Tr;
                                                    if ((0 | r[Y >> 0]) << 24 >> 24 == 45) {
                                                        tt = -(Pr + (-or - Pr));
                                                        break;
                                                    }
                                                    tt = or + Pr - Pr;
                                                    break;
                                                }
                                                tt = or;
                                            } while (0);
                                            for ((0 | (Er = 0 | st(kr = (0 | (Mr = 0 | o[y >> 2])) < 0 ? 0 - Mr | 0 : Mr, ((0 | kr) < 0) << 31 >> 31, f))) == (0 | f) ? (r[(Or = u + 11 | 0) >> 0] = 48, 
                                            H = Or) : H = Er, Cr = 255 & (43 + (2 & Mr >> 31) | 0), r[(H + -1 | 0) >> 0] = Cr, 
                                            Ir = 255 & (s + 15 | 0), r[(Rr = H + -2 | 0) >> 0] = Ir, Hr = (0 | i) < 1, Lr = 0 == (0 | 8 & a), 
                                            G = g, Mt = tt; jr = 255 & (255 & (0 | r[(4052 + (Nr = ~~Mt) | 0) >> 0]) | wr), 
                                            Dr = G + 1 | 0, r[G >> 0] = jr, Br = 16 * (Mt - +(0 | Nr)), 1 == (0 | Dr - b) ? Lr & Hr & 0 == Br ? vt = Dr : (Ur = G + 2 | 0, 
                                            r[Dr >> 0] = 46, vt = Ur) : vt = Dr, 0 != Br; ) G = vt, Mt = Br;
                                            ut(t, 32, n, Se = ((Ae = f - Rr | 0) + xr | 0) + (_e = 0 != (0 | i) & (0 | (Fr = vt - b | 0) - 2) < (0 | i) ? i + 2 | 0 : Fr) | 0, a), 
                                            nt(t, Y, xr), ut(t, 48, n, Se, 65536 ^ a), nt(t, g, Fr), ut(t, 48, _e - Fr | 0, 0, 0), 
                                            nt(t, Rr, Ae), ut(t, 32, n, Se, 8192 ^ a), xe = Se;
                                            break;
                                        }
                                        for (Xt = (0 | i) < 0 ? 6 : i, hr ? (Te = 268435456 * or, Pe = (0 | o[y >> 2]) - 28 | 0, 
                                        o[y >> 2] = Pe, Nt = Te, ye = Pe) : (Nt = or, ye = 0 | o[y >> 2]), B = ie = (0 | ye) < 0 ? m : m + 288 | 0, 
                                        $t = Nt; Me = ~~$t >>> 0, o[B >> 2] = Me, ke = B + 4 | 0, 0 != (Ee = 1e9 * ($t - +(Me >>> 0))); ) B = ke, 
                                        $t = Ee;
                                        if ((0 | ye) > 0) for (it = ie, ct = ke, Oe = ye; ;) {
                                            if (Ce = (0 | Oe) < 29 ? Oe : 29, (L = ct + -4 | 0) >>> 0 < it >>> 0) Et = it; else {
                                                for (N = L, D = 0; Le = 0 | At(0 | (Ie = 0 | _t(0 | gt(0 | o[N >> 2], 0, 0 | Ce), 0 | h, 0 | D, 0)), 0 | (Re = h), 1e9, 0), 
                                                o[N >> 2] = Le, Ne = 0 | wt(0 | Ie, 0 | Re, 1e9, 0), !((R = N + -4 | 0) >>> 0 < it >>> 0); ) N = R, 
                                                D = Ne;
                                                0 == (0 | Ne) ? Et = it : (o[(je = it + -4 | 0) >> 2] = Ne, Et = je);
                                            }
                                            for (Ot = ct; Ot >>> 0 > Et >>> 0 && 0 == (0 | o[(De = Ot + -4 | 0) >> 2]); ) Ot = De;
                                            if (Be = (0 | o[y >> 2]) - Ce | 0, o[y >> 2] = Be, !((0 | Be) > 0)) {
                                                rt = Et, at = Ot, ge = Be;
                                                break;
                                            }
                                            it = Et, ct = Ot, Oe = Be;
                                        } else rt = ie, at = ke, ge = ye;
                                        if ((0 | ge) < 0) for (Ue = 1 + ((0 | Xt + 25) / 9 & -1) | 0, Fe = 102 == (0 | br), 
                                        Bt = rt, Ft = at, $e = ge; ;) {
                                            if (Ve = (0 | (He = 0 - $e | 0)) < 9 ? He : 9, Bt >>> 0 < Ft >>> 0) {
                                                for (ze = (1 << Ve) - 1 | 0, Ye = 1e9 >>> Ve, I = 0, ot = Bt; We = (Ge = 0 | o[ot >> 2]) & ze, 
                                                Ke = (Ge >>> Ve) + I | 0, o[ot >> 2] = Ke, Xe = 0 | p(We, Ye), (Je = ot + 4 | 0) >>> 0 < Ft >>> 0; ) I = Xe, 
                                                ot = Je;
                                                x = 0 == (0 | o[Bt >> 2]) ? Bt + 4 | 0 : Bt, 0 == (0 | Xe) ? (A = x, Gt = Ft) : (Qe = Ft + 4 | 0, 
                                                o[Ft >> 2] = Xe, A = x, Gt = Qe);
                                            } else A = 0 == (0 | o[Bt >> 2]) ? Bt + 4 | 0 : Bt, Gt = Ft;
                                            if (S = (0 | (Gt - (qe = Fe ? ie : A) | 0) >> 2) > (0 | Ue) ? qe + (Ue << 2) | 0 : Gt, 
                                            Ze = (0 | o[y >> 2]) + Ve | 0, o[y >> 2] = Ze, !((0 | Ze) < 0)) {
                                                Dt = A, Ut = S;
                                                break;
                                            }
                                            Bt = A, Ft = S, $e = Ze;
                                        } else Dt = rt, Ut = at;
                                        if (tn = ie, Dt >>> 0 < Ut >>> 0) if (en = 9 * ((tn - Dt | 0) >> 2) | 0, (nn = 0 | o[Dt >> 2]) >>> 0 < 10) yt = en; else for ($ = en, 
                                        J = 10; ;) {
                                            if (on = $ + 1 | 0, nn >>> 0 < (rn = 10 * J | 0) >>> 0) {
                                                yt = on;
                                                break;
                                            }
                                            $ = on, J = rn;
                                        } else yt = 0;
                                        if ((0 | (un = (Xt - (102 != (0 | br) ? yt : 0) | 0) + (((sn = 0 != (0 | Xt)) & (an = 103 == (0 | br))) << 31 >> 31) | 0)) < (0 | (9 * ((Ut - tn | 0) >> 2) | 0) - 9)) {
                                            if (ln = (ie + 4 | 0) + ((((0 | (cn = un + 9216 | 0)) / 9 & -1) - 1024 | 0) << 2) | 0, 
                                            (0 | (K = 1 + ((0 | cn) % 9 & -1) | 0)) < 9) for (X = K, St = 10; ;) {
                                                if (fn = 10 * St | 0, 9 == (0 | (W = X + 1 | 0))) {
                                                    xt = fn;
                                                    break;
                                                }
                                                X = W, St = fn;
                                            } else xt = 10;
                                            if ((pn = (0 | ln + 4) == (0 | Ut)) & 0 == (0 | (hn = ((dn = 0 | o[ln >> 2]) >>> 0) % (xt >>> 0) & -1))) Yt = ln, 
                                            Wt = yt, de = Dt; else if (Qt = 0 == (0 | (dn >>> 0) / (xt >>> 0) & -1 & 1) ? 9007199254740992 : 9007199254740994, 
                                            T = hn >>> 0 < (_n = (0 | xt) / 2 & -1) >>> 0 ? .5 : pn & (0 | hn) == (0 | _n) ? 1 : 1.5, 
                                            0 == (0 | V) ? (q = T, Z = Qt) : (q = (mn = (0 | r[z >> 0]) << 24 >> 24 == 45) ? -T : T, 
                                            Z = mn ? -Qt : Qt), yn = dn - hn | 0, o[ln >> 2] = yn, Z + q != Z) {
                                                if (gn = yn + xt | 0, o[ln >> 2] = gn, gn >>> 0 > 999999999) for (ee = Dt, we = ln; ;) {
                                                    if (vn = we + -4 | 0, o[we >> 2] = 0, vn >>> 0 < ee >>> 0 ? (o[(bn = ee + -4 | 0) >> 2] = 0, 
                                                    ae = bn) : ae = ee, wn = 1 + (0 | o[vn >> 2]) | 0, o[vn >> 2] = wn, !(wn >>> 0 > 999999999)) {
                                                        te = ae, be = vn;
                                                        break;
                                                    }
                                                    ee = ae, we = vn;
                                                } else te = Dt, be = ln;
                                                if (xn = 9 * ((tn - te | 0) >> 2) | 0, (An = 0 | o[te >> 2]) >>> 0 < 10) Yt = be, 
                                                Wt = xn, de = te; else for (It = xn, Lt = 10; ;) {
                                                    if (Tn = It + 1 | 0, An >>> 0 < (Sn = 10 * Lt | 0) >>> 0) {
                                                        Yt = be, Wt = Tn, de = te;
                                                        break;
                                                    }
                                                    It = Tn, Lt = Sn;
                                                }
                                            } else Yt = ln, Wt = yt, de = Dt;
                                            re = Wt, fe = Ut >>> 0 > (Pn = Yt + 4 | 0) >>> 0 ? Pn : Ut, he = de;
                                        } else re = yt, fe = Ut, he = Dt;
                                        for (ce = fe; ;) {
                                            if (!(ce >>> 0 > he >>> 0)) {
                                                pe = 0;
                                                break;
                                            }
                                            if (0 != (0 | o[(Mn = ce + -4 | 0) >> 2])) {
                                                pe = 1;
                                                break;
                                            }
                                            ce = Mn;
                                        }
                                        kn = 0 - re | 0;
                                        do {
                                            if (an) {
                                                if ((0 | (Jt = (1 & (1 ^ sn)) + Xt | 0)) > (0 | re) & (0 | re) > -5 ? (C = s + -1 | 0, 
                                                kt = (Jt + -1 | 0) - re | 0) : (C = s + -2 | 0, kt = Jt + -1 | 0), 0 == (0 | (En = 8 & a))) {
                                                    if (pe) if (0 == (0 | (On = 0 | o[(ce + -4 | 0) >> 2]))) Rt = 9; else if (0 == (0 | (On >>> 0) % 10 & -1)) for (bt = 0, 
                                                    Ht = 10; ;) {
                                                        if (In = bt + 1 | 0, 0 != (0 | (On >>> 0) % ((Cn = 10 * Ht | 0) >>> 0) & -1)) {
                                                            Rt = In;
                                                            break;
                                                        }
                                                        bt = In, Ht = Cn;
                                                    } else Rt = 0; else Rt = 9;
                                                    if (Ln = (9 * ((ce - tn | 0) >> 2) | 0) - 9 | 0, 102 == (32 | C)) {
                                                        et = C, jt = (0 | kt) < (0 | (qt = (0 | (Nn = Ln - Rt | 0)) > 0 ? Nn : 0)) ? kt : qt, 
                                                        ve = 0;
                                                        break;
                                                    }
                                                    et = C, jt = (0 | kt) < (0 | (Zt = (0 | (jn = (Ln + re | 0) - Rt | 0)) > 0 ? jn : 0)) ? kt : Zt, 
                                                    ve = 0;
                                                    break;
                                                }
                                                et = C, jt = kt, ve = En;
                                            } else et = s, jt = Xt, ve = 8 & a;
                                        } while (0);
                                        if (Bn = 1 & 0 != (0 | (Dn = jt | ve)), Un = 102 == (32 | et)) Ct = 0, me = (0 | re) > 0 ? re : 0; else {
                                            if ((0 | ($n = f) - (Hn = 0 | st(Fn = (0 | re) < 0 ? kn : re, ((0 | Fn) < 0) << 31 >> 31, f))) < 2) for (pt = Hn; ;) {
                                                if (r[(Vn = pt + -1 | 0) >> 0] = 48, !((0 | $n - Vn) < 2)) {
                                                    ht = Vn;
                                                    break;
                                                }
                                                pt = Vn;
                                            } else ht = Hn;
                                            zn = 255 & (43 + (2 & re >> 31) | 0), r[(ht + -1 | 0) >> 0] = zn, Yn = 255 & et, 
                                            r[(Gn = ht + -2 | 0) >> 0] = Yn, Ct = Gn, me = $n - Gn | 0;
                                        }
                                        if (ut(t, 32, n, Kn = (((V + 1 | 0) + jt | 0) + Bn | 0) + me | 0, a), nt(t, z, V), 
                                        ut(t, 48, n, Kn, 65536 ^ a), Un) {
                                            for (Jn = Xn = g + 9 | 0, Qn = g + 8 | 0, ne = j = he >>> 0 > ie >>> 0 ? ie : he; ;) {
                                                if (qn = 0 | st(0 | o[ne >> 2], 0, Xn), (0 | ne) == (0 | j)) (0 | qn) == (0 | Xn) ? (r[Qn >> 0] = 48, 
                                                Q = Qn) : Q = qn; else if (qn >>> 0 > g >>> 0) for (mt(0 | g, 48, 0 | qn - b), E = qn; ;) {
                                                    if (!((Zn = E + -1 | 0) >>> 0 > g >>> 0)) {
                                                        Q = Zn;
                                                        break;
                                                    }
                                                    E = Zn;
                                                } else Q = qn;
                                                if (nt(t, Q, Jn - Q | 0), (tr = ne + 4 | 0) >>> 0 > ie >>> 0) break;
                                                ne = tr;
                                            }
                                            if (0 == (0 | Dn) || nt(t, 4068, 1), tr >>> 0 < ce >>> 0 & (0 | jt) > 0) for (zt = jt, 
                                            se = tr; ;) {
                                                if ((er = 0 | st(0 | o[se >> 2], 0, Xn)) >>> 0 > g >>> 0) for (mt(0 | g, 48, 0 | er - b), 
                                                k = er; ;) {
                                                    if (!((nr = k + -1 | 0) >>> 0 > g >>> 0)) {
                                                        M = nr;
                                                        break;
                                                    }
                                                    k = nr;
                                                } else M = er;
                                                if (nt(t, M, (0 | zt) < 9 ? zt : 9), ir = zt + -9 | 0, !((rr = se + 4 | 0) >>> 0 < ce >>> 0 & (0 | zt) > 9)) {
                                                    Vt = ir;
                                                    break;
                                                }
                                                zt = ir, se = rr;
                                            } else Vt = jt;
                                            ut(t, 48, Vt + 9 | 0, 9, 0);
                                        } else {
                                            if (le = pe ? ce : he + 4 | 0, (0 | jt) > -1) for (sr = 0 == (0 | ve), ur = ar = g + 9 | 0, 
                                            cr = 0 - b | 0, lr = g + 8 | 0, oe = jt, ue = he; ;) {
                                                (0 | (fr = 0 | st(0 | o[ue >> 2], 0, ar))) == (0 | ar) ? (r[lr >> 0] = 48, P = lr) : P = fr, 
                                                dr = (0 | ue) == (0 | he);
                                                do {
                                                    if (dr) {
                                                        if (_r = P + 1 | 0, nt(t, P, 1), sr & (0 | oe) < 1) {
                                                            Pt = _r;
                                                            break;
                                                        }
                                                        nt(t, 4068, 1), Pt = _r;
                                                    } else {
                                                        if (!(P >>> 0 > g >>> 0)) {
                                                            Pt = P;
                                                            break;
                                                        }
                                                        for (mt(0 | g, 48, 0 | P + cr), Tt = P; ;) {
                                                            if (!((pr = Tt + -1 | 0) >>> 0 > g >>> 0)) {
                                                                Pt = pr;
                                                                break;
                                                            }
                                                            Tt = pr;
                                                        }
                                                    }
                                                } while (0);
                                                if (nt(t, Pt, (0 | oe) > (0 | (mr = ur - Pt | 0)) ? mr : oe), !((gr = ue + 4 | 0) >>> 0 < le >>> 0 & (0 | (yr = oe - mr | 0)) > -1)) {
                                                    Kt = yr;
                                                    break;
                                                }
                                                oe = yr, ue = gr;
                                            } else Kt = jt;
                                            ut(t, 48, Kt + 18 | 0, 18, 0), nt(t, Ct, f - Ct | 0);
                                        }
                                        ut(t, 32, n, Kn, 8192 ^ a), xe = Kn;
                                    } else Rn = 0 != (0 | 32 & s), F = O != O | !1 ? Rn ? 4044 : 4048 : Rn ? 4036 : 4040, 
                                    ut(t, 32, n, Wn = V + 3 | 0, -65537 & a), nt(t, z, V), nt(t, F, 3), ut(t, 32, n, Wn, 8192 ^ a), 
                                    xe = Wn;
                                } while (0);
                                return c = w, 0 | ((0 | xe) < (0 | n) ? n : xe);
                            }
                            function ft(t) {
                                var e, n;
                                return t = +t, a[u >> 3] = t, e = 0 | o[u >> 2], n = 0 | o[u + 4 >> 2], h = n, 0 | e;
                            }
                            function dt(t, e) {
                                return + +function t(e, n) {
                                    e = +e, n |= 0;
                                    var r, i, s, c = 0, l = 0, f = 0, d = 0, h = 0;
                                    switch (a[u >> 3] = e, (2047 & (s = 0 | yt(0 | (r = 0 | o[u >> 2]), 0 | (i = 0 | o[u + 4 >> 2]), 52))) << 16 >> 16) {
                                      case 0:
                                        0 != e ? (l = +t(0x10000000000000000 * e, n), h = (0 | o[n >> 2]) - 64 | 0) : (l = e, 
                                        h = 0), o[n >> 2] = h, c = l;
                                        break;

                                      case 2047:
                                        c = e;
                                        break;

                                      default:
                                        f = (2047 & s) - 1022 | 0, o[n >> 2] = f, d = 1071644672 | -2146435073 & i, o[u >> 2] = r, 
                                        o[u + 4 >> 2] = d, c = +a[u >> 3];
                                    }
                                    return +c;
                                }(t = +t, e |= 0);
                            }
                            function ht(t) {
                                var e, n, r = 0, i = 0, a = 0, s = 0, u = 0, c = 0, l = 0, f = 0, d = 0;
                                return (0 | o[(e = 20 + (t |= 0) | 0) >> 2]) >>> 0 > (0 | o[(n = t + 28 | 0) >> 2]) >>> 0 ? (f = 0 | o[(t + 36 | 0) >> 2], 
                                kt[7 & f](t, 0, 0), 0 == (0 | o[e >> 2]) ? r = -1 : d = 3) : d = 3, 3 == (0 | d) && ((a = 0 | o[(i = t + 4 | 0) >> 2]) >>> 0 < (u = 0 | o[(s = t + 8 | 0) >> 2]) >>> 0 && (c = a - u | 0, 
                                l = 0 | o[(t + 40 | 0) >> 2], kt[7 & l](t, c, 1)), o[(t + 16 | 0) >> 2] = 0, o[n >> 2] = 0, 
                                o[e >> 2] = 0, o[s >> 2] = 0, o[i >> 2] = 0, r = 0), 0 | r;
                            }
                            function pt(t, e, n, r) {
                                return 0 | (h = (e |= 0) - (r |= 0) - ((n |= 0) >>> 0 > (t |= 0) >>> 0 | 0) >>> 0, 
                                0 | t - n >>> 0);
                            }
                            function _t(t, e, n, r) {
                                var i;
                                return 0 | (h = (e |= 0) + (r |= 0) + ((i = (t |= 0) + (n |= 0) >>> 0) >>> 0 < t >>> 0 | 0) >>> 0, 
                                0 | i);
                            }
                            function mt(t, e, n) {
                                e |= 0;
                                var i, a = 0, s = 0, u = 0;
                                if (i = (t |= 0) + (n |= 0) | 0, e &= 255, (0 | n) >= 67) {
                                    for (;0 != (3 & t); ) r[t >> 0] = e, t = t + 1 | 0;
                                    for (s = (a = -4 & i | 0) - 64 | 0, u = e | e << 8 | e << 16 | e << 24; (0 | t) <= (0 | s); ) o[t >> 2] = u, 
                                    o[t + 4 >> 2] = u, o[t + 8 >> 2] = u, o[t + 12 >> 2] = u, o[t + 16 >> 2] = u, o[t + 20 >> 2] = u, 
                                    o[t + 24 >> 2] = u, o[t + 28 >> 2] = u, o[t + 32 >> 2] = u, o[t + 36 >> 2] = u, 
                                    o[t + 40 >> 2] = u, o[t + 44 >> 2] = u, o[t + 48 >> 2] = u, o[t + 52 >> 2] = u, 
                                    o[t + 56 >> 2] = u, o[t + 60 >> 2] = u, t = t + 64 | 0;
                                    for (;(0 | t) < (0 | a); ) o[t >> 2] = u, t = t + 4 | 0;
                                }
                                for (;(0 | t) < (0 | i); ) r[t >> 0] = e, t = t + 1 | 0;
                                return i - n | 0;
                            }
                            function yt(t, e, n) {
                                return e |= 0, (0 | (n |= 0)) < 32 ? (h = e >>> n, (t |= 0) >>> n | (e & ((1 << n) - 1 | 0)) << 32 - n) : (h = 0, 
                                e >>> n - 32 | 0);
                            }
                            function gt(t, e, n) {
                                return t |= 0, (0 | (n |= 0)) < 32 ? (h = (e |= 0) << n | (t & ((1 << n) - 1 | 0) << 32 - n) >>> 32 - n, 
                                t << n) : (h = t << n - 32, 0);
                            }
                            function vt(t) {
                                var e = 0;
                                return (0 | (e = 0 | r[f + (255 & (t |= 0)) >> 0])) < 8 ? 0 | e : (0 | (e = 0 | r[f + (t >> 8 & 255) >> 0])) < 8 ? e + 8 | 0 : (0 | (e = 0 | r[f + (t >> 16 & 255) >> 0])) < 8 ? e + 16 | 0 : 24 + (0 | r[f + (t >>> 24) >> 0]) | 0;
                            }
                            function bt(t, e, n, r, i) {
                                i |= 0;
                                var a, s, u, c, l, f, d, p, m, y = 0, g = 0, v = 0, b = 0, w = 0, x = 0, A = 0, S = 0, T = 0, P = 0, M = 0, k = 0, E = 0, O = 0, C = 0, I = 0, R = 0, L = 0, N = 0, j = 0, D = 0, B = 0, U = 0, F = 0, H = 0, $ = 0, V = 0, z = 0, Y = 0, G = 0, W = 0, K = 0, X = 0, J = 0, Q = 0, q = 0, Z = 0, tt = 0, et = 0, nt = 0, rt = 0, it = 0, ot = 0, at = 0, st = 0, ut = 0, ct = 0, lt = 0, ft = 0, dt = 0;
                                if (a = t |= 0, c = n |= 0, f = l = r |= 0, 0 == (0 | (u = s = e |= 0))) return y = 0 != (0 | i), 
                                0 == (0 | f) ? (y && (o[i >> 2] = (a >>> 0) % (c >>> 0), o[i + 4 >> 2] = 0), 0 | (h = dt = 0, 
                                ft = (a >>> 0) / (c >>> 0) >>> 0)) : y ? (o[i >> 2] = -1 & t, o[i + 4 >> 2] = 0 & e, 
                                0 | (h = dt = 0, ft = 0)) : 0 | (h = dt = 0, ft = 0);
                                d = 0 == (0 | f);
                                do {
                                    if (0 == (0 | c)) {
                                        if (d) return 0 != (0 | i) && (o[i >> 2] = (u >>> 0) % (c >>> 0), o[i + 4 >> 2] = 0), 
                                        0 | (h = dt = 0, (u >>> 0) / (c >>> 0) >>> 0);
                                        if (0 == (0 | a)) return 0 != (0 | i) && (o[i >> 2] = 0, o[i + 4 >> 2] = (u >>> 0) % (f >>> 0)), 
                                        0 | (h = dt = 0, (u >>> 0) / (f >>> 0) >>> 0);
                                        if (0 == ((g = f - 1 | 0) & f | 0)) return 0 != (0 | i) && (o[i >> 2] = 0 | -1 & t, 
                                        o[i + 4 >> 2] = g & u | 0 & e), dt = 0, ft = u >>> ((0 | vt(0 | f)) >>> 0), 0 | (h = dt, 
                                        ft);
                                        if ((v = (0 | _(0 | f)) - (0 | _(0 | u)) | 0) >>> 0 <= 30) {
                                            B = b = v + 1 | 0, D = u << (w = 31 - v | 0) | a >>> (b >>> 0), j = u >>> (b >>> 0), 
                                            N = 0, L = a << w;
                                            break;
                                        }
                                        return 0 == (0 | i) || (o[i >> 2] = 0 | -1 & t, o[i + 4 >> 2] = s | 0 & e), 0 | (h = dt = 0, 
                                        0);
                                    }
                                    if (!d) {
                                        if ((O = (0 | _(0 | f)) - (0 | _(0 | u)) | 0) >>> 0 <= 31) {
                                            B = C = O + 1 | 0, D = a >>> (C >>> 0) & (R = O - 31 >> 31) | u << (I = 31 - O | 0), 
                                            j = u >>> (C >>> 0) & R, N = 0, L = a << I;
                                            break;
                                        }
                                        return 0 == (0 | i) || (o[i >> 2] = 0 | -1 & t, o[i + 4 >> 2] = s | 0 & e), 0 | (h = dt = 0, 
                                        0);
                                    }
                                    if (0 != ((x = c - 1 | 0) & c | 0)) {
                                        B = S = (33 + (0 | _(0 | c)) | 0) - (0 | _(0 | u)) | 0, D = (P = 32 - S | 0) - 1 >> 31 & u >>> ((k = S - 32 | 0) >>> 0) | (u << P | a >>> (S >>> 0)) & (E = k >> 31), 
                                        j = E & u >>> (S >>> 0), N = a << (T = 64 - S | 0) & (M = P >> 31), L = (u << T | a >>> (k >>> 0)) & M | a << P & S - 33 >> 31;
                                        break;
                                    }
                                    return 0 != (0 | i) && (o[i >> 2] = x & a, o[i + 4 >> 2] = 0), 1 == (0 | c) ? 0 | (h = dt = s | 0 & e, 
                                    ft = 0 | -1 & t) : (A = 0 | vt(0 | c), 0 | (h = dt = 0 | u >>> (A >>> 0), ft = u << 32 - A | a >>> (A >>> 0) | 0));
                                } while (0);
                                if (0 == (0 | B)) lt = L, ct = N, ut = j, st = D, at = 0, ot = 0; else {
                                    for (H = 0 | _t(0 | (U = 0 | -1 & n), 0 | (F = l | 0 & r), -1, -1), $ = h, K = L, 
                                    W = N, G = j, Y = D, z = B, V = 0; X = W >>> 31 | K << 1, J = V | W << 1, pt(0 | H, 0 | $, 0 | (Q = Y << 1 | K >>> 31 | 0), 0 | (q = Y >>> 31 | G << 1 | 0)), 
                                    et = 1 & (tt = (Z = h) >> 31 | ((0 | Z) < 0 ? -1 : 0) << 1), nt = 0 | pt(0 | Q, 0 | q, tt & U | 0, (((0 | Z) < 0 ? -1 : 0) >> 31 | ((0 | Z) < 0 ? -1 : 0) << 1) & F | 0), 
                                    rt = h, 0 != (0 | (it = z - 1 | 0)); ) K = X, W = J, G = rt, Y = nt, z = it, V = et;
                                    lt = X, ct = J, ut = rt, st = nt, at = 0, ot = et;
                                }
                                return p = ct, m = 0 | lt, 0 != (0 | i) && (o[i >> 2] = 0 | st, o[i + 4 >> 2] = 0 | ut), 
                                0 | (h = dt = (0 | p) >>> 31 | m << 1 | 0 & (0 | p >>> 31) | at, -2 & (p << 1 | 0) | ot);
                            }
                            function wt(t, e, n, r) {
                                return 0 | bt(t |= 0, e |= 0, n |= 0, r |= 0, 0);
                            }
                            function xt(t) {
                                var e, n;
                                return (0 | (t = 15 + (t |= 0) & -16 | 0)) > 0 & (0 | (n = (e = 0 | o[s >> 2]) + t | 0)) < (0 | e) | (0 | n) < 0 ? (g(), 
                                S(12), -1) : (o[s >> 2] = n, (0 | n) > (0 | y()) && 0 == (0 | m()) ? (o[s >> 2] = e, 
                                S(12), -1) : 0 | e);
                            }
                            function At(t, e, n, r) {
                                var i, a;
                                return a = c, c = c + 16 | 0, bt(t |= 0, e |= 0, n |= 0, r |= 0, i = 0 | a), c = a, 
                                0 | (h = 0 | o[i + 4 >> 2], 0 | o[i >> 2]);
                            }
                            function St(t, e, n) {
                                t |= 0, e |= 0;
                                var i, a, s = 0, u = 0;
                                if ((0 | (n |= 0)) >= 8192) return 0 | P(0 | t, 0 | e, 0 | n);
                                if (i = 0 | t, a = t + n | 0, (3 & t) == (3 & e)) {
                                    for (;3 & t; ) {
                                        if (0 == (0 | n)) return 0 | i;
                                        r[t >> 0] = 0 | r[e >> 0], t = t + 1 | 0, e = e + 1 | 0, n = n - 1 | 0;
                                    }
                                    for (u = (s = -4 & a | 0) - 64 | 0; (0 | t) <= (0 | u); ) o[t >> 2] = 0 | o[e >> 2], 
                                    o[t + 4 >> 2] = 0 | o[e + 4 >> 2], o[t + 8 >> 2] = 0 | o[e + 8 >> 2], o[t + 12 >> 2] = 0 | o[e + 12 >> 2], 
                                    o[t + 16 >> 2] = 0 | o[e + 16 >> 2], o[t + 20 >> 2] = 0 | o[e + 20 >> 2], o[t + 24 >> 2] = 0 | o[e + 24 >> 2], 
                                    o[t + 28 >> 2] = 0 | o[e + 28 >> 2], o[t + 32 >> 2] = 0 | o[e + 32 >> 2], o[t + 36 >> 2] = 0 | o[e + 36 >> 2], 
                                    o[t + 40 >> 2] = 0 | o[e + 40 >> 2], o[t + 44 >> 2] = 0 | o[e + 44 >> 2], o[t + 48 >> 2] = 0 | o[e + 48 >> 2], 
                                    o[t + 52 >> 2] = 0 | o[e + 52 >> 2], o[t + 56 >> 2] = 0 | o[e + 56 >> 2], o[t + 60 >> 2] = 0 | o[e + 60 >> 2], 
                                    t = t + 64 | 0, e = e + 64 | 0;
                                    for (;(0 | t) < (0 | s); ) o[t >> 2] = 0 | o[e >> 2], t = t + 4 | 0, e = e + 4 | 0;
                                } else for (s = a - 4 | 0; (0 | t) < (0 | s); ) r[t >> 0] = 0 | r[e >> 0], r[t + 1 >> 0] = 0 | r[e + 1 >> 0], 
                                r[t + 2 >> 0] = 0 | r[e + 2 >> 0], r[t + 3 >> 0] = 0 | r[e + 3 >> 0], t = t + 4 | 0, 
                                e = e + 4 | 0;
                                for (;(0 | t) < (0 | a); ) r[t >> 0] = 0 | r[e >> 0], t = t + 1 | 0, e = e + 1 | 0;
                                return 0 | i;
                            }
                            function Tt(t) {
                                return (255 & (t |= 0)) << 24 | (t >> 8 & 255) << 16 | (t >> 16 & 255) << 8 | t >>> 24 | 0;
                            }
                            function Pt(t, e, n) {
                                return w(1), 0;
                            }
                            var Mt = [ function(t) {
                                return b(0), 0;
                            }, function(t) {
                                var e, n, r, i;
                                return t |= 0, i = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), r = i, e = 0 | function(t) {
                                    return 0 | t;
                                }(0 | o[(t + 60 | 0) >> 2]), o[r >> 2] = e, n = 0 | W(0 | A(6, 0 | r)), c = i, 0 | n;
                            } ], kt = [ Pt, Pt, function(t, e, n) {
                                t |= 0, e |= 0, n |= 0;
                                var i, a, s, u, f = 0, d = 0;
                                return u = c, (0 | (c = c + 32 | 0)) >= (0 | l) && v(32), s = u, a = u + 16 | 0, 
                                o[(t + 36 | 0) >> 2] = 5, 0 == (0 | 64 & (0 | o[t >> 2])) && (d = 0 | o[(t + 60 | 0) >> 2], 
                                f = a, o[s >> 2] = d, o[(s + 4 | 0) >> 2] = 21523, o[(s + 8 | 0) >> 2] = f, 0 == (0 | M(54, 0 | s)) || (r[(t + 75 | 0) >> 0] = -1)), 
                                i = 0 | G(t, e, n), c = u, 0 | i;
                            }, function(t, e, n) {
                                t |= 0, e |= 0, n |= 0;
                                var r, i, a, s, u, f = 0;
                                return u = c, (0 | (c = c + 32 | 0)) >= (0 | l) && v(32), s = u, r = u + 20 | 0, 
                                i = 0 | o[(t + 60 | 0) >> 2], a = r, o[s >> 2] = i, o[(s + 4 | 0) >> 2] = 0, o[(s + 8 | 0) >> 2] = e, 
                                o[(s + 12 | 0) >> 2] = a, o[(s + 16 | 0) >> 2] = n, (0 | W(0 | T(140, 0 | s))) < 0 ? (o[r >> 2] = -1, 
                                f = -1) : f = 0 | o[r >> 2], c = u, 0 | f;
                            }, function(t, e, n) {
                                var r, i, a, s, u, c;
                                return e |= 0, n |= 0, a = 0 | o[(16 + (t |= 0) | 0) >> 2], St(0 | (u = 0 | o[(s = t + 20 | 0) >> 2]), 0 | e, 0 | (r = (c = a - u | 0) >>> 0 > n >>> 0 ? n : c)), 
                                i = (0 | o[s >> 2]) + r | 0, o[s >> 2] = i, 0 | n;
                            }, G, Pt, Pt ];
                            return {
                                _llvm_bswap_i32: Tt,
                                _loadtoken: function(t) {
                                    t |= 0;
                                    var e, n, i, a, s, u, f, d, h, p, _, m, y = 0, g = 0, b = 0, w = 0, x = 0, A = 0;
                                    m = c, (0 | (c = c + 80 | 0)) >= (0 | l) && v(80), s = m + 40 | 0, e = m + 4 | 0, 
                                    i = t, x = 1612, A = 16 + (w = a = m + 56 | 0) | 0;
                                    do {
                                        r[w >> 0] = 0 | r[x >> 0], w = w + 1 | 0, x = x + 1 | 0;
                                    } while ((0 | w) < (0 | A));
                                    x = 1628, A = (w = s) + 16 | 0;
                                    do {
                                        r[w >> 0] = 0 | r[x >> 0], w = w + 1 | 0, x = x + 1 | 0;
                                    } while ((0 | w) < (0 | A));
                                    if (0 == (0 | (d = 0 | z(u = 0 | X(i))))) return c = m, 4832;
                                    if (function(t, e, n) {
                                        t |= 0, e |= 0, n |= 0;
                                        var i, o, a, s, u = 0, f = 0, d = 0, h = 0, p = 0, _ = 0;
                                        for (s = c, (0 | (c = c + 32 | 0)) >= (0 | l) && v(32), i = t, o = e, a = n, h = 0; (0 | h) < (0 | a); ) u = 255 & (p = 0 | V(0 | r[(o + h | 0) >> 0])), 
                                        f = 255 & (_ = 0 | V(0 | r[(o + (h + 1 | 0) | 0) >> 0])), d = 255 & ((255 & (p = (0 | 255 & p) > 57 ? 255 & (u - 55 | 0) : 255 & (u - 48 | 0))) << 4 | 255 & (_ = (0 | 255 & _) > 57 ? 255 & (f - 55 | 0) : 255 & (f - 48 | 0))), 
                                        r[(i + ((0 | h) / 2 & -1) | 0) >> 0] = d, h = h + 2 | 0;
                                        c = s;
                                    }(d, i, u), 0 == (0 | (h = 0 | z(u)))) return c = m, 4832;
                                    for (p = a, _ = s, y = 0; (0 | y) < 16; ) g = 255 & (82 ^ 255 & (0 | r[(a + y | 0) >> 0])), 
                                    r[(p + y | 0) >> 0] = g, b = 255 & (82 ^ 255 & (0 | r[(s + y | 0) >> 0])), r[(_ + y | 0) >> 0] = b, 
                                    y = y + 1 | 0;
                                    return function(t, e, n, i, a) {
                                        t |= 0, e |= 0, n |= 0, i |= 0, a |= 0;
                                        var s, u, f, d, h, p, _, m = 0, y = 0, g = 0, b = 0, w = 0, x = 0, A = 0;
                                        for (_ = c, (0 | (c = c + 32 | 0)) >= (0 | l) && v(32), h = i, p = a, s = ((d = n) >>> 0) % 16 & -1 & 255, 
                                        O(x = t, A = e), u = x, o[1018] = u, 0 != (0 | h) && (y = h, o[1019] = y, function() {
                                            var t, e, n = 0, i = 0, a = 0, s = 0, u = 0, f = 0, d = 0, h = 0, p = 0, _ = 0, m = 0, y = 0, g = 0, b = 0, w = 0, x = 0, A = 0, S = 0, T = 0, P = 0, M = 0, k = 0, E = 0, O = 0, C = 0, I = 0;
                                            for (e = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), t = e + 12 | 0, n = 0; n >>> 0 < 4; ) S = 0 | o[1019], 
                                            s = 0 | r[(S + (0 + (n << 2) | 0) | 0) >> 0], r[(4656 + (0 + (n << 2) | 0) | 0) >> 0] = s, 
                                            p = 0 | o[1019], m = 0 | r[(p + (1 + (n << 2) | 0) | 0) >> 0], r[(4656 + (1 + (n << 2) | 0) | 0) >> 0] = m, 
                                            y = 0 | o[1019], g = 0 | r[(y + (2 + (n << 2) | 0) | 0) >> 0], r[(4656 + (2 + (n << 2) | 0) | 0) >> 0] = g, 
                                            b = 0 | o[1019], w = 0 | r[(b + (3 + (n << 2) | 0) | 0) >> 0], r[(4656 + (3 + (n << 2) | 0) | 0) >> 0] = w, 
                                            n = n + 1 | 0;
                                            for (;n >>> 0 < 44; ) {
                                                for (i = 0; x = n, i >>> 0 < 4; ) A = 0 | r[(4656 + (((x - 1 | 0) << 2) + i | 0) | 0) >> 0], 
                                                r[(t + i | 0) >> 0] = A, i = i + 1 | 0;
                                                0 == (0 | (x >>> 0) % 4 & -1) && (_ = 255 & (0 | r[t >> 0]), T = 0 | r[(t + 1 | 0) >> 0], 
                                                r[t >> 0] = T, P = 0 | r[(t + 2 | 0) >> 0], r[(t + 1 | 0) >> 0] = P, M = 0 | r[(t + 3 | 0) >> 0], 
                                                r[(t + 2 | 0) >> 0] = M, k = 255 & _, r[(t + 3 | 0) >> 0] = k, E = 0 | R(0 | r[t >> 0]), 
                                                r[t >> 0] = E, O = 0 | R(0 | r[(t + 1 | 0) >> 0]), r[(t + 1 | 0) >> 0] = O, C = 0 | R(0 | r[(t + 2 | 0) >> 0]), 
                                                r[(t + 2 | 0) >> 0] = C, I = 0 | R(0 | r[(t + 3 | 0) >> 0]), r[(t + 3 | 0) >> 0] = I, 
                                                a = 255 & (255 & (0 | r[t >> 0]) ^ 255 & (0 | r[(504 + ((n >>> 0) / 4 & -1) | 0) >> 0])), 
                                                r[t >> 0] = a), u = 255 & (255 & (0 | r[(4656 + (0 + ((n - 4 | 0) << 2) | 0) | 0) >> 0]) ^ 255 & (0 | r[t >> 0])), 
                                                r[(4656 + (0 + (n << 2) | 0) | 0) >> 0] = u, f = 255 & (255 & (0 | r[(4656 + (1 + ((n - 4 | 0) << 2) | 0) | 0) >> 0]) ^ 255 & (0 | r[(t + 1 | 0) >> 0])), 
                                                r[(4656 + (1 + (n << 2) | 0) | 0) >> 0] = f, d = 255 & (255 & (0 | r[(4656 + (2 + ((n - 4 | 0) << 2) | 0) | 0) >> 0]) ^ 255 & (0 | r[(t + 2 | 0) >> 0])), 
                                                r[(4656 + (2 + (n << 2) | 0) | 0) >> 0] = d, h = 255 & (255 & (0 | r[(4656 + (3 + ((n - 4 | 0) << 2) | 0) | 0) >> 0]) ^ 255 & (0 | r[(t + 3 | 0) >> 0])), 
                                                r[(4656 + (3 + (n << 2) | 0) | 0) >> 0] = h, n = n + 1 | 0;
                                            }
                                            c = e;
                                        }()), 0 != (0 | p) && (g = p, o[1020] = g), m = 0; m >>> 0 < d >>> 0; ) O(x, A), 
                                        b = x, o[1018] = b, C(), I(x), w = A, o[1020] = w, A = A + 16 | 0, x = x + 16 | 0, 
                                        m = m + 16 | 0;
                                        s << 24 >> 24 != 0 ? (O(x, A), mt(0 | x + (255 & s), 0, 0 | 16 - (255 & s)), f = x, 
                                        o[1018] = f, C(), c = _) : c = _;
                                    }(h, d, u, p, _), o[e >> 2] = 0, f = 0 | function(t, e, n) {
                                        t |= 0, e |= 0, n |= 0;
                                        var i, a, s, u, f, d, h = 0, p = 0, _ = 0, m = 0, y = 0, g = 0, b = 0, w = 0, x = 0, A = 0, S = 0, T = 0, P = 0, M = 0, k = 0, E = 0, O = 0, C = 0, I = 0, R = 0, L = 0, N = 0, j = 0, D = 0, B = 0, U = 0, F = 0, H = 0, $ = 0, V = 0, Y = 0, G = 0, W = 0;
                                        if (d = c, (0 | (c = c + 80 | 0)) >= (0 | l) && v(80), s = n, u = t, Y = 0, g = 0, 
                                        (0 | (a = e)) < 2) return o[s >> 2] = 0, c = d, 0;
                                        if (61 == (0 | 255 & (0 | r[(u + (a - 1 | 0) | 0) >> 0])) && (g = g + 1 | 0), 61 == (0 | 255 & (0 | r[(u + (a - 2 | 0) | 0) >> 0])) && (g = g + 1 | 0), 
                                        i = ((0 | 3 * a) / 4 & -1) - g | 0, o[s >> 2] = i, 0 == (0 | (f = 0 | z(0 | o[s >> 2])))) return c = d, 
                                        0;
                                        for (_ = 0; (0 | _) <= (0 | (a - 4 | 0) - g); ) H = 0 | r[(u + _ | 0) >> 0], A = 255 & (0 | r[(1335 + (255 & H) | 0) >> 0]), 
                                        $ = 0 | r[(u + (_ + 1 | 0) | 0) >> 0], T = 255 & (0 | r[(1335 + (255 & $) | 0) >> 0]), 
                                        V = 0 | r[(u + (_ + 2 | 0) | 0) >> 0], M = 255 & (0 | r[(1335 + (255 & V) | 0) >> 0]), 
                                        G = 0 | r[(u + (_ + 3 | 0) | 0) >> 0], O = 255 & (0 | r[(1335 + (255 & G) | 0) >> 0]), 
                                        m = 255 & (A << 2 | T >> 4), Y = (y = Y) + 1 | 0, r[(f + y | 0) >> 0] = m, b = 255 & (T << 4 | M >> 2), 
                                        Y = (w = Y) + 1 | 0, r[(f + w | 0) >> 0] = b, x = 255 & (M << 6 | O), Y = (S = Y) + 1 | 0, 
                                        r[(f + S | 0) >> 0] = x, _ = _ + 4 | 0;
                                        return 1 == (0 | g) ? (P = 0 | r[(u + _ | 0) >> 0], I = 255 & (0 | r[(1335 + (255 & P) | 0) >> 0]), 
                                        k = 0 | r[(u + (_ + 1 | 0) | 0) >> 0], L = 255 & (0 | r[(1335 + (255 & k) | 0) >> 0]), 
                                        E = 0 | r[(u + (_ + 2 | 0) | 0) >> 0], D = 255 & (0 | r[(1335 + (255 & E) | 0) >> 0]), 
                                        C = 255 & (I << 2 | L >> 4), Y = (R = Y) + 1 | 0, r[(f + R | 0) >> 0] = C, Y = (N = Y) + 1 | 0, 
                                        h = 255 & (L << 4 | D >> 2), p = f + N | 0, W = 16) : 2 == (0 | g) && (j = 0 | r[(u + _ | 0) >> 0], 
                                        U = 255 & (0 | r[(1335 + (255 & j) | 0) >> 0]), B = 0 | r[(u + (_ + 1 | 0) | 0) >> 0], 
                                        Y = (F = Y) + 1 | 0, h = 255 & (U << 2 | (255 & (0 | r[(1335 + (255 & B) | 0) >> 0])) >> 4), 
                                        p = f + F | 0, W = 16), 16 == (0 | W) && (r[p >> 0] = h), c = d, 0 | f;
                                    }(h, u, e), n = f, Y(h), Y(d), c = m, 0 | n;
                                },
                                _i64Subtract: pt,
                                ___udivdi3: wt,
                                setThrew: function(t, e) {
                                    0 == (0 | d) && (d = t |= 0);
                                },
                                _bitshift64Lshr: yt,
                                _bitshift64Shl: gt,
                                _fflush: function t(e) {
                                    var n, r = 0, i = 0, a = 0, s = 0, u = 0, c = 0, l = 0, f = 0, d = 0;
                                    n = 0 == (0 | (e |= 0));
                                    do {
                                        if (n) {
                                            if (d = 0 == (0 | o[94]) ? 0 : 0 | t(0 | o[94]), f = 0 | (x(4644), 4652), 0 == (0 | (a = 0 | o[f >> 2]))) u = d; else for (s = a, 
                                            c = d; ;) {
                                                if (o[(s + 76 | 0) >> 2], l = (0 | o[(s + 20 | 0) >> 2]) >>> 0 > (0 | o[(s + 28 | 0) >> 2]) >>> 0 ? 0 | ht(s) | c : c, 
                                                0 == (0 | (i = 0 | o[(s + 56 | 0) >> 2]))) {
                                                    u = l;
                                                    break;
                                                }
                                                s = i, c = l;
                                            }
                                            k(4644), r = u;
                                        } else {
                                            if (!((0 | o[(e + 76 | 0) >> 2]) > -1)) {
                                                r = 0 | ht(e);
                                                break;
                                            }
                                            r = 0 | ht(e);
                                        }
                                    } while (0);
                                    return 0 | r;
                                },
                                ___errno_location: K,
                                _memset: mt,
                                _sbrk: xt,
                                _memcpy: St,
                                stackAlloc: function(t) {
                                    var e;
                                    return e = c, (0 | (c = 15 + (c = c + (t |= 0) | 0) & -16)) >= (0 | l) && v(0 | t), 
                                    0 | e;
                                },
                                ___uremdi3: At,
                                getTempRet0: function() {
                                    return 0 | h;
                                },
                                setTempRet0: function(t) {
                                    h = t |= 0;
                                },
                                _i64Add: _t,
                                dynCall_iiii: function(t, e, n, r) {
                                    return e |= 0, n |= 0, r |= 0, 0 | kt[7 & (t |= 0)](0 | e, 0 | n, 0 | r);
                                },
                                _emscripten_get_global_libc: function() {
                                    return 4580;
                                },
                                dynCall_ii: function(t, e) {
                                    return e |= 0, 0 | Mt[1 & (t |= 0)](0 | e);
                                },
                                stackSave: function() {
                                    return 0 | c;
                                },
                                _free: Y,
                                runPostSets: function() {},
                                _getsign: function(t, e, n) {
                                    t |= 0, e |= 0, n |= 0;
                                    var i, a, s, u, f, d, h, p, _, m, y, g = 0, b = 0, w = 0, x = 0, A = 0, S = 0, T = 0, P = 0, M = 0, k = 0;
                                    y = c, (0 | (c = c + 176 | 0)) >= (0 | l) && v(176), m = y, i = y + 16 | 0, a = y + 136 | 0, 
                                    u = t, f = e, d = n, M = 1591, k = 16 + (P = h = y + 152 | 0) | 0;
                                    do {
                                        r[P >> 0] = 0 | r[M >> 0], P = P + 1 | 0, M = M + 1 | 0;
                                    } while ((0 | P) < (0 | k));
                                    if (0 == (0 | (_ = 0 | z(p = 16 + (((0 | X(u)) + (0 | X(f)) | 0) + (0 | X(d)) | 0) | 0)))) return c = y, 
                                    0;
                                    for (g = 0, St(0 | _, 0 | u, 0 | X(u)), St(0 | _ + (g = g + (0 | X(u)) | 0), 0 | f, 0 | X(f)), 
                                    St(0 | _ + (g = g + (0 | X(f)) | 0), 0 | d, 0 | X(d)), g = g + (0 | X(d)) | 0, b = 0; (0 | b) < 16; ) A = 255 & (82 ^ 255 & (0 | r[(h + b | 0) >> 0])), 
                                    r[(h + b | 0) >> 0] = A, b = b + 1 | 0;
                                    M = h, k = 16 + (P = _ + g | 0) | 0;
                                    do {
                                        r[P >> 0] = 0 | r[M >> 0], P = P + 1 | 0, M = M + 1 | 0;
                                    } while ((0 | P) < (0 | k));
                                    !function(t) {
                                        var e, n;
                                        t |= 0, n = c, (0 | (c = c + 16 | 0)) >= (0 | l) && v(16), o[(e = t) >> 2] = 0, 
                                        o[(e + 4 | 0) >> 2] = 0, o[(e + 8 | 0) >> 2] = 1732584193, o[(4 + (e + 8 | 0) | 0) >> 2] = -271733879, 
                                        o[(8 + (e + 8 | 0) | 0) >> 2] = -1732584194, o[(12 + (e + 8 | 0) | 0) >> 2] = 271733878, 
                                        c = n;
                                    }(i), F(i, _, p), function(t, e, n) {
                                        var r, i, a, s, u, f;
                                        t |= 0, e |= 0, f = c, (0 | (c = c + 32 | 0)) >= (0 | l) && v(32), u = f + 24 | 0, 
                                        i = e, s = ((a = 63 & (0 | o[(r = t) >> 2]) >>> 3) >>> 0 < 56 ? 56 : 120) - a | 0, 
                                        $(u, r, 8), F(r, 1271, s), F(r, u, 8), $(i, r + 8 | 0, 16), c = f;
                                    }(i, a), k = 33 + (P = s = 0 | z(33)) | 0;
                                    do {
                                        r[P >> 0] = 0, P = P + 1 | 0;
                                    } while ((0 | P) < (0 | k));
                                    for (w = s, x = 0; (0 | x) < 16; ) S = w, T = 255 & (0 | r[(a + x | 0) >> 0]), o[m >> 2] = T, 
                                    tt(S, 1607, m), w = w + 2 | 0, x = x + 1 | 0;
                                    return Y(_), c = y, 0 | s;
                                },
                                establishStackSpace: function(t, e) {
                                    c = t |= 0, l = e |= 0;
                                },
                                stackRestore: function(t) {
                                    c = t |= 0;
                                },
                                _malloc: z
                            };
                        }(Module.asmGlobalArg, Module.asmLibraryArg, buffer), real__llvm_bswap_i32 = asm._llvm_bswap_i32;
                        asm._llvm_bswap_i32 = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real__llvm_bswap_i32.apply(null, arguments);
                        };
                        var real__loadtoken = asm._loadtoken;
                        asm._loadtoken = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real__loadtoken.apply(null, arguments);
                        };
                        var real_getTempRet0 = asm.getTempRet0;
                        asm.getTempRet0 = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real_getTempRet0.apply(null, arguments);
                        };
                        var real____udivdi3 = asm.___udivdi3;
                        asm.___udivdi3 = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real____udivdi3.apply(null, arguments);
                        };
                        var real_setThrew = asm.setThrew;
                        asm.setThrew = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real_setThrew.apply(null, arguments);
                        };
                        var real__bitshift64Lshr = asm._bitshift64Lshr;
                        asm._bitshift64Lshr = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real__bitshift64Lshr.apply(null, arguments);
                        };
                        var real__bitshift64Shl = asm._bitshift64Shl;
                        asm._bitshift64Shl = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real__bitshift64Shl.apply(null, arguments);
                        };
                        var real__fflush = asm._fflush;
                        asm._fflush = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real__fflush.apply(null, arguments);
                        };
                        var real__sbrk = asm._sbrk;
                        asm._sbrk = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real__sbrk.apply(null, arguments);
                        };
                        var real____errno_location = asm.___errno_location;
                        asm.___errno_location = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real____errno_location.apply(null, arguments);
                        };
                        var real____uremdi3 = asm.___uremdi3;
                        asm.___uremdi3 = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real____uremdi3.apply(null, arguments);
                        };
                        var real_stackAlloc = asm.stackAlloc;
                        asm.stackAlloc = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real_stackAlloc.apply(null, arguments);
                        };
                        var real__i64Subtract = asm._i64Subtract;
                        asm._i64Subtract = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real__i64Subtract.apply(null, arguments);
                        };
                        var real_setTempRet0 = asm.setTempRet0;
                        asm.setTempRet0 = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real_setTempRet0.apply(null, arguments);
                        };
                        var real__i64Add = asm._i64Add;
                        asm._i64Add = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real__i64Add.apply(null, arguments);
                        };
                        var real__emscripten_get_global_libc = asm._emscripten_get_global_libc;
                        asm._emscripten_get_global_libc = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real__emscripten_get_global_libc.apply(null, arguments);
                        };
                        var real_stackSave = asm.stackSave;
                        asm.stackSave = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real_stackSave.apply(null, arguments);
                        };
                        var real__free = asm._free;
                        asm._free = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real__free.apply(null, arguments);
                        };
                        var real__getsign = asm._getsign;
                        asm._getsign = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real__getsign.apply(null, arguments);
                        };
                        var real_establishStackSpace = asm.establishStackSpace;
                        asm.establishStackSpace = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real_establishStackSpace.apply(null, arguments);
                        };
                        var real_stackRestore = asm.stackRestore;
                        asm.stackRestore = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real_stackRestore.apply(null, arguments);
                        };
                        var real__malloc = asm._malloc;
                        asm._malloc = function() {
                            return assert(runtimeInitialized, "you need to wait for the runtime to be ready (e.g. wait for main() to be called)"), 
                            assert(!runtimeExited, "the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)"), 
                            real__malloc.apply(null, arguments);
                        };
                        var _llvm_bswap_i32 = Module._llvm_bswap_i32 = asm._llvm_bswap_i32, _loadtoken = Module._loadtoken = asm._loadtoken, getTempRet0 = Module.getTempRet0 = asm.getTempRet0, ___udivdi3 = Module.___udivdi3 = asm.___udivdi3, setThrew = Module.setThrew = asm.setThrew, _bitshift64Lshr = Module._bitshift64Lshr = asm._bitshift64Lshr, _bitshift64Shl = Module._bitshift64Shl = asm._bitshift64Shl, _fflush = Module._fflush = asm._fflush, _memset = Module._memset = asm._memset, _sbrk = Module._sbrk = asm._sbrk, _memcpy = Module._memcpy = asm._memcpy, ___errno_location = Module.___errno_location = asm.___errno_location, ___uremdi3 = Module.___uremdi3 = asm.___uremdi3, stackAlloc = Module.stackAlloc = asm.stackAlloc, _i64Subtract = Module._i64Subtract = asm._i64Subtract, setTempRet0 = Module.setTempRet0 = asm.setTempRet0, _i64Add = Module._i64Add = asm._i64Add, _emscripten_get_global_libc = Module._emscripten_get_global_libc = asm._emscripten_get_global_libc, stackSave = Module.stackSave = asm.stackSave, _free = Module._free = asm._free, runPostSets = Module.runPostSets = asm.runPostSets, _getsign = Module._getsign = asm._getsign, establishStackSpace = Module.establishStackSpace = asm.establishStackSpace, stackRestore = Module.stackRestore = asm.stackRestore, _malloc = Module._malloc = asm._malloc, dynCall_ii = Module.dynCall_ii = asm.dynCall_ii, dynCall_iiii = Module.dynCall_iiii = asm.dynCall_iiii, initialStackTop;
                        function ExitStatus(t) {
                            this.name = "ExitStatus", this.message = "Program terminated with exit(" + t + ")", 
                            this.status = t;
                        }
                        Runtime.stackAlloc = Module.stackAlloc, Runtime.stackSave = Module.stackSave, Runtime.stackRestore = Module.stackRestore, 
                        Runtime.establishStackSpace = Module.establishStackSpace, Runtime.setTempRet0 = Module.setTempRet0, 
                        Runtime.getTempRet0 = Module.getTempRet0, Module.asm = asm, ExitStatus.prototype = new Error(), 
                        ExitStatus.prototype.constructor = ExitStatus;
                        var preloadStartTime = null, calledMain = !1;
                        function run(t) {
                            function e() {
                                Module.calledRun || (Module.calledRun = !0, ABORT || (ensureInitRuntime(), preMain(), 
                                ENVIRONMENT_IS_WEB && null !== preloadStartTime && Module.printErr("pre-main prep time: " + (Date.now() - preloadStartTime) + " ms"), 
                                Module.onRuntimeInitialized && Module.onRuntimeInitialized(), Module._main && shouldRunNow && Module.callMain(t), 
                                postRun()));
                            }
                            t = t || Module.arguments, null === preloadStartTime && (preloadStartTime = Date.now()), 
                            runDependencies > 0 || (writeStackCookie(), preRun(), runDependencies > 0 || Module.calledRun || (Module.setStatus ? (Module.setStatus("Running..."), 
                            setTimeout(function() {
                                setTimeout(function() {
                                    Module.setStatus("");
                                }, 1), e();
                            }, 1)) : e(), checkStackCookie()));
                        }
                        function exit(t, e) {
                            e && Module.noExitRuntime ? Module.printErr("exit(" + t + ") implicitly called by end of main(), but noExitRuntime, so not exiting the runtime (you can use emscripten_force_exit, if you want to force a true shutdown)") : (Module.noExitRuntime ? Module.printErr("exit(" + t + ") called, but noExitRuntime, so halting execution but not exiting the runtime or preventing further async execution (you can use emscripten_force_exit, if you want to force a true shutdown)") : (ABORT = !0, 
                            EXITSTATUS = t, STACKTOP = initialStackTop, exitRuntime(), Module.onExit && Module.onExit(t)), 
                            ENVIRONMENT_IS_NODE && process.exit(t), Module.quit(t, new ExitStatus(t)));
                        }
                        dependenciesFulfilled = function t() {
                            Module.calledRun || run(), Module.calledRun || (dependenciesFulfilled = t);
                        }, Module.callMain = Module.callMain = function(t) {
                            assert(0 == runDependencies, "cannot call main when async dependencies remain! (listen on __ATMAIN__)"), 
                            assert(0 == __ATPRERUN__.length, "cannot call main when preRun functions remain to be called"), 
                            t = t || [], ensureInitRuntime();
                            var e = t.length + 1;
                            function n() {
                                for (var t = 0; t < 3; t++) r.push(0);
                            }
                            var r = [ allocate(intArrayFromString(Module.thisProgram), "i8", ALLOC_NORMAL) ];
                            n();
                            for (var i = 0; i < e - 1; i += 1) r.push(allocate(intArrayFromString(t[i]), "i8", ALLOC_NORMAL)), 
                            n();
                            r.push(0), r = allocate(r, "i32", ALLOC_NORMAL);
                            try {
                                exit(Module._main(e, r, 0), !0);
                            } catch (t) {
                                if (t instanceof ExitStatus) return;
                                if ("SimulateInfiniteLoop" == t) return void (Module.noExitRuntime = !0);
                                var o = t;
                                t && "object" == _typeof(t) && t.stack && (o = [ t, t.stack ]), Module.printErr("exception thrown: " + o), 
                                Module.quit(1, t);
                            } finally {
                                calledMain = !0;
                            }
                        }, Module.run = Module.run = run, Module.exit = Module.exit = exit;
                        var abortDecorators = [];
                        function abort(t) {
                            Module.onAbort && Module.onAbort(t), void 0 !== t ? (Module.print(t), Module.printErr(t), 
                            t = JSON.stringify(t)) : t = "", ABORT = !0, EXITSTATUS = 1;
                            var e = "abort(" + t + ") at " + stackTrace();
                            throw abortDecorators && abortDecorators.forEach(function(n) {
                                e = n(e, t);
                            }), e;
                        }
                        if (Module.abort = Module.abort = abort, Module.preInit) for ("function" == typeof Module.preInit && (Module.preInit = [ Module.preInit ]); Module.preInit.length > 0; ) Module.preInit.pop()();
                        var shouldRunNow = !0;
                        Module.noInitialRun && (shouldRunNow = !1), run(), module.exports = Module;
                    }).call(this, __webpack_require__(6));
                }, function(t, e) {
                    var n = {
                        utf8: {
                            stringToBytes: function(t) {
                                return n.bin.stringToBytes(unescape(encodeURIComponent(t)));
                            },
                            bytesToString: function(t) {
                                return decodeURIComponent(escape(n.bin.bytesToString(t)));
                            }
                        },
                        bin: {
                            stringToBytes: function(t) {
                                for (var e = [], n = 0; n < t.length; n++) e.push(255 & t.charCodeAt(n));
                                return e;
                            },
                            bytesToString: function(t) {
                                for (var e = [], n = 0; n < t.length; n++) e.push(String.fromCharCode(t[n]));
                                return e.join("");
                            }
                        }
                    };
                    t.exports = n;
                }, function(t, e) {
                    var n;
                    n = function() {
                        return this;
                    }();
                    try {
                        n = n || Function("return this")() || (0, eval)("this");
                    } catch (t) {
                        "object" == ("undefined" == typeof window ? "undefined" : _typeof(window)) && (n = window);
                    }
                    t.exports = n;
                }, function(t, e, n) {
                    !function() {
                        var e = n(7), r = n(2).utf8, i = n(8), o = n(2).bin, a = function t(n, a) {
                            n.constructor == String ? n = a && "binary" === a.encoding ? o.stringToBytes(n) : r.stringToBytes(n) : i(n) ? n = Array.prototype.slice.call(n, 0) : Array.isArray(n) || (n = n.toString());
                            for (var s = e.bytesToWords(n), u = 8 * n.length, c = 1732584193, l = -271733879, f = -1732584194, d = 271733878, h = 0; h < s.length; h++) s[h] = 16711935 & (s[h] << 8 | s[h] >>> 24) | 4278255360 & (s[h] << 24 | s[h] >>> 8);
                            s[u >>> 5] |= 128 << u % 32, s[14 + (u + 64 >>> 9 << 4)] = u;
                            var p = t._ff, _ = t._gg, m = t._hh, y = t._ii;
                            for (h = 0; h < s.length; h += 16) {
                                var g = c, v = l, b = f, w = d;
                                l = y(l = y(l = y(l = y(l = m(l = m(l = m(l = m(l = _(l = _(l = _(l = _(l = p(l = p(l = p(l = p(l, f = p(f, d = p(d, c = p(c, l, f, d, s[h + 0], 7, -680876936), l, f, s[h + 1], 12, -389564586), c, l, s[h + 2], 17, 606105819), d, c, s[h + 3], 22, -1044525330), f = p(f, d = p(d, c = p(c, l, f, d, s[h + 4], 7, -176418897), l, f, s[h + 5], 12, 1200080426), c, l, s[h + 6], 17, -1473231341), d, c, s[h + 7], 22, -45705983), f = p(f, d = p(d, c = p(c, l, f, d, s[h + 8], 7, 1770035416), l, f, s[h + 9], 12, -1958414417), c, l, s[h + 10], 17, -42063), d, c, s[h + 11], 22, -1990404162), f = p(f, d = p(d, c = p(c, l, f, d, s[h + 12], 7, 1804603682), l, f, s[h + 13], 12, -40341101), c, l, s[h + 14], 17, -1502002290), d, c, s[h + 15], 22, 1236535329), f = _(f, d = _(d, c = _(c, l, f, d, s[h + 1], 5, -165796510), l, f, s[h + 6], 9, -1069501632), c, l, s[h + 11], 14, 643717713), d, c, s[h + 0], 20, -373897302), f = _(f, d = _(d, c = _(c, l, f, d, s[h + 5], 5, -701558691), l, f, s[h + 10], 9, 38016083), c, l, s[h + 15], 14, -660478335), d, c, s[h + 4], 20, -405537848), f = _(f, d = _(d, c = _(c, l, f, d, s[h + 9], 5, 568446438), l, f, s[h + 14], 9, -1019803690), c, l, s[h + 3], 14, -187363961), d, c, s[h + 8], 20, 1163531501), f = _(f, d = _(d, c = _(c, l, f, d, s[h + 13], 5, -1444681467), l, f, s[h + 2], 9, -51403784), c, l, s[h + 7], 14, 1735328473), d, c, s[h + 12], 20, -1926607734), f = m(f, d = m(d, c = m(c, l, f, d, s[h + 5], 4, -378558), l, f, s[h + 8], 11, -2022574463), c, l, s[h + 11], 16, 1839030562), d, c, s[h + 14], 23, -35309556), f = m(f, d = m(d, c = m(c, l, f, d, s[h + 1], 4, -1530992060), l, f, s[h + 4], 11, 1272893353), c, l, s[h + 7], 16, -155497632), d, c, s[h + 10], 23, -1094730640), f = m(f, d = m(d, c = m(c, l, f, d, s[h + 13], 4, 681279174), l, f, s[h + 0], 11, -358537222), c, l, s[h + 3], 16, -722521979), d, c, s[h + 6], 23, 76029189), f = m(f, d = m(d, c = m(c, l, f, d, s[h + 9], 4, -640364487), l, f, s[h + 12], 11, -421815835), c, l, s[h + 15], 16, 530742520), d, c, s[h + 2], 23, -995338651), f = y(f, d = y(d, c = y(c, l, f, d, s[h + 0], 6, -198630844), l, f, s[h + 7], 10, 1126891415), c, l, s[h + 14], 15, -1416354905), d, c, s[h + 5], 21, -57434055), f = y(f, d = y(d, c = y(c, l, f, d, s[h + 12], 6, 1700485571), l, f, s[h + 3], 10, -1894986606), c, l, s[h + 10], 15, -1051523), d, c, s[h + 1], 21, -2054922799), f = y(f, d = y(d, c = y(c, l, f, d, s[h + 8], 6, 1873313359), l, f, s[h + 15], 10, -30611744), c, l, s[h + 6], 15, -1560198380), d, c, s[h + 13], 21, 1309151649), f = y(f, d = y(d, c = y(c, l, f, d, s[h + 4], 6, -145523070), l, f, s[h + 11], 10, -1120210379), c, l, s[h + 2], 15, 718787259), d, c, s[h + 9], 21, -343485551), 
                                c = c + g >>> 0, l = l + v >>> 0, f = f + b >>> 0, d = d + w >>> 0;
                            }
                            return e.endian([ c, l, f, d ]);
                        };
                        a._ff = function(t, e, n, r, i, o, a) {
                            var s = t + (e & n | ~e & r) + (i >>> 0) + a;
                            return (s << o | s >>> 32 - o) + e;
                        }, a._gg = function(t, e, n, r, i, o, a) {
                            var s = t + (e & r | n & ~r) + (i >>> 0) + a;
                            return (s << o | s >>> 32 - o) + e;
                        }, a._hh = function(t, e, n, r, i, o, a) {
                            var s = t + (e ^ n ^ r) + (i >>> 0) + a;
                            return (s << o | s >>> 32 - o) + e;
                        }, a._ii = function(t, e, n, r, i, o, a) {
                            var s = t + (n ^ (e | ~r)) + (i >>> 0) + a;
                            return (s << o | s >>> 32 - o) + e;
                        }, a._blocksize = 16, a._digestsize = 16, t.exports = function(t, n) {
                            if (null == t) throw new Error("Illegal argument " + t);
                            var r = e.wordsToBytes(a(t, n));
                            return n && n.asBytes ? r : n && n.asString ? o.bytesToString(r) : e.bytesToHex(r);
                        };
                    }();
                }, function(t, e, n) {
                    n.r(e);
                    var r = n(1), i = n.n(r), o = n(4), a = n.n(o), s = n(0), u = {
                        version: "v1.7.0",
                        buidMetaData: 20181120,
                        jsonHost: "https://router.polyv.net/secure/",
                        isPreviewMode: !1,
                        isWx: !1,
                        token: "",
                        seed: 0,
                        state: "end",
                        timeStamp: 0,
                        time: 0,
                        currentTime: 0,
                        detailTime: 0,
                        videoId: "",
                        pid: "",
                        uid: "",
                        flow: 0,
                        pd: 0,
                        sd: 0,
                        cts: 0,
                        duration: 0,
                        pn: "",
                        pv: "",
                        sign: "",
                        sessionId: "",
                        param1: "",
                        param2: "",
                        param3: "",
                        param4: "",
                        param5: "",
                        useAudio: !1,
                        getVideo: function(t) {
                            this.loadJson(t);
                        },
                        getPreviewVideo: function(t) {
                            this.isPreviewMode = !0, this.loadJson(t);
                        },
                        loadJson: function(t) {
                            var e = this.version, n = {
                                version: e,
                                timeoutflow: !1,
                                outflow: !1
                            };
                            if ("" == t.vid) return n = {
                                version: e,
                                error: "vid不能为空"
                            }, void t.callback(n);
                            var r = new Date().getTime() + "X" + Math.floor(1e6 * Math.random() + 1e6), i = t.vid.substr(0, 10), o = this;
                            o.videoId = t.vid, o.ts = t.ts, o.sign = t.sign, o.uid = i, o.pid = r, o.time = 0, 
                            o.version = n.version, t.params && (t.params.param1 && (o.param1 = t.params.param1), 
                            t.params.param2 && (o.param2 = t.params.param2), t.params.param3 && (o.param3 = t.params.param3), 
                            t.params.param4 && (o.param4 = t.params.param4), t.params.param5 && (o.param5 = t.params.param5)), 
                            t.sid && (o.sessionId = t.sid), t.useAudio && (o.useAudio = t.useAudio), wx.request({
                                url: o.jsonHost + t.vid + ".js",
                                method: "GET",
                                success: function(e) {
                                    "true" == e.data.timeoutflow ? n.timeoutflow = !0 : "true" == e.data.outflow ? n.outflow = !0 : (n.poster = e.data.first_image, 
                                    n.title = e.data.title, n.teaser_url = e.data.teaser_url, n.catatree = e.data.catatree, 
                                    n.adMatter = e.data.adMatter, n.ratio = e.data.ratio, n.duration = e.data.duration, 
                                    n.poster = o.proxy(n.poster), n.teaser_url = o.proxy(n.teaser_url), n.adMatter = o.proxy(n.adMatter, "matterurl"), 
                                    o.seed = e.data.seed, 1 == e.data.seed ? n.src = o.proxy(e.data.hls) : n.src = o.proxy(e.data.mp4), 
                                    o.useAudio && e.data.aac_link && e.data.aac_link.length > 0 && (n.src = [ e.data.aac_link ]), 
                                    o.duration = e.data.duration), 1 === o.seed && t.wxApp && t.wxApp.isWx ? (o.isWx = !0, 
                                    o.getWxToken(t, function(r) {
                                        o.token = r;
                                        for (var i = 0; i < e.data.hls.length; i++) t.hlstest ? n.src[i] = o.resetUrl(e.data.hls[i]).replace("hls.", "hlstest.") : n.src[i] = o.resetUrl(e.data.hls[i]);
                                        t.callback(n);
                                    }, function() {
                                        n = {
                                            error: "播放token获取失败"
                                        }, t.callback(n);
                                    })) : t.callback(n), o.countInterval && clearInterval(o.countInterval), o.countInterval = setInterval(function() {
                                        o.countWholeTime();
                                    }, 1e3);
                                },
                                fail: function(e) {
                                    n = {
                                        error: "视频数据获取失败"
                                    }, t.callback(n);
                                }
                            });
                        },
                        getWxToken: function(t, e) {
                            var n = t.wxApp.wxAppUrl, r = new Date().getTime(), o = i.a.ccall("getsign", "string", [ "string", "string", "string" ], [ t.wxApp.wxUserId, t.vid, r.toString() ]), a = t.wxApp;
                            a.iswxa = 1, a.vid = t.vid, a.ts = r, a.sign = o, wx.request({
                                url: n,
                                method: "GET",
                                data: a,
                                success: function(t) {
                                    var n = i.a.ccall("loadtoken", "string", [ "string" ], [ t.data ]);
                                    e(JSON.parse(n).data.token);
                                },
                                fail: function() {}
                            });
                        },
                        timeUpdate: function(t) {
                            t && t.detail && t.detail.currentTime && (this.detailTime = t.detail.currentTime), 
                            this.useAudio && (this.detailTime = t);
                        },
                        updateState: function() {
                            this.currentTime == this.detailTime ? this.state = "end" : (this.state = "played", 
                            this.currentTime = this.detailTime);
                        },
                        countWholeTime: function() {
                            var t = new Date().getTime();
                            this.updateState(), "played" == this.state && (this.time += 1), t - this.timeStamp > 9e3 && (this.timeStamp = t, 
                            this.sendState());
                        },
                        sendState: function() {
                            var t, e;
                            if (e = Math.floor(this.currentTime), (t = this.time) > 0 && "played" == this.state) {
                                new Date().getTime();
                                var n = "rtas.net" + this.pid + this.videoId + this.flow + t + e, r = a()(n), i = this.sessionId, o = {
                                    pid: this.pid,
                                    uid: this.uid,
                                    vid: this.videoId,
                                    flow: 0,
                                    pd: t,
                                    sd: t,
                                    cts: e,
                                    duration: this.duration,
                                    pn: "webapp_vod",
                                    pv: this.version,
                                    sign: r,
                                    sid: s.Base64.encode(i),
                                    param1: s.Base64.encode(this.param1),
                                    param2: s.Base64.encode(this.param2),
                                    param3: s.Base64.encode(this.param3),
                                    param4: s.Base64.encode(this.param4),
                                    param5: s.Base64.encode(this.param5)
                                };
                                wx.request({
                                    url: "https://prtas.videocc.net/v2/view",
                                    data: o
                                });
                            }
                        },
                        proxy: function(t, e) {
                            if (void 0 === t || 0 == t.length) return "";
                            if ("string" == typeof t) return t = this.resetUrl(t), this.proxyUrl(t);
                            if (arguments[1]) for (var n = 0, r = t.length; n < r; n++) for (var i in t[n]) i == e && (t[n][i] = this.proxyUrl(t[n][i])); else for (n = 0, 
                            r = t.length; n < r; n++) {
                                if (this.isPreviewMode) {
                                    var o = this.videoId.substring(0, 32);
                                    t[n] = t[n].replace(o, "p_" + o);
                                }
                                this.ts && this.sign && (t[n].indexOf("?") > -1 ? t[n] = t[n] + "&ts=" + this.ts + "&sign=" + this.sign : t[n] = t[n] + "?ts=" + this.ts + "&sign=" + this.sign);
                            }
                            return t;
                        },
                        proxyUrl: function(t) {
                            return "" == t ? t : "https://router.polyv.net/proxy/" + (t = t.replace(/.*?:\/\//g, ""));
                        },
                        resetUrl: function(t) {
                            if (this.isPreviewMode && 1 == this.seed) {
                                var e = this.videoId.substring(0, 32);
                                t = t.replace(e, "p_" + e);
                            }
                            return this.ts && this.sign && (t = t.indexOf("?") > -1 ? t + "&ts=" + this.ts + "&sign=" + this.sign : t + "?ts=" + this.ts + "&sign=" + this.sign), 
                            this.isWx && (t = t.indexOf("?") > -1 ? t + "&token=" + this.token + "&iswxa=1&pid=" + this.pid : t + "?token=" + this.token + "&iswxa=1&pid=" + this.pid), 
                            t;
                        },
                        destroy: function() {
                            this.countInterval && clearInterval(this.countInterval);
                        }
                    };
                    e.default = u;
                }, function(t, e) {
                    var n, r, i = t.exports = {};
                    function o() {
                        throw new Error("setTimeout has not been defined");
                    }
                    function a() {
                        throw new Error("clearTimeout has not been defined");
                    }
                    function s(t) {
                        if (n === setTimeout) return setTimeout(t, 0);
                        if ((n === o || !n) && setTimeout) return n = setTimeout, setTimeout(t, 0);
                        try {
                            return n(t, 0);
                        } catch (e) {
                            try {
                                return n.call(null, t, 0);
                            } catch (e) {
                                return n.call(this, t, 0);
                            }
                        }
                    }
                    !function() {
                        try {
                            n = "function" == typeof setTimeout ? setTimeout : o;
                        } catch (t) {
                            n = o;
                        }
                        try {
                            r = "function" == typeof clearTimeout ? clearTimeout : a;
                        } catch (t) {
                            r = a;
                        }
                    }();
                    var u, c = [], l = !1, f = -1;
                    function d() {
                        l && u && (l = !1, u.length ? c = u.concat(c) : f = -1, c.length && h());
                    }
                    function h() {
                        if (!l) {
                            var t = s(d);
                            l = !0;
                            for (var e = c.length; e; ) {
                                for (u = c, c = []; ++f < e; ) u && u[f].run();
                                f = -1, e = c.length;
                            }
                            u = null, l = !1, function(t) {
                                if (r === clearTimeout) return clearTimeout(t);
                                if ((r === a || !r) && clearTimeout) return r = clearTimeout, clearTimeout(t);
                                try {
                                    r(t);
                                } catch (e) {
                                    try {
                                        return r.call(null, t);
                                    } catch (e) {
                                        return r.call(this, t);
                                    }
                                }
                            }(t);
                        }
                    }
                    function p(t, e) {
                        this.fun = t, this.array = e;
                    }
                    function _() {}
                    i.nextTick = function(t) {
                        var e = new Array(arguments.length - 1);
                        if (arguments.length > 1) for (var n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
                        c.push(new p(t, e)), 1 !== c.length || l || s(h);
                    }, p.prototype.run = function() {
                        this.fun.apply(null, this.array);
                    }, i.title = "browser", i.browser = !0, i.env = {}, i.argv = [], i.version = "", 
                    i.versions = {}, i.on = _, i.addListener = _, i.once = _, i.off = _, i.removeListener = _, 
                    i.removeAllListeners = _, i.emit = _, i.prependListener = _, i.prependOnceListener = _, 
                    i.listeners = function(t) {
                        return [];
                    }, i.binding = function(t) {
                        throw new Error("process.binding is not supported");
                    }, i.cwd = function() {
                        return "/";
                    }, i.chdir = function(t) {
                        throw new Error("process.chdir is not supported");
                    }, i.umask = function() {
                        return 0;
                    };
                }, function(t, e) {
                    !function() {
                        var e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", n = {
                            rotl: function(t, e) {
                                return t << e | t >>> 32 - e;
                            },
                            rotr: function(t, e) {
                                return t << 32 - e | t >>> e;
                            },
                            endian: function(t) {
                                if (t.constructor == Number) return 16711935 & n.rotl(t, 8) | 4278255360 & n.rotl(t, 24);
                                for (var e = 0; e < t.length; e++) t[e] = n.endian(t[e]);
                                return t;
                            },
                            randomBytes: function(t) {
                                for (var e = []; t > 0; t--) e.push(Math.floor(256 * Math.random()));
                                return e;
                            },
                            bytesToWords: function(t) {
                                for (var e = [], n = 0, r = 0; n < t.length; n++, r += 8) e[r >>> 5] |= t[n] << 24 - r % 32;
                                return e;
                            },
                            wordsToBytes: function(t) {
                                for (var e = [], n = 0; n < 32 * t.length; n += 8) e.push(t[n >>> 5] >>> 24 - n % 32 & 255);
                                return e;
                            },
                            bytesToHex: function(t) {
                                for (var e = [], n = 0; n < t.length; n++) e.push((t[n] >>> 4).toString(16)), e.push((15 & t[n]).toString(16));
                                return e.join("");
                            },
                            hexToBytes: function(t) {
                                for (var e = [], n = 0; n < t.length; n += 2) e.push(parseInt(t.substr(n, 2), 16));
                                return e;
                            },
                            bytesToBase64: function(t) {
                                for (var n = [], r = 0; r < t.length; r += 3) for (var i = t[r] << 16 | t[r + 1] << 8 | t[r + 2], o = 0; o < 4; o++) 8 * r + 6 * o <= 8 * t.length ? n.push(e.charAt(i >>> 6 * (3 - o) & 63)) : n.push("=");
                                return n.join("");
                            },
                            base64ToBytes: function(t) {
                                t = t.replace(/[^A-Z0-9+\/]/gi, "");
                                for (var n = [], r = 0, i = 0; r < t.length; i = ++r % 4) 0 != i && n.push((e.indexOf(t.charAt(r - 1)) & Math.pow(2, -2 * i + 8) - 1) << 2 * i | e.indexOf(t.charAt(r)) >>> 6 - 2 * i);
                                return n;
                            }
                        };
                        t.exports = n;
                    }();
                }, function(t, e) {
                    function n(t) {
                        return !!t.constructor && "function" == typeof t.constructor.isBuffer && t.constructor.isBuffer(t);
                    }
                    t.exports = function(t) {
                        return null != t && (n(t) || function(t) {
                            return "function" == typeof t.readFloatLE && "function" == typeof t.slice && n(t.slice(0, 0));
                        }(t) || !!t._isBuffer);
                    };
                }, function(t, e, n) {
                    (function(t) {
                        var r = n(10), i = n(11), o = n(12);
                        function a() {
                            return u.TYPED_ARRAY_SUPPORT ? 2147483647 : 1073741823;
                        }
                        function s(t, e) {
                            if (a() < e) throw new RangeError("Invalid typed array length");
                            return u.TYPED_ARRAY_SUPPORT ? (t = new Uint8Array(e)).__proto__ = u.prototype : (null === t && (t = new u(e)), 
                            t.length = e), t;
                        }
                        function u(t, e, n) {
                            if (!(u.TYPED_ARRAY_SUPPORT || this instanceof u)) return new u(t, e, n);
                            if ("number" == typeof t) {
                                if ("string" == typeof e) throw new Error("If encoding is specified then the first argument must be a string");
                                return f(this, t);
                            }
                            return c(this, t, e, n);
                        }
                        function c(t, e, n, r) {
                            if ("number" == typeof e) throw new TypeError('"value" argument must not be a number');
                            return "undefined" != typeof ArrayBuffer && e instanceof ArrayBuffer ? function(t, e, n, r) {
                                if (e.byteLength, n < 0 || e.byteLength < n) throw new RangeError("'offset' is out of bounds");
                                if (e.byteLength < n + (r || 0)) throw new RangeError("'length' is out of bounds");
                                return e = void 0 === n && void 0 === r ? new Uint8Array(e) : void 0 === r ? new Uint8Array(e, n) : new Uint8Array(e, n, r), 
                                u.TYPED_ARRAY_SUPPORT ? (t = e).__proto__ = u.prototype : t = d(t, e), t;
                            }(t, e, n, r) : "string" == typeof e ? function(t, e, n) {
                                if ("string" == typeof n && "" !== n || (n = "utf8"), !u.isEncoding(n)) throw new TypeError('"encoding" must be a valid string encoding');
                                var r = 0 | p(e, n), i = (t = s(t, r)).write(e, n);
                                return i !== r && (t = t.slice(0, i)), t;
                            }(t, e, n) : function(t, e) {
                                if (u.isBuffer(e)) {
                                    var n = 0 | h(e.length);
                                    return 0 === (t = s(t, n)).length || e.copy(t, 0, 0, n), t;
                                }
                                if (e) {
                                    if ("undefined" != typeof ArrayBuffer && e.buffer instanceof ArrayBuffer || "length" in e) return "number" != typeof e.length || function(t) {
                                        return t != t;
                                    }(e.length) ? s(t, 0) : d(t, e);
                                    if ("Buffer" === e.type && o(e.data)) return d(t, e.data);
                                }
                                throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.");
                            }(t, e);
                        }
                        function l(t) {
                            if ("number" != typeof t) throw new TypeError('"size" argument must be a number');
                            if (t < 0) throw new RangeError('"size" argument must not be negative');
                        }
                        function f(t, e) {
                            if (l(e), t = s(t, e < 0 ? 0 : 0 | h(e)), !u.TYPED_ARRAY_SUPPORT) for (var n = 0; n < e; ++n) t[n] = 0;
                            return t;
                        }
                        function d(t, e) {
                            var n = e.length < 0 ? 0 : 0 | h(e.length);
                            t = s(t, n);
                            for (var r = 0; r < n; r += 1) t[r] = 255 & e[r];
                            return t;
                        }
                        function h(t) {
                            if (t >= a()) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + a().toString(16) + " bytes");
                            return 0 | t;
                        }
                        function p(t, e) {
                            if (u.isBuffer(t)) return t.length;
                            if ("undefined" != typeof ArrayBuffer && "function" == typeof ArrayBuffer.isView && (ArrayBuffer.isView(t) || t instanceof ArrayBuffer)) return t.byteLength;
                            "string" != typeof t && (t = "" + t);
                            var n = t.length;
                            if (0 === n) return 0;
                            for (var r = !1; ;) switch (e) {
                              case "ascii":
                              case "latin1":
                              case "binary":
                                return n;

                              case "utf8":
                              case "utf-8":
                              case void 0:
                                return F(t).length;

                              case "ucs2":
                              case "ucs-2":
                              case "utf16le":
                              case "utf-16le":
                                return 2 * n;

                              case "hex":
                                return n >>> 1;

                              case "base64":
                                return H(t).length;

                              default:
                                if (r) return F(t).length;
                                e = ("" + e).toLowerCase(), r = !0;
                            }
                        }
                        function _(t, e, n) {
                            var r = t[e];
                            t[e] = t[n], t[n] = r;
                        }
                        function m(t, e, n, r, i) {
                            if (0 === t.length) return -1;
                            if ("string" == typeof n ? (r = n, n = 0) : n > 2147483647 ? n = 2147483647 : n < -2147483648 && (n = -2147483648), 
                            n = +n, isNaN(n) && (n = i ? 0 : t.length - 1), n < 0 && (n = t.length + n), n >= t.length) {
                                if (i) return -1;
                                n = t.length - 1;
                            } else if (n < 0) {
                                if (!i) return -1;
                                n = 0;
                            }
                            if ("string" == typeof e && (e = u.from(e, r)), u.isBuffer(e)) return 0 === e.length ? -1 : y(t, e, n, r, i);
                            if ("number" == typeof e) return e &= 255, u.TYPED_ARRAY_SUPPORT && "function" == typeof Uint8Array.prototype.indexOf ? i ? Uint8Array.prototype.indexOf.call(t, e, n) : Uint8Array.prototype.lastIndexOf.call(t, e, n) : y(t, [ e ], n, r, i);
                            throw new TypeError("val must be string, number or Buffer");
                        }
                        function y(t, e, n, r, i) {
                            var o, a = 1, s = t.length, u = e.length;
                            if (void 0 !== r && ("ucs2" === (r = String(r).toLowerCase()) || "ucs-2" === r || "utf16le" === r || "utf-16le" === r)) {
                                if (t.length < 2 || e.length < 2) return -1;
                                a = 2, s /= 2, u /= 2, n /= 2;
                            }
                            function c(t, e) {
                                return 1 === a ? t[e] : t.readUInt16BE(e * a);
                            }
                            if (i) {
                                var l = -1;
                                for (o = n; o < s; o++) if (c(t, o) === c(e, -1 === l ? 0 : o - l)) {
                                    if (-1 === l && (l = o), o - l + 1 === u) return l * a;
                                } else -1 !== l && (o -= o - l), l = -1;
                            } else for (n + u > s && (n = s - u), o = n; o >= 0; o--) {
                                for (var f = !0, d = 0; d < u; d++) if (c(t, o + d) !== c(e, d)) {
                                    f = !1;
                                    break;
                                }
                                if (f) return o;
                            }
                            return -1;
                        }
                        function g(t, e, n, r) {
                            n = Number(n) || 0;
                            var i = t.length - n;
                            r ? (r = Number(r)) > i && (r = i) : r = i;
                            var o = e.length;
                            if (o % 2 != 0) throw new TypeError("Invalid hex string");
                            r > o / 2 && (r = o / 2);
                            for (var a = 0; a < r; ++a) {
                                var s = parseInt(e.substr(2 * a, 2), 16);
                                if (isNaN(s)) return a;
                                t[n + a] = s;
                            }
                            return a;
                        }
                        function v(t, e, n, r) {
                            return $(F(e, t.length - n), t, n, r);
                        }
                        function b(t, e, n, r) {
                            return $(function(t) {
                                for (var e = [], n = 0; n < t.length; ++n) e.push(255 & t.charCodeAt(n));
                                return e;
                            }(e), t, n, r);
                        }
                        function w(t, e, n, r) {
                            return b(t, e, n, r);
                        }
                        function x(t, e, n, r) {
                            return $(H(e), t, n, r);
                        }
                        function A(t, e, n, r) {
                            return $(function(t, e) {
                                for (var n, r, i, o = [], a = 0; a < t.length && !((e -= 2) < 0); ++a) r = (n = t.charCodeAt(a)) >> 8, 
                                i = n % 256, o.push(i), o.push(r);
                                return o;
                            }(e, t.length - n), t, n, r);
                        }
                        function S(t, e, n) {
                            return 0 === e && n === t.length ? r.fromByteArray(t) : r.fromByteArray(t.slice(e, n));
                        }
                        function T(t, e, n) {
                            n = Math.min(t.length, n);
                            for (var r = [], i = e; i < n; ) {
                                var o, a, s, u, c = t[i], l = null, f = c > 239 ? 4 : c > 223 ? 3 : c > 191 ? 2 : 1;
                                if (i + f <= n) switch (f) {
                                  case 1:
                                    c < 128 && (l = c);
                                    break;

                                  case 2:
                                    128 == (192 & (o = t[i + 1])) && (u = (31 & c) << 6 | 63 & o) > 127 && (l = u);
                                    break;

                                  case 3:
                                    o = t[i + 1], a = t[i + 2], 128 == (192 & o) && 128 == (192 & a) && (u = (15 & c) << 12 | (63 & o) << 6 | 63 & a) > 2047 && (u < 55296 || u > 57343) && (l = u);
                                    break;

                                  case 4:
                                    o = t[i + 1], a = t[i + 2], s = t[i + 3], 128 == (192 & o) && 128 == (192 & a) && 128 == (192 & s) && (u = (15 & c) << 18 | (63 & o) << 12 | (63 & a) << 6 | 63 & s) > 65535 && u < 1114112 && (l = u);
                                }
                                null === l ? (l = 65533, f = 1) : l > 65535 && (l -= 65536, r.push(l >>> 10 & 1023 | 55296), 
                                l = 56320 | 1023 & l), r.push(l), i += f;
                            }
                            return function(t) {
                                var e = t.length;
                                if (e <= P) return String.fromCharCode.apply(String, t);
                                for (var n = "", r = 0; r < e; ) n += String.fromCharCode.apply(String, t.slice(r, r += P));
                                return n;
                            }(r);
                        }
                        e.Buffer = u, e.SlowBuffer = function(t) {
                            return +t != t && (t = 0), u.alloc(+t);
                        }, e.INSPECT_MAX_BYTES = 50, u.TYPED_ARRAY_SUPPORT = void 0 !== t.TYPED_ARRAY_SUPPORT ? t.TYPED_ARRAY_SUPPORT : function() {
                            try {
                                var t = new Uint8Array(1);
                                return t.__proto__ = {
                                    __proto__: Uint8Array.prototype,
                                    foo: function() {
                                        return 42;
                                    }
                                }, 42 === t.foo() && "function" == typeof t.subarray && 0 === t.subarray(1, 1).byteLength;
                            } catch (t) {
                                return !1;
                            }
                        }(), e.kMaxLength = a(), u.poolSize = 8192, u._augment = function(t) {
                            return t.__proto__ = u.prototype, t;
                        }, u.from = function(t, e, n) {
                            return c(null, t, e, n);
                        }, u.TYPED_ARRAY_SUPPORT && (u.prototype.__proto__ = Uint8Array.prototype, u.__proto__ = Uint8Array, 
                        "undefined" != typeof Symbol && Symbol.species && u[Symbol.species] === u && Object.defineProperty(u, Symbol.species, {
                            value: null,
                            configurable: !0
                        })), u.alloc = function(t, e, n) {
                            return function(t, e, n, r) {
                                return l(e), e <= 0 ? s(t, e) : void 0 !== n ? "string" == typeof r ? s(t, e).fill(n, r) : s(t, e).fill(n) : s(t, e);
                            }(null, t, e, n);
                        }, u.allocUnsafe = function(t) {
                            return f(null, t);
                        }, u.allocUnsafeSlow = function(t) {
                            return f(null, t);
                        }, u.isBuffer = function(t) {
                            return !(null == t || !t._isBuffer);
                        }, u.compare = function(t, e) {
                            if (!u.isBuffer(t) || !u.isBuffer(e)) throw new TypeError("Arguments must be Buffers");
                            if (t === e) return 0;
                            for (var n = t.length, r = e.length, i = 0, o = Math.min(n, r); i < o; ++i) if (t[i] !== e[i]) {
                                n = t[i], r = e[i];
                                break;
                            }
                            return n < r ? -1 : r < n ? 1 : 0;
                        }, u.isEncoding = function(t) {
                            switch (String(t).toLowerCase()) {
                              case "hex":
                              case "utf8":
                              case "utf-8":
                              case "ascii":
                              case "latin1":
                              case "binary":
                              case "base64":
                              case "ucs2":
                              case "ucs-2":
                              case "utf16le":
                              case "utf-16le":
                                return !0;

                              default:
                                return !1;
                            }
                        }, u.concat = function(t, e) {
                            if (!o(t)) throw new TypeError('"list" argument must be an Array of Buffers');
                            if (0 === t.length) return u.alloc(0);
                            var n;
                            if (void 0 === e) for (e = 0, n = 0; n < t.length; ++n) e += t[n].length;
                            var r = u.allocUnsafe(e), i = 0;
                            for (n = 0; n < t.length; ++n) {
                                var a = t[n];
                                if (!u.isBuffer(a)) throw new TypeError('"list" argument must be an Array of Buffers');
                                a.copy(r, i), i += a.length;
                            }
                            return r;
                        }, u.byteLength = p, u.prototype._isBuffer = !0, u.prototype.swap16 = function() {
                            var t = this.length;
                            if (t % 2 != 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
                            for (var e = 0; e < t; e += 2) _(this, e, e + 1);
                            return this;
                        }, u.prototype.swap32 = function() {
                            var t = this.length;
                            if (t % 4 != 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
                            for (var e = 0; e < t; e += 4) _(this, e, e + 3), _(this, e + 1, e + 2);
                            return this;
                        }, u.prototype.swap64 = function() {
                            var t = this.length;
                            if (t % 8 != 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
                            for (var e = 0; e < t; e += 8) _(this, e, e + 7), _(this, e + 1, e + 6), _(this, e + 2, e + 5), 
                            _(this, e + 3, e + 4);
                            return this;
                        }, u.prototype.toString = function() {
                            var t = 0 | this.length;
                            return 0 === t ? "" : 0 === arguments.length ? T(this, 0, t) : function(t, e, n) {
                                var r = !1;
                                if ((void 0 === e || e < 0) && (e = 0), e > this.length) return "";
                                if ((void 0 === n || n > this.length) && (n = this.length), n <= 0) return "";
                                if ((n >>>= 0) <= (e >>>= 0)) return "";
                                for (t || (t = "utf8"); ;) switch (t) {
                                  case "hex":
                                    return E(this, e, n);

                                  case "utf8":
                                  case "utf-8":
                                    return T(this, e, n);

                                  case "ascii":
                                    return M(this, e, n);

                                  case "latin1":
                                  case "binary":
                                    return k(this, e, n);

                                  case "base64":
                                    return S(this, e, n);

                                  case "ucs2":
                                  case "ucs-2":
                                  case "utf16le":
                                  case "utf-16le":
                                    return O(this, e, n);

                                  default:
                                    if (r) throw new TypeError("Unknown encoding: " + t);
                                    t = (t + "").toLowerCase(), r = !0;
                                }
                            }.apply(this, arguments);
                        }, u.prototype.equals = function(t) {
                            if (!u.isBuffer(t)) throw new TypeError("Argument must be a Buffer");
                            return this === t || 0 === u.compare(this, t);
                        }, u.prototype.inspect = function() {
                            var t = "", n = e.INSPECT_MAX_BYTES;
                            return this.length > 0 && (t = this.toString("hex", 0, n).match(/.{2}/g).join(" "), 
                            this.length > n && (t += " ... ")), "<Buffer " + t + ">";
                        }, u.prototype.compare = function(t, e, n, r, i) {
                            if (!u.isBuffer(t)) throw new TypeError("Argument must be a Buffer");
                            if (void 0 === e && (e = 0), void 0 === n && (n = t ? t.length : 0), void 0 === r && (r = 0), 
                            void 0 === i && (i = this.length), e < 0 || n > t.length || r < 0 || i > this.length) throw new RangeError("out of range index");
                            if (r >= i && e >= n) return 0;
                            if (r >= i) return -1;
                            if (e >= n) return 1;
                            if (this === t) return 0;
                            for (var o = (i >>>= 0) - (r >>>= 0), a = (n >>>= 0) - (e >>>= 0), s = Math.min(o, a), c = this.slice(r, i), l = t.slice(e, n), f = 0; f < s; ++f) if (c[f] !== l[f]) {
                                o = c[f], a = l[f];
                                break;
                            }
                            return o < a ? -1 : a < o ? 1 : 0;
                        }, u.prototype.includes = function(t, e, n) {
                            return -1 !== this.indexOf(t, e, n);
                        }, u.prototype.indexOf = function(t, e, n) {
                            return m(this, t, e, n, !0);
                        }, u.prototype.lastIndexOf = function(t, e, n) {
                            return m(this, t, e, n, !1);
                        }, u.prototype.write = function(t, e, n, r) {
                            if (void 0 === e) r = "utf8", n = this.length, e = 0; else if (void 0 === n && "string" == typeof e) r = e, 
                            n = this.length, e = 0; else {
                                if (!isFinite(e)) throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
                                e |= 0, isFinite(n) ? (n |= 0, void 0 === r && (r = "utf8")) : (r = n, n = void 0);
                            }
                            var i = this.length - e;
                            if ((void 0 === n || n > i) && (n = i), t.length > 0 && (n < 0 || e < 0) || e > this.length) throw new RangeError("Attempt to write outside buffer bounds");
                            r || (r = "utf8");
                            for (var o = !1; ;) switch (r) {
                              case "hex":
                                return g(this, t, e, n);

                              case "utf8":
                              case "utf-8":
                                return v(this, t, e, n);

                              case "ascii":
                                return b(this, t, e, n);

                              case "latin1":
                              case "binary":
                                return w(this, t, e, n);

                              case "base64":
                                return x(this, t, e, n);

                              case "ucs2":
                              case "ucs-2":
                              case "utf16le":
                              case "utf-16le":
                                return A(this, t, e, n);

                              default:
                                if (o) throw new TypeError("Unknown encoding: " + r);
                                r = ("" + r).toLowerCase(), o = !0;
                            }
                        }, u.prototype.toJSON = function() {
                            return {
                                type: "Buffer",
                                data: Array.prototype.slice.call(this._arr || this, 0)
                            };
                        };
                        var P = 4096;
                        function M(t, e, n) {
                            var r = "";
                            n = Math.min(t.length, n);
                            for (var i = e; i < n; ++i) r += String.fromCharCode(127 & t[i]);
                            return r;
                        }
                        function k(t, e, n) {
                            var r = "";
                            n = Math.min(t.length, n);
                            for (var i = e; i < n; ++i) r += String.fromCharCode(t[i]);
                            return r;
                        }
                        function E(t, e, n) {
                            var r = t.length;
                            (!e || e < 0) && (e = 0), (!n || n < 0 || n > r) && (n = r);
                            for (var i = "", o = e; o < n; ++o) i += U(t[o]);
                            return i;
                        }
                        function O(t, e, n) {
                            for (var r = t.slice(e, n), i = "", o = 0; o < r.length; o += 2) i += String.fromCharCode(r[o] + 256 * r[o + 1]);
                            return i;
                        }
                        function C(t, e, n) {
                            if (t % 1 != 0 || t < 0) throw new RangeError("offset is not uint");
                            if (t + e > n) throw new RangeError("Trying to access beyond buffer length");
                        }
                        function I(t, e, n, r, i, o) {
                            if (!u.isBuffer(t)) throw new TypeError('"buffer" argument must be a Buffer instance');
                            if (e > i || e < o) throw new RangeError('"value" argument is out of bounds');
                            if (n + r > t.length) throw new RangeError("Index out of range");
                        }
                        function R(t, e, n, r) {
                            e < 0 && (e = 65535 + e + 1);
                            for (var i = 0, o = Math.min(t.length - n, 2); i < o; ++i) t[n + i] = (e & 255 << 8 * (r ? i : 1 - i)) >>> 8 * (r ? i : 1 - i);
                        }
                        function L(t, e, n, r) {
                            e < 0 && (e = 4294967295 + e + 1);
                            for (var i = 0, o = Math.min(t.length - n, 4); i < o; ++i) t[n + i] = e >>> 8 * (r ? i : 3 - i) & 255;
                        }
                        function N(t, e, n, r, i, o) {
                            if (n + r > t.length) throw new RangeError("Index out of range");
                            if (n < 0) throw new RangeError("Index out of range");
                        }
                        function j(t, e, n, r, o) {
                            return o || N(t, 0, n, 4), i.write(t, e, n, r, 23, 4), n + 4;
                        }
                        function D(t, e, n, r, o) {
                            return o || N(t, 0, n, 8), i.write(t, e, n, r, 52, 8), n + 8;
                        }
                        u.prototype.slice = function(t, e) {
                            var n, r = this.length;
                            if ((t = ~~t) < 0 ? (t += r) < 0 && (t = 0) : t > r && (t = r), (e = void 0 === e ? r : ~~e) < 0 ? (e += r) < 0 && (e = 0) : e > r && (e = r), 
                            e < t && (e = t), u.TYPED_ARRAY_SUPPORT) (n = this.subarray(t, e)).__proto__ = u.prototype; else {
                                var i = e - t;
                                n = new u(i, void 0);
                                for (var o = 0; o < i; ++o) n[o] = this[o + t];
                            }
                            return n;
                        }, u.prototype.readUIntLE = function(t, e, n) {
                            t |= 0, e |= 0, n || C(t, e, this.length);
                            for (var r = this[t], i = 1, o = 0; ++o < e && (i *= 256); ) r += this[t + o] * i;
                            return r;
                        }, u.prototype.readUIntBE = function(t, e, n) {
                            t |= 0, e |= 0, n || C(t, e, this.length);
                            for (var r = this[t + --e], i = 1; e > 0 && (i *= 256); ) r += this[t + --e] * i;
                            return r;
                        }, u.prototype.readUInt8 = function(t, e) {
                            return e || C(t, 1, this.length), this[t];
                        }, u.prototype.readUInt16LE = function(t, e) {
                            return e || C(t, 2, this.length), this[t] | this[t + 1] << 8;
                        }, u.prototype.readUInt16BE = function(t, e) {
                            return e || C(t, 2, this.length), this[t] << 8 | this[t + 1];
                        }, u.prototype.readUInt32LE = function(t, e) {
                            return e || C(t, 4, this.length), (this[t] | this[t + 1] << 8 | this[t + 2] << 16) + 16777216 * this[t + 3];
                        }, u.prototype.readUInt32BE = function(t, e) {
                            return e || C(t, 4, this.length), 16777216 * this[t] + (this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3]);
                        }, u.prototype.readIntLE = function(t, e, n) {
                            t |= 0, e |= 0, n || C(t, e, this.length);
                            for (var r = this[t], i = 1, o = 0; ++o < e && (i *= 256); ) r += this[t + o] * i;
                            return r >= (i *= 128) && (r -= Math.pow(2, 8 * e)), r;
                        }, u.prototype.readIntBE = function(t, e, n) {
                            t |= 0, e |= 0, n || C(t, e, this.length);
                            for (var r = e, i = 1, o = this[t + --r]; r > 0 && (i *= 256); ) o += this[t + --r] * i;
                            return o >= (i *= 128) && (o -= Math.pow(2, 8 * e)), o;
                        }, u.prototype.readInt8 = function(t, e) {
                            return e || C(t, 1, this.length), 128 & this[t] ? -1 * (255 - this[t] + 1) : this[t];
                        }, u.prototype.readInt16LE = function(t, e) {
                            e || C(t, 2, this.length);
                            var n = this[t] | this[t + 1] << 8;
                            return 32768 & n ? 4294901760 | n : n;
                        }, u.prototype.readInt16BE = function(t, e) {
                            e || C(t, 2, this.length);
                            var n = this[t + 1] | this[t] << 8;
                            return 32768 & n ? 4294901760 | n : n;
                        }, u.prototype.readInt32LE = function(t, e) {
                            return e || C(t, 4, this.length), this[t] | this[t + 1] << 8 | this[t + 2] << 16 | this[t + 3] << 24;
                        }, u.prototype.readInt32BE = function(t, e) {
                            return e || C(t, 4, this.length), this[t] << 24 | this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3];
                        }, u.prototype.readFloatLE = function(t, e) {
                            return e || C(t, 4, this.length), i.read(this, t, !0, 23, 4);
                        }, u.prototype.readFloatBE = function(t, e) {
                            return e || C(t, 4, this.length), i.read(this, t, !1, 23, 4);
                        }, u.prototype.readDoubleLE = function(t, e) {
                            return e || C(t, 8, this.length), i.read(this, t, !0, 52, 8);
                        }, u.prototype.readDoubleBE = function(t, e) {
                            return e || C(t, 8, this.length), i.read(this, t, !1, 52, 8);
                        }, u.prototype.writeUIntLE = function(t, e, n, r) {
                            t = +t, e |= 0, n |= 0, r || I(this, t, e, n, Math.pow(2, 8 * n) - 1, 0);
                            var i = 1, o = 0;
                            for (this[e] = 255 & t; ++o < n && (i *= 256); ) this[e + o] = t / i & 255;
                            return e + n;
                        }, u.prototype.writeUIntBE = function(t, e, n, r) {
                            t = +t, e |= 0, n |= 0, r || I(this, t, e, n, Math.pow(2, 8 * n) - 1, 0);
                            var i = n - 1, o = 1;
                            for (this[e + i] = 255 & t; --i >= 0 && (o *= 256); ) this[e + i] = t / o & 255;
                            return e + n;
                        }, u.prototype.writeUInt8 = function(t, e, n) {
                            return t = +t, e |= 0, n || I(this, t, e, 1, 255, 0), u.TYPED_ARRAY_SUPPORT || (t = Math.floor(t)), 
                            this[e] = 255 & t, e + 1;
                        }, u.prototype.writeUInt16LE = function(t, e, n) {
                            return t = +t, e |= 0, n || I(this, t, e, 2, 65535, 0), u.TYPED_ARRAY_SUPPORT ? (this[e] = 255 & t, 
                            this[e + 1] = t >>> 8) : R(this, t, e, !0), e + 2;
                        }, u.prototype.writeUInt16BE = function(t, e, n) {
                            return t = +t, e |= 0, n || I(this, t, e, 2, 65535, 0), u.TYPED_ARRAY_SUPPORT ? (this[e] = t >>> 8, 
                            this[e + 1] = 255 & t) : R(this, t, e, !1), e + 2;
                        }, u.prototype.writeUInt32LE = function(t, e, n) {
                            return t = +t, e |= 0, n || I(this, t, e, 4, 4294967295, 0), u.TYPED_ARRAY_SUPPORT ? (this[e + 3] = t >>> 24, 
                            this[e + 2] = t >>> 16, this[e + 1] = t >>> 8, this[e] = 255 & t) : L(this, t, e, !0), 
                            e + 4;
                        }, u.prototype.writeUInt32BE = function(t, e, n) {
                            return t = +t, e |= 0, n || I(this, t, e, 4, 4294967295, 0), u.TYPED_ARRAY_SUPPORT ? (this[e] = t >>> 24, 
                            this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t) : L(this, t, e, !1), 
                            e + 4;
                        }, u.prototype.writeIntLE = function(t, e, n, r) {
                            if (t = +t, e |= 0, !r) {
                                var i = Math.pow(2, 8 * n - 1);
                                I(this, t, e, n, i - 1, -i);
                            }
                            var o = 0, a = 1, s = 0;
                            for (this[e] = 255 & t; ++o < n && (a *= 256); ) t < 0 && 0 === s && 0 !== this[e + o - 1] && (s = 1), 
                            this[e + o] = (t / a >> 0) - s & 255;
                            return e + n;
                        }, u.prototype.writeIntBE = function(t, e, n, r) {
                            if (t = +t, e |= 0, !r) {
                                var i = Math.pow(2, 8 * n - 1);
                                I(this, t, e, n, i - 1, -i);
                            }
                            var o = n - 1, a = 1, s = 0;
                            for (this[e + o] = 255 & t; --o >= 0 && (a *= 256); ) t < 0 && 0 === s && 0 !== this[e + o + 1] && (s = 1), 
                            this[e + o] = (t / a >> 0) - s & 255;
                            return e + n;
                        }, u.prototype.writeInt8 = function(t, e, n) {
                            return t = +t, e |= 0, n || I(this, t, e, 1, 127, -128), u.TYPED_ARRAY_SUPPORT || (t = Math.floor(t)), 
                            t < 0 && (t = 255 + t + 1), this[e] = 255 & t, e + 1;
                        }, u.prototype.writeInt16LE = function(t, e, n) {
                            return t = +t, e |= 0, n || I(this, t, e, 2, 32767, -32768), u.TYPED_ARRAY_SUPPORT ? (this[e] = 255 & t, 
                            this[e + 1] = t >>> 8) : R(this, t, e, !0), e + 2;
                        }, u.prototype.writeInt16BE = function(t, e, n) {
                            return t = +t, e |= 0, n || I(this, t, e, 2, 32767, -32768), u.TYPED_ARRAY_SUPPORT ? (this[e] = t >>> 8, 
                            this[e + 1] = 255 & t) : R(this, t, e, !1), e + 2;
                        }, u.prototype.writeInt32LE = function(t, e, n) {
                            return t = +t, e |= 0, n || I(this, t, e, 4, 2147483647, -2147483648), u.TYPED_ARRAY_SUPPORT ? (this[e] = 255 & t, 
                            this[e + 1] = t >>> 8, this[e + 2] = t >>> 16, this[e + 3] = t >>> 24) : L(this, t, e, !0), 
                            e + 4;
                        }, u.prototype.writeInt32BE = function(t, e, n) {
                            return t = +t, e |= 0, n || I(this, t, e, 4, 2147483647, -2147483648), t < 0 && (t = 4294967295 + t + 1), 
                            u.TYPED_ARRAY_SUPPORT ? (this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, 
                            this[e + 3] = 255 & t) : L(this, t, e, !1), e + 4;
                        }, u.prototype.writeFloatLE = function(t, e, n) {
                            return j(this, t, e, !0, n);
                        }, u.prototype.writeFloatBE = function(t, e, n) {
                            return j(this, t, e, !1, n);
                        }, u.prototype.writeDoubleLE = function(t, e, n) {
                            return D(this, t, e, !0, n);
                        }, u.prototype.writeDoubleBE = function(t, e, n) {
                            return D(this, t, e, !1, n);
                        }, u.prototype.copy = function(t, e, n, r) {
                            if (n || (n = 0), r || 0 === r || (r = this.length), e >= t.length && (e = t.length), 
                            e || (e = 0), r > 0 && r < n && (r = n), r === n) return 0;
                            if (0 === t.length || 0 === this.length) return 0;
                            if (e < 0) throw new RangeError("targetStart out of bounds");
                            if (n < 0 || n >= this.length) throw new RangeError("sourceStart out of bounds");
                            if (r < 0) throw new RangeError("sourceEnd out of bounds");
                            r > this.length && (r = this.length), t.length - e < r - n && (r = t.length - e + n);
                            var i, o = r - n;
                            if (this === t && n < e && e < r) for (i = o - 1; i >= 0; --i) t[i + e] = this[i + n]; else if (o < 1e3 || !u.TYPED_ARRAY_SUPPORT) for (i = 0; i < o; ++i) t[i + e] = this[i + n]; else Uint8Array.prototype.set.call(t, this.subarray(n, n + o), e);
                            return o;
                        }, u.prototype.fill = function(t, e, n, r) {
                            if ("string" == typeof t) {
                                if ("string" == typeof e ? (r = e, e = 0, n = this.length) : "string" == typeof n && (r = n, 
                                n = this.length), 1 === t.length) {
                                    var i = t.charCodeAt(0);
                                    i < 256 && (t = i);
                                }
                                if (void 0 !== r && "string" != typeof r) throw new TypeError("encoding must be a string");
                                if ("string" == typeof r && !u.isEncoding(r)) throw new TypeError("Unknown encoding: " + r);
                            } else "number" == typeof t && (t &= 255);
                            if (e < 0 || this.length < e || this.length < n) throw new RangeError("Out of range index");
                            if (n <= e) return this;
                            var o;
                            if (e >>>= 0, n = void 0 === n ? this.length : n >>> 0, t || (t = 0), "number" == typeof t) for (o = e; o < n; ++o) this[o] = t; else {
                                var a = u.isBuffer(t) ? t : F(new u(t, r).toString()), s = a.length;
                                for (o = 0; o < n - e; ++o) this[o + e] = a[o % s];
                            }
                            return this;
                        };
                        var B = /[^+\/0-9A-Za-z-_]/g;
                        function U(t) {
                            return t < 16 ? "0" + t.toString(16) : t.toString(16);
                        }
                        function F(t, e) {
                            var n;
                            e = e || 1 / 0;
                            for (var r = t.length, i = null, o = [], a = 0; a < r; ++a) {
                                if ((n = t.charCodeAt(a)) > 55295 && n < 57344) {
                                    if (!i) {
                                        if (n > 56319) {
                                            (e -= 3) > -1 && o.push(239, 191, 189);
                                            continue;
                                        }
                                        if (a + 1 === r) {
                                            (e -= 3) > -1 && o.push(239, 191, 189);
                                            continue;
                                        }
                                        i = n;
                                        continue;
                                    }
                                    if (n < 56320) {
                                        (e -= 3) > -1 && o.push(239, 191, 189), i = n;
                                        continue;
                                    }
                                    n = 65536 + (i - 55296 << 10 | n - 56320);
                                } else i && (e -= 3) > -1 && o.push(239, 191, 189);
                                if (i = null, n < 128) {
                                    if ((e -= 1) < 0) break;
                                    o.push(n);
                                } else if (n < 2048) {
                                    if ((e -= 2) < 0) break;
                                    o.push(n >> 6 | 192, 63 & n | 128);
                                } else if (n < 65536) {
                                    if ((e -= 3) < 0) break;
                                    o.push(n >> 12 | 224, n >> 6 & 63 | 128, 63 & n | 128);
                                } else {
                                    if (!(n < 1114112)) throw new Error("Invalid code point");
                                    if ((e -= 4) < 0) break;
                                    o.push(n >> 18 | 240, n >> 12 & 63 | 128, n >> 6 & 63 | 128, 63 & n | 128);
                                }
                            }
                            return o;
                        }
                        function H(t) {
                            return r.toByteArray(function(t) {
                                if ((t = function(t) {
                                    return t.trim ? t.trim() : t.replace(/^\s+|\s+$/g, "");
                                }(t).replace(B, "")).length < 2) return "";
                                for (;t.length % 4 != 0; ) t += "=";
                                return t;
                            }(t));
                        }
                        function $(t, e, n, r) {
                            for (var i = 0; i < r && !(i + n >= e.length || i >= t.length); ++i) e[i + n] = t[i];
                            return i;
                        }
                    }).call(this, n(3));
                }, function(t, e, n) {
                    e.byteLength = function(t) {
                        var e = c(t), n = e[0], r = e[1];
                        return 3 * (n + r) / 4 - r;
                    }, e.toByteArray = function(t) {
                        for (var e, n = c(t), r = n[0], a = n[1], s = new o(3 * (r + a) / 4 - a), u = 0, l = a > 0 ? r - 4 : r, f = 0; f < l; f += 4) e = i[t.charCodeAt(f)] << 18 | i[t.charCodeAt(f + 1)] << 12 | i[t.charCodeAt(f + 2)] << 6 | i[t.charCodeAt(f + 3)], 
                        s[u++] = e >> 16 & 255, s[u++] = e >> 8 & 255, s[u++] = 255 & e;
                        return 2 === a && (e = i[t.charCodeAt(f)] << 2 | i[t.charCodeAt(f + 1)] >> 4, s[u++] = 255 & e), 
                        1 === a && (e = i[t.charCodeAt(f)] << 10 | i[t.charCodeAt(f + 1)] << 4 | i[t.charCodeAt(f + 2)] >> 2, 
                        s[u++] = e >> 8 & 255, s[u++] = 255 & e), s;
                    }, e.fromByteArray = function(t) {
                        for (var e, n = t.length, i = n % 3, o = [], a = 0, s = n - i; a < s; a += 16383) o.push(f(t, a, a + 16383 > s ? s : a + 16383));
                        return 1 === i ? (e = t[n - 1], o.push(r[e >> 2] + r[e << 4 & 63] + "==")) : 2 === i && (e = (t[n - 2] << 8) + t[n - 1], 
                        o.push(r[e >> 10] + r[e >> 4 & 63] + r[e << 2 & 63] + "=")), o.join("");
                    };
                    for (var r = [], i = [], o = "undefined" != typeof Uint8Array ? Uint8Array : Array, a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", s = 0, u = a.length; s < u; ++s) r[s] = a[s], 
                    i[a.charCodeAt(s)] = s;
                    function c(t) {
                        var e = t.length;
                        if (e % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
                        var n = t.indexOf("=");
                        return -1 === n && (n = e), [ n, n === e ? 0 : 4 - n % 4 ];
                    }
                    function l(t) {
                        return r[t >> 18 & 63] + r[t >> 12 & 63] + r[t >> 6 & 63] + r[63 & t];
                    }
                    function f(t, e, n) {
                        for (var r, i = [], o = e; o < n; o += 3) r = (t[o] << 16 & 16711680) + (t[o + 1] << 8 & 65280) + (255 & t[o + 2]), 
                        i.push(l(r));
                        return i.join("");
                    }
                    i["-".charCodeAt(0)] = 62, i["_".charCodeAt(0)] = 63;
                }, function(t, e) {
                    e.read = function(t, e, n, r, i) {
                        var o, a, s = 8 * i - r - 1, u = (1 << s) - 1, c = u >> 1, l = -7, f = n ? i - 1 : 0, d = n ? -1 : 1, h = t[e + f];
                        for (f += d, o = h & (1 << -l) - 1, h >>= -l, l += s; l > 0; o = 256 * o + t[e + f], 
                        f += d, l -= 8) ;
                        for (a = o & (1 << -l) - 1, o >>= -l, l += r; l > 0; a = 256 * a + t[e + f], f += d, 
                        l -= 8) ;
                        if (0 === o) o = 1 - c; else {
                            if (o === u) return a ? NaN : 1 / 0 * (h ? -1 : 1);
                            a += Math.pow(2, r), o -= c;
                        }
                        return (h ? -1 : 1) * a * Math.pow(2, o - r);
                    }, e.write = function(t, e, n, r, i, o) {
                        var a, s, u, c = 8 * o - i - 1, l = (1 << c) - 1, f = l >> 1, d = 23 === i ? Math.pow(2, -24) - Math.pow(2, -77) : 0, h = r ? 0 : o - 1, p = r ? 1 : -1, _ = e < 0 || 0 === e && 1 / e < 0 ? 1 : 0;
                        for (e = Math.abs(e), isNaN(e) || e === 1 / 0 ? (s = isNaN(e) ? 1 : 0, a = l) : (a = Math.floor(Math.log(e) / Math.LN2), 
                        e * (u = Math.pow(2, -a)) < 1 && (a--, u *= 2), (e += a + f >= 1 ? d / u : d * Math.pow(2, 1 - f)) * u >= 2 && (a++, 
                        u /= 2), a + f >= l ? (s = 0, a = l) : a + f >= 1 ? (s = (e * u - 1) * Math.pow(2, i), 
                        a += f) : (s = e * Math.pow(2, f - 1) * Math.pow(2, i), a = 0)); i >= 8; t[n + h] = 255 & s, 
                        h += p, s /= 256, i -= 8) ;
                        for (a = a << i | s, c += i; c > 0; t[n + h] = 255 & a, h += p, a /= 256, c -= 8) ;
                        t[n + h - p] |= 128 * _;
                    };
                }, function(t, e) {
                    var n = {}.toString;
                    t.exports = Array.isArray || function(t) {
                        return "[object Array]" == n.call(t);
                    };
                } ]);
            }, "object" == _typeof(exports) && "object" == _typeof(module) ? module.exports = e() : (__WEBPACK_AMD_DEFINE_ARRAY__ = [], 
            void 0 === (__WEBPACK_AMD_DEFINE_RESULT__ = "function" == typeof (__WEBPACK_AMD_DEFINE_FACTORY__ = e) ? __WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__) : __WEBPACK_AMD_DEFINE_FACTORY__) || (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
        }).call(this, __webpack_require__("bc2e").default, __webpack_require__("62e4")(module));
    },
    "6f19": function(t, e) {},
    "6f8f": function(t, e) {
        t.exports = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
                !0;
            } catch (t) {
                return !1;
            }
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    7037: function(t, e) {
        function n(e) {
            return t.exports = n = "function" == typeof Symbol && "symbol" == _typeof3(Symbol.iterator) ? function(t) {
                return _typeof3(t);
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : _typeof3(t);
            }, t.exports.__esModule = !0, t.exports.default = t.exports, n(e);
        }
        t.exports = n, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    7073: function(t, e, n) {
        var r = this && this.__importDefault || function(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        };
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var i = r(n("2504")), o = String.fromCodePoint || function(t) {
            var e = "";
            return t > 65535 && (t -= 65536, e += String.fromCharCode(t >>> 10 & 1023 | 55296), 
            t = 56320 | 1023 & t), e += String.fromCharCode(t);
        };
        e.default = function(t) {
            return t >= 55296 && t <= 57343 || t > 1114111 ? "�" : (t in i.default && (t = i.default[t]), 
            o(t));
        };
    },
    "7ec2": function(t, e, n) {
        var r = n("7037").default;
        function i() {
            t.exports = i = function() {
                return e;
            }, t.exports.__esModule = !0, t.exports.default = t.exports;
            var e = {}, n = Object.prototype, o = n.hasOwnProperty, a = Object.defineProperty || function(t, e, n) {
                t[e] = n.value;
            }, s = "function" == typeof Symbol ? Symbol : {}, u = s.iterator || "@@iterator", c = s.asyncIterator || "@@asyncIterator", l = s.toStringTag || "@@toStringTag";
            function f(t, e, n) {
                return Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }), t[e];
            }
            try {
                f({}, "");
            } catch (t) {
                f = function(t, e, n) {
                    return t[e] = n;
                };
            }
            function d(t, e, n, r) {
                var i = e && e.prototype instanceof _ ? e : _, o = Object.create(i.prototype), s = new k(r || []);
                return a(o, "_invoke", {
                    value: S(t, n, s)
                }), o;
            }
            function h(t, e, n) {
                try {
                    return {
                        type: "normal",
                        arg: t.call(e, n)
                    };
                } catch (t) {
                    return {
                        type: "throw",
                        arg: t
                    };
                }
            }
            e.wrap = d;
            var p = {};
            function _() {}
            function m() {}
            function y() {}
            var g = {};
            f(g, u, function() {
                return this;
            });
            var v = Object.getPrototypeOf, b = v && v(v(E([])));
            b && b !== n && o.call(b, u) && (g = b);
            var w = y.prototype = _.prototype = Object.create(g);
            function x(t) {
                [ "next", "throw", "return" ].forEach(function(e) {
                    f(t, e, function(t) {
                        return this._invoke(e, t);
                    });
                });
            }
            function A(t, e) {
                var n;
                a(this, "_invoke", {
                    value: function(i, a) {
                        function s() {
                            return new e(function(n, s) {
                                !function n(i, a, s, u) {
                                    var c = h(t[i], t, a);
                                    if ("throw" !== c.type) {
                                        var l = c.arg, f = l.value;
                                        return f && "object" == r(f) && o.call(f, "__await") ? e.resolve(f.__await).then(function(t) {
                                            n("next", t, s, u);
                                        }, function(t) {
                                            n("throw", t, s, u);
                                        }) : e.resolve(f).then(function(t) {
                                            l.value = t, s(l);
                                        }, function(t) {
                                            return n("throw", t, s, u);
                                        });
                                    }
                                    u(c.arg);
                                }(i, a, n, s);
                            });
                        }
                        return n = n ? n.then(s, s) : s();
                    }
                });
            }
            function S(t, e, n) {
                var r = "suspendedStart";
                return function(i, o) {
                    if ("executing" === r) throw new Error("Generator is already running");
                    if ("completed" === r) {
                        if ("throw" === i) throw o;
                        return {
                            value: void 0,
                            done: !0
                        };
                    }
                    for (n.method = i, n.arg = o; ;) {
                        var a = n.delegate;
                        if (a) {
                            var s = T(a, n);
                            if (s) {
                                if (s === p) continue;
                                return s;
                            }
                        }
                        if ("next" === n.method) n.sent = n._sent = n.arg; else if ("throw" === n.method) {
                            if ("suspendedStart" === r) throw r = "completed", n.arg;
                            n.dispatchException(n.arg);
                        } else "return" === n.method && n.abrupt("return", n.arg);
                        r = "executing";
                        var u = h(t, e, n);
                        if ("normal" === u.type) {
                            if (r = n.done ? "completed" : "suspendedYield", u.arg === p) continue;
                            return {
                                value: u.arg,
                                done: n.done
                            };
                        }
                        "throw" === u.type && (r = "completed", n.method = "throw", n.arg = u.arg);
                    }
                };
            }
            function T(t, e) {
                var n = e.method, r = t.iterator[n];
                if (void 0 === r) return e.delegate = null, "throw" === n && t.iterator.return && (e.method = "return", 
                e.arg = void 0, T(t, e), "throw" === e.method) || "return" !== n && (e.method = "throw", 
                e.arg = new TypeError("The iterator does not provide a '" + n + "' method")), p;
                var i = h(r, t.iterator, e.arg);
                if ("throw" === i.type) return e.method = "throw", e.arg = i.arg, e.delegate = null, 
                p;
                var o = i.arg;
                return o ? o.done ? (e[t.resultName] = o.value, e.next = t.nextLoc, "return" !== e.method && (e.method = "next", 
                e.arg = void 0), e.delegate = null, p) : o : (e.method = "throw", e.arg = new TypeError("iterator result is not an object"), 
                e.delegate = null, p);
            }
            function P(t) {
                var e = {
                    tryLoc: t[0]
                };
                1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), 
                this.tryEntries.push(e);
            }
            function M(t) {
                var e = t.completion || {};
                e.type = "normal", delete e.arg, t.completion = e;
            }
            function k(t) {
                this.tryEntries = [ {
                    tryLoc: "root"
                } ], t.forEach(P, this), this.reset(!0);
            }
            function E(t) {
                if (t) {
                    var e = t[u];
                    if (e) return e.call(t);
                    if ("function" == typeof t.next) return t;
                    if (!isNaN(t.length)) {
                        var n = -1, r = function e() {
                            for (;++n < t.length; ) if (o.call(t, n)) return e.value = t[n], e.done = !1, e;
                            return e.value = void 0, e.done = !0, e;
                        };
                        return r.next = r;
                    }
                }
                return {
                    next: O
                };
            }
            function O() {
                return {
                    value: void 0,
                    done: !0
                };
            }
            return m.prototype = y, a(w, "constructor", {
                value: y,
                configurable: !0
            }), a(y, "constructor", {
                value: m,
                configurable: !0
            }), m.displayName = f(y, l, "GeneratorFunction"), e.isGeneratorFunction = function(t) {
                var e = "function" == typeof t && t.constructor;
                return !!e && (e === m || "GeneratorFunction" === (e.displayName || e.name));
            }, e.mark = function(t) {
                return Object.setPrototypeOf ? Object.setPrototypeOf(t, y) : (t.__proto__ = y, f(t, l, "GeneratorFunction")), 
                t.prototype = Object.create(w), t;
            }, e.awrap = function(t) {
                return {
                    __await: t
                };
            }, x(A.prototype), f(A.prototype, c, function() {
                return this;
            }), e.AsyncIterator = A, e.async = function(t, n, r, i, o) {
                void 0 === o && (o = Promise);
                var a = new A(d(t, n, r, i), o);
                return e.isGeneratorFunction(n) ? a : a.next().then(function(t) {
                    return t.done ? t.value : a.next();
                });
            }, x(w), f(w, l, "Generator"), f(w, u, function() {
                return this;
            }), f(w, "toString", function() {
                return "[object Generator]";
            }), e.keys = function(t) {
                var e = Object(t), n = [];
                for (var r in e) n.push(r);
                return n.reverse(), function t() {
                    for (;n.length; ) {
                        var r = n.pop();
                        if (r in e) return t.value = r, t.done = !1, t;
                    }
                    return t.done = !0, t;
                };
            }, e.values = E, k.prototype = {
                constructor: k,
                reset: function(t) {
                    if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, 
                    this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(M), 
                    !t) for (var e in this) "t" === e.charAt(0) && o.call(this, e) && !isNaN(+e.slice(1)) && (this[e] = void 0);
                },
                stop: function() {
                    this.done = !0;
                    var t = this.tryEntries[0].completion;
                    if ("throw" === t.type) throw t.arg;
                    return this.rval;
                },
                dispatchException: function(t) {
                    if (this.done) throw t;
                    var e = this;
                    function n(n, r) {
                        return a.type = "throw", a.arg = t, e.next = n, r && (e.method = "next", e.arg = void 0), 
                        !!r;
                    }
                    for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                        var i = this.tryEntries[r], a = i.completion;
                        if ("root" === i.tryLoc) return n("end");
                        if (i.tryLoc <= this.prev) {
                            var s = o.call(i, "catchLoc"), u = o.call(i, "finallyLoc");
                            if (s && u) {
                                if (this.prev < i.catchLoc) return n(i.catchLoc, !0);
                                if (this.prev < i.finallyLoc) return n(i.finallyLoc);
                            } else if (s) {
                                if (this.prev < i.catchLoc) return n(i.catchLoc, !0);
                            } else {
                                if (!u) throw new Error("try statement without catch or finally");
                                if (this.prev < i.finallyLoc) return n(i.finallyLoc);
                            }
                        }
                    }
                },
                abrupt: function(t, e) {
                    for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                        var r = this.tryEntries[n];
                        if (r.tryLoc <= this.prev && o.call(r, "finallyLoc") && this.prev < r.finallyLoc) {
                            var i = r;
                            break;
                        }
                    }
                    i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null);
                    var a = i ? i.completion : {};
                    return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, 
                    p) : this.complete(a);
                },
                complete: function(t, e) {
                    if ("throw" === t.type) throw t.arg;
                    return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, 
                    this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), 
                    p;
                },
                finish: function(t) {
                    for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                        var n = this.tryEntries[e];
                        if (n.finallyLoc === t) return this.complete(n.completion, n.afterLoc), M(n), p;
                    }
                },
                catch: function(t) {
                    for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                        var n = this.tryEntries[e];
                        if (n.tryLoc === t) {
                            var r = n.completion;
                            if ("throw" === r.type) {
                                var i = r.arg;
                                M(n);
                            }
                            return i;
                        }
                    }
                    throw new Error("illegal catch attempt");
                },
                delegateYield: function(t, e, n) {
                    return this.delegate = {
                        iterator: E(t),
                        resultName: e,
                        nextLoc: n
                    }, "next" === this.method && (this.arg = void 0), p;
                }
            }, e;
        }
        t.exports = i, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    "8f0e": function(t) {
        t.exports = JSON.parse('{"Aacute":"Á","aacute":"á","Acirc":"Â","acirc":"â","acute":"´","AElig":"Æ","aelig":"æ","Agrave":"À","agrave":"à","amp":"&","AMP":"&","Aring":"Å","aring":"å","Atilde":"Ã","atilde":"ã","Auml":"Ä","auml":"ä","brvbar":"¦","Ccedil":"Ç","ccedil":"ç","cedil":"¸","cent":"¢","copy":"©","COPY":"©","curren":"¤","deg":"°","divide":"÷","Eacute":"É","eacute":"é","Ecirc":"Ê","ecirc":"ê","Egrave":"È","egrave":"è","ETH":"Ð","eth":"ð","Euml":"Ë","euml":"ë","frac12":"½","frac14":"¼","frac34":"¾","gt":">","GT":">","Iacute":"Í","iacute":"í","Icirc":"Î","icirc":"î","iexcl":"¡","Igrave":"Ì","igrave":"ì","iquest":"¿","Iuml":"Ï","iuml":"ï","laquo":"«","lt":"<","LT":"<","macr":"¯","micro":"µ","middot":"·","nbsp":" ","not":"¬","Ntilde":"Ñ","ntilde":"ñ","Oacute":"Ó","oacute":"ó","Ocirc":"Ô","ocirc":"ô","Ograve":"Ò","ograve":"ò","ordf":"ª","ordm":"º","Oslash":"Ø","oslash":"ø","Otilde":"Õ","otilde":"õ","Ouml":"Ö","ouml":"ö","para":"¶","plusmn":"±","pound":"£","quot":"\\"","QUOT":"\\"","raquo":"»","reg":"®","REG":"®","sect":"§","shy":"­","sup1":"¹","sup2":"²","sup3":"³","szlig":"ß","THORN":"Þ","thorn":"þ","times":"×","Uacute":"Ú","uacute":"ú","Ucirc":"Û","ucirc":"û","Ugrave":"Ù","ugrave":"ù","uml":"¨","Uuml":"Ü","uuml":"ü","Yacute":"Ý","yacute":"ý","yen":"¥","yuml":"ÿ"}');
    },
    "923f": function(t, e, n) {
        "function" == typeof Object.create ? t.exports = function(t, e) {
            t.super_ = e, t.prototype = Object.create(e.prototype, {
                constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            });
        } : t.exports = function(t, e) {
            t.super_ = e;
            var n = function() {};
            n.prototype = e.prototype, t.prototype = new n(), t.prototype.constructor = t;
        };
    },
    9516: function(t, e, n) {
        function r(t, e) {
            var n = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
            if (!n) {
                if (Array.isArray(t) || (n = function(t, e) {
                    if (t) {
                        if ("string" == typeof t) return i(t, e);
                        var n = Object.prototype.toString.call(t).slice(8, -1);
                        return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? i(t, e) : void 0;
                    }
                }(t)) || e && t && "number" == typeof t.length) {
                    n && (t = n);
                    var r = 0, o = function() {};
                    return {
                        s: o,
                        n: function() {
                            return r >= t.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: t[r++]
                            };
                        },
                        e: function(t) {
                            throw t;
                        },
                        f: o
                    };
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            var a, s = !0, u = !1;
            return {
                s: function() {
                    n = n.call(t);
                },
                n: function() {
                    var t = n.next();
                    return s = t.done, t;
                },
                e: function(t) {
                    u = !0, a = t;
                },
                f: function() {
                    try {
                        s || null == n.return || n.return();
                    } finally {
                        if (u) throw a;
                    }
                }
            };
        }
        function i(t, e) {
            (null == e || e > t.length) && (e = t.length);
            for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
            return r;
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = {
            getTextLength: function(t, e) {
                for (var n = 0, r = 0; r < t.length; r++) {
                    var i = t.charCodeAt(r);
                    i >= 1 && i <= 126 || 65376 <= i && i <= 65439 ? n++ : n += e ? 2 : 1;
                }
                return n;
            },
            transferBorder: function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", e = t.match(/(\w+)px\s(\w+)\s(.*)/), n = {};
                return e && (n = {
                    width: +e[1],
                    style: e[2],
                    color: e[3]
                }), e ? n : null;
            },
            transferColor: function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", e = "#";
                (t = (t = t.replace(/^rgba?\(/, "").replace(/\)$/, "")).split(", ")).length > 3 && (t.length = 3);
                var n, i = r(t);
                try {
                    for (i.s(); !(n = i.n()).done; ) {
                        var o = n.value;
                        e += (o = parseInt(o || 0)) < 10 ? "0" + o : o.toString(16);
                    }
                } catch (t) {
                    i.e(t);
                } finally {
                    i.f();
                }
                return e;
            },
            transferPadding: function() {
                for (var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "0 0 0 0", e = 0, n = (t = t.split(" ")).length; e < n; e++) t[e] = +t[e].replace("px", "");
                return t;
            },
            transferBoxShadow: function() {
                var t, e, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                if (n && "none" !== n) return (e = n.match(/(\w+)\s(\w+)\s(\w+)\s(rgb.*)/)) ? (e.shift(), 
                n = e, t = e[3] || "#ffffff") : (t = (e = n.split(") "))[0] + ")", n = e[1].split("px ")), 
                {
                    offsetX: +n[0] || 0,
                    offsetY: +n[1] || 0,
                    blur: +n[2] || 0,
                    color: t
                };
            },
            getUid: function(t) {
                return (t = t || "") + "xxyxxyxx".replace(/[xy]/g, function(t) {
                    var e = 16 * Math.random() | 0;
                    return ("x" === t ? e : 3 & e | 8).toString(16);
                });
            }
        };
        e.default = o;
    },
    9523: function(t, e, n) {
        var r = n("a395");
        t.exports = function(t, e, n) {
            return (e = r(e)) in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n, t;
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    "970b": function(t, e) {
        t.exports = function(t, e) {
            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    "9b42": function(t, e) {
        t.exports = function(t, e) {
            var n = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
            if (null != n) {
                var r, i, o, a, s = [], u = !0, c = !1;
                try {
                    if (o = (n = n.call(t)).next, 0 === e) {
                        if (Object(n) !== n) return;
                        u = !1;
                    } else for (;!(u = (r = o.call(n)).done) && (s.push(r.value), s.length !== e); u = !0) ;
                } catch (t) {
                    c = !0, i = t;
                } finally {
                    try {
                        if (!u && null != n.return && (a = n.return(), Object(a) !== a)) return;
                    } finally {
                        if (c) throw i;
                    }
                }
                return s;
            }
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    a395: function(t, e, n) {
        var r = n("7037").default, i = n("e50d");
        t.exports = function(t) {
            var e = i(t, "string");
            return "symbol" === r(e) ? e : String(e);
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    a548: function(t, e, n) {
        var r = n("7073"), i = {}, o = n("8f0e"), a = n("fafd"), s = 0, u = s++, c = s++, l = s++, f = s++, d = s++, h = s++, p = s++, _ = s++, m = s++, y = s++, g = s++, v = s++, b = s++, w = s++, x = s++, A = s++, S = s++, T = s++, P = s++, M = s++, k = s++, E = s++, O = s++, C = s++, I = s++, R = s++, L = s++, N = s++, j = s++, D = s++, B = s++, U = s++, F = s++, H = s++, $ = s++, V = s++, z = s++, Y = s++, G = s++, W = s++, K = s++, X = s++, J = s++, Q = s++, q = s++, Z = s++, tt = s++, et = s++, nt = s++, rt = s++, it = s++, ot = s++, at = s++, st = s++, ut = s++, ct = 0, lt = ct++, ft = ct++, dt = ct++;
        function ht(t) {
            return " " === t || "\n" === t || "\t" === t || "\f" === t || "\r" === t;
        }
        function pt(t, e, n) {
            var r = t.toLowerCase();
            return t === r ? function(t) {
                t === r ? this._state = e : (this._state = n, this._index--);
            } : function(i) {
                i === r || i === t ? this._state = e : (this._state = n, this._index--);
            };
        }
        function _t(t, e) {
            var n = t.toLowerCase();
            return function(r) {
                r === n || r === t ? this._state = e : (this._state = l, this._index--);
            };
        }
        function mt(t, e) {
            this._state = u, this._buffer = "", this._sectionStart = 0, this._index = 0, this._bufferOffset = 0, 
            this._baseState = u, this._special = lt, this._cbs = e, this._running = !0, this._ended = !1, 
            this._xmlMode = !(!t || !t.xmlMode), this._decodeEntities = !(!t || !t.decodeEntities);
        }
        mt.prototype._stateText = function(t) {
            "<" === t ? (this._index > this._sectionStart && this._cbs.ontext(this._getSection()), 
            this._state = c, this._sectionStart = this._index) : this._decodeEntities && this._special === lt && "&" === t && (this._index > this._sectionStart && this._cbs.ontext(this._getSection()), 
            this._baseState = u, this._state = it, this._sectionStart = this._index);
        }, mt.prototype._stateBeforeTagName = function(t) {
            "/" === t ? this._state = d : "<" === t ? (this._cbs.ontext(this._getSection()), 
            this._sectionStart = this._index) : ">" === t || this._special !== lt || ht(t) ? this._state = u : "!" === t ? (this._state = x, 
            this._sectionStart = this._index + 1) : "?" === t ? (this._state = S, this._sectionStart = this._index + 1) : (this._state = this._xmlMode || "s" !== t && "S" !== t ? l : B, 
            this._sectionStart = this._index);
        }, mt.prototype._stateInTagName = function(t) {
            ("/" === t || ">" === t || ht(t)) && (this._emitToken("onopentagname"), this._state = _, 
            this._index--);
        }, mt.prototype._stateBeforeCloseingTagName = function(t) {
            ht(t) || (">" === t ? this._state = u : this._special !== lt ? "s" === t || "S" === t ? this._state = U : (this._state = u, 
            this._index--) : (this._state = h, this._sectionStart = this._index));
        }, mt.prototype._stateInCloseingTagName = function(t) {
            (">" === t || ht(t)) && (this._emitToken("onclosetag"), this._state = p, this._index--);
        }, mt.prototype._stateAfterCloseingTagName = function(t) {
            ">" === t && (this._state = u, this._sectionStart = this._index + 1);
        }, mt.prototype._stateBeforeAttributeName = function(t) {
            ">" === t ? (this._cbs.onopentagend(), this._state = u, this._sectionStart = this._index + 1) : "/" === t ? this._state = f : ht(t) || (this._state = m, 
            this._sectionStart = this._index);
        }, mt.prototype._stateInSelfClosingTag = function(t) {
            ">" === t ? (this._cbs.onselfclosingtag(), this._state = u, this._sectionStart = this._index + 1) : ht(t) || (this._state = _, 
            this._index--);
        }, mt.prototype._stateInAttributeName = function(t) {
            ("=" === t || "/" === t || ">" === t || ht(t)) && (this._cbs.onattribname(this._getSection()), 
            this._sectionStart = -1, this._state = y, this._index--);
        }, mt.prototype._stateAfterAttributeName = function(t) {
            "=" === t ? this._state = g : "/" === t || ">" === t ? (this._cbs.onattribend(), 
            this._state = _, this._index--) : ht(t) || (this._cbs.onattribend(), this._state = m, 
            this._sectionStart = this._index);
        }, mt.prototype._stateBeforeAttributeValue = function(t) {
            '"' === t ? (this._state = v, this._sectionStart = this._index + 1) : "'" === t ? (this._state = b, 
            this._sectionStart = this._index + 1) : ht(t) || (this._state = w, this._sectionStart = this._index, 
            this._index--);
        }, mt.prototype._stateInAttributeValueDoubleQuotes = function(t) {
            '"' === t ? (this._emitToken("onattribdata"), this._cbs.onattribend(), this._state = _) : this._decodeEntities && "&" === t && (this._emitToken("onattribdata"), 
            this._baseState = this._state, this._state = it, this._sectionStart = this._index);
        }, mt.prototype._stateInAttributeValueSingleQuotes = function(t) {
            "'" === t ? (this._emitToken("onattribdata"), this._cbs.onattribend(), this._state = _) : this._decodeEntities && "&" === t && (this._emitToken("onattribdata"), 
            this._baseState = this._state, this._state = it, this._sectionStart = this._index);
        }, mt.prototype._stateInAttributeValueNoQuotes = function(t) {
            ht(t) || ">" === t ? (this._emitToken("onattribdata"), this._cbs.onattribend(), 
            this._state = _, this._index--) : this._decodeEntities && "&" === t && (this._emitToken("onattribdata"), 
            this._baseState = this._state, this._state = it, this._sectionStart = this._index);
        }, mt.prototype._stateBeforeDeclaration = function(t) {
            this._state = "[" === t ? E : "-" === t ? T : A;
        }, mt.prototype._stateInDeclaration = function(t) {
            ">" === t && (this._cbs.ondeclaration(this._getSection()), this._state = u, this._sectionStart = this._index + 1);
        }, mt.prototype._stateInProcessingInstruction = function(t) {
            ">" === t && (this._cbs.onprocessinginstruction(this._getSection()), this._state = u, 
            this._sectionStart = this._index + 1);
        }, mt.prototype._stateBeforeComment = function(t) {
            "-" === t ? (this._state = P, this._sectionStart = this._index + 1) : this._state = A;
        }, mt.prototype._stateInComment = function(t) {
            "-" === t && (this._state = M);
        }, mt.prototype._stateAfterComment1 = function(t) {
            this._state = "-" === t ? k : P;
        }, mt.prototype._stateAfterComment2 = function(t) {
            ">" === t ? (this._cbs.oncomment(this._buffer.substring(this._sectionStart, this._index - 2)), 
            this._state = u, this._sectionStart = this._index + 1) : "-" !== t && (this._state = P);
        }, mt.prototype._stateBeforeCdata1 = pt("C", O, A), mt.prototype._stateBeforeCdata2 = pt("D", C, A), 
        mt.prototype._stateBeforeCdata3 = pt("A", I, A), mt.prototype._stateBeforeCdata4 = pt("T", R, A), 
        mt.prototype._stateBeforeCdata5 = pt("A", L, A), mt.prototype._stateBeforeCdata6 = function(t) {
            "[" === t ? (this._state = N, this._sectionStart = this._index + 1) : (this._state = A, 
            this._index--);
        }, mt.prototype._stateInCdata = function(t) {
            "]" === t && (this._state = j);
        }, mt.prototype._stateAfterCdata1 = function(t) {
            this._state = "]" === t ? D : N;
        }, mt.prototype._stateAfterCdata2 = function(t) {
            ">" === t ? (this._cbs.oncdata(this._buffer.substring(this._sectionStart, this._index - 2)), 
            this._state = u, this._sectionStart = this._index + 1) : "]" !== t && (this._state = N);
        }, mt.prototype._stateBeforeSpecial = function(t) {
            "c" === t || "C" === t ? this._state = F : "t" === t || "T" === t ? this._state = J : (this._state = l, 
            this._index--);
        }, mt.prototype._stateBeforeSpecialEnd = function(t) {
            this._special !== ft || "c" !== t && "C" !== t ? this._special !== dt || "t" !== t && "T" !== t ? this._state = u : this._state = tt : this._state = Y;
        }, mt.prototype._stateBeforeScript1 = _t("R", H), mt.prototype._stateBeforeScript2 = _t("I", $), 
        mt.prototype._stateBeforeScript3 = _t("P", V), mt.prototype._stateBeforeScript4 = _t("T", z), 
        mt.prototype._stateBeforeScript5 = function(t) {
            ("/" === t || ">" === t || ht(t)) && (this._special = ft), this._state = l, this._index--;
        }, mt.prototype._stateAfterScript1 = pt("R", G, u), mt.prototype._stateAfterScript2 = pt("I", W, u), 
        mt.prototype._stateAfterScript3 = pt("P", K, u), mt.prototype._stateAfterScript4 = pt("T", X, u), 
        mt.prototype._stateAfterScript5 = function(t) {
            ">" === t || ht(t) ? (this._special = lt, this._state = h, this._sectionStart = this._index - 6, 
            this._index--) : this._state = u;
        }, mt.prototype._stateBeforeStyle1 = _t("Y", Q), mt.prototype._stateBeforeStyle2 = _t("L", q), 
        mt.prototype._stateBeforeStyle3 = _t("E", Z), mt.prototype._stateBeforeStyle4 = function(t) {
            ("/" === t || ">" === t || ht(t)) && (this._special = dt), this._state = l, this._index--;
        }, mt.prototype._stateAfterStyle1 = pt("Y", et, u), mt.prototype._stateAfterStyle2 = pt("L", nt, u), 
        mt.prototype._stateAfterStyle3 = pt("E", rt, u), mt.prototype._stateAfterStyle4 = function(t) {
            ">" === t || ht(t) ? (this._special = lt, this._state = h, this._sectionStart = this._index - 5, 
            this._index--) : this._state = u;
        }, mt.prototype._stateBeforeEntity = pt("#", ot, at), mt.prototype._stateBeforeNumericEntity = pt("X", ut, st), 
        mt.prototype._parseNamedEntityStrict = function() {
            if (this._sectionStart + 1 < this._index) {
                var t = this._buffer.substring(this._sectionStart + 1, this._index), e = this._xmlMode ? a : i;
                e.hasOwnProperty(t) && (this._emitPartial(e[t]), this._sectionStart = this._index + 1);
            }
        }, mt.prototype._parseLegacyEntity = function() {
            var t = this._sectionStart + 1, e = this._index - t;
            for (e > 6 && (e = 6); e >= 2; ) {
                var n = this._buffer.substr(t, e);
                if (o.hasOwnProperty(n)) return this._emitPartial(o[n]), void (this._sectionStart += e + 1);
                e--;
            }
        }, mt.prototype._stateInNamedEntity = function(t) {
            ";" === t ? (this._parseNamedEntityStrict(), this._sectionStart + 1 < this._index && !this._xmlMode && this._parseLegacyEntity(), 
            this._state = this._baseState) : (t < "a" || t > "z") && (t < "A" || t > "Z") && (t < "0" || t > "9") && (this._xmlMode || this._sectionStart + 1 === this._index || (this._baseState !== u ? "=" !== t && this._parseNamedEntityStrict() : this._parseLegacyEntity()), 
            this._state = this._baseState, this._index--);
        }, mt.prototype._decodeNumericEntity = function(t, e) {
            var n = this._sectionStart + t;
            if (n !== this._index) {
                var i = this._buffer.substring(n, this._index), o = parseInt(i, e);
                this._emitPartial(r(o)), this._sectionStart = this._index;
            } else this._sectionStart--;
            this._state = this._baseState;
        }, mt.prototype._stateInNumericEntity = function(t) {
            ";" === t ? (this._decodeNumericEntity(2, 10), this._sectionStart++) : (t < "0" || t > "9") && (this._xmlMode ? this._state = this._baseState : this._decodeNumericEntity(2, 10), 
            this._index--);
        }, mt.prototype._stateInHexEntity = function(t) {
            ";" === t ? (this._decodeNumericEntity(3, 16), this._sectionStart++) : (t < "a" || t > "f") && (t < "A" || t > "F") && (t < "0" || t > "9") && (this._xmlMode ? this._state = this._baseState : this._decodeNumericEntity(3, 16), 
            this._index--);
        }, mt.prototype._cleanup = function() {
            this._sectionStart < 0 ? (this._buffer = "", this._bufferOffset += this._index, 
            this._index = 0) : this._running && (this._state === u ? (this._sectionStart !== this._index && this._cbs.ontext(this._buffer.substr(this._sectionStart)), 
            this._buffer = "", this._bufferOffset += this._index, this._index = 0) : this._sectionStart === this._index ? (this._buffer = "", 
            this._bufferOffset += this._index, this._index = 0) : (this._buffer = this._buffer.substr(this._sectionStart), 
            this._index -= this._sectionStart, this._bufferOffset += this._sectionStart), this._sectionStart = 0);
        }, mt.prototype.write = function(t) {
            this._ended && this._cbs.onerror(Error(".write() after done!")), this._buffer += t, 
            this._parse();
        }, mt.prototype._parse = function() {
            for (;this._index < this._buffer.length && this._running; ) {
                var t = this._buffer.charAt(this._index);
                this._state === u ? this._stateText(t) : this._state === c ? this._stateBeforeTagName(t) : this._state === l ? this._stateInTagName(t) : this._state === d ? this._stateBeforeCloseingTagName(t) : this._state === h ? this._stateInCloseingTagName(t) : this._state === p ? this._stateAfterCloseingTagName(t) : this._state === f ? this._stateInSelfClosingTag(t) : this._state === _ ? this._stateBeforeAttributeName(t) : this._state === m ? this._stateInAttributeName(t) : this._state === y ? this._stateAfterAttributeName(t) : this._state === g ? this._stateBeforeAttributeValue(t) : this._state === v ? this._stateInAttributeValueDoubleQuotes(t) : this._state === b ? this._stateInAttributeValueSingleQuotes(t) : this._state === w ? this._stateInAttributeValueNoQuotes(t) : this._state === x ? this._stateBeforeDeclaration(t) : this._state === A ? this._stateInDeclaration(t) : this._state === S ? this._stateInProcessingInstruction(t) : this._state === T ? this._stateBeforeComment(t) : this._state === P ? this._stateInComment(t) : this._state === M ? this._stateAfterComment1(t) : this._state === k ? this._stateAfterComment2(t) : this._state === E ? this._stateBeforeCdata1(t) : this._state === O ? this._stateBeforeCdata2(t) : this._state === C ? this._stateBeforeCdata3(t) : this._state === I ? this._stateBeforeCdata4(t) : this._state === R ? this._stateBeforeCdata5(t) : this._state === L ? this._stateBeforeCdata6(t) : this._state === N ? this._stateInCdata(t) : this._state === j ? this._stateAfterCdata1(t) : this._state === D ? this._stateAfterCdata2(t) : this._state === B ? this._stateBeforeSpecial(t) : this._state === U ? this._stateBeforeSpecialEnd(t) : this._state === F ? this._stateBeforeScript1(t) : this._state === H ? this._stateBeforeScript2(t) : this._state === $ ? this._stateBeforeScript3(t) : this._state === V ? this._stateBeforeScript4(t) : this._state === z ? this._stateBeforeScript5(t) : this._state === Y ? this._stateAfterScript1(t) : this._state === G ? this._stateAfterScript2(t) : this._state === W ? this._stateAfterScript3(t) : this._state === K ? this._stateAfterScript4(t) : this._state === X ? this._stateAfterScript5(t) : this._state === J ? this._stateBeforeStyle1(t) : this._state === Q ? this._stateBeforeStyle2(t) : this._state === q ? this._stateBeforeStyle3(t) : this._state === Z ? this._stateBeforeStyle4(t) : this._state === tt ? this._stateAfterStyle1(t) : this._state === et ? this._stateAfterStyle2(t) : this._state === nt ? this._stateAfterStyle3(t) : this._state === rt ? this._stateAfterStyle4(t) : this._state === it ? this._stateBeforeEntity(t) : this._state === ot ? this._stateBeforeNumericEntity(t) : this._state === at ? this._stateInNamedEntity(t) : this._state === st ? this._stateInNumericEntity(t) : this._state === ut ? this._stateInHexEntity(t) : this._cbs.onerror(Error("unknown _state"), this._state), 
                this._index++;
            }
            this._cleanup();
        }, mt.prototype.pause = function() {
            this._running = !1;
        }, mt.prototype.resume = function() {
            this._running = !0, this._index < this._buffer.length && this._parse(), this._ended && this._finish();
        }, mt.prototype.end = function(t) {
            this._ended && this._cbs.onerror(Error(".end() after done!")), t && this.write(t), 
            this._ended = !0, this._running && this._finish();
        }, mt.prototype._finish = function() {
            this._sectionStart < this._index && this._handleTrailingData(), this._cbs.onend();
        }, mt.prototype._handleTrailingData = function() {
            var t = this._buffer.substr(this._sectionStart);
            this._state === N || this._state === j || this._state === D ? this._cbs.oncdata(t) : this._state === P || this._state === M || this._state === k ? this._cbs.oncomment(t) : this._state !== at || this._xmlMode ? this._state !== st || this._xmlMode ? this._state !== ut || this._xmlMode ? this._state !== l && this._state !== _ && this._state !== g && this._state !== y && this._state !== m && this._state !== b && this._state !== v && this._state !== w && this._state !== h && this._cbs.ontext(t) : (this._decodeNumericEntity(3, 16), 
            this._sectionStart < this._index && (this._state = this._baseState, this._handleTrailingData())) : (this._decodeNumericEntity(2, 10), 
            this._sectionStart < this._index && (this._state = this._baseState, this._handleTrailingData())) : (this._parseLegacyEntity(), 
            this._sectionStart < this._index && (this._state = this._baseState, this._handleTrailingData()));
        }, mt.prototype.reset = function() {
            mt.call(this, {
                xmlMode: this._xmlMode,
                decodeEntities: this._decodeEntities
            }, this._cbs);
        }, mt.prototype.getAbsoluteIndex = function() {
            return this._bufferOffset + this._index;
        }, mt.prototype._getSection = function() {
            return this._buffer.substring(this._sectionStart, this._index);
        }, mt.prototype._emitToken = function(t) {
            this._cbs[t](this._getSection()), this._sectionStart = -1;
        }, mt.prototype._emitPartial = function(t) {
            this._baseState !== u ? this._cbs.onattribdata(t) : this._cbs.ontext(t);
        }, t.exports = mt;
    },
    aa2e: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        e.default = {
            namespaced: !0,
            state: {
                duration: null,
                vipDialog: !1
            },
            getters: {
                getDuration: function(t) {
                    return t.duration;
                },
                getVipDialog: function(t) {
                    return t.vipDialog;
                }
            },
            mutations: {
                setDuration: function(t, e) {
                    t.duration = e;
                },
                setVipDialog: function(t, e) {
                    t.vipDialog = e;
                }
            },
            actions: {}
        };
    },
    b17c: function(t, e, n) {
        var r = n("4a4b"), i = n("6f8f");
        function o(e, n, a) {
            return i() ? (t.exports = o = Reflect.construct.bind(), t.exports.__esModule = !0, 
            t.exports.default = t.exports) : (t.exports = o = function(t, e, n) {
                var i = [ null ];
                i.push.apply(i, e);
                var o = Function.bind.apply(t, i), a = new o();
                return n && r(a, n.prototype), a;
            }, t.exports.__esModule = !0, t.exports.default = t.exports), o.apply(null, arguments);
        }
        t.exports = o, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    b69b: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var r = n("a548"), i = {
            input: !0,
            option: !0,
            optgroup: !0,
            select: !0,
            button: !0,
            datalist: !0,
            textarea: !0
        }, o = {
            tr: {
                tr: !0,
                th: !0,
                td: !0
            },
            th: {
                th: !0
            },
            td: {
                thead: !0,
                th: !0,
                td: !0
            },
            body: {
                head: !0,
                link: !0,
                script: !0
            },
            li: {
                li: !0
            },
            p: {
                p: !0
            },
            h1: {
                p: !0
            },
            h2: {
                p: !0
            },
            h3: {
                p: !0
            },
            h4: {
                p: !0
            },
            h5: {
                p: !0
            },
            h6: {
                p: !0
            },
            select: i,
            input: i,
            output: i,
            button: i,
            datalist: i,
            textarea: i,
            option: {
                option: !0
            },
            optgroup: {
                optgroup: !0
            }
        }, a = {
            __proto__: null,
            area: !0,
            base: !0,
            basefont: !0,
            br: !0,
            col: !0,
            command: !0,
            embed: !0,
            frame: !0,
            hr: !0,
            img: !0,
            input: !0,
            isindex: !0,
            keygen: !0,
            link: !0,
            meta: !0,
            param: !0,
            source: !0,
            track: !0,
            wbr: !0
        }, s = {
            __proto__: null,
            math: !0,
            svg: !0
        }, u = {
            __proto__: null,
            mi: !0,
            mo: !0,
            mn: !0,
            ms: !0,
            mtext: !0,
            "annotation-xml": !0,
            foreignObject: !0,
            desc: !0,
            title: !0
        }, c = /\s|\//;
        function l(t, e) {
            this._options = e || {}, this._cbs = t || {}, this._tagname = "", this._attribname = "", 
            this._attribvalue = "", this._attribs = null, this._stack = [], this._foreignContext = [], 
            this.startIndex = 0, this.endIndex = null, this._lowerCaseTagNames = "lowerCaseTags" in this._options ? !!this._options.lowerCaseTags : !this._options.xmlMode, 
            this._lowerCaseAttributeNames = "lowerCaseAttributeNames" in this._options ? !!this._options.lowerCaseAttributeNames : !this._options.xmlMode, 
            this._options.Tokenizer && (r = this._options.Tokenizer), this._tokenizer = new r(this._options, this), 
            this._cbs.onparserinit && this._cbs.onparserinit(this);
        }
        n("923f")(l, n("faa1").EventEmitter), l.prototype._updatePosition = function(t) {
            null === this.endIndex ? this._tokenizer._sectionStart <= t ? this.startIndex = 0 : this.startIndex = this._tokenizer._sectionStart - t : this.startIndex = this.endIndex + 1, 
            this.endIndex = this._tokenizer.getAbsoluteIndex();
        }, l.prototype.ontext = function(t) {
            this._updatePosition(1), this.endIndex--, this._cbs.ontext && this._cbs.ontext(t);
        }, l.prototype.onopentagname = function(t) {
            if (this._lowerCaseTagNames && (t = t.toLowerCase()), this._tagname = t, !this._options.xmlMode && t in o) for (var e; (e = this._stack[this._stack.length - 1]) in o[t]; this.onclosetag(e)) ;
            !this._options.xmlMode && t in a || (this._stack.push(t), t in s ? this._foreignContext.push(!0) : t in u && this._foreignContext.push(!1)), 
            this._cbs.onopentagname && this._cbs.onopentagname(t), this._cbs.onopentag && (this._attribs = {});
        }, l.prototype.onopentagend = function() {
            this._updatePosition(1), this._attribs && (this._cbs.onopentag && this._cbs.onopentag(this._tagname, this._attribs), 
            this._attribs = null), !this._options.xmlMode && this._cbs.onclosetag && this._tagname in a && this._cbs.onclosetag(this._tagname), 
            this._tagname = "";
        }, l.prototype.onclosetag = function(t) {
            if (this._updatePosition(1), this._lowerCaseTagNames && (t = t.toLowerCase()), (t in s || t in u) && this._foreignContext.pop(), 
            !this._stack.length || t in a && !this._options.xmlMode) this._options.xmlMode || "br" !== t && "p" !== t || (this.onopentagname(t), 
            this._closeCurrentTag()); else {
                var e = this._stack.lastIndexOf(t);
                if (-1 !== e) if (this._cbs.onclosetag) for (e = this._stack.length - e; e--; ) this._cbs.onclosetag(this._stack.pop()); else this._stack.length = e; else "p" !== t || this._options.xmlMode || (this.onopentagname(t), 
                this._closeCurrentTag());
            }
        }, l.prototype.onselfclosingtag = function() {
            this._options.xmlMode || this._options.recognizeSelfClosing || this._foreignContext[this._foreignContext.length - 1] ? this._closeCurrentTag() : this.onopentagend();
        }, l.prototype._closeCurrentTag = function() {
            var t = this._tagname;
            this.onopentagend(), this._stack[this._stack.length - 1] === t && (this._cbs.onclosetag && this._cbs.onclosetag(t), 
            this._stack.pop());
        }, l.prototype.onattribname = function(t) {
            this._lowerCaseAttributeNames && (t = t.toLowerCase()), this._attribname = t;
        }, l.prototype.onattribdata = function(t) {
            this._attribvalue += t;
        }, l.prototype.onattribend = function() {
            this._cbs.onattribute && this._cbs.onattribute(this._attribname, this._attribvalue), 
            this._attribs && !Object.prototype.hasOwnProperty.call(this._attribs, this._attribname) && (this._attribs[this._attribname] = this._attribvalue), 
            this._attribname = "", this._attribvalue = "";
        }, l.prototype._getInstructionName = function(t) {
            var e = t.search(c), n = e < 0 ? t : t.substr(0, e);
            return this._lowerCaseTagNames && (n = n.toLowerCase()), n;
        }, l.prototype.ondeclaration = function(t) {
            if (this._cbs.onprocessinginstruction) {
                var e = this._getInstructionName(t);
                this._cbs.onprocessinginstruction("!" + e, "!" + t);
            }
        }, l.prototype.onprocessinginstruction = function(t) {
            if (this._cbs.onprocessinginstruction) {
                var e = this._getInstructionName(t);
                this._cbs.onprocessinginstruction("?" + e, "?" + t);
            }
        }, l.prototype.oncomment = function(t) {
            this._updatePosition(4), this._cbs.oncomment && this._cbs.oncomment(t), this._cbs.oncommentend && this._cbs.oncommentend();
        }, l.prototype.oncdata = function(t) {
            this._updatePosition(1), this._options.xmlMode || this._options.recognizeCDATA ? (this._cbs.oncdatastart && this._cbs.oncdatastart(), 
            this._cbs.ontext && this._cbs.ontext(t), this._cbs.oncdataend && this._cbs.oncdataend()) : this.oncomment("[CDATA[" + t + "]]");
        }, l.prototype.onerror = function(t) {
            this._cbs.onerror && this._cbs.onerror(t);
        }, l.prototype.onend = function() {
            if (this._cbs.onclosetag) for (var t = this._stack.length; t > 0; this._cbs.onclosetag(this._stack[--t])) ;
            this._cbs.onend && this._cbs.onend();
        }, l.prototype.reset = function() {
            this._cbs.onreset && this._cbs.onreset(), this._tokenizer.reset(), this._tagname = "", 
            this._attribname = "", this._attribs = null, this._stack = [], this._cbs.onparserinit && this._cbs.onparserinit(this);
        }, l.prototype.parseComplete = function(t) {
            this.reset(), this.end(t);
        }, l.prototype.write = function(t) {
            this._tokenizer.write(t);
        }, l.prototype.end = function(t) {
            this._tokenizer.end(t);
        }, l.prototype.pause = function() {
            this._tokenizer.pause();
        }, l.prototype.resume = function() {
            this._tokenizer.resume();
        }, l.prototype.parseChunk = l.prototype.write, l.prototype.done = l.prototype.end, 
        e.default = l, t.exports = e.default;
    },
    b887: function(t, e, n) {
        var r = n("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i, o = r(n("9523")), a = n("ebf2"), s = "https://kc".concat(a.ENV, ".xinli001.com/"), u = "lingxikc/meditating/api/", c = (i = {
            getSessionKey: "".concat(s).concat(u, "miniApp/getSessionKey"),
            saveUserInfo: "".concat(s).concat(u, "miniApp/saveUserInfo"),
            meditationPay: "".concat(s).concat(u, "pay"),
            getIndexData: "".concat(s).concat(u, "index"),
            getFeaturedData: "".concat(s).concat(u, "getFeaturedList"),
            checkIsJoin: "".concat(s).concat(u, "checkIsJoin"),
            sortTags: "".concat(s).concat(u, "tagList"),
            practiceTagList: "".concat(s).concat(u, "meditatingTagList"),
            voiceTags: "".concat(s, "lingxikc/mediVoice/api/tagList"),
            voiceTagList: "".concat(s, "lingxikc/mediVoice/api/tagVoiceList"),
            myHomeInfo: "".concat(s).concat(u, "myHomeInfo"),
            getBaseInfo: "".concat(s, "lingxikc/user/api/getBaseInfo"),
            getMyVip: "".concat(s).concat(u, "myVip"),
            meditationVip: "".concat(s, "lingxikc/user/api/vip"),
            getFissionStatus: "".concat(s, "lingxikc/meditating/api/fission/getFissionStatus"),
            getFissionInvite: "".concat(s, "lingxikc/meditating/api/fission/getFissionInvite"),
            lottery: "".concat(s, "lingxikc/meditating/api/fission/lottery"),
            receive: "".concat(s, "lingxikc/meditating/api/fission/receive"),
            fetchDetail: "".concat(s).concat(u, "detail"),
            fetchMeditatingCollegeRate: "".concat(s).concat(u, "getMeditatingCollegeRate"),
            fetchLikeComment: "".concat(s).concat(u, "likeComment"),
            fetchPlayDone: "".concat(s).concat(u, "playDone"),
            fetchBookPlayInfo: "".concat(s).concat(u, "play"),
            fetchCountTime: "".concat(s).concat("lingxikc/common/api/", "countTime"),
            fetchPolyvPlayInfo: "".concat(s).concat("lingxikc/common/api/", "polyvPlayInfo"),
            fetchBeforePlay: "".concat(s).concat(u, "beforePlay")
        }, (0, o.default)(i, "meditationPay", "".concat(s).concat(u, "pay")), (0, o.default)(i, "fetchPractice", "".concat(s).concat(u, "detail")), 
        (0, o.default)(i, "getPlayRecordList", "".concat(s).concat(u, "getPlayRecordList")), 
        (0, o.default)(i, "mediVoiceInfo", "".concat(s).concat("lingxikc/mediVoice/api/", "info")), 
        (0, o.default)(i, "mediVoiceRecordPlay", "".concat(s).concat("lingxikc/mediVoice/api/", "recordPlay")), 
        (0, o.default)(i, "fetchMyPrompt", "".concat(s).concat(u, "myPrompt")), (0, o.default)(i, "joinAgainMeditating", "".concat(s).concat(u, "joinAgainMeditating")), 
        (0, o.default)(i, "getAssistanceUser", "".concat(s).concat(u, "practiseFission/getAssistanceUser")), 
        (0, o.default)(i, "getPractiseInvite", "".concat(s).concat(u, "practiseFission/getFissionInvite")), 
        (0, o.default)(i, "receivePractise", "".concat(s).concat(u, "practiseFission/receive")), 
        (0, o.default)(i, "checkAudit", "".concat(s).concat(u, "getExamineStatus")), (0, 
        o.default)(i, "getRecommendMediRate", "".concat(s).concat(u, "getRecommendMediRate")), 
        (0, o.default)(i, "fetchPlayRecord", "".concat(s).concat(u, "visited")), (0, o.default)(i, "getActivityToo", "".concat(s).concat(u, "getActivityTool")), 
        (0, o.default)(i, "getAdvertisingList", "".concat(s).concat(u, "getAdvertisingList")), 
        i);
        e.default = c;
    },
    bc2e: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r = [ "qy", "env", "error", "version", "lanDebug", "cloud", "serviceMarket", "router", "worklet" ], i = [ "lanDebug", "router", "worklet" ], o = "undefined" != typeof globalThis ? globalThis : function() {
            return this;
        }(), a = [ "w", "x" ].join(""), s = o[a], u = s.getLaunchOptionsSync ? s.getLaunchOptionsSync() : null;
        function c(t) {
            return (!u || 1154 !== u.scene || !i.includes(t)) && (r.indexOf(t) > -1 || "function" == typeof s[t]);
        }
        o[a] = function() {
            var t = {};
            for (var e in s) c(e) && (t[e] = s[e]);
            return t;
        }();
        var l = o[a];
        e.default = l;
    },
    c135: function(t, e) {
        t.exports = function(t) {
            if (Array.isArray(t)) return t;
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    c240: function(t, e) {
        t.exports = function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    c8ba: function(t, e) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (t) {
            "object" === ("undefined" == typeof window ? "undefined" : _typeof3(window)) && (n = window);
        }
        t.exports = n;
    },
    c973: function(t, e) {
        function n(t, e, n, r, i, o, a) {
            try {
                var s = t[o](a), u = s.value;
            } catch (t) {
                return void n(t);
            }
            s.done ? e(u) : Promise.resolve(u).then(r, i);
        }
        t.exports = function(t) {
            return function() {
                var e = this, r = arguments;
                return new Promise(function(i, o) {
                    var a = t.apply(e, r);
                    function s(t) {
                        n(a, i, o, s, u, "next", t);
                    }
                    function u(t) {
                        n(a, i, o, s, u, "throw", t);
                    }
                    s(void 0);
                });
            };
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    d177: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r = {
            onLoad: function() {
                for (var t = this, e = arguments.length, n = new Array(e), r = 0; r < e; r++) n[r] = arguments[r];
                this.$utils.loginOver().then(function(e) {
                    t._initData && t._initData(n);
                });
            }
        };
        e.default = r;
    },
    d489: function(t, e, n) {
        var r = n("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = r(n("9523"));
        function o(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(t);
                e && (r = r.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), n.push.apply(n, r);
            }
            return n;
        }
        function a(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? o(Object(n), !0).forEach(function(e) {
                    (0, i.default)(t, e, n[e]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                });
            }
            return t;
        }
        var s = {
            methods: {
                bookClubPay: function(t) {
                    var e = this, n = {
                        "order.channelId": getApp().globalData.channelId,
                        "order.tradeType": "ALI_PAY_WAP"
                    };
                    return this.$http({
                        url: this.$APIS.meditationPay,
                        data: a(a({}, n), t)
                    }).then(function(t) {
                        var e = t.code;
                        if (t.data, 200 === Number(e)) return Promise.resolve({
                            message: "freeSuccess"
                        });
                    }).catch(function(t) {
                        return e.hideLoading().then(function() {
                            return Promise.reject(t);
                        });
                    });
                }
            }
        };
        e.default = s;
    },
    e2ed: function(t, e, n) {
        var r = n("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = r(n("9523")), o = n("f8e4"), a = r(n("b887"));
        function s(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(t);
                e && (r = r.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), n.push.apply(n, r);
            }
            return n;
        }
        function u(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? s(Object(n), !0).forEach(function(e) {
                    (0, i.default)(t, e, n[e]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach(function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                });
            }
            return t;
        }
        var c = {
            namespaced: !0,
            state: {
                userInfoDialog: !1,
                wxUserInfo: {},
                baseInfo: {},
                completeShare: {
                    type: "practice",
                    meditatingId: "",
                    title: ""
                },
                payStatus: !1
            },
            getters: {
                getUserInfoDialog: function(t) {
                    return t.userInfoDialog;
                },
                getWxUserInfo: function(t) {
                    return t.wxUserInfo;
                },
                getBaseInfo: function(t) {
                    return t.baseInfo;
                },
                getCompleteShare: function(t) {
                    return t.completeShare;
                },
                getPayStatus: function(t) {
                    return t.payStatus;
                }
            },
            mutations: {
                setUserInfoDialog: function(t, e) {
                    t.userInfoDialog = e;
                },
                setWxUserInfo: function(t, e) {
                    console.log("setWxUserInfo", e), t.wxUserInfo = e;
                },
                setBaseInfo: function(t, e) {
                    t.baseInfo = e;
                },
                setCompleteShare: function(t, e) {
                    console.log(e), t.completeShare = e;
                },
                setPayStatus: function(t, e) {
                    t.payStatus = e;
                }
            },
            actions: {
                fetchBaseInfo: function(t, e) {
                    var n = t.commit;
                    return (0, o.http)({
                        url: a.default.getBaseInfo,
                        data: {
                            vipType: 2
                        }
                    }).then(function(t) {
                        if ("1" === t.code) {
                            var e = t.data.userVo, r = u(u({}, e), {}, {
                                avatarUrl: e.avatar,
                                nickName: e.nickname
                            });
                            n("setBaseInfo", r), console.log("getWxUserInfo", r);
                        }
                    });
                }
            }
        };
        e.default = c;
    },
    e50d: function(t, e, n) {
        var r = n("7037").default;
        t.exports = function(t, e) {
            if ("object" !== r(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 !== n) {
                var i = n.call(t, e || "default");
                if ("object" !== r(i)) return i;
                throw new TypeError("@@toPrimitive must return a primitive value.");
            }
            return ("string" === e ? String : Number)(t);
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    e546: function(t, e, n) {
        (function(t) {
            var r = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = r(n("2eee")), o = r(n("9523")), a = r(n("c973")), s = r(n("970b")), u = r(n("5bc3")), c = r(n("6e5b"));
            function l(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function f(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? l(Object(n), !0).forEach(function(e) {
                        (0, o.default)(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : l(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            var d = function() {
                function e(t) {
                    (0, s.default)(this, e), console.log("create player"), this.loading = 1, this.progress = 0, 
                    this.duration = 6e4, this.playing = 0, this.useBgm = 1, this.playComplete = 0, this.forceStop = !1, 
                    this.startAtSecond = 0, this.BGMPLayer = null, this.MainPlayer = null, this.progeressTimer = null, 
                    this.record = 0, this.seekHistory = [], this.startTimeStr = "", this.BGMpolyvConfig = t, 
                    this.MainPolyvConfig = null, this.userPlay = !1, this.progressHandler = null;
                }
                return (0, u.default)(e, [ {
                    key: "getAudioSrc",
                    value: function() {
                        var e = (0, a.default)(i.default.mark(function e(n) {
                            return i.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return n.vid || console.log("获取音频src, 没有vid", n), e.abrupt("return", new Promise(function(e, r) {
                                        var i = {
                                            vid: n.vid,
                                            useAudio: !0,
                                            callback: function(n) {
                                                console.log(n, "获取音频src成功"), n && n.src ? e(f(f({}, n), {}, {
                                                    src: n.src[0]
                                                })) : (t.showToast({
                                                    title: "获取音频src失败"
                                                }), r());
                                            }
                                        };
                                        c.default.getVideo(i);
                                    }));

                                  case 2:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }));
                        return function(t) {
                            return e.apply(this, arguments);
                        };
                    }()
                }, {
                    key: "initBothPlayer",
                    value: function() {
                        var t = (0, a.default)(i.default.mark(function t(e, n) {
                            return i.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return console.log("初始化双播放器"), t.next = 3, this.initBGMPlayer();

                                  case 3:
                                    return t.abrupt("return", this.initMainPlayer(e));

                                  case 4:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        return function(e, n) {
                            return t.apply(this, arguments);
                        };
                    }()
                }, {
                    key: "initPay",
                    value: function() {
                        this.playing = 1, this.playComplete = 0, this.clearSeekHistory(), this.startProgress();
                    }
                }, {
                    key: "initBGMPlayer",
                    value: function() {
                        var e = (0, a.default)(i.default.mark(function e() {
                            var n, r, o = this;
                            return i.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (this.BGMpolyvConfig) {
                                        e.next = 2;
                                        break;
                                    }
                                    return e.abrupt("return");

                                  case 2:
                                    if (!this.BGMPLayer || !this.BGMPLayer.src) {
                                        e.next = 4;
                                        break;
                                    }
                                    return e.abrupt("return");

                                  case 4:
                                    return console.log("初始化背景音", this.BGMpolyvConfig), e.next = 7, this.getAudioSrc(this.BGMpolyvConfig);

                                  case 7:
                                    return n = e.sent, r = n.src, this.BGMPLayer || (this.BGMPLayer = t.createInnerAudioContext()), 
                                    this.BGMPLayer.loop = this.BGMpolyvConfig.loop, this.BGMPLayer.autoplay = this.BGMpolyvConfig.autoplay, 
                                    this.BGMPLayer.volume = this.BGMpolyvConfig.volume, this.BGMPLayer.obeyMuteSwitch = this.BGMpolyvConfig.obeyMuteSwitch, 
                                    this.BGMPLayer.src = r, t.setInnerAudioOption({
                                        obeyMuteSwitch: !1
                                    }), console.log(this.BGMPLayer, "this.BGMPLayer"), e.abrupt("return", new Promise(function(t) {
                                        o.BGMPLayer.onCanplay(function() {
                                            console.log("BGM音频进入可以播放状态，但不保证后面可以流畅播放"), t();
                                        });
                                    }));

                                  case 18:
                                  case "end":
                                    return e.stop();
                                }
                            }, e, this);
                        }));
                        return function() {
                            return e.apply(this, arguments);
                        };
                    }()
                }, {
                    key: "initMainPlayer",
                    value: function() {
                        var t = (0, a.default)(i.default.mark(function t() {
                            var e, n = this, r = arguments;
                            return i.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return (e = r.length > 0 && void 0 !== r[0] ? r[0] : this.MainPolyvConfig) && (this.MainPolyvConfig = e), 
                                    t.abrupt("return", new Promise(function(t) {
                                        n.setMainPlayer(e).then(function() {
                                            console.log("初始化setMainPlayer回调"), n.initPay(), (e.autoplay || n.userPlay) && (n.startTimeStr = n.getCurTime()), 
                                            t();
                                        });
                                    }));

                                  case 3:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        return function() {
                            return t.apply(this, arguments);
                        };
                    }()
                }, {
                    key: "getCurTime",
                    value: function() {
                        var t = new Date();
                        return "".concat(t.getFullYear(), "-").concat((t.getMonth() + 1 + "").padStart(2, "0"), "-").concat(t.getDate(), " ").concat(String(t.getHours()).padStart(2, "0"), ":").concat(String(t.getMinutes()).padStart(2, "0"), ":").concat(String(t.getSeconds()).padStart(2, "0"));
                    }
                }, {
                    key: "changeVid",
                    value: function() {
                        var t = (0, a.default)(i.default.mark(function t(e) {
                            var n = this;
                            return i.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    console.log("切换音视频"), this.MainPolyvConfig = e, this.setMainPlayer({
                                        vid: e.vid
                                    }).then(function(t) {
                                        n.initPay();
                                    });

                                  case 3:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        return function(e) {
                            return t.apply(this, arguments);
                        };
                    }()
                }, {
                    key: "setMainPlayer",
                    value: function(e) {
                        var n = this;
                        return new Promise(function() {
                            var r = (0, a.default)(i.default.mark(function r(o, a) {
                                var s, u, c;
                                return i.default.wrap(function(r) {
                                    for (;;) switch (r.prev = r.next) {
                                      case 0:
                                        return r.next = 2, n.getAudioSrc(e);

                                      case 2:
                                        s = r.sent, u = s.src, c = s.duration, n.MainPlayer || (n.MainPlayer = t.getBackgroundAudioManager()), 
                                        n.MainPlayer.src = u, n.MainPlayer.title = n.MainPolyvConfig.title, n.MainPlayer.coverImgUrl = n.MainPolyvConfig.cover, 
                                        n.MainPlayer.obeyMuteSwitch = !1, n.duration = Math.ceil(c), n.MainPlayer.onEnded(function() {
                                            console.log("自然结束"), n.stop(!0);
                                        }), n.MainPlayer.onStop(function() {
                                            console.log("监听到停止事件"), n.playing = 0, n.playComplete = 1, n.useBgm && n.BGMPLayer && n.BGMPLayer.stop(), 
                                            n.forceStop = !0;
                                        }), n.MainPlayer.onPause(function() {
                                            console.log("监听到暂停事件"), n.pause();
                                        }), n.MainPlayer.onPlay(function() {
                                            console.log("监听到播放事件"), n.play();
                                        }), n.MainPlayer.onCanplay(function() {
                                            console.log("主音频进入可以播放状态，但不保证后面可以流畅播放, 这个时候主音频对象上还没有src"), o();
                                        }), console.log(n.MainPlayer, "this.MainPlayer");

                                      case 16:
                                      case "end":
                                        return r.stop();
                                    }
                                }, r);
                            }));
                            return function(t, e) {
                                return r.apply(this, arguments);
                            };
                        }());
                    }
                }, {
                    key: "play",
                    value: function() {
                        var t = (0, a.default)(i.default.mark(function t(e) {
                            var n, r = arguments;
                            return i.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    if (n = r.length > 1 && void 0 !== r[1] && r[1], this.userPlay = !0, !this.useBgm || !this.BGMpolyvConfig) {
                                        t.next = 6;
                                        break;
                                    }
                                    return t.next = 5, this.initBGMPlayer();

                                  case 5:
                                    getApp().globalData._platform || this.BGMPLayer.play();

                                  case 6:
                                    this.startTimeStr = this.startTimeStr || this.getCurTime(), this.MainPlayer && this.MainPlayer.src ? (void 0 === e || Number.isNaN(1 * e) || this.seek(e, n), 
                                    this.MainPlayer.play(), this.playing = 1, this.playComplete = 0, this.startProgress()) : this.MainPolyvConfig ? this.initMainPlayer() : console.error("@Medi player: progressTimer is undefined"), 
                                    this.forceStop = !1;

                                  case 9:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        return function(e) {
                            return t.apply(this, arguments);
                        };
                    }()
                }, {
                    key: "pause",
                    value: function() {
                        var t = this;
                        console.log("pause"), setTimeout(function() {
                            t.useBgm && t.BGMPLayer && t.BGMPLayer.pause(), t.MainPlayer && t.MainPlayer.pause(), 
                            t.playing = 0;
                        }, 50);
                    }
                }, {
                    key: "stop",
                    value: function(t) {
                        console.info("@Medi player: polyv stop", t), this.playing = 0, this.playComplete = 1, 
                        this.useBgm && this.BGMPLayer && this.BGMPLayer.stop(), this.MainPlayer && !t && (this.MainPlayer.stop(), 
                        "function" == typeof this.endHandler && this.endHandler(this.getStayTime(), t), 
                        this.forceStop = !0);
                    }
                }, {
                    key: "replay",
                    value: function() {
                        return console.log("@mediPlayer: replay"), this.clearSeekHistory(), this.startAtSecond = 0, 
                        this.play(0, !0);
                    }
                }, {
                    key: "seek",
                    value: function(t) {
                        var e = this, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                        return console.log("sec, dontRecord = 0", t, n = 0), new Promise(function(r) {
                            if (!e.MainPlayer || !e.MainPlayer.src) {
                                if (!e.MainPolyvConfig) return void console.error("@mediPlayerSeek: mediPlayerPlay is undefined，unable to seek");
                                e.initMainPlayer().then(function() {
                                    e.seek(t);
                                });
                            }
                            var i = e.getProgress() - t;
                            0 === i || Number.isNaN(i) || n || (console.log("push seek", i), e.seekHistory.push(i)), 
                            e.MainPlayer.seek(t), console.info("@Medi player: seek " + t), r();
                        });
                    }
                }, {
                    key: "startProgress",
                    value: function() {
                        var t = this;
                        if (this.progeressTimer && this.stopProgress(), this.MainPlayer) {
                            if (this.playing) {
                                var e = this.progress;
                                this.progress = this.getProgress(), e === this.progress ? this.loading = 1 : this.loading = 0, 
                                this.progress > 0 && (this.record++, this.duration = Math.ceil(this.MainPlayer.duration)), 
                                this.progeressTimer = setTimeout(function() {
                                    t.startProgress();
                                }, 1e3), "function" == typeof this.progressHandler && this.progressHandler();
                            } else if (this.playComplete && !this.forceStop) {
                                this.duration - this.progress > 0 ? (this.progress++, this.progeressTimer = setTimeout(function() {
                                    t.startProgress();
                                }, 1e3)) : (this.stopProgress(), "function" == typeof this.endHandler && this.endHandler(this.getStayTime(), !0));
                            }
                        } else console.error("@mediPlayerRunProgress: medi_mix_PlayerProgressTimer is undefined");
                    }
                }, {
                    key: "stopProgress",
                    value: function() {
                        this.progeressTimer && clearTimeout(this.progeressTimer);
                    }
                }, {
                    key: "getProgress",
                    value: function() {
                        var t = this.MainPlayer.currentTime;
                        return this.MainPlayer ? t : 0;
                    }
                }, {
                    key: "getStayTime",
                    value: function() {
                        var t = this.seekHistory.reduce(function(t, e) {
                            return t + e;
                        }, this.playComplete ? this.progress : this.getProgress());
                        return t < 0 && (console.log("@polyvplayer: staytime 异常，返回duration"), t = this.duration), 
                        Math.ceil(t);
                    }
                }, {
                    key: "toggleBGM",
                    value: function() {
                        this.useBgm = !this.useBgm, console.log("now useBGM:" + this.useBgm), console.log("now useBGM:" + this.BGMPLayer), 
                        this.BGMPLayer && (this.useBgm ? this.BGMPLayer.play() : this.BGMPLayer.pause());
                    }
                }, {
                    key: "pauseBGM",
                    value: function() {
                        console.log("背景音乐暂停", this.BGMPLayer), this.useBgm = !1, this.BGMPLayer && this.BGMPLayer.pause();
                    }
                }, {
                    key: "destory",
                    value: function() {
                        this.BGMPLayer.destroy(), this.MainPlayer.destroy();
                    }
                }, {
                    key: "onEnd",
                    value: function(t) {
                        if (this.MainPlayer && "function" == typeof t) if ("function" == typeof this.endHandler) {
                            var e = this.endHandler;
                            this.endHandler = function() {
                                e(), t();
                            };
                        } else this.endHandler = t;
                    }
                }, {
                    key: "onProgress",
                    value: function(t) {
                        this.MainPlayer && "function" == typeof t && (this.progressHandler = t);
                    }
                }, {
                    key: "clearSeekHistory",
                    value: function() {
                        this.seekHistory = [];
                    }
                } ]), e;
            }();
            e.default = d;
        }).call(this, n("543d").default);
    },
    eb14: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r = {}, i = {
            $on: function(t, e) {
                r[t] || (r[t] = []), r[t].push(e);
            },
            $emit: function(t, e) {
                var n = r[t];
                n && n.map(function(t) {
                    t(e);
                });
            },
            $off: function(t, e) {
                var n = r[t];
                r[t] = e ? n.filter(function(t) {
                    return t != e;
                }) : null;
            },
            $once: function(t, e) {
                r[t] = [ e ];
            }
        };
        e.default = i;
    },
    ebd0: function(t, e, n) {
        var r = n("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = r(n("44a2")), o = r(n("f79d"));
        r(n("1123"));
        var a = function() {
            var t = null, e = null;
            return function(n, r, a) {
                if ("reset" === n) t = e = null; else {
                    if (!n) return e;
                    if (t === n) return e;
                    if (e && (console.log("统计上个播放对象的时长,并停止初始化."), e.trackLearnTime(), e.stop(!0), e.initPay(), 
                    e.stopProgress()), null != r) {
                        if (t = n, "practiceToPlay" === n) return e = new i.default(r, a);
                        if ("voicePlay" === n) return e = new o.default(r, a);
                    }
                }
            };
        }();
        e.default = a;
    },
    ebf2: function(t, e, n) {
        var r = n("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.upperFirstChat = e.toVersion = e.setScrollTop = e.secondsFormat = e.secondToTime = e.padZero = e.onShareTimeLine = e.onShareAppMessage = e.obj2FormObjForOneDimen = e.loadScript = e.formatTimeToDuring = e.formatDuring = e.businessDomain = e.ENV = void 0;
        var i = r(n("9523"));
        function o(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(t);
                e && (r = r.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), n.push.apply(n, r);
            }
            return n;
        }
        function a(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? o(Object(n), !0).forEach(function(e) {
                    (0, i.default)(t, e, n[e]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                });
            }
            return t;
        }
        e.ENV = "", e.businessDomain = [ "kc-box5.xinli001.com", "kc-qc4.xinli001.com", "kc.xinli001.com", "medi-box5.onexinli.com", "medi-qc4.onexinli.com", "medi.onexinli.com", "static-box5.xinli001.com", "static-qc4.xinli001.com", "static.xinli001.com", "hd-box5.onexinli.com", "hd-qc4.onexinli.com", "hd.onexinli.com", "countsheep.cn", "tongji.dcloud.io" ], 
        e.onShareAppMessage = function(t) {
            return console.log(a({
                title: "最近发现一个睡眠、放松、减压正念冥想神器！推荐！",
                imageUrl: "https://lapp.xinli001.com/images/medi-wxapp/images/share.jpg",
                path: "/pages/explore/explore"
            }, t)), a({
                title: "最近发现一个睡眠、放松、减压正念冥想神器！推荐！",
                imageUrl: "https://lapp.xinli001.com/images/medi-wxapp/images/share.jpg",
                path: "/pages/explore/explore"
            }, t);
        }, e.onShareTimeLine = function(t) {
            return console.log(a({
                title: "最近发现一个睡眠、放松、减压正念冥想神器！推荐！",
                imageUrl: "https://lapp.xinli001.com/images/medi-wxapp/images/share.jpg"
            }, t)), a({
                title: "最近发现一个睡眠、放松、减压正念冥想神器！推荐！",
                imageUrl: "https://lapp.xinli001.com/images/medi-wxapp/images/share.jpg"
            }, t);
        }, e.upperFirstChat = function(t) {
            return t[0].toUpperCase() + t.slice(1);
        }, e.loadScript = function(t) {
            return window.loadedScript = window.loadedScript || [], new Promise(function(e) {
                window.loadedScript.includes(t) && e({
                    code: 1,
                    msg: "this script was loaded"
                });
                var n = document.createElement("script");
                n.type = "text/javascript", n.src = t, document.getElementsByTagName("head")[0].appendChild(n), 
                n.onload = function() {
                    n.onload = null, window.loadedScript.push(t), e({
                        code: 1,
                        msg: "script load success!"
                    });
                };
            });
        }, e.secondToTime = function(t) {
            if (!t) return "00:00";
            var e = s(Math.floor(t) % 60, 2), n = Math.floor(t / 60).toFixed(0);
            return (n + "").length < 2 && (n = s(n, 2)), "".concat(n, ":").concat(e);
        };
        var s = function(t, e) {
            return (Array(e).join("0") + t).slice(-e);
        };
        e.padZero = s, e.setScrollTop = function(t) {
            "number" == typeof (1 * t) ? (document.documentElement && void 0 !== document.documentElement.scrollTop && (document.documentElement.scrollTop = t), 
            document.body && void 0 !== document.body.scrollTop && (document.body.scrollTop = t)) : console.error("设置scrollTop传入的值不是数字");
        }, e.formatDuring = function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "'", n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : '"';
            if (!t) return "0";
            var r = parseInt(t % 36e5 / 6e4), i = Math.round(t % 6e4 / 1e3);
            return "".concat(s(r, 2)).concat(e).concat(s(i, 2)).concat(n);
        }, e.secondsFormat = function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ":", n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : ":", r = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3], i = Math.floor(t / 86400), o = Math.floor((t - 24 * i * 3600) / 3600), a = Math.floor((t - 24 * i * 3600 - 3600 * o) / 60), u = Math.round(t - 24 * i * 3600 - 3600 * o - 60 * a), c = s(o, 2) + e;
            return r || (c = ""), c + s(a, 2) + n + s(u, 2);
        }, e.formatTimeToDuring = function(t) {
            return t && "string" == typeof t ? 60 * (1 * t.split(":")[0]) + 1 * t.split(":")[1].split(".")[0] : 0;
        }, e.obj2FormObjForOneDimen = function(t, e) {
            for (var n = {}, r = 0; r < t.length; r++) n[e + "[" + r + "]"] = t[r];
            return n;
        }, e.toVersion = function(t) {
            for (var e = t.toString().split("."), n = [ "", "0", "00", "000", "0000" ].reverse(), r = 0; r < e.length; r++) {
                var i = e[r].length;
                e[r] = n[i] + e[r];
            }
            return e.join("");
        };
    },
    ed6d: function(t, e, n) {
        var r = n("4a4b");
        t.exports = function(t, e) {
            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
            t.prototype = Object.create(e && e.prototype, {
                constructor: {
                    value: t,
                    writable: !0,
                    configurable: !0
                }
            }), Object.defineProperty(t, "prototype", {
                writable: !1
            }), e && r(t, e);
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    f0c5: function(t, e, n) {
        function r(t, e, n, r, i, o, a, s, u, c) {
            var l, f = "function" == typeof t ? t.options : t;
            if (u) {
                f.components || (f.components = {});
                var d = Object.prototype.hasOwnProperty;
                for (var h in u) d.call(u, h) && !d.call(f.components, h) && (f.components[h] = u[h]);
            }
            if (c && ("function" == typeof c.beforeCreate && (c.beforeCreate = [ c.beforeCreate ]), 
            (c.beforeCreate || (c.beforeCreate = [])).unshift(function() {
                this[c.__module] = this;
            }), (f.mixins || (f.mixins = [])).push(c)), e && (f.render = e, f.staticRenderFns = n, 
            f._compiled = !0), r && (f.functional = !0), o && (f._scopeId = "data-v-" + o), 
            a ? (l = function(t) {
                (t = t || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (t = __VUE_SSR_CONTEXT__), 
                i && i.call(this, t), t && t._registeredComponents && t._registeredComponents.add(a);
            }, f._ssrRegister = l) : i && (l = s ? function() {
                i.call(this, this.$root.$options.shadowRoot);
            } : i), l) if (f.functional) {
                f._injectStyles = l;
                var p = f.render;
                f.render = function(t, e) {
                    return l.call(e), p(t, e);
                };
            } else {
                var _ = f.beforeCreate;
                f.beforeCreate = _ ? [].concat(_, l) : [ l ];
            }
            return {
                exports: t,
                options: f
            };
        }
        n.d(e, "a", function() {
            return r;
        });
    },
    f0e4: function(t, e) {
        t.exports = function(t, e) {
            if (null == t) return {};
            var n, r, i = {}, o = Object.keys(t);
            for (r = 0; r < o.length; r++) n = o[r], e.indexOf(n) >= 0 || (i[n] = t[n]);
            return i;
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
    },
    f23f: function(t, e, n) {
        var r = this && this.__createBinding || (Object.create ? function(t, e, n, r) {
            void 0 === r && (r = n);
            var i = Object.getOwnPropertyDescriptor(e, n);
            i && !("get" in i ? !e.__esModule : i.writable || i.configurable) || (i = {
                enumerable: !0,
                get: function() {
                    return e[n];
                }
            }), Object.defineProperty(t, r, i);
        } : function(t, e, n, r) {
            void 0 === r && (r = n), t[r] = e[n];
        }), i = this && this.__exportStar || function(t, e) {
            for (var n in t) "default" === n || Object.prototype.hasOwnProperty.call(e, n) || r(e, t, n);
        };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.DomHandler = void 0;
        var o = n("6403"), a = n("01d0");
        i(n("01d0"), e);
        var s = /\s+/g, u = {
            normalizeWhitespace: !1,
            withStartIndices: !1,
            withEndIndices: !1,
            xmlMode: !1
        }, c = function() {
            function t(t, e, n) {
                this.dom = [], this.root = new a.Document(this.dom), this.done = !1, this.tagStack = [ this.root ], 
                this.lastNode = null, this.parser = null, "function" == typeof e && (n = e, e = u), 
                "object" === _typeof3(t) && (e = t, t = void 0), this.callback = null != t ? t : null, 
                this.options = null != e ? e : u, this.elementCB = null != n ? n : null;
            }
            return t.prototype.onparserinit = function(t) {
                this.parser = t;
            }, t.prototype.onreset = function() {
                this.dom = [], this.root = new a.Document(this.dom), this.done = !1, this.tagStack = [ this.root ], 
                this.lastNode = null, this.parser = null;
            }, t.prototype.onend = function() {
                this.done || (this.done = !0, this.parser = null, this.handleCallback(null));
            }, t.prototype.onerror = function(t) {
                this.handleCallback(t);
            }, t.prototype.onclosetag = function() {
                this.lastNode = null;
                var t = this.tagStack.pop();
                this.options.withEndIndices && (t.endIndex = this.parser.endIndex), this.elementCB && this.elementCB(t);
            }, t.prototype.onopentag = function(t, e) {
                var n = this.options.xmlMode ? o.ElementType.Tag : void 0, r = new a.Element(t, e, void 0, n);
                this.addNode(r), this.tagStack.push(r);
            }, t.prototype.ontext = function(t) {
                var e = this.options.normalizeWhitespace, n = this.lastNode;
                if (n && n.type === o.ElementType.Text) e ? n.data = (n.data + t).replace(s, " ") : n.data += t, 
                this.options.withEndIndices && (n.endIndex = this.parser.endIndex); else {
                    e && (t = t.replace(s, " "));
                    var r = new a.Text(t);
                    this.addNode(r), this.lastNode = r;
                }
            }, t.prototype.oncomment = function(t) {
                if (this.lastNode && this.lastNode.type === o.ElementType.Comment) this.lastNode.data += t; else {
                    var e = new a.Comment(t);
                    this.addNode(e), this.lastNode = e;
                }
            }, t.prototype.oncommentend = function() {
                this.lastNode = null;
            }, t.prototype.oncdatastart = function() {
                var t = new a.Text(""), e = new a.NodeWithChildren(o.ElementType.CDATA, [ t ]);
                this.addNode(e), t.parent = e, this.lastNode = t;
            }, t.prototype.oncdataend = function() {
                this.lastNode = null;
            }, t.prototype.onprocessinginstruction = function(t, e) {
                var n = new a.ProcessingInstruction(t, e);
                this.addNode(n);
            }, t.prototype.handleCallback = function(t) {
                if ("function" == typeof this.callback) this.callback(t, this.dom); else if (t) throw t;
            }, t.prototype.addNode = function(t) {
                var e = this.tagStack[this.tagStack.length - 1], n = e.children[e.children.length - 1];
                this.options.withStartIndices && (t.startIndex = this.parser.startIndex), this.options.withEndIndices && (t.endIndex = this.parser.endIndex), 
                e.children.push(t), n && (t.prev = n, n.next = t), t.parent = e, this.lastNode = null;
            }, t;
        }();
        e.DomHandler = c, e.default = c;
    },
    f4d9: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        e.default = {
            namespaced: !0,
            state: {
                harderTitleAvtive: null
            },
            getters: {
                getHarderTitleAvtive: function(t) {
                    return t.harderTitleAvtive;
                }
            },
            mutations: {
                setHarderTitleAvtive: function(t, e) {
                    t.harderTitleAvtive = e;
                }
            },
            actions: {}
        };
    },
    f79d: function(t, e, n) {
        var r = n("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = r(n("970b")), o = r(n("5bc3")), a = r(n("ed6d")), s = r(n("6b58")), u = r(n("36c6")), c = r(n("06e8")), l = r(n("1123")), f = n("f8e4"), d = r(n("b887"));
        r(n("eb14"));
        var h = function(t) {
            (0, a.default)(n, t);
            var e = function(t) {
                var e = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
                        !0;
                    } catch (t) {
                        return !1;
                    }
                }();
                return function() {
                    var n, r = (0, u.default)(t);
                    if (e) {
                        var i = (0, u.default)(this).constructor;
                        n = Reflect.construct(r, arguments, i);
                    } else n = r.apply(this, arguments);
                    return (0, s.default)(this, n);
                };
            }(n);
            function n(t) {
                var r, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                return (0, i.default)(this, n), (r = e.call(this, "")).playType = "voice", r.mainConfig = null, 
                r.recordBase = 0, r.mediId = t, r.mediInfo = {}, r.startAtSecond = o, r.mediTimes = 0, 
                r.endMediHandler = null, r.mediComplete = !1, r.todayLearnTime = 0, r.polyVid = "", 
                r.init(t), r;
            }
            return (0, o.default)(n, [ {
                key: "init",
                value: function(t) {
                    var e = this;
                    this.mediId = t, this.getPlayData(t).then(function() {
                        console.log(e.polyVid, "polyVid"), e.polyVid && e.initMainPlayer({
                            vid: e.polyVid,
                            title: e.mediInfo.title,
                            cover: e.mediInfo.cover
                        }).then(function() {
                            e.onProgress(function() {
                                e.getStayTime() > 0 && e.getStayTime() % 600 == 0 && Number.isNaN(e.allPlayTime) && e.fetchFinishRecord(0, !1);
                            }), l.default.getters["mine/getHomeInfo"].totalLearnDays ? e.mediTimes = l.default.getters["mine/getHomeInfo"].totalLearnDays : l.default.dispatch("mine/fetchHomeInfo").then(function(t) {
                                e.mediTimes = t.totalLearnDays;
                            });
                        });
                    });
                }
            }, {
                key: "fetchFinishRecord",
                value: function(t) {
                    var e = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], n = this.getStayTime(), r = {
                        objectName: "MEDI_VOICE",
                        objectId: this.mediInfo.id,
                        objectChildId: 0,
                        startTimeStr: this.startTimeStr ? this.startTimeStr : p(),
                        recordSecond: n ? n + "" : 0,
                        iosStatus: 0,
                        platform: 4,
                        offline: 0,
                        playDone: t ? 1 : 0
                    };
                    [ null, void 0, "", NaN ].includes(r.startTimeStr) && (r.startTimeStr = p(new Date()));
                    var i = [ r ];
                    return console.log("播放记录", i), this.startTimeStr = e ? "" : this.startTimeStr, (0, 
                    f.http)({
                        url: d.default.fetchPlayRecord,
                        data: {
                            visiteds: JSON.stringify(i)
                        }
                    });
                }
            }, {
                key: "getPlayData",
                value: function(t) {
                    var e = this;
                    return (0, f.http)({
                        url: d.default.mediVoiceRecordPlay,
                        data: {
                            voiceId: t
                        }
                    }).then(function() {
                        return (0, f.http)({
                            url: d.default.mediVoiceInfo,
                            data: {
                                id: t
                            }
                        }).then(function(t) {
                            var n = t.code, r = t.data;
                            t.msg, console.log("medi api done", r), 1 == +n && (e.recordBase = r.todayLearnTime, 
                            e.todayLearnTime = r.todayLearnTime, e.mediInfo = r.voiceInfo, e.polyVid = r.polyVid, 
                            e.duration = r.voiceInfo && r.voiceInfo.duration);
                        });
                    });
                }
            }, {
                key: "changeMediId",
                value: function(t, e) {
                    var n = this;
                    console.info("替换音频"), this.mediId = t, this.startAtSecond = e, this.mediComplete = !1, 
                    this.getPlayData(t).then(function() {
                        n.polyVid && n.changeVid({
                            vid: n.polyVid,
                            title: n.mediInfo.title,
                            cover: n.mediInfo.cover
                        });
                    });
                }
            }, {
                key: "trackLearnTime",
                value: function(t) {
                    return t = this.getStayTime() || t, console.log("学习时间", {
                        "play.objectName": "MEDI_VOICE",
                        "play.objectPid": this.mediInfo.id,
                        "play.objectId": this.mediInfo.id,
                        "play.playTime": t + "",
                        "play.learningTime": this.recordBase + t + ""
                    }), (0, f.http)({
                        url: d.default.fetchCountTime,
                        data: {
                            "play.objectName": "MEDI_VOICE",
                            "play.objectPid": this.mediInfo.id,
                            "play.objectId": this.mediInfo.id,
                            "play.playTime": t + "",
                            "play.learningTime": this.recordBase + t + ""
                        },
                        hideLoading: !0
                    });
                }
            }, {
                key: "endHandler",
                value: function(t, e) {
                    var n = this;
                    return this.fetchFinishRecord(e), (0, f.http)({
                        url: d.default.fetchPlayDone,
                        data: {
                            meditatingId: 0,
                            notIncr: !0
                        }
                    }).then(function(r) {
                        var i = r.code, o = r.data;
                        if (console.log("playDone", o), 1 * i == 1) {
                            var a = o.totalLearnDays;
                            n.mediTimes = a;
                        }
                        "function" == typeof n.endMediHandler && (console.log("end handler", t, n.mediTimes), 
                        n.endMediHandler(t, e));
                    });
                }
            } ]), n;
        }(c.default), p = function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : new Date(), e = t.getFullYear(), n = t.getMonth() + 1 < 10 ? "0" + (t.getMonth() + 1) : t.getMonth() + 1, r = t.getDate() < 10 ? "0" + t.getDate() : t.getDate(), i = t.getHours() < 10 ? "0" + t.getHours() : t.getHours(), o = t.getMinutes() < 10 ? "0" + t.getMinutes() : t.getMinutes(), a = t.getSeconds() < 10 ? "0" + t.getSeconds() : t.getSeconds();
            return e + "-" + n + "-" + r + " " + i + ":" + o + ":" + a;
        }, _ = h;
        e.default = _;
    },
    f8e4: function(t, e, n) {
        (function(t) {
            var r = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.login = e.http = void 0;
            var i = r(n("278c")), o = r(n("4082")), a = r(n("b887")), s = r(n("66fd")), u = [ "data", "method", "header" ], c = [ "url", "data", "method", "header" ];
            s.default.prototype.$APIS = a.default;
            var l = function(e) {
                var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                if ("[object String]" === Object.prototype.toString.call(e)) var r = e, i = n.data, a = void 0 === i ? {} : i, s = n.method, l = void 0 === s ? "get" : s, f = n.header, h = void 0 === f ? {} : f, p = (0, 
                o.default)(n, u); else {
                    r = e.url;
                    var _ = e.data, m = (a = void 0 === _ ? {} : _, e.method), y = (l = void 0 === m ? "get" : m, 
                    e.header);
                    h = void 0 === y ? {} : y, p = (0, o.default)(e, c);
                }
                p.hideLoading || t.showLoading({
                    title: "加载中"
                });
                var g = new Promise(function(e, n) {
                    var i = getApp().globalData._platform, o = getApp().globalData.sessionKey, s = Object.assign({
                        _appSource: getApp().globalData._appSource,
                        channelId: getApp().globalData.channelId,
                        _platform: i,
                        _version: getApp().globalData._version
                    }, a);
                    t.request({
                        url: r,
                        method: l,
                        data: s,
                        header: Object.assign({
                            cookie: "lingxi_session=".concat(o, ";")
                        }, h),
                        timeout: 3e4,
                        success: function(n) {
                            var r = n.data, i = r.code, o = r.msg;
                            40416 == +i ? d() : 1 != +i && t.showToast({
                                title: o
                            }), e(r);
                        },
                        fail: function(e) {
                            console.log(e), t.showToast({
                                title: e.msg
                            }), n(e);
                        },
                        complete: function() {
                            t.hideLoading();
                        }
                    });
                });
                return g;
            };
            e.http = l;
            var f = !1, d = function e() {
                if (!f) {
                    f = !0;
                    var n = a.default.getSessionKey;
                    t.getProvider({
                        service: "oauth",
                        success: function(r) {
                            Promise.all([ t.getSystemInfo(), t.login({
                                provider: r.provider[0]
                            }) ]).then(function(t) {
                                var r = (0, i.default)(t, 2), o = r[0], a = r[1];
                                getApp().globalData.systemInfo = o[1], getApp().globalData._platform = o[1].system.includes("iOS") ? "ios" : "Android", 
                                l({
                                    url: n,
                                    data: {
                                        jsCode: a[1].code,
                                        appCode: getApp().globalData._appCode
                                    }
                                }).then(function(t) {
                                    if (1 == +t.code && 0 == +t.data.needUserAuth) {
                                        getApp().globalData.sessionKey = t.data.sessionKey;
                                        var n = getCurrentPages();
                                        n.length && (n[n.length - 1].onLoad(), n[n.length - 1].onShow());
                                    } else e();
                                }).finally(function() {
                                    f = !1;
                                });
                            }).catch(function() {
                                f = !1;
                            });
                        },
                        fail: function() {
                            f = !1;
                        }
                    });
                }
            };
            e.login = d, s.default.prototype.$http = l;
        }).call(this, n("543d").default);
    },
    faa1: function(t, e, n) {
        var r, i = "object" === ("undefined" == typeof Reflect ? "undefined" : _typeof3(Reflect)) ? Reflect : null, o = i && "function" == typeof i.apply ? i.apply : function(t, e, n) {
            return Function.prototype.apply.call(t, e, n);
        };
        r = i && "function" == typeof i.ownKeys ? i.ownKeys : Object.getOwnPropertySymbols ? function(t) {
            return Object.getOwnPropertyNames(t).concat(Object.getOwnPropertySymbols(t));
        } : function(t) {
            return Object.getOwnPropertyNames(t);
        };
        var a = Number.isNaN || function(t) {
            return t != t;
        };
        function s() {
            s.init.call(this);
        }
        t.exports = s, t.exports.once = function(t, e) {
            return new Promise(function(n, r) {
                function i(n) {
                    t.removeListener(e, o), r(n);
                }
                function o() {
                    "function" == typeof t.removeListener && t.removeListener("error", i), n([].slice.call(arguments));
                }
                y(t, e, o, {
                    once: !0
                }), "error" !== e && function(t, e, n) {
                    "function" == typeof t.on && y(t, "error", e, {
                        once: !0
                    });
                }(t, i);
            });
        }, s.EventEmitter = s, s.prototype._events = void 0, s.prototype._eventsCount = 0, 
        s.prototype._maxListeners = void 0;
        var u = 10;
        function c(t) {
            if ("function" != typeof t) throw new TypeError('The "listener" argument must be of type Function. Received type ' + _typeof3(t));
        }
        function l(t) {
            return void 0 === t._maxListeners ? s.defaultMaxListeners : t._maxListeners;
        }
        function f(t, e, n, r) {
            var i, o, a;
            if (c(n), void 0 === (o = t._events) ? (o = t._events = Object.create(null), t._eventsCount = 0) : (void 0 !== o.newListener && (t.emit("newListener", e, n.listener ? n.listener : n), 
            o = t._events), a = o[e]), void 0 === a) a = o[e] = n, ++t._eventsCount; else if ("function" == typeof a ? a = o[e] = r ? [ n, a ] : [ a, n ] : r ? a.unshift(n) : a.push(n), 
            (i = l(t)) > 0 && a.length > i && !a.warned) {
                a.warned = !0;
                var s = new Error("Possible EventEmitter memory leak detected. " + a.length + " " + String(e) + " listeners added. Use emitter.setMaxListeners() to increase limit");
                s.name = "MaxListenersExceededWarning", s.emitter = t, s.type = e, s.count = a.length, 
                function(t) {
                    console && console.warn && console.warn(t);
                }(s);
            }
            return t;
        }
        function d() {
            if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, 
            0 === arguments.length ? this.listener.call(this.target) : this.listener.apply(this.target, arguments);
        }
        function h(t, e, n) {
            var r = {
                fired: !1,
                wrapFn: void 0,
                target: t,
                type: e,
                listener: n
            }, i = d.bind(r);
            return i.listener = n, r.wrapFn = i, i;
        }
        function p(t, e, n) {
            var r = t._events;
            if (void 0 === r) return [];
            var i = r[e];
            return void 0 === i ? [] : "function" == typeof i ? n ? [ i.listener || i ] : [ i ] : n ? function(t) {
                for (var e = new Array(t.length), n = 0; n < e.length; ++n) e[n] = t[n].listener || t[n];
                return e;
            }(i) : m(i, i.length);
        }
        function _(t) {
            var e = this._events;
            if (void 0 !== e) {
                var n = e[t];
                if ("function" == typeof n) return 1;
                if (void 0 !== n) return n.length;
            }
            return 0;
        }
        function m(t, e) {
            for (var n = new Array(e), r = 0; r < e; ++r) n[r] = t[r];
            return n;
        }
        function y(t, e, n, r) {
            if ("function" == typeof t.on) r.once ? t.once(e, n) : t.on(e, n); else {
                if ("function" != typeof t.addEventListener) throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + _typeof3(t));
                t.addEventListener(e, function i(o) {
                    r.once && t.removeEventListener(e, i), n(o);
                });
            }
        }
        Object.defineProperty(s, "defaultMaxListeners", {
            enumerable: !0,
            get: function() {
                return u;
            },
            set: function(t) {
                if ("number" != typeof t || t < 0 || a(t)) throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + t + ".");
                u = t;
            }
        }), s.init = function() {
            void 0 !== this._events && this._events !== Object.getPrototypeOf(this)._events || (this._events = Object.create(null), 
            this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0;
        }, s.prototype.setMaxListeners = function(t) {
            if ("number" != typeof t || t < 0 || a(t)) throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + t + ".");
            return this._maxListeners = t, this;
        }, s.prototype.getMaxListeners = function() {
            return l(this);
        }, s.prototype.emit = function(t) {
            for (var e = [], n = 1; n < arguments.length; n++) e.push(arguments[n]);
            var r = "error" === t, i = this._events;
            if (void 0 !== i) r = r && void 0 === i.error; else if (!r) return !1;
            if (r) {
                var a;
                if (e.length > 0 && (a = e[0]), a instanceof Error) throw a;
                var s = new Error("Unhandled error." + (a ? " (" + a.message + ")" : ""));
                throw s.context = a, s;
            }
            var u = i[t];
            if (void 0 === u) return !1;
            if ("function" == typeof u) o(u, this, e); else {
                var c = u.length, l = m(u, c);
                for (n = 0; n < c; ++n) o(l[n], this, e);
            }
            return !0;
        }, s.prototype.addListener = function(t, e) {
            return f(this, t, e, !1);
        }, s.prototype.on = s.prototype.addListener, s.prototype.prependListener = function(t, e) {
            return f(this, t, e, !0);
        }, s.prototype.once = function(t, e) {
            return c(e), this.on(t, h(this, t, e)), this;
        }, s.prototype.prependOnceListener = function(t, e) {
            return c(e), this.prependListener(t, h(this, t, e)), this;
        }, s.prototype.removeListener = function(t, e) {
            var n, r, i, o, a;
            if (c(e), void 0 === (r = this._events)) return this;
            if (void 0 === (n = r[t])) return this;
            if (n === e || n.listener === e) 0 == --this._eventsCount ? this._events = Object.create(null) : (delete r[t], 
            r.removeListener && this.emit("removeListener", t, n.listener || e)); else if ("function" != typeof n) {
                for (i = -1, o = n.length - 1; o >= 0; o--) if (n[o] === e || n[o].listener === e) {
                    a = n[o].listener, i = o;
                    break;
                }
                if (i < 0) return this;
                0 === i ? n.shift() : function(t, e) {
                    for (;e + 1 < t.length; e++) t[e] = t[e + 1];
                    t.pop();
                }(n, i), 1 === n.length && (r[t] = n[0]), void 0 !== r.removeListener && this.emit("removeListener", t, a || e);
            }
            return this;
        }, s.prototype.off = s.prototype.removeListener, s.prototype.removeAllListeners = function(t) {
            var e, n, r;
            if (void 0 === (n = this._events)) return this;
            if (void 0 === n.removeListener) return 0 === arguments.length ? (this._events = Object.create(null), 
            this._eventsCount = 0) : void 0 !== n[t] && (0 == --this._eventsCount ? this._events = Object.create(null) : delete n[t]), 
            this;
            if (0 === arguments.length) {
                var i, o = Object.keys(n);
                for (r = 0; r < o.length; ++r) "removeListener" !== (i = o[r]) && this.removeAllListeners(i);
                return this.removeAllListeners("removeListener"), this._events = Object.create(null), 
                this._eventsCount = 0, this;
            }
            if ("function" == typeof (e = n[t])) this.removeListener(t, e); else if (void 0 !== e) for (r = e.length - 1; r >= 0; r--) this.removeListener(t, e[r]);
            return this;
        }, s.prototype.listeners = function(t) {
            return p(this, t, !0);
        }, s.prototype.rawListeners = function(t) {
            return p(this, t, !1);
        }, s.listenerCount = function(t, e) {
            return "function" == typeof t.listenerCount ? t.listenerCount(e) : _.call(t, e);
        }, s.prototype.listenerCount = _, s.prototype.eventNames = function() {
            return this._eventsCount > 0 ? r(this._events) : [];
        };
    },
    fafd: function(t) {
        t.exports = JSON.parse('{"amp":"&","apos":"\'","gt":">","lt":"<","quot":"\\""}');
    }
} ]);