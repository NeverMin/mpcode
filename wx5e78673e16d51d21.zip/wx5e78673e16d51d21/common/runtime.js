var e = require("../@babel/runtime/helpers/typeof");

!function() {
    try {
        var e = Function("return this")();
        e && !e.Math && (Object.assign(e, {
            isFinite: isFinite,
            Array: Array,
            Date: Date,
            Error: Error,
            Function: Function,
            Math: Math,
            Object: Object,
            RegExp: RegExp,
            String: String,
            TypeError: TypeError,
            setTimeout: setTimeout,
            clearTimeout: clearTimeout,
            setInterval: setInterval,
            clearInterval: clearInterval
        }), "undefined" != typeof Reflect && (e.Reflect = Reflect));
    } catch (e) {}
}(), function(o) {
    function n(e) {
        for (var n, i, c = e[0], p = e[1], m = e[2], s = 0, l = []; s < c.length; s++) i = c[s], 
        Object.prototype.hasOwnProperty.call(r, i) && r[i] && l.push(r[i][0]), r[i] = 0;
        for (n in p) Object.prototype.hasOwnProperty.call(p, n) && (o[n] = p[n]);
        for (d && d(e); l.length; ) l.shift()();
        return a.push.apply(a, m || []), t();
    }
    function t() {
        for (var e, o = 0; o < a.length; o++) {
            for (var n = a[o], t = !0, i = 1; i < n.length; i++) {
                var c = n[i];
                0 !== r[c] && (t = !1);
            }
            t && (a.splice(o--, 1), e = p(p.s = n[0]));
        }
        return e;
    }
    var i = {}, c = {
        "common/runtime": 0
    }, r = {
        "common/runtime": 0
    }, a = [];
    function p(e) {
        if (i[e]) return i[e].exports;
        var n = i[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        return o[e].call(n.exports, n, n.exports, p), n.l = !0, n.exports;
    }
    p.e = function(e) {
        var o = [];
        c[e] ? o.push(c[e]) : 0 !== c[e] && {
            "components/common/bookPlayerBar/bookPlayerBar": 1,
            "components/common/getUserInfo/getUserInfo": 1,
            "components/common/pageHeader/index": 1,
            "components/common/vip/dialog/index": 1,
            "pages/explore/components/recommend": 1,
            "pages/explore/components/meditationList": 1,
            "pages/explore/components/voice": 1,
            "components/common/uniml2canvas/uniml2canvas": 1,
            "components/common/goApp/index": 1,
            "components/exercise/practiceCover/practiceCover": 1,
            "components/voice/listItem": 1,
            "components/common/uni-badge/uni-badge": 1,
            "components/meditation/confirm/index": 1,
            "components/meditation/playerBarLoading/playerBar-loading": 1,
            "components/meditation/step/stepWrapper": 1,
            "pages/vip/components/countDown": 1,
            "pages/task/components/dialog": 1,
            "pages/task/components/lottery": 1,
            "pages/task/components/present": 1,
            "components/common/practiceOtherInfo": 1,
            "components/meditation/practiceFeelingsInDetail/index": 1,
            "components/meditation/step/index": 1,
            "components/common/dialogBox": 1,
            "components/meditation/textFold/index": 1,
            "pages/practiceComplete/components/clockIn": 1,
            "components/common/uni-popup/uni-popup": 1,
            "pages/voicePlay/components/timing": 1,
            "pages/voicePlay/components/voiceList": 1,
            "components/common/uni-status-bar/uni-status-bar": 1,
            "components/common/practiceInfo/index": 1,
            "components/meditation/step/step2": 1,
            "components/meditation/practiceFeelingsItem/index": 1,
            "components/common/uni-transition/uni-transition": 1,
            "components/meditation/textFoldForArray/index": 1
        }[e] && o.push(c[e] = new Promise(function(o, n) {
            for (var t = ({
                "components/common/bookPlayerBar/bookPlayerBar": "components/common/bookPlayerBar/bookPlayerBar",
                "components/common/getUserInfo/getUserInfo": "components/common/getUserInfo/getUserInfo",
                "components/common/pageHeader/index": "components/common/pageHeader/index",
                "components/common/vip/dialog/index": "components/common/vip/dialog/index",
                "pages/explore/components/recommend": "pages/explore/components/recommend",
                "pages/explore/components/meditationList": "pages/explore/components/meditationList",
                "pages/explore/components/voice": "pages/explore/components/voice",
                "components/common/uniml2canvas/uniml2canvas": "components/common/uniml2canvas/uniml2canvas",
                "components/common/goApp/index": "components/common/goApp/index",
                "components/exercise/practiceCover/practiceCover": "components/exercise/practiceCover/practiceCover",
                "components/voice/listItem": "components/voice/listItem",
                "components/common/uni-badge/uni-badge": "components/common/uni-badge/uni-badge",
                "components/meditation/confirm/index": "components/meditation/confirm/index",
                "components/meditation/playerBarLoading/playerBar-loading": "components/meditation/playerBarLoading/playerBar-loading",
                "components/meditation/step/stepWrapper": "components/meditation/step/stepWrapper",
                "pages/vip/components/countDown": "pages/vip/components/countDown",
                "pages/task/components/dialog": "pages/task/components/dialog",
                "pages/task/components/lottery": "pages/task/components/lottery",
                "pages/task/components/present": "pages/task/components/present",
                "components/common/practiceOtherInfo": "components/common/practiceOtherInfo",
                "components/meditation/practiceFeelingsInDetail/index": "components/meditation/practiceFeelingsInDetail/index",
                "components/meditation/step/index": "components/meditation/step/index",
                "components/common/dialogBox": "components/common/dialogBox",
                "components/meditation/textFold/index": "components/meditation/textFold/index",
                "pages/practiceComplete/components/clockIn": "pages/practiceComplete/components/clockIn",
                "components/common/uni-popup/uni-popup": "components/common/uni-popup/uni-popup",
                "pages/voicePlay/components/timing": "pages/voicePlay/components/timing",
                "pages/voicePlay/components/voiceList": "pages/voicePlay/components/voiceList",
                "components/common/uni-status-bar/uni-status-bar": "components/common/uni-status-bar/uni-status-bar",
                "components/common/practiceInfo/index": "components/common/practiceInfo/index",
                "components/meditation/step/step2": "components/meditation/step/step2",
                "components/meditation/practiceFeelingsItem/index": "components/meditation/practiceFeelingsItem/index",
                "components/common/uni-transition/uni-transition": "components/common/uni-transition/uni-transition",
                "components/meditation/textFoldForArray/index": "components/meditation/textFoldForArray/index"
            }[e] || e) + ".wxss", i = p.p + t, r = document.getElementsByTagName("link"), a = 0; a < r.length; a++) {
                var m = r[a], s = m.getAttribute("data-href") || m.getAttribute("href");
                if ("stylesheet" === m.rel && (s === t || s === i)) return o();
            }
            var l = document.getElementsByTagName("style");
            for (a = 0; a < l.length; a++) if ((s = (m = l[a]).getAttribute("data-href")) === t || s === i) return o();
            var d = document.createElement("link");
            d.rel = "stylesheet", d.type = "text/css", d.onload = o, d.onerror = function(o) {
                var t = o && o.target && o.target.src || i, r = new Error("Loading CSS chunk " + e + " failed.\n(" + t + ")");
                r.code = "CSS_CHUNK_LOAD_FAILED", r.request = t, delete c[e], d.parentNode.removeChild(d), 
                n(r);
            }, d.href = i, document.getElementsByTagName("head")[0].appendChild(d);
        }).then(function() {
            c[e] = 0;
        }));
        var n = r[e];
        if (0 !== n) if (n) o.push(n[2]); else {
            var t = new Promise(function(o, t) {
                n = r[e] = [ o, t ];
            });
            o.push(n[2] = t);
            var i, a = document.createElement("script");
            a.charset = "utf-8", a.timeout = 120, p.nc && a.setAttribute("nonce", p.nc), a.src = function(e) {
                return p.p + "" + e + ".js";
            }(e);
            var m = new Error();
            i = function(o) {
                a.onerror = a.onload = null, clearTimeout(s);
                var n = r[e];
                if (0 !== n) {
                    if (n) {
                        var t = o && ("load" === o.type ? "missing" : o.type), i = o && o.target && o.target.src;
                        m.message = "Loading chunk " + e + " failed.\n(" + t + ": " + i + ")", m.name = "ChunkLoadError", 
                        m.type = t, m.request = i, n[1](m);
                    }
                    r[e] = void 0;
                }
            };
            var s = setTimeout(function() {
                i({
                    type: "timeout",
                    target: a
                });
            }, 12e4);
            a.onerror = a.onload = i, document.head.appendChild(a);
        }
        return Promise.all(o);
    }, p.m = o, p.c = i, p.d = function(e, o, n) {
        p.o(e, o) || Object.defineProperty(e, o, {
            enumerable: !0,
            get: n
        });
    }, p.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        });
    }, p.t = function(o, n) {
        if (1 & n && (o = p(o)), 8 & n) return o;
        if (4 & n && "object" === e(o) && o && o.__esModule) return o;
        var t = Object.create(null);
        if (p.r(t), Object.defineProperty(t, "default", {
            enumerable: !0,
            value: o
        }), 2 & n && "string" != typeof o) for (var i in o) p.d(t, i, function(e) {
            return o[e];
        }.bind(null, i));
        return t;
    }, p.n = function(e) {
        var o = e && e.__esModule ? function() {
            return e.default;
        } : function() {
            return e;
        };
        return p.d(o, "a", o), o;
    }, p.o = function(e, o) {
        return Object.prototype.hasOwnProperty.call(e, o);
    }, p.p = "/", p.oe = function(e) {
        throw console.error(e), e;
    };
    var m = global.webpackJsonp = global.webpackJsonp || [], s = m.push.bind(m);
    m.push = n, m = m.slice();
    for (var l = 0; l < m.length; l++) n(m[l]);
    var d = s;
    t();
}([]);