(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/main" ], {
    "0f5c": function(e, o, n) {},
    "184c": function(e, o, n) {
        (function(e, o) {
            var t = n("4ea4"), a = t(n("9523"));
            n("6f19");
            var i = t(n("66fd")), r = t(n("3dc9")), s = t(n("1123")), c = t(n("eb14")), l = t(n("10db"));
            n("f8e4");
            var u = t(n("154c")), f = n("ebf2");
            function d(e, o) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var t = Object.getOwnPropertySymbols(e);
                    o && (t = t.filter(function(o) {
                        return Object.getOwnPropertyDescriptor(e, o).enumerable;
                    })), n.push.apply(n, t);
                }
                return n;
            }
            e.__webpack_require_UNI_MP_PLUGIN__ = n, i.default.config.productionTip = !1, r.default.mpType = "app", 
            i.default.prototype.$store = s.default, i.default.prototype.$observer = c.default, 
            i.default.prototype.$utils = l.default, i.default.prototype.$navTo = u.default, 
            i.default.prototype.$onShareAppMessage = f.onShareAppMessage, i.default.prototype.$onShareTimeLine = f.onShareTimeLine, 
            i.default.component("getUserInfo", function() {
                n.e("components/common/getUserInfo/getUserInfo").then(function() {
                    return resolve(n("79a4"));
                }.bind(null, n)).catch(n.oe);
            }), i.default.component("bookPlayerBar", function() {
                Promise.all([ n.e("common/vendor"), n.e("components/common/bookPlayerBar/bookPlayerBar") ]).then(function() {
                    return resolve(n("6a65"));
                }.bind(null, n)).catch(n.oe);
            }), i.default.component("pageHeader", function() {
                n.e("components/common/pageHeader/index").then(function() {
                    return resolve(n("d179"));
                }.bind(null, n)).catch(n.oe);
            }), i.default.component("vipDialog", function() {
                n.e("components/common/vip/dialog/index").then(function() {
                    return resolve(n("4702"));
                }.bind(null, n)).catch(n.oe);
            });
            var p = new i.default(function(e) {
                for (var o = 1; o < arguments.length; o++) {
                    var n = null != arguments[o] ? arguments[o] : {};
                    o % 2 ? d(Object(n), !0).forEach(function(o) {
                        (0, a.default)(e, o, n[o]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : d(Object(n)).forEach(function(o) {
                        Object.defineProperty(e, o, Object.getOwnPropertyDescriptor(n, o));
                    });
                }
                return e;
            }({
                store: s.default
            }, r.default));
            o(p).$mount();
        }).call(this, n("bc2e").default, n("543d").createApp);
    },
    "3dc9": function(e, o, n) {
        n.r(o);
        var t = n("5720");
        for (var a in t) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(o, e, function() {
                return t[e];
            });
        }(a);
        n("cc57");
        var i = n("f0c5"), r = Object(i.a)(t.default, void 0, void 0, !1, null, null, null, !1, void 0, void 0);
        o.default = r.exports;
    },
    5720: function(e, o, n) {
        n.r(o);
        var t = n("e88f"), a = n.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(o, e, function() {
                return t[e];
            });
        }(i);
        o.default = a.a;
    },
    cc57: function(e, o, n) {
        var t = n("0f5c");
        n.n(t).a;
    },
    e88f: function(e, o, n) {
        (function(e) {
            var t = n("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var a = t(n("278c"));
            n("3329"), n("57e5");
            var i = t(n("d177")), r = t(n("66fd")), s = {
                globalData: {
                    sessionKey: "",
                    vipId: 3,
                    userInfoSQ: !1,
                    systemInfo: {},
                    _version: "1.0.0",
                    _provider: "weixin",
                    channelId: 2147,
                    _appSource: "miniProgram",
                    _appCode: 4,
                    _sourceFlag: "weixin",
                    isSinglePage: !1,
                    isAudit: 0
                },
                data: function() {
                    return {
                        loginCode: ""
                    };
                },
                onLaunch: function(e) {
                    this.$options.globalData.isSinglePage = 1154 === e.scene, this.login(), r.default.mixin(i.default);
                },
                onShow: function() {},
                onHide: function() {},
                methods: {
                    checkAudit: function() {
                        var e = this;
                        this.$http({
                            url: this.$APIS.checkAudit
                        }).then(function(o) {
                            var n = o.code, t = o.data;
                            "1" === n && (e.$options.globalData.isAudit = 0 === t.status, console.log(e.$options.globalData.isAudit, "提交获取的状态"));
                        });
                    },
                    getUserInfo: function() {
                        var o = this;
                        e.getUserInfo({
                            provider: this.$options.globalData._provider,
                            success: function(e) {
                                o.$options.globalData.userInfoSQ = !0, o.$observer.$emit("onGotUserInfo"), o.$store.commit("common/setWxUserInfo", e.userInfo), 
                                o.$store.dispatch("common/fetchBaseInfo").then(function() {
                                    return o.getWxUserinfo(e);
                                });
                            },
                            fail: function(e) {
                                console.log("getUserInfo-fail", e), o.$options.globalData.userInfoSQ = !1;
                            }
                        });
                    },
                    checkSession: function() {
                        var o = this;
                        e.checkSession({
                            success: function() {
                                e.getStorage({
                                    key: "sessionKey",
                                    success: function(e) {
                                        console.log("getStorage-sessionKey-success", e), o.$options.globalData.sessionKey = e.data, 
                                        o.$observer.$emit("loginOver"), o.getUserInfo();
                                    },
                                    fail: function(e) {
                                        console.log("getStorage-sessionKey-fail", e), o.login();
                                    }
                                });
                            },
                            fail: function(e) {
                                console.log("checkSession-fail", e), o.login();
                            }
                        });
                    },
                    login: function() {
                        var o = this;
                        e.getProvider({
                            service: "oauth",
                            success: function(n) {
                                var t = {
                                    provider: n.provider[0]
                                };
                                Promise.all([ e.getSystemInfo(), e.login(t) ]).then(function(e) {
                                    var n = (0, a.default)(e, 2), t = n[0], i = n[1];
                                    o.$options.globalData.systemInfo = t[1], console.log("systemInfo", t[1]), o.loginRes = i[1] ? i[1].code : i.code, 
                                    o.$options.globalData._platform = t[1].system.includes("iOS") ? "ios" : "Android", 
                                    o.fetchGetSessionKey(), o.checkAudit();
                                });
                            }
                        });
                    },
                    fetchGetSessionKey: function() {
                        var o = this, n = e.getStorageSync("__IS_RECEIVE_PAGE"), t = {
                            jsCode: this.loginRes,
                            appCode: this.$options.globalData._appCode
                        };
                        n && (t.tabNewUser = 1);
                        var a = this.$APIS.getSessionKey;
                        this.$http({
                            url: a,
                            data: t
                        }).then(function(e) {
                            1 == +e.code && 0 == +e.data.needUserAuth ? (o.$options.globalData.sessionKey = e.data.sessionKey, 
                            o.$observer.$emit("loginOver"), o.getUserInfo()) : o.$options.globalData.isSinglePage ? o.$observer.$emit("loginOver") : o.login();
                        });
                    },
                    getWxUserinfo: function(e) {
                        var o = e.encryptedData, n = e.iv, t = e.userInfo, a = this.$store.getters["common/getBaseInfo"];
                        console.log(a, "拿到的用户信息1"), this.$http({
                            url: this.$APIS.saveUserInfo,
                            data: {
                                encryptedData: o,
                                avatarUrl: a.avatar ? a.avatar : t.avatarUrl,
                                nickName: a.nickname ? a.nickname : t.nickName,
                                ivStr: n,
                                "userInfo.avatar": a.avatar ? a.avatar : t.avatarUrl,
                                "userInfo.nickName": a.nickname ? a.nickname : t.nickName,
                                "userInfo.gender": t.gender,
                                "userInfo.country": t.country,
                                "userInfo.province": t.province,
                                "userInfo.city": t.city,
                                appCode: 4
                            }
                        }).then(function(e) {
                            console.log(e, "保存用户信息");
                        });
                    }
                }
            };
            o.default = s;
        }).call(this, n("543d").default);
    }
}, [ [ "184c", "common/runtime", "common/vendor" ] ] ]);