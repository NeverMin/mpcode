Component({
    properties: {
        showThankYou: {
            type: Boolean
        },
        showNoThankyou: {
            type: Boolean,
            value: !0
        },
        thankyouData: {
            type: Object,
            value: {}
        },
        orderStatusUrl: {
            type: String
        }
    },
    data: {
        message: "订阅订单状态通知",
        isSubscribed: !1
    },
    methods: {
        onDone: function() {
            console.log("onDone", this.data.showNoThankyou), wx.reLaunch({
                url: "../landing/landing"
            }), wx.hideLoading();
        },
        onSubscribe: function() {
            var e = this, o = !1;
            wx.requestSubscribeMessage({
                tmplIds: [ "iiuSp9EYsMnj6phnbcUe8xnLvJMyWDVFfoa5xBy8kj4" ],
                success: function(s) {
                    console.log("requestSubscribeMessage success", s), o = !0, e.setData({
                        isSubscribed: o
                    });
                },
                fail: function(e) {
                    console.log("requestSubscribeMessage fail", e);
                },
                complete: function() {
                    console.log("requestSubscribeMessage complete"), e.data.isSubscribed && e.setData({
                        message: "已订阅"
                    });
                }
            });
        },
        onRequestPayment: function() {
            console.log("onRequestPayment"), this.triggerEvent("requestPayment");
        },
        onOrderStatus: function() {
            wx.redirectTo({
                url: "/pages/pageView/pageView?url=" + encodeURIComponent(this.data.orderStatusUrl + "?orderNumber=" + this.data.thankyouData.model.orderNumber)
            });
        }
    }
});