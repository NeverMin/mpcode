var t = require("../../../@babel/runtime/helpers/defineProperty");

Component({
    properties: {
        editing: {
            type: Boolean,
            value: !1
        },
        cartdata: {
            type: Array,
            value: []
        },
        startX: {
            type: Number,
            value: 0
        },
        isLeft: {
            type: Number,
            value: 0
        },
        delBtnw: {
            type: Number,
            value: 148
        },
        editCart: {
            type: Object,
            value: {}
        },
        bagDetails: {
            type: Object,
            value: {}
        },
        isEditingGiftPackage: {
            type: Boolean
        },
        checkXmove: {
            type: Boolean
        }
    },
    data: {
        isred: !1,
        checkXmove: !1,
        plusLongPressClearTimeoutId: null,
        plusLongPressClearIntervalId: null,
        minusLongPressClearTimeoutId: null,
        minusLongPressClearIntervalId: null
    },
    lifetimes: {
        attached: function() {
            var t = this;
            wx.getSystemInfo({
                success: function(e) {
                    t.setData({
                        theme: e.theme
                    });
                }
            }), wx.onThemeChange(function(e) {
                t.setData({
                    theme: e.theme
                });
            });
        }
    },
    methods: {
        handleTouchStart: function(t) {
            this.data.isEditingGiftPackage || (this.data.startX = t.touches[0].pageX);
        },
        onPlus: function(e) {
            var a = e.target.dataset.index, s = "cartdata[" + a + "].quantity", i = this.data.cartdata[a].quantity + 1;
            this.setData(t({}, s, i));
        },
        onMinus: function(e) {
            var a = e.target.dataset.index, s = "cartdata[" + a + "].quantity", i = this.data.cartdata[a].quantity - 1;
            i >= 0 && this.setData(t({}, s, i));
        },
        onPlusStart: function(t) {
            var e = this;
            this.data.plusLongPressClearTimeoutId = setTimeout(function() {
                e.data.plusLongPressClearIntervalId = setInterval(function() {
                    e.onPlus(t);
                }, 350);
            }, 350);
        },
        onPlusEnd: function() {
            this.data.plusLongPressClearTimeoutId && clearTimeout(this.data.plusLongPressClearTimeoutId), 
            this.data.plusLongPressClearIntervalId && clearInterval(this.data.plusLongPressClearIntervalId);
        },
        onMinusStart: function(t) {
            var e = this;
            this.data.minusLongPressClearTimeoutId = setTimeout(function() {
                e.data.minusLongPressClearIntervalId = setInterval(function() {
                    e.onMinus(t);
                }, 350);
            }, 350);
        },
        onMinusEnd: function() {
            this.data.minusLongPressClearTimeoutId && clearTimeout(this.data.minusLongPressClearTimeoutId), 
            this.data.minusLongPressClearIntervalId && clearInterval(this.data.minusLongPressClearIntervalId);
        },
        handleTouchEnd: function(t) {
            this.data.isEditingGiftPackage || (t.changedTouches[0].pageX < this.data.startX && t.changedTouches[0].pageX - this.data.startX <= -30 ? this.showDeleteButton(t.currentTarget.dataset.i) : this.hideDeleteButton(t.currentTarget.dataset.i));
        },
        showDeleteButton: function(t) {
            var e = this.data.cartdata;
            e[t].hideDelete = !0, this.setXmove(t, -165), this.setData({
                isred: !0,
                openEditing: !0,
                cartdata: e
            });
        },
        onClickRemoveButton: function(t) {
            var e = t.target.dataset.index;
            this.setData({
                isred: !0
            }), this.setXmove(e, -165);
        },
        hideAll: function() {
            for (var t = 0; t <= this.data.cartdata.length - 1; t++) this.setXmove(t, 100);
        },
        hideDeleteButton: function(t) {
            var e = this.data.cartdata;
            e[t].hideDelete = !1, this.setXmove(t, 0), this.setData({
                isred: !1,
                openEditing: !1,
                cartdata: e
            });
        },
        setXmove: function(t, e) {
            var a = this, s = this.data.cartdata;
            s[t].xmove = e, s.forEach(function(t) {
                -165 === t.xmove && a.setData({
                    checkXmove: !0
                });
            }), s.every(function(t) {
                return -165 !== t.xmove;
            }) && this.setData({
                checkXmove: !1
            }), this.setData({
                cartdata: s
            }), this.triggerEvent("nocheckout", this.data.checkXmove);
        },
        handleMovableChange: function(t) {
            this.data.isEditingGiftPackage || (this.setData({
                isred: !0
            }), "friction" === t.detail.source ? t.detail.x < -30 ? this.showDeleteButton(t.currentTarget.dataset.i) : this.hideDeleteButton(t.currentTarget.dataset.i) : "out-of-bounds" === t.detail.source && 0 === t.detail.x && this.hideDeleteButton(t.currentTarget.dataset.i));
        },
        handleDelete: function(t) {
            var e = t.target.dataset.id;
            this.triggerEvent("itemDelete", {
                id: e
            }, {}), this.setData({
                checkXmove: !1
            });
        }
    }
});