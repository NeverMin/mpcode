Component({
    properties: {
        tradeInRemainValue: {
            type: String
        },
        translations: {
            type: Object
        },
        imageURL: {
            type: String
        },
        darkURL: {
            type: String
        },
        name: {
            type: String
        },
        tagLine: {
            type: String
        },
        hasTradeUpDetail: {
            type: Boolean
        },
        tradeUpDetail: {
            type: String
        },
        price: {
            type: String
        },
        parentIndex: {
            type: Number
        },
        childIndex: {
            type: Number
        },
        hideDelete: {
            type: Boolean
        },
        disableDelete: {
            type: Boolean
        }
    },
    data: {},
    lifetimes: {
        attached: function() {
            var e = this;
            wx.getSystemInfo({
                success: function(t) {
                    e.setData({
                        theme: t.theme
                    });
                }
            }), wx.onThemeChange(function(t) {
                e.setData({
                    theme: t.theme
                });
            });
        }
    },
    methods: {
        handleDeleteTradeIn: function(e) {
            !this.data.disableDelete && this.triggerEvent("tradeInDelete", {
                child: this.data.childIndex,
                parent: this.data.parentIndex
            }, {
                bubbles: !0,
                composed: !0
            });
        }
    }
});