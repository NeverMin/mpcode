Object.defineProperty(exports, "__esModule", {
    value: !0
});

Component({
    properties: {
        index: {
            type: Number
        },
        openediting: {
            type: Boolean,
            value: !1
        },
        editingMode: {
            type: Boolean,
            value: !1
        },
        item: {
            type: Object,
            value: {}
        },
        bagDetails: {
            type: Object,
            value: {}
        }
    },
    data: {
        editing: !1,
        message: ""
    },
    observers: {
        "item.gifting.giftMessage": function(e) {
            this.setData({
                message: null != e ? e : ""
            });
        },
        editing: function(e) {
            this.triggerEvent("editGift", e, {
                composed: !0,
                bubbles: !0
            });
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            wx.getSystemInfo({
                success: function(t) {
                    e.setData({
                        theme: t.theme
                    });
                }
            }), wx.onThemeChange(function(t) {
                e.setData({
                    theme: t.theme
                });
            });
        }
    },
    methods: {
        tapGifting: function() {
            this.setData({
                editing: !0
            });
        },
        onDelete: function(e) {
            var t = this.data.item.gifting.removeGiftPackage;
            this.triggerEvent("deleteGift", {
                url: t
            }, {
                composed: !0,
                bubbles: !0
            }), this.setData({
                message: "",
                editing: !1
            });
        },
        onSave: function(e) {
            var t, i, s = this.data.item, a = null === (t = e.detail) || void 0 === t || null === (i = t.value) || void 0 === i ? void 0 : i.message;
            this.triggerEvent("saveGift", {
                message: a,
                item: s
            }, {
                composed: !0,
                bubbles: !0
            }), this.setData({
                editing: !1
            });
        },
        onMessageUpdate: function(e) {
            this.setData({
                message: e.detail.value
            });
        }
    }
});