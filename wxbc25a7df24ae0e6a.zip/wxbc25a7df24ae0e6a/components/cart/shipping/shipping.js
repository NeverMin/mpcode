Component({
    properties: {
        label: {
            type: String
        },
        dude: {
            type: Array
        },
        quote: {
            type: String
        },
        isDudeAttributesPresent: {
            type: Boolean
        }
    },
    data: {},
    methods: {}
});