Component({
    properties: {
        pickupLabel: {
            type: String
        },
        pickupQuote: {
            type: String
        }
    },
    data: {},
    methods: {}
});