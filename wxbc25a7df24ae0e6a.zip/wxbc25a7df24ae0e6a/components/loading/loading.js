Component({
    properties: {},
    data: {},
    methods: {
        onLoad: function() {
            wx.hideHomeButton(), wx.showLoading({
                title: "正在载入...",
                mask: !0
            });
        }
    }
});