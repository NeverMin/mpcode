Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        show: {
            type: Boolean
        },
        round: {
            type: Boolean,
            value: !0
        },
        zIndex: {
            type: Number,
            value: 100
        },
        overlay: {
            type: Boolean,
            value: !0
        },
        closeOnClickOverlay: {
            type: Boolean,
            value: !0
        },
        closeOnClickLeft: {
            type: Boolean
        },
        closeOnClickRight: {
            type: Boolean
        },
        title: {
            type: String
        },
        leftText: {
            type: String
        },
        rightText: {
            type: String
        },
        safeAreaInsetBottom: {
            type: Boolean,
            value: !0
        }
    },
    methods: {
        onClickLeft: function() {
            this.triggerEvent("click-left"), this.data.closeOnClickLeft && this.onClose();
        },
        onClickRight: function() {
            this.triggerEvent("click-right"), this.data.closeOnClickRight && this.onClose();
        },
        onClose: function() {
            this.triggerEvent("close");
        },
        onClickOverlay: function() {
            this.triggerEvent("click-overlay"), this.onClose();
        }
    }
});