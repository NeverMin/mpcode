Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.showTab = exports.showRedDot = exports.showBadge = exports.hideTab = exports.hideRedDot = exports.hideBadge = void 0, 
exports.switchTab = function(e, t) {
    console.log("switchTab called"), "function" == typeof e.getTabBar && e.getTabBar() ? (console.log("true"), 
    console.log("switchTab：", t), e.getTabBar().setData({
        selected: t
    })) : console.log("false");
};

exports.showRedDot = function(e, t, o, a) {
    "function" == typeof e.getTabBar && e.getTabBar() && e.getTabBar().showRedDot(t, o, a);
};

exports.hideRedDot = function(e, t, o, a) {
    "function" == typeof e.getTabBar && e.getTabBar() && e.getTabBar().hideRedDot(t, o, a);
};

exports.showBadge = function(e, t, o, a, r) {
    "function" == typeof e.getTabBar && e.getTabBar() && e.getTabBar().showBadge(t, o, a, r);
};

exports.hideBadge = function(e, t, o, a) {
    "function" == typeof e.getTabBar && e.getTabBar() && e.getTabBar().hideBadge(t, o, a);
};

exports.showTab = function(e, t) {
    "function" == typeof e.getTabBar && e.getTabBar() && e.getTabBar().showTab(t);
};

exports.hideTab = function(e, t) {
    "function" == typeof e.getTabBar && e.getTabBar() && e.getTabBar().hideTab(t);
};