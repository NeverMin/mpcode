Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.searchData = void 0;

exports.searchData = {
    searchResultClicked: {
        "apl.microevents1": 'apl.microevents1: "asa:shop:{searchResult}:config | search results | {searchResult}"',
        linkName: "asa:shop:{searchResult}:config | search results | {searchResult}"
    }
};