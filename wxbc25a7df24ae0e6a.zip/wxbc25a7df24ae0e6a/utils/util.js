Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.appendUrlParams = function(e, r) {
    if (!e) return e;
    return -1 !== e.indexOf("?") ? "".concat(e, "&").concat(r) : "".concat(e, "?").concat(r);
}, exports.cookieHeader = v, exports.devOnly = g, exports.getCode = exports.generateURLHashParameter = exports.formatTime = void 0, 
exports.getEnvDomain = function(e) {
    if (g(), !e) return void console.error("Bad DIWA Fetch URL");
    var r = e.match(/^https:\/\/[^\/]*/);
    if (!r) return null;
    return r[0];
}, exports.inScopeCookies = h, exports.isExpired = d, exports.parseAllCookies = p, 
exports.parseCookies = function(e, r) {
    var t, n = {}, o = e["set-cookie"].replace(/, /g, "  ").split(","), a = i(o);
    try {
        for (a.s(); !(t = a.n()).done; ) {
            var s, u = t.value.replace("  ", ", ").split(";"), c = i(u);
            try {
                for (c.s(); !(s = c.n()).done; ) {
                    var l = s.value;
                    if (l.startsWith(r)) n[r] = l.replace(r + "=", ""); else if (l.startsWith("as_pvi")) {
                        var p = l.substring(0, l.indexOf("="));
                        n[p] = l.replace(p + "=", "");
                    } else l.trimStart().startsWith("Max-Age") ? n["Max-Age"] = l.replace(" Max-Age=", "") : l.trimStart().startsWith("Expires") && (n.Expires = l.replace(" Expires=", ""));
                }
            } catch (e) {
                c.e(e);
            } finally {
                c.f();
            }
        }
    } catch (e) {
        a.e(e);
    } finally {
        a.f();
    }
    return n.Created = Date.now(), n;
}, exports.requestOrShowError = function(e, r) {
    return m.apply(this, arguments);
}, exports.requestWithCookies = x, exports.sleep = void 0, exports.updateCookieJar = f;

var e = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/asyncToGenerator"), t = require("../@babel/runtime/helpers/objectSpread2"), n = require("../@babel/runtime/helpers/objectWithoutProperties"), o = require("../@babel/runtime/helpers/toConsumableArray");

require("../@babel/runtime/helpers/Objectentries");

var a, i = require("../@babel/runtime/helpers/createForOfIteratorHelper"), s = require("../@babel/runtime/helpers/slicedToArray"), u = (a = require("set-cookie-parser")) && a.__esModule ? a : {
    default: a
}, c = [ "success", "fail", "url", "header" ];

exports.formatTime = function(e) {
    var r = e.getFullYear(), t = e.getMonth() + 1, n = e.getDate(), o = e.getHours(), a = e.getMinutes(), i = e.getSeconds();
    return [ r, t, n ].map(l).join("/") + " " + [ o, a, i ].map(l).join(":");
};

var l = function(e) {
    var r = e.toString();
    return r[1] ? r : "0" + r;
};

function p(e) {
    var r, t, n = (r = e, Object.fromEntries(Object.entries(r).map(function(e) {
        var r = s(e, 2), t = r[0], n = r[1];
        return [ t.toLowerCase(), n ];
    })))["set-cookie"], o = u.default.splitCookiesString(n), a = u.default.parse(o, {
        decodeValues: !1
    }), c = Date.now(), l = i(a);
    try {
        for (l.s(); !(t = l.n()).done; ) {
            t.value.createdOn = c;
        }
    } catch (e) {
        l.e(e);
    } finally {
        l.f();
    }
    return a;
}

function f(e, r) {
    var t = p(r);
    if (!e) return o(t);
    var n = e.filter(function(e) {
        return !t.some(function(r) {
            return r.name == e.name;
        });
    });
    return [].concat(o(n), o(t));
}

function d(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
    return e.maxAge ? (Date.now() - e.createdOn) / 1e3 + r >= e.maxAge : !!e.expires && new Date(e.expires).getTime() <= Date.now();
}

function h(e, r) {
    return e.filter(function(e) {
        return !d(e);
    });
}

function v(e) {
    return e.reduce(function(e, r) {
        return (e ? e + " " : "") + r.name + "=" + r.value + ";";
    }, "");
}

function x(e, r) {
    var o = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
    return new Promise(function(a, i) {
        var s, u = e.success, l = e.fail, p = e.url, d = e.header, x = n(e, c);
        if (r) {
            var m = v(h(r));
            s = t(t({}, d), {}, {
                cookie: m
            });
        } else s = d;
        o && (s = t(t({}, s), {}, {
            "content-type": "application/x-www-form-urlencoded"
        })), wx.request(t(t({
            url: p,
            header: s
        }, x), {}, {
            success: function(e) {
                if (e.header.type) {
                    var t = "?type=" + e.header.type;
                    e.header.ti && (t = t + "&ti=" + e.header.ti), wx.reLaunch({
                        url: "../covers/covers" + t,
                        fail: function(e) {
                            console.log(e);
                        }
                    });
                } else if ("string" == typeof e.data && e.data.slice(0, 30).match("\x3c!-- covers --\x3e")) wx.reLaunch({
                    url: "../covers/covers",
                    fail: function(e) {
                        console.log(e);
                    }
                }); else {
                    u && u(e);
                    var n = f(r, e.header);
                    a({
                        res: e,
                        cookieJar: n
                    });
                }
            },
            fail: function(e) {
                l && l(e), i(e);
            }
        }));
    });
}

function m() {
    return (m = r(e().mark(function r(t, n) {
        var o, a = arguments;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return o = a.length > 2 && void 0 !== a[2] && a[2], e.prev = 1, e.next = 4, x(t, n, o);

              case 4:
                return e.abrupt("return", e.sent);

              case 7:
                throw e.prev = 7, e.t0 = e.catch(1), wx.showToast({
                    title: "服务器错误",
                    icon: "error"
                }), e.t0;

              case 11:
              case "end":
                return e.stop();
            }
        }, r, null, [ [ 1, 7 ] ]);
    }))).apply(this, arguments);
}

function g() {
    wx.showToast({
        title: "Dev Only",
        icon: "error"
    });
}

exports.generateURLHashParameter = function(e) {
    for (var r = "", t = 0, n = Object.entries(e); t < n.length; t++) {
        var o = s(n[t], 2), a = o[0], i = o[1];
        r += (0 === r.length ? "" : "&") + a + "=" + i;
    }
    return r;
};

exports.sleep = function(e) {
    return new Promise(function(r, t) {
        setTimeout(function() {
            r();
        }, e);
    });
};

exports.getCode = function() {
    return new Promise(function(e, r) {
        wx.login({
            success: function(r) {
                e(r.code);
            },
            fail: function(e) {
                r(e);
            }
        });
    });
};