Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.initSharedData = void 0;

var e = {
    textAssets: {
        tabTitles: {
            shop: "选购",
            sessions: "课程",
            search: "搜索",
            cart: "购物袋",
            beta: "Beta"
        },
        editing: "编辑",
        finish: "完成",
        loading: "正在载入",
        searchStore: "搜索产品和零售店",
        nearbyStoreSearch: "查找附近的零售店",
        recentlyViewed: "FIXME RECENTLY VIEWED",
        trySearch: "尝试搜索",
        topResults: "热门结果",
        moreResults: "更多结果",
        noSearchResult: "未找到任何结果。",
        browseAllStores: "浏览所有 Apple Store 零售店",
        browseApplePremiumStores: "查找 Apple 优质经销商",
        address: "地址",
        map: "地图",
        models: "款",
        list: "列表",
        searchByCityPostalCodeOrName: "按城市、邮政编码或名称搜索",
        search: "搜索",
        cancel: "取消",
        delete: "删除",
        processingOrder: "正在处理您的订单",
        processingPay: "准备付款",
        genericDataError: "尝试完成你的请求时出错。请稍后再试。",
        ok: "确定",
        checkout: "结账",
        shipping: "运送信息",
        pickupContact: "取货联系人",
        pickupStore: "取货零售店",
        invoice: "发票",
        save: "存储",
        defaultSharingTitle: "为你提供 Apple 产品的最新信息和快速便捷的购物体验。",
        sessionSharingTitle: "Today at Apple: 快来零售店参加免费课程",
        landingSharingTitle: "官方在线商店现已精彩上线"
    },
    bootstrapURL: "https://web.mmap.apple.com/miniprogram-merch/p/wechat/init",
    bootstrap: {
        diwaCookieName: "",
        disaCookieName: "",
        urls: {
            aprstoredetails: null,
            aprstoredetailslist: null,
            diwaFetchURL: void 0,
            extrastoreinfo: null,
            resellerCountryList: null,
            resellerStoresInCountry: null,
            shopLandingUrl: void 0,
            storedetails: null,
            storesearchpage: null,
            storesfederatedsearch: null,
            calendarFilterWrapper: null,
            sessionsHome: null,
            sessionsHomeWrapper: null,
            sessionsList: null,
            spotlight: null,
            splitSearchUrl: null,
            disaFetchURL: null,
            elmoBagLandingURL: null,
            idmsLoginUrlWithBindingRedirect: null,
            openIdFetchUrl: null,
            baselineDataURL: null,
            allstoresinfolite: null,
            orderStatusUrl: null
        }
    },
    urls: {
        aosShippingPickup: "https://www.apple.com.cn/shop/shipping-pickup",
        redirectURLHelper: "https://web.mmap.apple.com/miniprogram-merch/p/wechat/redirect",
        checkoutStart: null,
        domain: "https://web.mmap.apple.com/"
    },
    location: void 0,
    cookieJar: [],
    isAppReady: void 0,
    notifications: {
        orderstatus: "iiuSp9EYsMnj6phnbcUe8xnLvJMyWDVFfoa5xBy8kj4",
        todayatapple: "YYMHvNIop7JDf3vczBMAGnzGVVNth7pIf2_j49QV9tA",
        survey: "WKz7qfC7LwyVAvgUZpfnfvHx_U7Znb2Gqy2qoGRyLAM",
        efapiao: "EOlZgapS_CsjcWKalogOdGeau6CULjaDAPy6estPYXo"
    },
    images: {
        appleLogoUrl: "http://mmbiz.qpic.cn/sz_mmbiz_png/s37uxK5D5wlAF6ucZSmPCJjByQSKicJ4fZbNFnrgzWEYan3RKPRQiaU5M5bAp7QH6J6E6dgJM9YcVr8ZU9JewTGg/0?wx_fmt=png",
        sessionSharingUrl: "http://mmbiz.qpic.cn/sz_mmbiz_jpg/s37uxK5D5wmWzVcXs9CmibAKHcWuoiaJHSZDMSnC7DIzB9rgCpnSZylcsJITwLZAzBhC9PqjzDWTkBCT95FZarzw/0?wx_fmt=jpeg",
        landingSharingUrl: "http://mmbiz.qpic.cn/sz_mmbiz_png/s37uxK5D5wlnGiaiazXKXxYlremArkxeNpiaCKjRKwiakvdZHrTTgibsg82PSh0HiazOFUCoorWzHicywFibawEdI5SkzQ/0?wx_fmt=png"
    }
};

exports.initSharedData = e;