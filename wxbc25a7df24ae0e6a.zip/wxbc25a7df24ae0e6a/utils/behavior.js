Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.sharedDataBehavior = exports.requestWithSharedCookies = void 0;

var e = require("../@babel/runtime/helpers/regeneratorRuntime"), a = require("../@babel/runtime/helpers/asyncToGenerator"), r = require("./util");

var t = Behavior({
    lifetimes: {
        detached: function() {
            this.data.sharedSaved ? console.warn("Did not save SharedData ".concat(this.route)) : (this.setData({
                sharedSaved: !0
            }), getApp().globalData.shared = this.data.shared, console.warn("Saved SharedData ".concat(this.route)));
        }
    },
    pageLifetimes: {
        show: function() {
            this.setData({
                shared: getApp().globalData.shared,
                sharedSaved: !1
            }), console.warn("Loaded SharedData ".concat(this.route));
        },
        hide: function() {
            this.data.sharedSaved ? console.warn("Did not save SharedData ".concat(this.route)) : (this.setData({
                sharedSaved: !0
            }), getApp().globalData.shared = this.data.shared, console.warn("Saved SharedData ".concat(this.route)));
        }
    }
});

exports.sharedDataBehavior = t;

var o = Behavior({
    methods: {
        set: function(e) {
            var a = this;
            return new Promise(function(r) {
                a.setData(e, r);
            });
        },
        crequest: function(t) {
            var o = arguments, s = this;
            return a(e().mark(function a() {
                var n, i, d, h, c, u;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return d = o.length > 1 && void 0 !== o[1] ? o[1] : {}, e.next = 3, d.dontShowError ? (0, 
                        r.requestWithCookies)(t, s.data.shared.cookieJar, null !== (n = d.formUrlEncoded) && void 0 !== n && n) : (0, 
                        r.requestOrShowError)(t, s.data.shared.cookieJar, null !== (i = d.formUrlEncoded) && void 0 !== i && i);

                      case 3:
                        return h = e.sent, c = h.res, u = h.cookieJar, e.next = 8, s.set({
                            "shared.cookieJar": u
                        });

                      case 8:
                        return e.abrupt("return", c);

                      case 9:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        }
    }
});

exports.requestWithSharedCookies = o;