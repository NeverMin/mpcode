var e = require("../@babel/runtime/helpers/typeof");

require("../@babel/runtime/helpers/Arrayincludes");

var t = require("../@babel/runtime/helpers/toConsumableArray");

require("../@babel/runtime/helpers/Objectentries");

var a = require("../@babel/runtime/helpers/classCallCheck"), n = require("../@babel/runtime/helpers/createClass");

!function() {
    var s = {}, i = {}, o = {};
    function c(e, t) {
        return o[e] || (i[e] = {
            exports: {},
            loaded: !1
        }, o[e] = !0, 0 === e && "function" == typeof require ? require.main = i[0] : i[e].parent = i[t], 
        s[e].call(this, i[e], i[e].exports), i[e].loaded = !0), i[e].exports;
    }
    if (s[0] = function(e, t) {
        var s = c(1, 0), i = c(2, 0), o = c(3, 0), r = c(4, 0).registerAppEvent, u = c(5, 0).logService, l = c(6, 0).InvalidArgumentException, d = u, p = {
            contextdata: {
                "analytics.offlineEnabled": !1,
                "app.version": "",
                "session.timeout": 30
            }
        };
        var h = function() {
            function e() {
                a(this, e), this.eventProcessor = new o();
            }
            return n(e, [ {
                key: "init",
                value: function(e) {
                    if (this.started) d.error("AdobeSDK - you can not initialize AdobeSDK more than once "); else {
                        if (!function(e) {
                            return !!e && (!!e["analytics.server"] && (!!e["analytics.rsids"] && !!e["app.id"]));
                        }(e)) throw d.error("AdobeSDK - not initialize AdobeSDK correctly, config = ", e), 
                        new l("invalid configuration");
                        d.debug("AdobeSDK - init, config = ", e);
                        var t, a, n = (t = e, a = Object.assign({}, p.contextdata), Object.assign(a, t));
                        d.debug("AdobeSDK - merge configuration with default value = ", n);
                        var o = {
                            name: "amsdk.configuration",
                            data: {
                                contextdata: n
                            }
                        }, c = new s(o, this.eventProcessor), u = new i(o, this.eventProcessor);
                        this.eventProcessor.registerProcessor(c), this.eventProcessor.registerProcessor(u), 
                        r(c), this.eventProcessor.process({
                            name: "amsdk.app.on.launch",
                            date: Date.now()
                        }), this.started = !0, d.debug("AdobeSDK - launched adobe sdk sucessfullly.");
                    }
                }
            }, {
                key: "setDebugLoggingEnabled",
                value: function(e) {
                    d.ENABLE_DEBUG = e || !1;
                }
            }, {
                key: "trackAction",
                value: function(e, t) {
                    this.started ? (d.debug("Analytics - track action , event =", t), this.eventProcessor.process({
                        name: "amsdk.analytics.action",
                        data: {
                            action: e,
                            contextdata: t
                        }
                    })) : d.error("AdobeSDK - not initialize AdobeSDK correctly, IGNORE curretion operation - track action with args = ", e, t);
                }
            }, {
                key: "trackState",
                value: function(e, t) {
                    this.started ? (d.debug("Analytics - track state , event =", t), this.eventProcessor.process({
                        name: "amsdk.analytics.state",
                        data: {
                            state: e,
                            contextdata: t
                        }
                    })) : d.error("AdobeSDK - not initialize AdobeSDK correctly, IGNORE curretion operation - track state with args = ", e, t);
                }
            } ]), e;
        }(), f = function() {
            function e() {
                a(this, e), this.amsdk = new h();
            }
            return n(e, [ {
                key: "init",
                value: function(e) {
                    try {
                        this.amsdk.init(e);
                    } catch (e) {
                        if (d.error(e.stack), this.debugMode) throw e;
                    }
                }
            }, {
                key: "trackState",
                value: function(e, t) {
                    try {
                        this.amsdk.trackState(e, t);
                    } catch (e) {
                        if (d.error(e.stack), this.debugMode) throw e;
                    }
                }
            }, {
                key: "trackAction",
                value: function(e, t) {
                    try {
                        this.amsdk.trackAction(e, t);
                    } catch (e) {
                        if (d.error(e.stack), this.debugMode) throw e;
                    }
                }
            }, {
                key: "setDebugModeEnabled",
                value: function(e) {
                    this.debugMode = e || !1;
                }
            }, {
                key: "setDebugLoggingEnabled",
                value: function(e) {
                    this.amsdk.setDebugLoggingEnabled(e);
                }
            } ]), e;
        }();
        return e.exports = new f(), e.exports;
    }, s[1] = function(e, t) {
        var s = c(5, 1), i = s.localStorageService, o = s.logService, r = c(6, 1).InvalidArgumentException, u = o;
        return e.exports = function() {
            function e(t, n) {
                if (a(this, e), u.debug("Lifecycle - init -- configuration = ", t), !t || !n) throw new r("failed to initialize Lifecycle object, as configuraiont or event processor is not set correctly.");
                if (!(t.name && t.data && t.data.contextdata && t.data.contextdata["app.version"] && t.data.contextdata["session.timeout"])) throw new r("failed to initialize Lifecycle object, configuration event error : " + JSON.stringify(t));
                this.eventProcessor = n, this.confContextData = t.data.contextdata, this.contextdata = {}, 
                this.appLifecycle = this._loadLocalObj();
            }
            return n(e, [ {
                key: "_loadLocalObj",
                value: function() {
                    if (i.has("amsdk.lifecye.local")) {
                        var e = i.get("amsdk.lifecye.local");
                        return u.debug("Lifecycle - load object [appLifecycle] from local storage, key = amsdk.lifecye.local value = ", e), 
                        e;
                    }
                    return u.debug("Lifecycle - object [appLifecycle] does not exist in local storage, return default value."), 
                    {
                        install: {},
                        upgrade: {},
                        "session.previous": {},
                        "session.current": {},
                        "latest.engaged.day": null,
                        "latest.engaged.month": null,
                        launches: 0
                    };
                }
            }, {
                key: "_processOnLaunchEvent",
                value: function(e) {
                    switch (this._launchAppType(this.appLifecycle.install, this.confContextData)) {
                      case 1001:
                        u.debug("Lifecycle - process install event."), this.appLifecycle.install = {
                            "first.install.date": e,
                            "latest.install.date": e,
                            "app.version": this.confContextData["app.version"]
                        }, this.appLifecycle.upgrade = {
                            "last.upgrade.date": e,
                            "launches.since.last.upgrade": 0
                        }, u.debug("Lifecycle - update appLifecycle object -", this.appLifecycle), this.contextdata["a.InstallEvent"] = "InstallEvent", 
                        this.contextdata["a.InstallDate"] = this._dateString(e), u.debug("Lifecycle - update contextdata of lifecycle event - ", this.contextdata);
                        break;

                      case 1002:
                        u.debug("Lifecycle - process upgrade event."), this.appLifecycle.install["latest.install.date"] = e, 
                        this.appLifecycle.install["app.version"] = this.confContextData["app.version"], 
                        this.contextdata["a.UpgradeEvent"] = "UpgradeEvent", this.contextdata["a.DaysSinceLastUpgrade"] = this._daysSinceLastUpgrade(this.appLifecycle.upgrade, e), 
                        this.contextdata["a.LaunchesSinceUpgrade"] = this._launchesSinceUpgrade(this.appLifecycle.upgrade), 
                        u.debug("Lifecycle - update contextdata of lifecycle event - ", this.contextdata), 
                        this.appLifecycle.upgrade = {}, this.appLifecycle.upgrade["last.upgrade.date"] = e, 
                        this.appLifecycle.upgrade["launches.since.last.upgrade"] = 0, u.debug("Lifecycle - update appLifecycle object -", this.appLifecycle);
                    }
                }
            }, {
                key: "_launchAppType",
                value: function(e, t) {
                    return e && e["app.version"] ? t["app.version"] && e["app.version"] != t["app.version"] ? 1002 : 1003 : 1001;
                }
            }, {
                key: "_daysSinceLastUpgrade",
                value: function(e, t) {
                    return e && e["last.upgrade.date"] ? this._daysInterval(e["last.upgrade.date"], t) : 0;
                }
            }, {
                key: "_launchesSinceUpgrade",
                value: function(e) {
                    return e && e["launches.since.last.upgrade"] ? e["launches.since.last.upgrade"] : 0;
                }
            }, {
                key: "_sendAnalyticsEvent",
                value: function() {
                    var e = {
                        name: "amsdk.lifecycle",
                        data: {
                            action: "Lifecycle",
                            isInternalAction: !0,
                            contextdata: this.contextdata
                        }
                    };
                    u.debug("Lifecycle - send analytics request, event = ", e), this.eventProcessor.process(e), 
                    this.contextdata = {};
                }
            }, {
                key: "_processOnShowEvent",
                value: function(e) {
                    var t = this.confContextData["session.timeout"], a = this.appLifecycle["session.current"]["amsdk.session.end.date"];
                    switch (this._showAppType(e, a, t)) {
                      case 2001:
                        this._processNewSessionEvent(e);
                        break;

                      case 2002:
                        var n = this.appLifecycle["session.current"]["amsdk.session.end.date"];
                        this.appLifecycle["session.current"]["amsdk.session.backgound.time"] || (this.appLifecycle["session.current"]["amsdk.session.backgound.time"] = 0), 
                        n && (this.appLifecycle["session.current"]["amsdk.session.backgound.time"] += e - n), 
                        this.appLifecycle["session.current"]["amsdk.session.end.date"] = null, u.debug("Lifecycle - retain session, update appLifecycle object -", this.appLifecycle);
                    }
                }
            }, {
                key: "_processNewSessionEvent",
                value: function(e) {
                    this.appLifecycle.upgrade["launches.since.last.upgrade"]++, this.appLifecycle.launches++, 
                    this.appLifecycle["session.previous"] = this.appLifecycle["session.current"];
                    var t = {};
                    t["amsdk.session.start.date"] = e, this.appLifecycle["session.current"] = t, this.contextdata["a.LaunchEvent"] = "LaunchEvent";
                    var a = this._sessionLength(this.appLifecycle["session.previous"]);
                    a > 0 && (this.contextdata["a.PrevSessionLength"] = a), this.contextdata["a.Launches"] = this.appLifecycle.launches, 
                    this.contextdata["a.DaysSinceFirstUse"] = this._daysSinceFirstUse(this.appLifecycle.install, e), 
                    this.contextdata["a.DaysSinceLastUse"] = this._daysSinceLastUse(this.appLifecycle["session.previous"], e), 
                    this._hasEngagedThisMonth(e, this.appLifecycle["latest.engaged.month"]) || (this.appLifecycle["latest.engaged.month"] = new Date(e).getMonth() + 1, 
                    this.contextdata["a.MonthlyEngUserEvent"] = "MonthlyEngUserEvent"), this._hasEngagedToday(this.appLifecycle["latest.engaged.day"]) || (this.appLifecycle["latest.engaged.day"] = this._dateString(e), 
                    this.contextdata["a.DailyEngUserEvent"] = "DailyEngUserEvent"), this.contextdata["a.HourOfDay"] = new Date(e).getHours(), 
                    this.contextdata["a.DayOfWeek"] = new Date(e).getDay() + 1, this.contextdata["a.sessionStartTimestamp"] = e, 
                    u.debug("Lifecycle - update appLifecycle object -", this.appLifecycle), u.debug("Lifecycle - update contextdata of lifecycle event - ", this.contextdata), 
                    this._sendAnalyticsEvent();
                }
            }, {
                key: "_hasEngagedThisMonth",
                value: function(e, t) {
                    var a = new Date(e).getMonth() + 1;
                    return !(!t || t != a);
                }
            }, {
                key: "_hasEngagedToday",
                value: function(e) {
                    var t = this._dateString(Date.now());
                    return !(!e || t != e);
                }
            }, {
                key: "_daysSinceFirstUse",
                value: function(e, t) {
                    return e["first.install.date"] ? this._daysInterval(e["first.install.date"], t) : 0;
                }
            }, {
                key: "_daysSinceLastUse",
                value: function(e, t) {
                    return e["amsdk.session.end.date"] ? this._daysInterval(e["amsdk.session.end.date"], t) : 0;
                }
            }, {
                key: "_daysInterval",
                value: function(e, t) {
                    return Math.round((t - e) / 864e5);
                }
            }, {
                key: "_sessionLength",
                value: function(e) {
                    if (!e["amsdk.session.start.date"] || !e["amsdk.session.end.date"]) return 0;
                    var t = this.appLifecycle["session.current"]["amsdk.session.backgound.time"];
                    return (!t || t < 0) && (t = 0), Math.round((e["amsdk.session.end.date"] - e["amsdk.session.start.date"] - t) / 1e3);
                }
            }, {
                key: "_showAppType",
                value: function(e, t, a) {
                    return "UpgradeEvent" === this.contextdata["a.UpgradeEvent"] || !t || Math.round((e - t) / 1e3) > a ? 2001 : 2002;
                }
            }, {
                key: "_updateConfigContextData",
                value: function(e) {
                    this.confContextData = e, u.debug("Lifecycle - update configuration = ", e);
                }
            }, {
                key: "process",
                value: function(e) {
                    switch (e.name) {
                      case "amsdk.configuration":
                        u.debug("Lifecycle - processing [amsdk.configuration] event."), this._updateConfigContextData(e.contextdata);
                        break;

                      case "amsdk.app.on.launch":
                        u.debug("Lifecycle - processing [amsdk.app.on.launch] event."), this._processOnLaunchEvent(e.date);
                        break;

                      case "amsdk.app.on.show":
                        u.debug("Lifecycle - processing [amsdk.app.on.show] event."), this._processOnShowEvent(e.date);
                        break;

                      case "amsdk.app.on.hide":
                        u.debug("Lifecycle - processing [amsdk.app.on.hide] event."), this._processOnHideEvent(e.date);
                    }
                    this._saveObjToLocal();
                }
            }, {
                key: "_processOnHideEvent",
                value: function(e) {
                    this.appLifecycle["session.current"]["amsdk.session.end.date"] = e, u.debug("Lifecycle - update appLifecycle object -", this.appLifecycle);
                }
            }, {
                key: "_saveObjToLocal",
                value: function() {
                    u.debug("Lifecycle - save appLifecycle object to local storage -", this.appLifecycle), 
                    this.appLifecycle && i.set("amsdk.lifecye.local", this.appLifecycle);
                }
            }, {
                key: "_dateString",
                value: function(e) {
                    var t = new Date(e);
                    return t.getUTCMonth() + 1 + "/" + t.getUTCDate() + "/" + t.getUTCFullYear();
                }
            } ]), e;
        }(), e.exports;
    }, s[2] = function(e, s) {
        var i = c(5, 2), o = i.localStorageService, r = i.systemInfoService, u = i.networkService, l = i.logService, d = c(7, 2), p = c(8, 2).serializeAnalyticsRequest, h = l, f = c(6, 2).InvalidArgumentException, y = c(9, 2), v = "wechat-" + y.sdk_version;
        return e.exports = function() {
            function e(t, n) {
                if (a(this, e), !(t && t.name && n && t.data && t.data.contextdata)) throw new f("fail to initialize Analytics object, as configuraiont or event processor is not set correctly.");
                this.confContextData = t.data.contextdata, this.eventProcessor = n, this.context = {}, 
                this.queue = new d(1), this.cachedEvents = [], this._loadAid(), this.taskId = 0;
            }
            return n(e, [ {
                key: "_loadAid",
                value: function() {
                    o.has("adobe.analytics.aid") && o.get("adobe.analytics.aid").length > 0 ? this.context.aid = o.get("adobe.analytics.aid") : this._getAidFromServer();
                }
            }, {
                key: "_saveAid",
                value: function(e) {
                    this.context.aid = e, o.set("adobe.analytics.aid", e);
                    var t = {
                        name: "amsdk.analytics.aid",
                        data: {
                            contextdata: {
                                aid: e
                            }
                        }
                    };
                    h.debug("Analytics - send analytics aid, event = ", t), this.eventProcessor.process(t);
                }
            }, {
                key: "_getAidFromServer",
                value: function() {
                    var e = this, t = "https://".concat(this.confContextData["analytics.server"], "/id");
                    h.debug("Analytics - try to fetch aid from remote, url = ", t), this.queue.push(function(a) {
                        u.request({
                            url: t,
                            success: function(t) {
                                t.data && t.data.id && t.data.id.length > 0 ? (h.debug("Analytics - get aid from remote, response = ", t), 
                                e._saveAid(t.data.id)) : (h.debug("Analytics - fail to get aid from remote ( unsupported browser ), response = ", t), 
                                e._saveAid(e._generateAid())), a();
                            },
                            fail: function(t) {
                                h.debug("Analytics - fail to get aid from remote, error = ", t), e._saveAid(e._generateAid()), 
                                a();
                            }
                        });
                    }, this.taskId++);
                }
            }, {
                key: "_generateAid",
                value: function() {
                    for (var e = [], t = 0; t < 33; t++) e[t] = "0123456789ABCDEF".substr(Math.floor(16 * Math.random()), 1);
                    e[0] = "01234567".substr(Math.floor(8 * Math.random()), 1), e[17] = "0123".substr(Math.floor(4 * Math.random()), 1), 
                    e[16] = "-";
                    var a = e.join("");
                    return h.debug("Analytics - generate aid from devie, uuid = ", a), a;
                }
            }, {
                key: "process",
                value: function(e) {
                    if (!this.context.aid) return this.cachedEvents.push(e), void h.debug("Analytics - aid is not ready, cache event = ", e);
                    if (0 == this.cachedEvents.length) this._process(e); else for (h.debug("Analytics - aid is ready, start to process cached events"); this.cachedEvents.length > 0; ) {
                        var t = this.cachedEvents.shift();
                        t && this._process(t);
                    }
                }
            }, {
                key: "_process",
                value: function(e) {
                    switch (e.name) {
                      case "amsdk.configuration":
                        h.debug("Analytics -- update configuration -- event = ", e), this.confContextData = e.data.contextdata;
                        break;

                      case "amsdk.lifecycle":
                        this.sessionStartTimestamp = e.data.contextdata["a.sessionStartTimestamp"], delete e.data.contextdata["a.sessionStartTimestamp"], 
                        h.debug("Analytics -- track action (lifecycle) -- event = ", e), this._trackAction(e);
                        break;

                      case "amsdk.analytics.action":
                        h.debug("Analytics -- track action -- event = ", e), this._trackAction(e);
                        break;

                      case "amsdk.analytics.state":
                        h.debug("Analytics -- track state -- event = ", e), this._trackState(e);
                    }
                }
            }, {
                key: "_trackAction",
                value: function(e) {
                    this._track(e.data);
                }
            }, {
                key: "_trackState",
                value: function(e) {
                    this._track(e.data);
                }
            }, {
                key: "_track",
                value: function(e) {
                    h.debug("Analytics - track, event data = ", e);
                    var t = this._assembleAnalyticsData(e), a = this._assembleAnalyticsVars(e), n = p(t, a), s = this._getUrl(this.confContextData);
                    h.debug("Analytics - start to send analytics hits to ".concat(s, ", with payload = "), n), 
                    this.queue.push(function(e) {
                        u.request({
                            url: s,
                            method: "POST",
                            data: n,
                            success: function(t) {
                                h.debug("Analytics - sucesss to send analytics hit, with response = ", t), e();
                            },
                            fail: function(t) {
                                h.debug("Analytics - fail to send analytics hit, error = ", t), e();
                            }
                        });
                    }, this.taskId++);
                }
            }, {
                key: "_getUrl",
                value: function(e) {
                    var t = Math.floor(Math.random() * Math.floor(1e8));
                    return "https://".concat(e["analytics.server"], "/b/ss/").concat(e["analytics.rsids"], "/0/").concat(v, "/s").concat(t);
                }
            }, {
                key: "_getSystemInfoMap",
                value: function() {
                    var e = r.getSystemInfo();
                    return e["a.AppId"] = this._getAppIdString(), new Map(Object.entries(e));
                }
            }, {
                key: "_assembleAnalyticsData",
                value: function(t) {
                    var a = this._getSystemInfoMap();
                    h.debug("Analytics - get system info = ", a);
                    var n = new Map(Object.entries(t.contextdata || {})), s = e._mergeMaps(a, n);
                    if (t.action && s.set("a.action", t.action), this.sessionStartTimestamp) {
                        var i = Math.round((Date.now() - this.sessionStartTimestamp) / 1e3);
                        s.set("a.TimeSinceLaunch", i);
                    }
                    return s;
                }
            }, {
                key: "_assembleAnalyticsVars",
                value: function(e) {
                    var t = new Map(), a = e.action, n = e.isInternalAction, s = e.state;
                    a && (t.set("pe", "lnk_o"), t.set("pev2", (n ? "ADBINTERNAL:" : "AMACTION:") + (a || "None"))), 
                    t.set("pageName", this._getAppIdString()), s && t.set("pageName", s);
                    var i = this.context.aid;
                    return i && t.set("aid", i), t.set("ce", "UTF-8"), t.set("t", this._getTimestampTzOffset()), 
                    this.confContextData["analytics.offlineEnabled"] && t.set("ts", this._getTimestamp()), 
                    t.set("cp", "foreground"), t;
                }
            }, {
                key: "_getTimestamp",
                value: function() {
                    return Math.round(Date.now() / 1e3);
                }
            }, {
                key: "_getTimestampTzOffset",
                value: function() {
                    return "00/00/0000 00:00:00 0 ".concat(new Date().getTimezoneOffset());
                }
            }, {
                key: "_getAppIdString",
                value: function() {
                    var e = this.confContextData["app.version"];
                    return e.length > 0 ? this.confContextData["app.id"] + " (" + e + ")" : this.confContextData["app.id"];
                }
            } ], [ {
                key: "_mergeMaps",
                value: function(e, a) {
                    return new Map([].concat(t(e), t(a)));
                }
            } ]), e;
        }(), e.exports;
    }, s[3] = function(e, t) {
        var s = c(5, 3).logService;
        return e.exports = function() {
            function e() {
                a(this, e), this.processors = [];
            }
            return n(e, [ {
                key: "registerProcessor",
                value: function(e) {
                    this.processors.push(e);
                }
            }, {
                key: "process",
                value: function(e) {
                    e && e.name ? this.processors.forEach(function(t) {
                        t.process(e);
                    }) : s.debug("EventHut - invalid event = ", e);
                }
            } ]), e;
        }(), e.exports;
    }, s[4] = function(e, t) {
        var a = c(5, 4), n = a.appLifecycleService, s = a.logService;
        return t.registerAppEvent = function(e) {
            s.debug("AppLifecycleRegister -  register app onHide action."), n.onAppHide(function() {
                e.process({
                    name: "amsdk.app.on.hide",
                    date: Date.now()
                });
            }), s.debug("AppLifecycleRegister -  register app onShow action."), n.onAppShow(function(t) {
                e.process({
                    name: "amsdk.app.on.show",
                    date: Date.now()
                });
            });
        }, e.exports;
    }, s[5] = function(e, t) {
        return t.localStorageService = c(10, 5), t.systemInfoService = c(11, 5), t.networkService = c(12, 5), 
        t.logService = c(13, 5), t.appLifecycleService = c(14, 5), e.exports;
    }, s[6] = function(e, t) {
        function a(e) {
            this.message = e, "captureStackTrace" in Error ? Error.captureStackTrace(this, a) : this.stack = new Error().stack;
        }
        return a.prototype = Object.create(Error.prototype), a.prototype.name = "InvalidArgumentException", 
        a.prototype.constructor = a, e.exports.InvalidArgumentException = a, e.exports;
    }, s[7] = function(e, t) {
        var s = c(13, 7);
        return e.exports = function() {
            function e() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
                a(this, e), this.concurrency = t, this.queue = [], this.activeCount = 0;
            }
            return n(e, [ {
                key: "push",
                value: function(e, t) {
                    var a = this;
                    s.debug("queue size = ".concat(this.queue.length));
                    var n = function() {
                        a.activeCount++, s.debug("run task [".concat(t, "] --- ")), new Promise(function(a) {
                            try {
                                e(a);
                            } catch (e) {
                                s.debug("task [".concat(t, "] throw exception - "), e), a();
                            }
                        }).then(function() {
                            s.debug("task [".concat(t, "] trigger next task")), a.next();
                        });
                    };
                    this.activeCount < this.concurrency ? n() : this.queue.push(n) && s.debug(" catch task [".concat(t, "]"));
                }
            }, {
                key: "next",
                value: function() {
                    this.activeCount--, this.queue.length > 0 && this.queue.shift()(), s.debug("queue size = ".concat(this.queue.length));
                }
            } ]), e;
        }(), e.exports;
    }, s[8] = function(t, a) {
        var n = c(5, 8).logService;
        function s(e) {
            return !(!/^[0-9A-Za-z_]+$/.test(e) && !/^[0-9A-Za-z_]+\.[0-9A-Za-z_\.]*[0-9A-Za-z_]+$/.test(e));
        }
        function i(e) {
            var t = {};
            return e && e instanceof Map && e.forEach(function(e, a) {
                a && s(a) ? a.includes(".") ? o(a.split("."), t, e) : (t[a] = {}, t[a]["#node_value"] = e) : n.error("invalid data key [".concat(a, "]"));
            }), t;
        }
        function o(e, t, a) {
            var n = e.shift();
            if (n) {
                if (!e[0]) return t[n] || (t[n] = {}), void (t[n]["#node_value"] = a);
                t[n] || (t[n] = {}), o(e, t[n], a);
            }
        }
        function r(t, a) {
            if ("object" != e(t)) return "";
            var n = "", s = "";
            return t.hasOwnProperty("#node_value") && (s = "&" + a + "=" + encodeURIComponent(t["#node_value"])), 
            function(e) {
                return 1 == Object.keys(e).length && "#node_value" == Object.keys(e)[0];
            }(t) ? s : (Object.keys(t).forEach(function(e) {
                "#node_value" != e && (n += r(t[e], e));
            }), s + "&" + a + "." + n + "&." + a);
        }
        return a.serializeAnalyticsRequest = function(e, t) {
            var a, o = new Map(e), c = new Map(t), u = "ndh=1";
            return o.delete(""), o.delete("&&"), o.forEach(function(e, t) {
                if (t && t.startsWith("&&")) {
                    var a = t.substring(2);
                    s(a) ? (o.delete(t), c.set(a, e)) : (n.debug("invalid data key [".concat(a, "]")), 
                    o.delete(t));
                }
            }), o.size > 0 && (u += r(i(o), "c")), c.size > 0 && (u += (a = [], c.forEach(function(e, t) {
                if (!s(t)) {
                    var i = "Invalid key :" + t;
                    throw n.error(i), new InvalidDataKeyException(i);
                }
                a.push(t + "=" + encodeURIComponent(e));
            }), "&" + a.join("&"))), u;
        }, a._convertDataMapToObj = i, a._applyPropertyToObj = o, a._stringifyObj = r, a._isValidDataKey = s, 
        t.exports;
    }, s[9] = function(e, t) {
        return e.exports.sdk_version = "1.0.0", e.exports;
    }, s[10] = function(e, t) {
        var s = function() {
            function e() {
                a(this, e);
            }
            return n(e, [ {
                key: "set",
                value: function(e, t) {
                    wx.setStorageSync(e, t);
                }
            }, {
                key: "get",
                value: function(e) {
                    return wx.getStorageSync(e);
                }
            }, {
                key: "has",
                value: function(e) {
                    return !!wx.getStorageSync(e);
                }
            }, {
                key: "removeWhenExist",
                value: function(e) {
                    this.get(e) && wx.removeStorageSync(e);
                }
            } ]), e;
        }();
        return e.exports = new s(), e.exports;
    }, s[11] = function(e, t) {
        var s = function() {
            function e() {
                a(this, e);
            }
            return n(e, [ {
                key: "getSystemInfo",
                value: function() {
                    var e = wx.getSystemInfoSync(), t = e.windowHeight + "x" + e.windowWidth, a = {};
                    return a["a.OSVersion"] = e.system, a["a.DeviceName"] = e.model, a["a.Resolution"] = t, 
                    a["a.RunMode"] = "Application", a["a.PlatformVersion"] = "wechat-" + e.version, 
                    a;
                }
            } ]), e;
        }();
        return e.exports = new s(), e.exports;
    }, s[12] = function(e, t) {
        var s = c(13, 12), i = function() {
            function e() {
                a(this, e);
            }
            return n(e, [ {
                key: "request",
                value: function(e) {
                    if (!e || !e.url || 0 == e.url.length) return s.debug("Invalid request", e), void (e.fail && e.fail("Invalid request ".concat(e)));
                    s.debug("Sending request", e), wx.request({
                        url: e.url,
                        method: e.method || "GET",
                        data: e.data,
                        header: e.header || {
                            "content-type": "application/x-www-form-urlencoded"
                        },
                        success: function(t) {
                            s.debug("Request success", t), e.success && e.success(t);
                        },
                        fail: function(t) {
                            s.debug("Request failed", t), e.fail && e.fail(t);
                        },
                        complete: function() {
                            s.debug("Request complete"), e.complete && e.complete();
                        }
                    });
                }
            } ]), e;
        }();
        return e.exports = new i(), e.exports;
    }, s[13] = function(e, t) {
        var s = function() {
            function e() {
                a(this, e);
            }
            return n(e, [ {
                key: "debug",
                value: function() {
                    var e;
                    this.ENABLE_DEBUG && (e = console).debug.apply(e, [ "Adobe SDK [DEBUG]-[" + new Date().toLocaleString() + "]" ].concat(Array.prototype.slice.call(arguments)));
                }
            }, {
                key: "log",
                value: function() {
                    var e;
                    (e = console).log.apply(e, [ "Adobe SDK [DEBUG]-[" + new Date().toLocaleString() + "]" ].concat(Array.prototype.slice.call(arguments)));
                }
            }, {
                key: "warn",
                value: function() {
                    var e;
                    (e = console).warn.apply(e, [ "Adobe SDK [DEBUG]-[" + new Date().toLocaleString() + "]" ].concat(Array.prototype.slice.call(arguments)));
                }
            }, {
                key: "info",
                value: function() {
                    var e;
                    (e = console).info.apply(e, [ "Adobe SDK [DEBUG]-[" + new Date().toLocaleString() + "]" ].concat(Array.prototype.slice.call(arguments)));
                }
            }, {
                key: "error",
                value: function() {
                    var e;
                    (e = console).error.apply(e, [ "Adobe SDK [DEBUG]-[" + new Date().toLocaleString() + "]" ].concat(Array.prototype.slice.call(arguments)));
                }
            } ]), e;
        }();
        return e.exports = new s(), e.exports;
    }, s[14] = function(e, t) {
        var s = function() {
            function e() {
                a(this, e);
            }
            return n(e, [ {
                key: "onAppShow",
                value: function(e) {
                    wx.onAppShow(e);
                }
            }, {
                key: "onAppHide",
                value: function(e) {
                    wx.onAppHide(e);
                }
            }, {
                key: "onError",
                value: function(e) {
                    wx.onError(e);
                }
            } ]), e;
        }();
        return e.exports = new s(), e.exports;
    }, "object" !== ("undefined" == typeof module ? "undefined" : e(module))) return c(0);
    module.exports = c(0);
}();