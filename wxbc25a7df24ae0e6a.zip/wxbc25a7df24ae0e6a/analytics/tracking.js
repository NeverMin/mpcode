Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.trackLinkOmniture = void 0;

var e = require("../@babel/runtime/helpers/objectSpread2"), r = require("../@babel/runtime/helpers/slicedToArray");

require("../@babel/runtime/helpers/Objectentries");

var a, t = require("../@babel/runtime/helpers/typeof"), n = (a = require("./AdobeSDK-1.0.0")) && a.__esModule ? a : {
    default: a
};

var l = function(a, n, l) {
    var c = {}, p = null, i = [], o = "", s = "", u = function(e, r) {
        return o = e.replace(/\$\{\w*\}/g, function(e) {
            return s = (s = e.replace("${", "")).replace("}", ""), r && r[s] || "";
        }).replace(/\$\(\w*\)/g, function(e) {
            return s = (s = e.replace("$(", "")).replace(")", ""), r && r[s] || "";
        }).replace(/\$\(\w*[/]\w*\)/g, function(e) {
            return s = (s = e.replace("$(", "")).replace(")", ""), r && r[s] || "";
        }).replace(/\$\(\w*[.]\w*\)/g, function(e) {
            return s = (s = e.replace("$(", "")).replace(")", ""), r && r[s] || "";
        }).replace(/\$\{\w*[.]\w*\}/g, function(e) {
            return s = (s = e.replace("${", "")).replace("}", ""), r && r[s] || "";
        }).replace(/\{\w*\}/g, function(e) {
            return s = (s = e.replace("{", "")).replace("}", ""), r && r[s] || "";
        }), o.replace(/>\s{2}/g, "");
    };
    return a && a.products && (p = u(a.products, n), a.addOnProducts && n && n.addOnProducts ? (n.addOnProducts.forEach(function(e) {
        i.push(u(a.addOnProducts, e));
    }), c.products = p + i.join(";")) : c.products = p), a && "object" === t(a) && Object.entries(a).forEach(function(e) {
        var a = r(e, 2), t = a[0], l = a[1];
        [ "products", "addOnProducts" ].indexOf(t) >= 0 || "string" == typeof l && (c[t] = u(l, n));
    }), e(e({}, l), c);
};

function c(e) {
    Object.keys(e).forEach(function(r) {
        if ("products" === r) {
            e["&&products"] = e.products;
        }
        if ("events" === r) {
            e["&&events"] = e.events;
        }
        if ("prop22" === r) {
            e["apl.olssWebOrderID"] = e.prop22, delete e.prop22;
        }
    });
}

var p = [ "apl.storeName", "apl.platformDisplayResolution", "apl.workshopAndEventID", "apl.internalSearchResultCount", "apl.internalSearchResultRank", "apl.internalSearchKeyword", "apl.appSizeClass", "apl.carrierAndUseCase", "apl.searchMethodAndIntent", "apl.searchResultTab", "apl.storeDistance", "apl.tradeInDevice", "apl.affiliatePartnerID", "apl.merchandising", "apl.searchMethodAndIntent", "apl.relayID", "apl.deviceColor", "apl.searchSuggestionsSelected", "apl.seoReferrerID", "apl.appSettings", "apl.pushNotification", "apl.appVersion", "apl.inStoreMode", "apl.appleCardState", "apl.checkoutOption", "apl.giftWrapping", "apl.taGuestNo", "apl.idContainer", "linkTrackVars", "storeId", "trackingServer" ];

function i(r, a, t, i, o, s) {
    var u, d;
    t || (t = {}), d = l(r, e(e({}, r), t)), u = l(a, e(e({}, d), t));
    var f = e(e({}, d), u);
    c(f), f.linkName || (f.linkName = f["apl.microevents1"] || f["apl.microevents2"] || f["apl.microevents3"] || f["apl.cartCheckoutMicroevents"] || f["apl.errors"]), 
    p.forEach(function(e) {
        f[e] && delete f[e];
    }), n.default.trackAction(f.linkName, f);
}

exports.trackLinkOmniture = function(r) {
    var a = r.omniture, t = r.type, o = r.data, s = r.isTrackAsPages, u = void 0 === s ? null : s;
    if (a) {
        var d = a.trackPage;
        if (u && null != a && a.trackAsPages) {
            var f, v = null === (f = a.trackAsPages) || void 0 === f ? void 0 : f[t];
            v && i(a.trackAsPages, v, o);
        } else if ("PAGE_LOAD" === t && d) !function(r) {
            var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
            a && (r = l(r, a));
            r.trackingServer || (r.trackingServer = "securemetrics.apple.com.cn");
            if (!r || !r.trackingServer) return null;
            c(r), p.forEach(function(e) {
                r[e] && delete r[e];
            }), r = e(e({}, r), {}, {
                "apl.analyticsCallType": "s.t"
            }), n.default.trackState(r["apl.pageName"], r);
        }(d, o); else if (d && a.trackLinks && t in a.trackLinks) {
            i(d, a.trackLinks[t], o);
        }
    }
};