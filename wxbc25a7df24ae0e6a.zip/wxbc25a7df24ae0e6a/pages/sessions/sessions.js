var e = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var a = s(t);
    if (a && a.has(e)) return a.get(e);
    var r = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var n in e) if ("default" !== n && Object.prototype.hasOwnProperty.call(e, n)) {
        var o = i ? Object.getOwnPropertyDescriptor(e, n) : null;
        o && (o.get || o.set) ? Object.defineProperty(r, n, o) : r[n] = e[n];
    }
    r.default = e, a && a.set(e, r);
    return r;
}(require("../../utils/tabbarUtil")), t = require("../../utils/behavior"), a = require("../../utils/sharedData"), r = require("../../utils/util.js");

function s(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), a = new WeakMap();
    return (s = function(e) {
        return e ? a : t;
    })(e);
}

Component({
    data: {
        shared: a.initSharedData,
        tabIndex: 1,
        url: "",
        urlParams: ""
    },
    methods: {
        onLoad: function(e) {
            this.setData({
                urlParams: e
            });
        },
        onShow: function() {
            e.switchTab(this, this.data.tabIndex);
        },
        onReady: function() {
            var e = this;
            void 0 !== this.data.shared.isAppReady ? this.data.shared.isAppReady && this.setUrlwithHash() : getApp().watch(function(t) {
                t && e.setUrlwithHash();
            });
        },
        setUrlwithHash: function() {
            var e = this.data.shared.bootstrap.urls.sessionsHomeWrapper, t = {}, a = this.data.shared.location;
            void 0 !== a && (t.loc = a.latitude + "," + a.longitude);
            var s = encodeURIComponent((0, r.generateURLHashParameter)(t)), i = (0, r.generateURLHashParameter)(this.data.urlParams);
            this.setData({
                url: e + (i ? "?" + i : "") + (s ? "#" + s : "")
            });
        },
        onShareAppMessage: function(e) {
            return {
                title: this.data.shared.textAssets.sessionSharingTitle,
                path: "/pages/pageView/pageView?url=" + encodeURIComponent(e.webViewUrl),
                imageUrl: this.data.shared.images.sessionSharingUrl
            };
        },
        handlePostMessage: function(e) {
            var t = e.detail.data;
            console.log("handlePostMessage", t), this.setData({
                postSharingData: t
            });
        }
    },
    behaviors: [ t.sharedDataBehavior ]
});