Page({
    data: {
        title: "订阅活动状态通知",
        message: "订阅活动提醒",
        isSubscribed: !1
    },
    onSubscribe: function() {
        var e = this, s = !1;
        wx.requestSubscribeMessage({
            tmplIds: [ "YYMHvNIop7JDf3vczBMAGnzGVVNth7pIf2_j49QV9tA" ],
            success: function(t) {
                console.log("requestSubscribeMessage success", t), s = !0, e.setData({
                    isSubscribed: s
                });
            },
            fail: function(e) {
                console.log("requestSubscribeMessage fail", e);
            },
            complete: function() {
                console.log("requestSubscribeMessage complete"), e.data.isSubscribed && e.setData({
                    message: "已订阅"
                });
            }
        });
    }
});