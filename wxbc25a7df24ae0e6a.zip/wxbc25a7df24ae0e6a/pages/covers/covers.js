Page({
    data: {
        coverMessages: {
            plain: {
                title: "种种精彩，已为你准备就绪。",
                detail: "我们将尽快为你呈现，请稍后回来。"
            },
            announce: {
                title: "稍等一下",
                detail: "我们正在更新 Apple Store, 请稍后再来"
            },
            preorder: {
                title: "我们同样迫不及待。",
                detail: "今晚 9 点开始预购，到时见。"
            },
            ramp: {
                title: "快到了。",
                detail: "仅需要一点收尾Apple Store便准备就绪，一会儿见。"
            },
            wwdc: {
                title: "精彩码上揭晓",
                detail: "Apple Store 在线商店更新中。特别活动正于 apple.com 线上直播，活动结束后欢迎再来。"
            },
            upcomingEvent: {
                title: "转眼就好",
                detail: "Apple Store 上新中，咱们稍后见。",
                link: "观看特别活动 ↗",
                url: "https://www.apple.com.cn/apple-events/"
            },
            selectedCoverMessages: {
                title: "种种精彩，已为你准备就绪。",
                detail: "我们将尽快为你呈现，请稍后回来。"
            }
        },
        copyright: " Copyright © " + new Date().getFullYear() + " Apple Inc. 保留所有权利。",
        isVideo: !0
    },
    onLoad: function(e) {
        var t = e.type, s = e.ti || 60, a = 1e3 * parseInt(s);
        setTimeout(function() {
            getApp().bootstrap();
        }, a), this.messageSelector(t);
    },
    messageSelector: function(e) {
        switch (e) {
          case "npia":
            this.setData({
                selectedCoverMessages: this.data.coverMessages.announce
            });
            break;

          case "npip":
            this.setData({
                selectedCoverMessages: this.data.coverMessages.preorder
            });
            break;

          case "p":
            this.setData({
                selectedCoverMessages: this.data.coverMessages.ramp
            });
            break;

          default:
            this.setData({
                selectedCoverMessages: this.data.coverMessages.plain
            });
        }
    }
});