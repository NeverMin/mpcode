var e = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), t = require("../../@babel/runtime/helpers/regeneratorRuntime"), o = require("../../@babel/runtime/helpers/asyncToGenerator"), n = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var o = s(t);
    if (o && o.has(e)) return o.get(e);
    var n = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
        var r = a ? Object.getOwnPropertyDescriptor(e, i) : null;
        r && (r.get || r.set) ? Object.defineProperty(n, i, r) : n[i] = e[i];
    }
    n.default = e, o && o.set(e, n);
    return n;
}(require("../../utils/tabbarUtil")), a = require("../../utils/util"), i = require("../../utils/behavior"), r = require("../../utils/sharedData");

function s(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), o = new WeakMap();
    return (s = function(e) {
        return e ? o : t;
    })(e);
}

Component({
    data: {
        cookieString: "",
        bootstrapURL: {
            prod: "https://web.mmap.apple.com/miniprogram-merch/p/wechat/init",
            it: "https://web-it.apple.com/miniprogram-merch/p/wechat/init",
            uat: "https://web-uat.apple.com/miniprogram-merch/p/wechat/init",
            xe03: "https://web.xe03aws.g.apple.com/miniprogram-merch/p/wechat/init",
            ce03: "https://web.ce03aws.g.apple.com/miniprogram-merch/p/wechat/init",
            xe04: "https://web.xe04aws.g.apple.com/miniprogram-merch/p/wechat/init",
            ce04: "https://web.ce04aws.g.apple.com/miniprogram-merch/p/wechat/init",
            xe05: "https://web.xe05aws.g.apple.com/miniprogram-merch/p/wechat/init",
            ce05: "https://web.ce05aws.g.apple.com/miniprogram-merch/p/wechat/init"
        },
        shared: r.initSharedData,
        revision: ""
    },
    methods: {
        goto: function() {
            wx.navigateTo({
                url: "/pages/pageView/pageView?url=https%3A%2F%2Fweb.mmap.apple.com%2Fminiprogram-merch%2Fp%2Fwechat%2Fshop%2Fgoto%2Fproduct%2FMM0A3FE%2FA%3Fcid%3Daos-cn-kwwe-brand%26mnid%3D1A1zbDAx_mtid_18707vxu38484%26mtid%3D18707vxu38484%26aosid%3Dp238"
            });
        },
        updateRevision: function(e) {
            this.setData({
                revision: e.detail.value
            });
        },
        onLoad: function() {
            this.getVersionInfo();
        },
        onShow: function() {
            (0, a.devOnly)(), n.switchTab(this, this.data.tabIndex);
        },
        onShareAppMessage: function() {
            return {
                title: "Environment Switcher",
                imageUrl: "http://mmbiz.qpic.cn/mmbiz_png/h8o3zEnERNSSJmumoEZZ3xjicyR6WE9HlHKBXgJECaxAG75TxFzVPVLkDWDiah31fia6SCEdk8D5O4JricKRYnYAWw/0?wx_fmt=png"
            };
        },
        subscribe: function() {
            wx.requestSubscribeMessage({
                tmplIds: [ this.data.shared.notifications.orderstatus, this.data.shared.notifications.todayatapple, this.data.shared.notifications.survey ],
                success: function(e) {
                    console.log("requestSubscribeMessage success", e);
                },
                fail: function(e) {
                    console.log("requestSubscribeMessage fail", e);
                },
                complete: function() {
                    console.log("requestSubscribeMessage complete");
                }
            });
        },
        getOpenId: function() {
            var e = this;
            return o(t().mark(function o() {
                var n, i;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.prev = 0, t.next = 3, (0, a.requestOrShowError)({
                            url: "https://web.mmap.apple.com/miniprogram-bootstrap/fetchOpenId"
                        }, e.data.shared.cookieJar);

                      case 3:
                        n = t.sent, i = n.res, n.cookieJar, e.setData({
                            openIdString: i.data.openID
                        }), t.next = 13;
                        break;

                      case 9:
                        return t.prev = 9, t.t0 = t.catch(0), console.error("getOpenId failed", t.t0), t.abrupt("return");

                      case 13:
                      case "end":
                        return t.stop();
                    }
                }, o, null, [ [ 0, 9 ] ]);
            }))();
        },
        storeFinder: function() {
            wx.navigateTo({
                url: "../storeFinder/storeFinder"
            });
        },
        chooseAddress: function() {
            wx.chooseAddress({
                success: function(e) {
                    e ? console.log("chooseAddress win " + e) : console.log("chooseAddress lose " + e);
                }
            });
        },
        openLocation: function() {
            wx.getLocation({
                type: "gcj02",
                success: function(e) {
                    var t = e.latitude, o = e.longitude;
                    wx.openLocation({
                        latitude: t,
                        longitude: o,
                        scale: 18
                    });
                }
            });
        },
        naviTest: function() {
            wx.navigateTo({
                url: "../covers/covers"
            });
        },
        gotoCheckout: function() {
            wx.navigateTo({
                url: "../checkout/checkout"
            });
        },
        redirectTest: function() {
            wx.redirectTo({
                url: "../covers/covers"
            });
        },
        gotoProd: function() {
            this.setupEnv(this.data.bootstrapURL.prod);
        },
        gotoIT: function() {
            this.setupEnv(this.data.bootstrapURL.it);
        },
        gotoUAT: function() {
            this.setupEnv(this.data.bootstrapURL.uat);
        },
        gotoCE03: function() {
            this.setupEnv(this.data.bootstrapURL.ce03);
        },
        gotoXE03: function() {
            this.setupEnv(this.data.bootstrapURL.xe03);
        },
        gotoCE04: function() {
            this.setupEnv(this.data.bootstrapURL.ce04);
        },
        gotoXE04: function() {
            this.setupEnv(this.data.bootstrapURL.xe04);
        },
        gotoCE05: function() {
            this.setupEnv(this.data.bootstrapURL.ce05);
        },
        gotoXE05: function() {
            this.setupEnv(this.data.bootstrapURL.xe05);
        },
        getCookie: function() {
            var t, o = wx.getStorageSync("cookieJar"), n = e(o);
            try {
                for (n.s(); !(t = n.n()).done; ) {
                    var a = t.value;
                    if (a.name.startsWith("as_diwa")) {
                        this.setData({
                            cookieString: a.name + "=" + a.value
                        });
                        break;
                    }
                }
            } catch (e) {
                n.e(e);
            } finally {
                n.f();
            }
        },
        getCode: function() {
            var e = this;
            wx.login({
                success: function(t) {
                    t.code && e.setData({
                        codeString: t.code
                    });
                }
            });
        },
        checkout: function() {
            var e = new Date().getTime().toString(), t = {
                appId: "wxb9811d3b2e3de44c",
                nonceStr: "noIZ2b1UZ2KhOBX4",
                package: "prepay_id=wx17160853314595ec44718634f760d30000",
                signType: "MD5",
                timeStamp: e
            }, o = Object.keys(t).sort().map(function(e) {
                return "".concat(e, "=").concat(t[e]);
            }).join("&") + "&key=" + mch_key;
            console.log(o), wx.requestPayment({
                timeStamp: e.toString(),
                nonceStr: "noIZ2b1UZ2KhOBX4",
                package: "prepay_id=wx17160853314595ec44718634f760d30000",
                signType: "MD5",
                paySign: "ABAC148CE0B6EF401694D2CA17010C1C31A8FDD3590B452D981D1C6D63D6E6DD",
                success: function(e) {
                    console.log("checkout success", e);
                },
                fail: function(e) {
                    console.log("checkout failed", e);
                }
            });
        },
        modalTest: function() {
            wx.showModal({
                title: "提示",
                content: "这是一个模态弹窗",
                success: function(e) {
                    e.confirm ? console.log("用户点击确定") : e.cancel && console.log("用户点击取消");
                }
            });
        },
        clearStorage: function() {
            wx.clearStorageSync();
        },
        getVersionInfo: function() {
            var e = wx.getAccountInfoSync().miniProgram, t = e.version, o = e.envVersion;
            this.setData({
                versionNo: "release" === o ? t : o
            });
        },
        setupEnv: function(e) {
            if (wx.showLoading({
                title: "加载中",
                mask: !0
            }), e !== this.data.shared.bootstrapURL) {
                wx.clearStorage(), this.data.revision ? (e = -1 !== e.indexOf("?") ? e + "&revision=" + this.data.revision : e + "?revision=" + this.data.revision, 
                console.log("new urls:", e)) : console.log("revision is empty"), wx.setStorageSync("bootstrapURL", e);
                var t = this;
                wx.request({
                    url: e,
                    method: "GET",
                    success: function(o) {
                        getApp().globalData.shared.bootstrap = o.data, getApp().globalData.shared.bootstrapURL = e, 
                        wx.login({
                            success: function(e) {
                                e.code && wx.request({
                                    url: (0, a.appendUrlParams)(t.data.shared.bootstrap.urls.diwaFetchURL, "code=" + encodeURIComponent(e.code)),
                                    method: "GET",
                                    header: {
                                        "content-type": "application/json"
                                    },
                                    success: function(e) {
                                        var t = (0, a.parseAllCookies)(e.header);
                                        wx.setStorageSync("cookieJar", t), getApp().globalData.shared.cookieJar = t, getApp().globalData.shared.isAppRead = !0, 
                                        wx.hideLoading(), wx.reLaunch({
                                            url: "../landing/landing"
                                        });
                                    },
                                    fail: function(e) {
                                        console.log(e);
                                    }
                                });
                            }
                        });
                    },
                    fail: function(e) {
                        console.log(e);
                    }
                });
            } else wx.reLaunch({
                url: "../landing/landing"
            }), wx.hideLoading();
        },
        launchAppError: function(e) {
            console.log(e.detail.errMsg);
        },
        openMapApp: function() {
            console.log("openMapApp"), wx.openLocation({
                latitude: 31.23943,
                longitude: 121.47954,
                name: "目的地",
                scale: 8,
                success: function(e) {
                    console.log(e);
                },
                fail: function(e) {
                    console.log(e);
                },
                complete: function() {
                    wx.hideLoading();
                }
            });
        },
        openThankyou: function() {
            this.setData({
                showThankYou: !0
            });
        },
        openSessionSub: function() {
            wx.navigateTo({
                url: "/pages/sessions/subscribe"
            });
        }
    },
    behaviors: [ i.sharedDataBehavior ]
});