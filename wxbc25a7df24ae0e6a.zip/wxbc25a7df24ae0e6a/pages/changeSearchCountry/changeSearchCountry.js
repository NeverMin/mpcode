var t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), e = require("../../utils/behavior"), a = require("../../utils/sharedData");

Component({
    data: {
        shared: a.initSharedData,
        countryNameMapping: {
            KR: "韩国",
            CH: "瑞士",
            ES: "西班牙",
            BE: "比利时",
            JP: "日本",
            CN: "中国大陆",
            GB: "英国",
            AE: "阿拉伯联合酋长国",
            HK: "香港",
            TH: "泰国",
            SE: "瑞典",
            IT: "意大利",
            SG: "新加坡",
            US: "美国",
            BR: "巴西",
            NL: "荷兰",
            TR: "土耳其",
            MO: "澳门",
            TW: "台湾",
            AT: "奥地利",
            AU: "澳大利亚",
            DE: "德国",
            FR: "法国",
            CA: "加拿大",
            MX: "墨西哥"
        },
        countries: "",
        changeCountryText: "",
        selectedCountry: {},
        showCheckMark: !1
    },
    methods: {
        onLoad: function(t) {
            var e = getApp().globalData.storesData, a = wx.getStorageSync("selectedCountry");
            if (e && e.countryStateMapping && e.countryStateMapping.length > 0) {
                var n = this.getCountryNameKey(e.countryStateMapping, "CN"), r = this.data.countryNameMapping.CN || n;
                Object.keys(a).length ? this.setData({
                    selectedCountry: a
                }) : this.setData({
                    selectedCountry: {
                        key: n,
                        value: r,
                        countryCode: "CN"
                    }
                });
            }
            this.fetchListOfCountries(e, this.data.countryNameMapping, this.data.selectedCountry);
        },
        getCountryNameKey: function(t, e) {
            var a = t.find(function(t) {
                return t.countryCode === e;
            });
            return a && a.countryName;
        },
        fetchListOfCountries: function(t, e, a) {
            var n = this, r = {};
            t && t.countryStateMapping && t.countryStateMapping.map(function(t) {
                if (t) {
                    var a = t.countryName, n = t.countryCode;
                    r[a] = e[n] || a;
                }
            }), Object.keys(r).map(function(t) {
                t && r[t] && n.setData({
                    countries: r
                });
            });
        },
        updateCountry: function(t) {
            var e = t.currentTarget.dataset.id, a = this.getKeyByValue(this.data.countries, e), n = this.getCountryCodeFromCountryName(a);
            this.setData({
                selectedCountry: {
                    key: a,
                    value: e,
                    countryCode: n
                }
            }), wx.setStorageSync("selectedCountry", this.data.selectedCountry), this.getChangeCountryText();
            var r = getCurrentPages();
            r[r.length - 2].setData({
                changeCountryText: this.data.changeCountryText
            }), wx.navigateBack({
                delta: 0
            });
        },
        getChangeCountryText: function() {
            var t, e = getApp().globalData.translations, a = (t = this.data.selectedCountry && (this.data.selectedCountry.value || this.data.selectedCountry.key)) && e.searchingCountry && e.searchingCountry.replace("{countryName}", t);
            wx.setStorageSync("changeCountryText", a), this.setData({
                changeCountryText: a
            }), console.log(a);
        },
        getKeyByValue: function(t, e) {
            return Object.keys(t).find(function(a) {
                return t[a] === e;
            });
        },
        getCountryCodeFromCountryName: function(e) {
            var a, n = getApp().globalData.storesData.countryStateMapping, r = t(n);
            try {
                for (r.s(); !(a = r.n()).done; ) {
                    var o = a.value;
                    if (o.countryName === e) return o.countryCode;
                }
            } catch (t) {
                r.e(t);
            } finally {
                r.f();
            }
        }
    },
    behaviors: [ e.sharedDataBehavior ]
});