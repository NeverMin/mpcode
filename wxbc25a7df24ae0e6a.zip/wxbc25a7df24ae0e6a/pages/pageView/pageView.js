require("../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../utils/behavior"), a = require("../../utils/sharedData");

Component({
    data: {
        shared: a.initSharedData
    },
    methods: {
        onLoad: function(e) {
            console.log(e.url), this.setData({
                url: decodeURIComponent(e.url)
            }), console.log("pageview", this.data.url);
        },
        handlePostMessage: function(e) {
            var a = e.detail.data;
            console.log("handlePostMessage", a), this.setData({
                postSharingData: a
            });
        },
        onShareAppMessage: function(e) {
            var a = this.data.postSharingData;
            if (a) {
                a = a[a.length - 1];
                var t = JSON.parse(a);
                return {
                    title: t.data.title,
                    path: "/pages/pageView/pageView?url=" + encodeURIComponent(e.webViewUrl),
                    imageUrl: t.data.imgUrl
                };
            }
            return {
                title: this.data.shared.textAssets.defaultSharingTitle,
                path: "/pages/pageView/pageView?url=" + encodeURIComponent(e.webViewUrl)
            };
        },
        loadSuccess: function(e) {
            var a = e.detail.src;
            if (a.indexOf("covers.html") >= 0) {
                var t = a.split("html")[1];
                wx.reLaunch({
                    url: "../covers/covers" + t,
                    fail: function(e) {
                        console.log(e);
                    }
                });
            }
        },
        loadError: function(e) {
            console.log("loadError", e);
        },
        onShow: function() {
            this.data.forceReload && wx.redirectTo({
                url: "../pageView/pageView?url=" + encodeURIComponent(this.data.url)
            });
        },
        onHide: function() {
            var e;
            null !== (e = this.data.url) && void 0 !== e && e.includes("accountview") && this.setData({
                forceReload: !0
            });
        }
    },
    behaviors: [ e.sharedDataBehavior ]
});