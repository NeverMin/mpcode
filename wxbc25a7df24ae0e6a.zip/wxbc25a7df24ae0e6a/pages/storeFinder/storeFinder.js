var e, t = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../@babel/runtime/helpers/defineProperty"), r = (e = require("haversine")) && e.__esModule ? e : {
    default: e
}, o = require("../../utils/behavior"), s = require("../../utils/sharedData"), n = require("../../analytics/tracking");

Component({
    data: {
        shared: s.initSharedData,
        markers: [],
        stores: [],
        searchText: "",
        isStoreSearchInputFocus: !1,
        userLatLong: {
            latitude: "",
            longitude: "",
            errMsg: ""
        },
        searchInLocation: !1,
        translations: {},
        allExtraStoreInfo: "",
        selectedCountry: {
            key: "China mainland",
            value: "中国大陆",
            countryCode: "CN"
        },
        storeHours: "",
        nearAprStoreList: [],
        changeCountryText: "正在搜索中国大陆。",
        tabActiveOne: !0,
        tabActiveTwo: !1,
        omniture: {
            trackLinks: {
                panelDrawerSelected: {
                    "apl.navigationalLinkClicks": "${apl.pageName} || Panel Drawer",
                    linkName: "${apl.pageName} || Panel Drawer"
                },
                chatNow: {
                    "apl.microevents1": "${apl.pageName} || Chat Now",
                    linkName: "${apl.pageName} || Chat Now"
                },
                browseAllReseller: {
                    "apl.microevents1": "${apl.pageName}  | browse all resellers",
                    linkName: "${apl.pageName} | browse all resellers"
                },
                selectStoreCold: {
                    "apl.microevents3": "${apl.pageName} | BUAC | Select Store",
                    "apl.buacColdStart": 1,
                    "apl.potentialBopisPurchase": 1
                },
                storeSearch: {
                    "apl.microevents1": "${apl.pageName} | ${searchText} | search results",
                    linkName: "${apl.pageName} | ${searchText} | search results"
                },
                storeSelected: {
                    "apl.navigationalLinkClicks": "${apl.pageName} | ${storeName} | selected",
                    linkName: "${apl.pageName} | ${storeName} | selected"
                },
                selectStoreWarm: {
                    "apl.microevents3": "${apl.pageName} | BUAC | Select Store",
                    "apl.buacWarmStart": 1,
                    "apl.potentialBopisPurchase": 1
                },
                storeList: {
                    "apl.microevents1": "${apl.pageName} || List view",
                    linkName: "${apl.pageName} || List view"
                },
                changeCountry: {
                    "apl.microevents1": "${apl.pageName} || Change country",
                    linkName: "${apl.pageName} || Change country"
                },
                browseAllStores: {
                    "apl.microevents1": "${apl.pageName} | browse all stores",
                    linkName: "${apl.pageName} | browse all stores"
                },
                map: {
                    "apl.microevents1": "${apl.pageName} || Map view",
                    linkName: "${apl.pageName} || Map view"
                }
            },
            trackPage: {
                server: "mmap.pd01a1.svc.cluster.local",
                "apl.customerSegment": "asa:cn wechat",
                storeId: "802467",
                "apl.currencyCode": "CNY",
                "apl.pageNameNode": "AOS : stores/storesearchpage",
                "apl.pageName": "AOS : stores/storesearchpage",
                "apl.siteSection": "AOS : stores/storesearchpage",
                "apl.langLocale": "zh-cn",
                "apl.storeName": "AOS : WeChat Platform Store",
                "apl.storeAndSegment": "AOS : WeChat Platform Store",
                trackingServer: "securemetrics.apple.com.cn",
                "apl.storefrontID": "802467",
                reportSuiteId: "applestorewwmobile"
            }
        }
    },
    methods: {
        bindKeyInput: function(e) {
            this.setData({
                searchText: e.detail.value
            });
        },
        onTabOneClick: function() {
            this.setData({
                tabActiveOne: !0,
                tabActiveTwo: !1
            });
        },
        onTabTwoClick: function() {
            this.setData({
                tabActiveOne: !1,
                tabActiveTwo: !0
            });
        },
        handleStoreSearchKeyUp: function(e) {
            var t = this, a = wx.getStorageSync("selectedCountry");
            if ("" !== this.data.searchText) {
                var r = {};
                r.r = this.data.searchText, Object.keys(a).length ? r.country = a.countryCode : r.country = this.data.selectedCountry.countryCode, 
                wx.navigateTo({
                    url: "../searchFilteredStores/searchFilteredStores"
                }), wx.setStorageSync("countryParams", r), setTimeout(function() {
                    t.removeStoreSearchInputFocus();
                }, 1e3);
            }
        },
        handleStoreSearchInputFocus: function(e) {
            this.setData({
                isStoreSearchInputFocus: !0
            });
        },
        removeStoreSearchInputFocus: function(e) {
            this.setData({
                isStoreSearchInputFocus: !1,
                searchText: ""
            });
        },
        onReady: function(e) {
            var t = this;
            void 0 !== this.data.shared.isAppReady ? this.data.shared.isAppReady && this.ReadyToGo() : getApp().watch(function(e) {
                e && t.ReadyToGo();
            });
        },
        ReadyToGo: function() {
            wx.setStorageSync("type", ""), this.getLocation(), this.fetchData();
        },
        markertap: function(e) {
            var t = "R" + String(e.detail.markerId).padStart(3, "0");
            wx.navigateTo({
                url: "../storeDetails/storeDetails?id=" + t
            });
        },
        getLocation: function() {
            var e = this;
            wx.getLocation({
                type: "wgs84",
                success: function(t) {
                    e.setData({
                        userLatLong: {
                            latitude: t.latitude,
                            longitude: t.longitude,
                            errMsg: t.errMsg
                        }
                    }), wx.setStorageSync("userLatLong", e.data.userLatLong);
                },
                fail: function(e) {
                    console.log(e);
                }
            });
        },
        fetchData: function() {
            var e = this;
            this.setData({
                loading: !0
            }), this.setData({
                userLatLong: wx.getStorageSync("userLatLong")
            });
            var t = {}, a = [];
            wx.request({
                url: this.data.shared.bootstrap.urls.storesearchpage + "?type=json",
                method: "GET",
                success: function(r) {
                    var o, s;
                    t.countryStateMapping = null == r || null === (o = r.data) || void 0 === o || null === (s = o.responseModel) || void 0 === s ? void 0 : s.countryStateMapping, 
                    t && Object.keys(t).length && !t.storeMapping && (t.storeMapping = e.getStoreMapping(t)), 
                    e.setData({
                        translations: r.data.translations,
                        loading: !1
                    }), e.data.userLatLong.latitude && e.data.userLatLong.longitude && (a = e.getFourtyMileNearStoreData(t.storeMapping, e.data.userLatLong)), 
                    a && 0 === a.length && e.data.userLatLong && e.data.userLatLong.latitude && e.data.userLatLong.longitude && e.fetchNearAprStoresList(), 
                    a.length > 0 && e.fetchExtraStoreInfo(e.data.shared.bootstrap.urls.extrastoreinfo, a);
                    var n = getApp();
                    n.globalData.storesData = t, n.globalData.translations = e.data.translations, wx.setStorageSync("storesData", t), 
                    wx.setStorageSync("translations", e.data.translations);
                },
                fail: function() {
                    console.log("FAILED");
                },
                complete: function() {
                    console.log("COMPLETED");
                }
            });
        },
        fetchNearAprStoresList: function() {
            var e = this;
            wx.request({
                url: this.data.shared.bootstrap.urls.aprstoredetailslist,
                method: "GET",
                data: {
                    userLat: this.data.userLatLong.latitude,
                    userLong: this.data.userLatLong.longitude,
                    numberOfStores: 10,
                    type: "json"
                },
                success: function(t) {
                    e.setData({
                        nearAprStoreList: t.data.responseModel.stores
                    });
                },
                fail: function() {
                    console.log("FAILED");
                },
                complete: function() {
                    console.log("COMPLETED");
                }
            });
        },
        fetchExtraStoreInfo: function(e, r) {
            var o = {}, s = this, n = [];
            r.forEach(function(r) {
                wx.request({
                    url: e,
                    data: {
                        type: "json",
                        storeid: r.storeNumber
                    },
                    method: "GET",
                    success: function(e) {
                        e.data && e.data.responseModel && e.data.responseModel.storeInfoList && e.data.responseModel.storeInfoList[0] && e.data.responseModel.storeInfoList[0].storeHours && (o = a({}, r.storeNumber, e.data.responseModel.storeInfoList[0].storeHours)), 
                        r = t(t({}, r), {}, {
                            storeHours: o[r.storeNumber],
                            iconPath: "../../images/tray/applelogo.pin.point.of.interest.fill.svg",
                            height: 34,
                            joinCluster: !0,
                            width: 18,
                            id: parseInt(r.storeNumber.substring(1), 10),
                            title: r.storeName,
                            customCallout: {
                                anchorX: 0,
                                anchorY: 0,
                                display: "BYCLICK"
                            },
                            content1: "".concat(r.storeName),
                            content2: "".concat(r.storeAddress.split("\n", 1)),
                            label: {
                                content: r.storeName,
                                textAlign: "center",
                                fontSize: 15,
                                padding: 3,
                                width: 120,
                                height: 30
                            }
                        }), n.push(r), s.setData({
                            stores: n
                        });
                    },
                    fail: function() {
                        console.log("FAILED");
                    },
                    complete: function() {
                        console.log("COMPLETED");
                    }
                });
            });
        },
        getStoreMapping: function(e) {
            var t = {};
            return e && e.countryStateMapping && e.countryStateMapping.length > 0 && e.countryStateMapping.forEach(function(e) {
                e.states.forEach(function(e) {
                    e.stores.forEach(function(e) {
                        e && e.storeNumber && (t[e.storeNumber] = e);
                    });
                });
            }), t;
        },
        getFourtyMileNearStoreData: function(e, a) {
            if (e && a && a.latitude && "" !== a.latitude) {
                var o = [];
                return Object.keys(e).map(function(s) {
                    var n = e[s];
                    if (n) {
                        var i = {
                            latitude: n.latitude,
                            longitude: n.longitude
                        }, l = (0, r.default)(a, i, {
                            unit: "km"
                        });
                        l <= 60 && o.push(t(t({}, n), {}, {
                            distance: parseFloat(l).toFixed(1),
                            distanceInMiles: l
                        }));
                    }
                }), (o = o.sort(function(e, t) {
                    return e.distanceInMiles - t.distanceInMiles;
                })).length > 15 && (o = o.slice(0, 15)), o;
            }
            return null;
        },
        onJump: function(e) {
            var t = e.currentTarget.dataset.id.storeNumber;
            wx.navigateTo({
                url: "../storeDetails/storeDetails?id=" + t,
                success: function(t) {
                    t.eventChannel.emit("getSpecificStoreNumber", {
                        storeNumber: e.currentTarget.dataset.id.storeNumber
                    });
                }
            });
        },
        onJumpToCountryChangePage: function() {
            var e = this;
            wx.navigateTo({
                url: "../changeSearchCountry/changeSearchCountry"
            }), setTimeout(function() {
                e.setData({
                    isStoreSearchInputFocus: !1
                });
            }, 1e3);
        },
        onJumpCountryPageFromAllApleStores: function(e) {
            (0, n.trackLinkOmniture)({
                type: "browseAllStores",
                omniture: this.data.omniture
            });
            wx.navigateTo({
                url: "../countryList/countryList?id=allStores"
            });
        },
        onJumpCountryPageFromAllAprApleStores: function(e) {
            wx.navigateTo({
                url: "../countryList/countryList?id=allAprStores"
            });
        },
        onJumpToAprStoreDetails: function(e) {
            wx.navigateTo({
                url: "../aprStoreDetails/aprStoreDetails",
                success: function(t) {
                    t.eventChannel.emit("getSelectedStoreData", {
                        data: e.currentTarget.dataset.id
                    });
                }
            });
        },
        onShow: function() {
            (0, n.trackLinkOmniture)({
                type: "PAGE_LOAD",
                omniture: this.data.omniture
            }), wx.setStorageSync("countryParams", {});
            var e = wx.getStorageSync("changeCountryText");
            "" !== e && this.setData({
                changeCountryText: e
            }), "function" == typeof this.getTabBar && this.getTabBar() && this.getTabBar().setData({
                selected: 2
            });
        }
    },
    behaviors: [ o.sharedDataBehavior ]
});