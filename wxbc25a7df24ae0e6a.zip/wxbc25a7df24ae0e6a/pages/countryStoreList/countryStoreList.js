var t = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../../utils/behavior"), a = require("../../utils/sharedData");

Component({
    data: {
        shared: a.initSharedData,
        stores: [],
        isCountryStoresFetching: !1
    },
    methods: {
        onLoad: function(t) {
            var e = wx.getStorageSync("pageTitle");
            wx.setNavigationBarTitle({
                title: e
            }), this.setData({
                id: t.id
            });
        },
        onReady: function() {
            this.fetchAprCountryStoreList(this.data.id);
        },
        fetchAprCountryStoreList: function(e) {
            var a = this;
            this.setData({
                isCountryStoresFetching: !0
            });
            wx.request({
                url: this.data.shared.bootstrap.urls.resellerStoresInCountry,
                data: {
                    type: "json",
                    locationShiftEnabled: 0,
                    country: e
                },
                method: "GET",
                success: function(e) {
                    var r, i, o, n = null == e || null === (r = e.data) || void 0 === r || null === (i = r.responseModel) || void 0 === i || null === (o = i.dataItem) || void 0 === o ? void 0 : o.stores, s = (null == n ? void 0 : n.length) > 0 && n.map(function(e) {
                        var a = e.distance;
                        return a && a.indexOf("mi") > -1 ? (a = a.replace("mi", ""), a = (1.6 * parseFloat(a)).toFixed(1)) : a && a.indexOf("km") > -1 && (a = a.replace("km", "")), 
                        e = t(t({}, e), {}, {
                            distance: a.toString() + "km"
                        });
                    });
                    a.setData({
                        stores: s,
                        isCountryStoresFetching: !1
                    });
                },
                fail: function(t) {
                    console.log("FAILED", t);
                },
                complete: function() {
                    a.setData({
                        isCountryStoresFetching: !1
                    }), console.log("COMPLETED");
                }
            });
        },
        onJumpToAprStoreDetails: function(t) {
            var e = t.currentTarget.dataset.id, a = {
                storeID: t.currentTarget.dataset.id.storeID,
                latitude: t.currentTarget.dataset.id.latitude,
                longitude: t.currentTarget.dataset.id.longitude
            }, r = JSON.stringify(a);
            console.log(e), wx.navigateTo({
                url: "../aprStoreDetails/aprStoreDetails?id=" + r
            });
        }
    },
    behaviors: [ e.sharedDataBehavior ]
});