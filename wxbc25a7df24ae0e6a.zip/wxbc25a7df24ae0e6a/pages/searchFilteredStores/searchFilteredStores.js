var t, e = require("../../@babel/runtime/helpers/defineProperty"), o = require("../../@babel/runtime/helpers/objectSpread2"), s = (t = require("haversine")) && t.__esModule ? t : {
    default: t
}, a = require("../../utils/behavior"), r = require("../../utils/sharedData");

Component({
    data: {
        shared: r.initSharedData,
        storesData: [],
        stores: [],
        isStoreSearchFetching: !1,
        searchInLocation: !0,
        translations: {}
    },
    methods: {
        onReady: function() {
            this.fetchStores(), wx.setStorageSync("type", "");
        },
        fetchStores: function() {
            var t = this, e = {};
            console.log(this.data.shared.bootstrap.urls.storesearchpage), wx.request({
                url: this.data.shared.bootstrap.urls.storesearchpage + "?type=json",
                method: "GET",
                success: function(o) {
                    console.log(o), e.countryStateMapping = o.data.responseModel.countryStateMapping, 
                    e && Object.keys(e).length && !e.storeMapping && (e.storeMapping = t.getStoreMapping(e)), 
                    t.setData({
                        storesData: e
                    }), console.log("this is storedata", t.data.storesData), t.fetchStoreSearchData();
                },
                fail: function() {
                    console.log("FAILED");
                },
                complete: function() {
                    console.log("COMPLETED");
                }
            });
        },
        fetchStoreSearchData: function() {
            var t = this;
            this.setData({
                isStoreSearchFetching: !0
            });
            var e = [], s = wx.getStorageSync("countryParams");
            console.log(this.data.shared), wx.request({
                url: this.data.shared.bootstrap.urls.storesfederatedsearch,
                data: o(o({}, s), {}, {
                    type: "json"
                }),
                method: "GET",
                success: function(o) {
                    var s = o.data.storeNumbers;
                    if (s && s.length > 0) {
                        var a = [];
                        s.map(function(e) {
                            var o = t.data.storesData && t.data.storesData.storeMapping;
                            e && o && o[e] && a.push(o[e]);
                        }), console.log("if", a), e.stores = a;
                    } else e.stores = [];
                    t.setData({
                        stores: e.stores,
                        isStoreSearchFetching: !1,
                        translations: o.data.translations
                    }), console.log("result store are", t.data.stores), t.getStoresWithDistance(t.data.stores.length > 0 ? t.data.stores : []);
                },
                fail: function(t) {
                    console.log("FAILED", t);
                },
                complete: function() {
                    console.log("COMPLETED");
                }
            });
        },
        getStoresWithDistance: function(t) {
            var e = wx.getStorageSync("userLatLong"), a = [];
            t.map(function(t) {
                var r = t.distance;
                if (!r && e && e.latitude && "" !== e.latitude) {
                    var n = {
                        latitude: t.latitude,
                        longitude: t.longitude
                    }, i = (0, s.default)(e, n, {
                        unit: "km"
                    });
                    r = i = i && parseFloat(i).toFixed(1), a.push(o(o({}, t), {}, {
                        distance: r
                    }));
                }
            }), a.length > 0 && this.fetchExtraStoreInfo(this.data.shared.bootstrap.urls.extrastoreinfo, a);
        },
        getStoreMapping: function(t) {
            var e = {};
            return t && t.countryStateMapping && t.countryStateMapping.length > 0 && t.countryStateMapping.forEach(function(t) {
                t.states.forEach(function(t) {
                    t.stores.forEach(function(t) {
                        t && t.storeNumber && (e[t.storeNumber] = t);
                    });
                });
            }), e;
        },
        fetchExtraStoreInfo: function(t, s) {
            var a = {}, r = this, n = [];
            s.forEach(function(s) {
                wx.request({
                    url: t,
                    data: {
                        type: "json",
                        storeid: s.storeNumber
                    },
                    method: "GET",
                    success: function(t) {
                        t.data && t.data.responseModel && t.data.responseModel.storeInfoList && t.data.responseModel.storeInfoList[0] && t.data.responseModel.storeInfoList[0].storeHours && (a = e({}, s.storeNumber, t.data.responseModel.storeInfoList[0].storeHours)), 
                        s = o(o({}, s), {}, {
                            storeHours: a[s.storeNumber]
                        }), n.push(s), r.setData({
                            stores: n
                        });
                    },
                    fail: function(t) {
                        console.log("FAILED", t);
                    },
                    complete: function() {
                        console.log("COMPLETED");
                    }
                });
            });
        },
        onJump: function(t) {
            var e = t.currentTarget.dataset.id.storeNumber;
            wx.navigateTo({
                url: "../storeDetails/storeDetails?id=" + e,
                success: function(e) {
                    e.eventChannel.emit("getSpecificStoreNumber", {
                        storeNumber: t.currentTarget.dataset.id.storeNumber
                    });
                }
            });
        },
        onJumpCountryPageFromAllAppleStores: function(t) {
            wx.navigateTo({
                url: "../countryList/countryList",
                success: function(t) {
                    t.eventChannel.emit("getDataFromAppleStores", {
                        type: "allStores"
                    });
                }
            });
        }
    },
    behaviors: [ a.sharedDataBehavior ]
});