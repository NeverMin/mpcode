var e, t = require("../../@babel/runtime/helpers/defineProperty"), a = require("../../@babel/runtime/helpers/objectSpread2"), s = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var a = u(t);
    if (a && a.has(e)) return a.get(e);
    var s = {}, r = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var n in e) if ("default" !== n && Object.prototype.hasOwnProperty.call(e, n)) {
        var o = r ? Object.getOwnPropertyDescriptor(e, n) : null;
        o && (o.get || o.set) ? Object.defineProperty(s, n, o) : s[n] = e[n];
    }
    s.default = e, a && a.set(e, s);
    return s;
}(require("../../utils/tabbarUtil")), r = (e = require("haversine")) && e.__esModule ? e : {
    default: e
}, n = require("../../utils/behavior"), o = require("../../utils/sharedData"), i = require("../../analytics/tracking"), c = require("../../utils/trankLinksData");

function u(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), a = new WeakMap();
    return (u = function(e) {
        return e ? a : t;
    })(e);
}

Component({
    requestTask: null,
    data: {
        shared: o.initSharedData,
        searchOmnitureData: c.searchData,
        tabIndex: 2,
        suggestions: [],
        countries: [ {
            id: "AirTag"
        }, {
            id: "AirPods"
        }, {
            id: "AppleCare"
        }, {
            id: "Beats"
        }, {
            id: "翻新产品"
        }, {
            id: "iPhone机型比较"
        } ],
        searchInput: "",
        searchResult: [],
        searchResultLength: "",
        showNearby: !1,
        showSearchText: !0,
        didUserInput: !1,
        isFetchingSearch: !1,
        recommendFlashCheck: !0,
        isInputFocused: !1,
        stores: [],
        userLatLong: {}
    },
    methods: t({
        onShow: function() {
            this.getSearchTab(), s.switchTab(this, this.data.tabIndex);
        },
        onReady: function() {
            this.getLocation();
        },
        jumptoStoreFinder: function() {
            var e, t;
            null !== (e = this.data) && void 0 !== e && null !== (t = e.searchData) && void 0 !== t && t.omniture && (0, 
            i.trackLinkOmniture)({
                type: "nearYouSelected",
                omniture: this.data.searchData.omniture,
                data: null
            }), wx.navigateTo({
                url: "../storeFinder/storeFinder"
            });
        },
        getSearchTab: function() {
            var e = this;
            wx.request({
                url: this.data.shared.bootstrap.urls.searchLandingUrl,
                data: {
                    type: "json"
                },
                method: "GET",
                success: function(t) {
                    var a, s;
                    e.setData({
                        suggestions: null === (a = t.data) || void 0 === a ? void 0 : a.suggestions,
                        searchData: t.data
                    }), null !== (s = t.data) && void 0 !== s && s.omniture && (0, i.trackLinkOmniture)({
                        type: "PAGE_LOAD",
                        omniture: t.data.omniture,
                        data: null
                    });
                }
            });
        },
        onLoad: function() {
            var e = this;
            wx.getSystemInfo({
                success: function(t) {
                    e.setData({
                        theme: t.theme
                    });
                }
            }), wx.onThemeChange(function(t) {
                e.setData({
                    theme: t.theme
                });
            });
        },
        showclear: function(e) {
            wx.showModal({
                title: "Are you sure you want to clear all recently viewed items?",
                success: function(e) {
                    e.confirm ? console.log("用户点击确定") : e.cancel && (console.log("用户点击取消"), decodeURIComponent);
                }
            });
        },
        handleFocus: function(e) {
            var t, a;
            this.setData({
                showNearby: !0,
                isInputFocused: !0,
                showSearchText: !1
            });
            var s = null === (t = this.data) || void 0 === t || null === (a = t.searchData) || void 0 === a ? void 0 : a.omniture;
            s && (0, i.trackLinkOmniture)({
                type: "searchBarClicked",
                omniture: s,
                data: null
            });
        },
        handleBlur: function(e) {
            this.setData({
                showNearby: !1,
                showSearchText: !0
            });
        },
        handleSearchInput: function(e) {
            this.setData({
                searchInput: e.detail.value,
                showNearby: !0,
                showSearchText: !0,
                selection: null
            });
        },
        onDelete: function(e) {
            this.setData({
                searchInput: ""
            });
        },
        onJumpCountryPageFromAllAppleStores: function() {
            wx.navigateTo({
                url: "../storeFinder/storeFinder"
            });
        },
        fetchSearchData: function(e, t) {
            var a = this;
            wx.showLoading({
                title: this.data.shared.textAssets.loading,
                mask: !1
            }), this.setData({
                isFetchingSearch: !0,
                showNearby: !1
            }), this.requestTask = wx.request({
                url: e,
                data: {
                    type: "json"
                },
                method: "GET",
                success: function(e) {
                    var s, r, n = [], o = e.data, c = o.searchResponse.activeSearchElementType;
                    (a.setData({
                        productstype: c
                    }), "PRODUCT" === c && (0 !== Object.keys(o.searchResponse.searchResults.KEYWORD_MATCHES).length ? (n = o.searchResponse.searchResults.KEYWORD_MATCHES.concat(o.searchResponse.searchResults.PRODUCT), 
                    a.setData({
                        productstype: "PRODUCT_KEY"
                    })) : n = o.searchResponse.searchResults.PRODUCT), "RETAILSTORE" === c) && (n = o.searchResponse.searchResults.RETAILSTORE, 
                    null !== (s = a.data) && void 0 !== s && null !== (r = s.searchData) && void 0 !== r && r.omniture && (0, 
                    i.trackLinkOmniture)({
                        type: "storeSearchResult",
                        omniture: a.data.searchData.omniture,
                        data: {
                            searchTerm: t
                        }
                    }));
                    wx.hideLoading(), 0 === n.length ? a.setData({
                        searchResult: [],
                        searchResultLength: n.length,
                        isFetchingSearch: !1,
                        recommendFlashCheck: !1
                    }) : ("RETAILSTORE" === c && a.fetchStoreSearchData(), a.setData({
                        searchResult: n,
                        page: o.searchResponse.currentPage,
                        totalcount: o.searchResponse.totalCount,
                        searchResultLength: n.length,
                        isFetchingSearch: !1,
                        recommendFlashCheck: !1
                    })), a.setData({
                        didUserInput: !0
                    });
                },
                fail: function() {
                    console.log("FAILED");
                }
            });
        },
        fetchStoreSearchData: function() {
            var e = this, t = {};
            wx.request({
                url: this.data.shared.bootstrap.urls.storesearchpage + "?type=json",
                method: "GET",
                success: function(a) {
                    t.countryStateMapping = a.data.responseModel.countryStateMapping, t && Object.keys(t).length && !t.storeMapping && (t.storeMapping = e.getStoreMapping(t)), 
                    e.setData({
                        storesData: t
                    }), e.fetchResult();
                },
                fail: function() {
                    console.log("FAILED");
                },
                complete: function() {
                    console.log("COMPLETED");
                }
            });
        },
        fetchResult: function() {
            var e = this, t = {}, s = {};
            s.r = this.data.searchInput, wx.request({
                url: this.data.shared.bootstrap.urls.storesfederatedsearch,
                data: a(a({}, s), {}, {
                    type: "json"
                }),
                method: "GET",
                success: function(a) {
                    var s = a.data.storeNumbers;
                    if (s && s.length > 0) {
                        var r = [];
                        s.map(function(t) {
                            var a = e.data.storesData && e.data.storesData.storeMapping;
                            t && a && a[t] && r.push(a[t]);
                        }), t.stores = r;
                    } else t.stores = [];
                    e.setData({
                        stores: t.stores,
                        isStoreSearchFetching: !1,
                        translations: a.data.translations
                    }), e.getStoresWithDistance(e.data.stores.length > 0 ? e.data.stores : []);
                },
                fail: function() {
                    console.log("FAILED");
                },
                complete: function() {
                    console.log("COMPLETED");
                }
            });
        },
        onJump: function(e) {
            var t, a, s, r, n, o, c = e.currentTarget.dataset.id.storeNumber;
            null !== (t = this.data) && void 0 !== t && null !== (a = t.searchData) && void 0 !== a && a.omniture && (0, 
            i.trackLinkOmniture)({
                type: "storeTopResultClicks",
                omniture: this.data.searchData.omniture,
                data: {
                    storeNumber: c,
                    searchTerm: this.data.searchInput
                },
                isTrackAsPages: !0
            });
            var u = null === (s = this.data) || void 0 === s || null === (r = s.shared) || void 0 === r || null === (n = r.bootstrap) || void 0 === n || null === (o = n.urls) || void 0 === o ? void 0 : o.storesearchpage, h = u && u + "/storedetails?storeid=" + c;
            h && wx.navigateTo({
                url: "../pageView/pageView?url=" + encodeURIComponent(h)
            });
        },
        fetchExtraStoreInfo: function(e, s) {
            var r = {}, n = this, o = [];
            s.forEach(function(s) {
                wx.request({
                    url: e,
                    data: {
                        type: "json",
                        storeid: s.storeNumber
                    },
                    method: "GET",
                    success: function(e) {
                        e.data && e.data.responseModel && e.data.responseModel.storeInfoList && e.data.responseModel.storeInfoList[0] && e.data.responseModel.storeInfoList[0].storeHours && (r = t({}, s.storeNumber, e.data.responseModel.storeInfoList[0].storeHours)), 
                        r && (s = a(a({}, s), {}, {
                            storeHours: r[s.storeNumber]
                        }), o.push(s)), n.setData({
                            stores: o
                        });
                    },
                    fail: function(e) {
                        console.log("FAILED", e);
                    },
                    complete: function() {
                        console.log("COMPLETED");
                    }
                });
            });
        },
        getStoresWithDistance: function(e) {
            var t = wx.getStorageSync("userLatLong"), s = [];
            e.map(function(e) {
                var n = e.distance;
                if (!n && t && t.latitude && "" !== t.latitude) {
                    var o = {
                        latitude: e.latitude,
                        longitude: e.longitude
                    }, i = (0, r.default)(t, o, {
                        unit: "km"
                    });
                    n = i = i && parseFloat(i).toFixed(1), s.push(a(a({}, e), {}, {
                        distance: n
                    }));
                }
            }), (null == s ? void 0 : s.length) > 0 && this.fetchExtraStoreInfo(this.data.shared.bootstrap.urls.extrastoreinfo, s);
        },
        loadMoreresult: function(e) {
            var t = this.data.shared.bootstrap.urls.splitSearchUrl + "?currentPage=" + this.data.page + "&itemsPerPage=20";
            t += "&r=".concat(this.data.selection), console.log(t), this.fetchSearchMoreData(t);
        },
        fetchSearchMoreData: function(e) {
            var t = this;
            wx.showLoading({
                title: this.data.shared.textAssets.loading,
                mask: !0
            }), this.setData({
                showNearby: !1
            }), wx.request({
                url: e,
                data: {
                    type: "json"
                },
                method: "GET",
                success: function(e) {
                    wx.hideLoading();
                    var a = [], s = e.data, r = s.searchResponse.activeSearchElementType;
                    if (t.setData({
                        productstype: r
                    }), "PRODUCT" === r && (0 !== Object.keys(s.searchResponse.searchResults.KEYWORD_MATCHES).length ? (a = s.searchResponse.searchResults.KEYWORD_MATCHES.concat(s.searchResponse.searchResults.PRODUCT), 
                    t.setData({
                        productstype: "PRODUCT_KEY"
                    })) : a = s.searchResponse.searchResults.PRODUCT), "RETAILSTORE" === r && (a = s.searchResponse.searchResults.RETAILSTORE), 
                    0 === a.length) t.setData({
                        searchResult: [],
                        searchResultLength: a.length,
                        isFetchingSearch: !1,
                        recommendFlashCheck: !1
                    }); else {
                        "RETAILSTORE" === r && t.fetchStoreSearchData();
                        var n = t.data.searchResult;
                        a.forEach(function(e) {
                            return n.push(e);
                        }), t.setData({
                            searchResult: n,
                            page: s.searchResponse.currentPage,
                            totalcount: s.searchResponse.totalCount,
                            searchResultLength: a.length,
                            isFetchingSearch: !1,
                            recommendFlashCheck: !1
                        });
                    }
                    t.setData({
                        didUserInput: !0
                    });
                },
                fail: function() {
                    console.log("FAILED");
                }
            });
        },
        onReachBottom: function() {
            console.log(this.data);
            var e = this.data.page + 1;
            20 * e < this.data.totalcount && (console.log(e), console.log(this.data.page), this.setData({
                page: this.data.page + 1
            }), this.loadMoreresult(this.data.page));
        },
        handleSearchKeyUp: function(e) {
            e.currentTarget.dataset.selection && this.setData({
                searchInput: e.currentTarget.dataset.selection
            });
            var t = this.data.shared.bootstrap.urls.splitSearchUrl + "?currentPage=0&itemsPerPage=20";
            e.currentTarget.dataset.selection ? (this.setData({
                selection: e.currentTarget.dataset.selection
            }), t += "&r=".concat(e.currentTarget.dataset.selection), this.fetchSearchData(t, e.currentTarget.dataset.selection)) : "" !== this.data.searchInput && (t += "&r=".concat(this.data.searchInput), 
            this.setData({
                selection: this.data.searchInput
            }), this.fetchSearchData(t, this.data.searchInput));
        },
        getLocation: function() {
            var e = this;
            wx.getLocation({
                type: "wgs84",
                success: function(t) {
                    e.setData({
                        userLatLong: {
                            latitude: t.latitude,
                            longitude: t.longitude,
                            errMsg: t.errMsg
                        }
                    }), wx.setStorageSync("userLatLong", e.data.userLatLong);
                },
                fail: function(e) {
                    console.log(e);
                }
            });
        },
        handleResultSearchClick: function(e) {
            var t, s;
            if (null !== (t = e.currentTarget.dataset) && void 0 !== t && null !== (s = t.productlink) && void 0 !== s && s.url) var r = e.currentTarget.dataset.productlink.url; else r = e.currentTarget.dataset.productlink;
            var n = encodeURIComponent(r);
            if (r) {
                var o, c, u;
                if (null !== (o = this.data) && void 0 !== o && o.searchOmnitureData) (0, i.trackLinkOmniture)({
                    type: "searchResultClicked",
                    omniture: a(a({}, null === (c = this.data) || void 0 === c ? void 0 : c.searchData.omniture), {}, {
                        trackLinks: this.data.searchOmnitureData
                    }),
                    data: {
                        searchResult: null === (u = e.currentTarget.dataset) || void 0 === u ? void 0 : u.productdisplayname
                    }
                });
                wx.setStorageSync("searchResultURL", n), wx.navigateTo({
                    url: "../pageView/pageView?url=" + n
                });
            }
        },
        getStoreMapping: function(e) {
            var t = {};
            return e && e.countryStateMapping && e.countryStateMapping.length > 0 && e.countryStateMapping.forEach(function(e) {
                e.states.forEach(function(e) {
                    e.stores.forEach(function(e) {
                        e && e.storeNumber && (t[e.storeNumber] = e);
                    });
                });
            }), t;
        },
        clearInput: function() {
            this.requestTask.abort(), wx.hideLoading(), this.setData({
                searchInput: "",
                didUserInput: !1,
                recommendFlashCheck: !0,
                isInputFocused: !1,
                isFetchingSearch: !1,
                searchResultLength: ""
            });
        }
    }, "onLoad", function() {
        var e = this;
        wx.getSystemInfo({
            success: function(t) {
                e.setData({
                    theme: t.theme
                });
            }
        }), wx.onThemeChange(function(t) {
            e.setData({
                theme: t.theme
            });
        });
    }),
    behaviors: [ n.sharedDataBehavior ]
});