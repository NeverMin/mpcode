var a = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), e = function(a, e) {
    if (!e && a && a.__esModule) return a;
    if (null === a || "object" != typeof a && "function" != typeof a) return {
        default: a
    };
    var t = o(e);
    if (t && t.has(a)) return t.get(a);
    var r = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var s in a) if ("default" !== s && Object.prototype.hasOwnProperty.call(a, s)) {
        var n = i ? Object.getOwnPropertyDescriptor(a, s) : null;
        n && (n.get || n.set) ? Object.defineProperty(r, s, n) : r[s] = a[s];
    }
    r.default = a, t && t.set(a, r);
    return r;
}(require("../../utils/tabbarUtil")), t = require("../../utils/behavior"), r = require("../../utils/sharedData"), i = require("../../utils/util.js");

function o(a) {
    if ("function" != typeof WeakMap) return null;
    var e = new WeakMap(), t = new WeakMap();
    return (o = function(a) {
        return a ? t : e;
    })(a);
}

Component({
    data: {
        url: "",
        urlParams: "",
        shared: r.initSharedData,
        tabIndex: 0
    },
    methods: {
        onLoad: function(a) {
            if ("true" === a.unbind) {
                var e = getApp().globalData.shared.cookieJar.filter(function(a) {
                    return a.name !== getApp().globalData.shared.bootstrap.disaCookieName;
                });
                getApp().globalData.shared.cookieJar = e, wx.setStorageSync("cookieJar", e);
            }
            this.setData({
                urlParams: a
            }), wx.showLoading({
                title: "加载中",
                mask: !1
            });
        },
        onReady: function() {
            var a = this;
            void 0 !== this.data.shared.isAppReady ? this.data.shared.isAppReady && this.setUrlwithHash() : getApp().watch(function(e) {
                e && a.setUrlwithHash();
            });
        },
        onShow: function() {
            e.switchTab(this, this.data.tabIndex);
        },
        handlePostMessage: function(a) {
            var e = a.detail.data;
            console.log("handlePostMessage", e), this.setData({
                postSharingData: e
            });
        },
        onShareAppMessage: function() {
            return {
                title: this.data.shared.textAssets.landingSharingTitle,
                imageUrl: this.data.shared.images.landingSharingUrl
            };
        },
        setUrlwithHash: function() {
            var e = this.data.shared.bootstrap.urls.shopLandingUrl, t = {}, r = this.data.shared.location;
            void 0 !== r && (t.loc = r.latitude + "," + r.longitude);
            var o, s = a(this.data.shared.cookieJar);
            try {
                for (s.s(); !(o = s.n()).done; ) {
                    var n = o.value;
                    (n.name === this.data.shared.bootstrap.diwaCookieName || n.name.startsWith("as_pvi")) && (t[n.name] = n.value);
                }
            } catch (a) {
                s.e(a);
            } finally {
                s.f();
            }
            var l = encodeURIComponent((0, i.generateURLHashParameter)(t)), d = (0, i.generateURLHashParameter)(this.data.urlParams);
            this.setData({
                url: e + (d ? "?" + d : "") + (l ? "#" + l : "")
            });
        },
        loadSuccess: function(a) {
            console.log("loadSuccess", a), wx.hideLoading();
        },
        loadError: function(a) {
            console.log("loadError", a), wx.hideLoading();
        }
    },
    behaviors: [ t.sharedDataBehavior ]
});