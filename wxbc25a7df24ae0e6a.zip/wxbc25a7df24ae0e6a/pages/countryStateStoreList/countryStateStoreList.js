var t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), e = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../utils/behavior"), s = require("../../utils/sharedData");

Component({
    data: {
        shared: s.initSharedData,
        stateStoresList: [],
        noStoresMessage: "",
        storesOfStates: [],
        storeListLoaded: 8,
        localStateList: []
    },
    methods: {
        onLoad: function(t) {
            var e = wx.getStorageSync("pageTitle");
            wx.setNavigationBarTitle({
                title: e
            });
            var a = this.getListOfStatesWithStores(t.id);
            if (this.setData({
                localStateList: a
            }), null === a) this.setData({
                noStoresMessage: "No Stores Found"
            }); else if (a.length > 0) {
                var s = this.getDisplayList(a, this.data.storeListLoaded);
                this.setData({
                    stateStoresList: s
                });
            }
        },
        getDisplayList: function(t, a) {
            var s = 0, r = [];
            return t.map(function(t) {
                if (s + t.stores.length <= a) r.push(e({}, t)), s += t.stores.length; else {
                    var o = a - s;
                    o && (r.push(e(e({}, t), {}, {
                        stores: t.stores.slice(0, o)
                    })), s += o);
                }
            }), r;
        },
        getListOfStatesWithStores: function(e) {
            var a = getApp().globalData.storesData;
            if (console.log("storesdata", a), a && a.countryStateMapping) {
                var s, r = t(a.countryStateMapping);
                try {
                    for (r.s(); !(s = r.n()).done; ) {
                        var o = s.value;
                        if (o.countryCode === e) {
                            var i = o.states;
                            console.log(o);
                            var n, l = [], u = i.sort(function(t, e) {
                                var a = t.stateName.toLowerCase(), s = e.stateName.toLowerCase();
                                return a < s ? -1 : a > s ? 1 : 0;
                            }), c = t(u);
                            try {
                                for (c.s(); !(n = c.n()).done; ) {
                                    var d = n.value, h = d.stores.sort(function(t, e) {
                                        var a = t.storeName.toLowerCase(), s = e.storeName.toLowerCase();
                                        return a < s ? -1 : a > s ? 1 : 0;
                                    }), L = {
                                        stateName: d.stateName,
                                        stores: h
                                    };
                                    l.push(L);
                                }
                            } catch (t) {
                                c.e(t);
                            } finally {
                                c.f();
                            }
                            return l;
                        }
                    }
                } catch (t) {
                    r.e(t);
                } finally {
                    r.f();
                }
            }
            return null;
        },
        onJumpToStoreDetails: function(t) {
            var e = t.currentTarget.dataset.id.storeNumber;
            wx.navigateTo({
                url: "../storeDetails/storeDetails?id=" + e,
                success: function(e) {
                    e.eventChannel.emit("getSpecificStoreNumber", {
                        storeNumber: t.currentTarget.dataset.id.storeNumber
                    });
                }
            });
        },
        onReachBottom: function() {
            var t = this.getDisplayList(this.data.localStateList, 2 * this.data.storeListLoaded);
            this.setData({
                stateStoresList: t,
                storeListLoaded: this.data.storeListLoaded + 8
            });
        }
    },
    behaviors: [ a.sharedDataBehavior ]
});