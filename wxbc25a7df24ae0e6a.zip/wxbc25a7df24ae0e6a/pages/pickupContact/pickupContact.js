var t = require("./contactData");

Component({
    data: {
        pickupContact: {},
        terms: {},
        addressFields: []
    },
    methods: {
        onLoad: function(a) {
            this.setData({
                terms: t.contactData.pickupContact.pickupContactTerms,
                addressFields: t.contactData.pickupContact.mobileAddress.addressFields
            }), console.log("caleed line 71", this.data.addressFields);
        }
    }
});