var t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), e = require("../../utils/behavior"), s = require("../../utils/sharedData");

Component({
    data: {
        shared: s.initSharedData,
        storeNumber: "",
        storeDetails: "",
        healthAndSafetySection: "",
        signLanguageSection: {},
        storeHours: "",
        physicalAddress: "",
        storeDataTranslation: "",
        commonData: "",
        supportedPickupTypes: "",
        fallBackData: "",
        upcomingSessionListData: "",
        upcomingTranslation: "",
        showAllSpecialHours: "",
        pickupMethodCompareLink: "",
        compareView: !1,
        seeMoreDesc: !1,
        fetchStoreData: !1,
        storeHeaderSubtitle: "",
        storeName: ""
    },
    methods: {
        onLoad: function(t) {
            this.setData({
                id: t.id
            });
        },
        onReady: function() {
            this.fetchStoreDetails(this.data.id), this.fetchCommonData(), this.fetchSpotlightTAA(this.data.id), 
            this.fetchSessionList(this.data.id), this.fetchFallBack();
        },
        fetchStoreDetails: function(t) {
            var e = this;
            this.setData({
                fetchStoreData: !0
            }), wx.request({
                url: this.data.shared.bootstrap.urls.storedetails,
                data: {
                    type: "json",
                    storeid: t
                },
                method: "GET",
                success: function(t) {
                    var s, a, o, i = t.data.responseModel.extraStoreInfo, n = t.data.responseModel.supportedPickupTypes, r = null == n ? void 0 : n.map(function(t) {
                        return t.toLowerCase();
                    }), l = t.data.responseModel.healthAndSafetySection, c = t.data.responseModel.signLanguageSection, u = e.checkStoreDates(null == t || null === (s = t.data) || void 0 === s || null === (a = s.responseModel) || void 0 === a ? void 0 : a.storeHours), d = null == u ? void 0 : u.storeHoursSummary, p = t.data.responseModel.translations, h = null == u || null === (o = u.storeHourDays) || void 0 === o ? void 0 : o.find(function(t) {
                        return t.special;
                    });
                    e.setData({
                        fetchStoreData: !1,
                        storeDetails: i,
                        healthAndSafetySection: l,
                        signLanguageSection: c,
                        storeHours: null == u ? void 0 : u.storeHourDays,
                        physicalAddress: 1111111,
                        storeDataTranslation: p,
                        showAllSpecialHours: h,
                        storeHeaderSubtitle: d,
                        supportedPickupTypes: r
                    });
                },
                fail: function() {
                    console.log("FAILED");
                },
                complete: function() {
                    var t, s = e.prependAppleToStoreName(null === (t = e.data.storeDetails) || void 0 === t ? void 0 : t.storeName);
                    e.setData({
                        isCountryListFetching: !1,
                        storeName: s
                    }), console.log("COMPLETED", e.data.storeDetails);
                }
            });
        },
        fetchCommonData: function() {
            var t = this;
            this.setData({
                fetchStoreData: !0
            }), wx.request({
                url: this.data.shared.bootstrap.urls.baselineDataURL,
                method: "GET",
                data: {
                    type: "json"
                },
                success: function(e) {
                    var s = e.data.translations;
                    t.setData({
                        fetchStoreData: !1,
                        commonData: s,
                        pickupMethodCompareLink: t.data.shared.aosShippingPickup
                    });
                },
                fail: function() {
                    console.log("FAILED");
                },
                complete: function() {
                    t.setData({
                        isCountryListFetching: !1
                    }), console.log("COMPLETED");
                }
            });
        },
        prependAppleToStoreName: function(t) {
            return t ? (-1 === t.toLowerCase().indexOf("apple") && (t = "Apple " + t), t) : "";
        },
        checkStoreDates: function(t) {
            var e = new Date().getTime(), s = "", a = t.filter(function(t) {
                if (t.isoDate) {
                    var s = new Date(t.isoDate).setDate(new Date(t.isoDate).getDate() + 1);
                    return e < s;
                }
                return !0;
            }).slice(0, 7);
            return a[0] && (s = a[0].storeHoursSummary), {
                storeHourDays: a,
                storeHoursSummary: s
            };
        },
        fetchFallBack: function() {
            var t = this;
            wx.request({
                url: this.data.shared.bootstrap.urls.sessionsHome + "?type=json",
                method: "GET",
                data: {
                    type: "json"
                },
                success: function(e) {
                    console.log("fetchFallBack", e);
                    var s = e.data.dmlNodeResponse.fallbacks[0];
                    t.setData({
                        fallBackData: s
                    });
                },
                fail: function(t) {
                    console.log("FAILED", t);
                },
                complete: function() {
                    t.setData({
                        isCountryListFetching: !1
                    }), console.log("COMPLETED");
                }
            });
        },
        fetchSpotlightTAA: function(t) {
            var e = this;
            wx.request({
                url: this.data.shared.bootstrap.urls.spotlight,
                data: {
                    type: "json",
                    store: t,
                    includeEditorials: !1
                },
                method: "GET",
                success: function(t) {
                    console.log("COMPLETED");
                },
                fail: function() {
                    console.log("FAILED");
                },
                complete: function() {
                    e.setData({
                        isCountryListFetching: !1
                    }), console.log("COMPLETED");
                }
            });
        },
        fetchSessionList: function(e) {
            var s = this;
            wx.request({
                url: this.data.shared.bootstrap.urls.sessionsList,
                data: {
                    type: "json",
                    store: e,
                    endDate: 1671505199e3
                },
                method: "GET",
                success: function(e) {
                    console.log("fetchSessionList====", e);
                    var a = e.data, o = a.sessionsList, i = a.templatesMap, n = (a.tagsMap, a.translations);
                    console.log(n, "translationstranslationstranslations");
                    var r = o && o.map(function(e) {
                        if (e.templateId) {
                            i[e.templateId].tags;
                            e.sessions && e.sessions[0];
                            var s = [];
                            if (e.sessions) {
                                var a, o = t(e.sessions);
                                try {
                                    for (o.s(); !(a = o.n()).done; ) {
                                        var r = a.value;
                                        s.push(r.dayTime);
                                    }
                                } catch (t) {
                                    o.e(t);
                                } finally {
                                    o.f();
                                }
                            } else s = [ e.time, e.isVirtual ? n.online : "" ];
                            return {
                                title: e.shortName,
                                descList: s
                            };
                        }
                    });
                    s.setData({
                        upcomingSessionListData: r,
                        upcomingTranslation: n
                    });
                },
                fail: function() {
                    console.log("FAILED");
                },
                complete: function() {
                    s.setData({
                        isCountryListFetching: !1
                    }), console.log("COMPLETED");
                }
            });
        },
        gotoPickUp: function() {
            this.setData({
                compareView: !0
            });
            var t = this.data.shared.urls.aosShippingPickup;
            wx.navigateTo({
                url: "../pageView/pageView?url=" + t
            });
        },
        nearBy: function() {
            wx.redirectTo({
                url: "../sessions/sessions"
            });
        },
        seeMore: function() {
            this.setData({
                seeMoreDesc: !0
            });
            var t = this.data.shared.bootstrap.urls.calendarFilterWrapper + "?country=CN";
            wx.navigateTo({
                url: "../pageView/pageView?url=" + t
            });
        }
    },
    behaviors: [ e.sharedDataBehavior ]
});