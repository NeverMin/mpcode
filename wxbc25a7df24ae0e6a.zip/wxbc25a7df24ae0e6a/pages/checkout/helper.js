Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getFirstLast = function(e) {
    if (e.match(/^[ A-Za-z.]*$/)) {
        var r = e.split(" ").filter(function(e) {
            return "" !== e;
        });
        if (2 === r.length) return [ r[0], r[1] ];
        if (3 === r.length) return [ "".concat(r[0], " ").concat(r[1]), r[2] ];
    }
    if (function(e) {
        var r = e.replace(" ", "");
        if (r.length > 2) {
            var n, a = t(u);
            try {
                for (a.s(); !(n = a.n()).done; ) {
                    var i = n.value;
                    if (r.startsWith(i)) return !0;
                }
            } catch (e) {
                a.e(e);
            } finally {
                a.f();
            }
        }
        return !1;
    }(e)) {
        var n = e.replace(" ", "");
        return [ n.slice(2), n.slice(0, 2) ];
    }
    if (function(e) {
        var r, n = t(a);
        try {
            for (n.s(); !(r = n.n()).done; ) {
                var u = r.value;
                if (e.startsWith(u)) return !0;
            }
        } catch (e) {
            n.e(e);
        } finally {
            n.f();
        }
        var o, l = t(i);
        try {
            for (l.s(); !(o = l.n()).done; ) {
                var s = o.value;
                if (e.startsWith(s)) return !0;
            }
        } catch (e) {
            l.e(e);
        } finally {
            l.f();
        }
        return !1;
    }(e)) return [ e.slice(1).trim(), e[0] ];
    if (e.match(/^[ \u4E00-\u9FFF]*$/)) {
        var o = e.split(" ").filter(function(e) {
            return "" !== e;
        });
        if (2 === o.length) return [ o[1], o[0] ];
        if (1 === o.length) {
            var l = o[0];
            if (2 === l.length) return [ l[1], l[0] ];
        }
    }
    return [ "", "" ];
}, exports.getFourtyMileNearStoreData = function(e, t, a) {
    var i = a || {}, u = i.radius, o = void 0 === u ? 60 : u, l = i.storesMaxCount, s = void 0 === l ? 15 : l;
    if (e && t && t.latitude && "" !== t.latitude) {
        var f = [];
        return Object.keys(e).forEach(function(a) {
            var i = e[a];
            if (i) {
                var u = {
                    latitude: i.latitude,
                    longitude: i.longitude
                }, l = (0, n.default)(t, u, {
                    unit: "km"
                });
                l <= o && f.push(r(r({}, i), {}, {
                    distance: parseFloat(l).toFixed(1),
                    distanceInMiles: l
                }));
            }
        }), (f = f.sort(function(e, t) {
            return e.distanceInMiles - t.distanceInMiles;
        })).length > s && (f = f.slice(0, s)), f;
    }
    return null;
}, exports.getStoreMapping = function(e) {
    var t = [];
    e && e.countryStateMapping && e.countryStateMapping.length > 0 && e.countryStateMapping.forEach(function(e) {
        e.states.forEach(function(e) {
            e.stores.forEach(function(e) {
                e && null != e && e.storeNumber && (t[e.storeNumber] = e);
            });
        });
    });
    return t;
}, exports.prependAppleToStoreName = function(e) {
    if (!e) return "";
    -1 === e.toLowerCase().indexOf("apple") && (e = "Apple " + e);
    return e;
};

var e, t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), r = require("../../@babel/runtime/helpers/objectSpread2"), n = (e = require("haversine")) && e.__esModule ? e : {
    default: e
};

var a = [ "王", "李", "张", "刘", "陈", "杨", "黄", "赵", "吴", "周", "徐", "孙", "马", "朱", "胡", "郭", "何", "高", "林", "罗", "郑", "梁", "谢", "宋", "唐", "许", "韩", "冯", "邓", "曹", "彭", "曾", "肖", "田", "董", "袁", "潘", "于", "蒋", "蔡", "余", "杜", "叶", "程", "苏", "魏", "吕", "丁", "任", "沈", "姚", "卢", "姜", "崔", "钟", "谭", "陆", "汪", "范", "金", "石", "廖", "贾", "夏", "韦", "付", "方", "白", "邹", "孟", "熊", "秦", "邱", "江", "尹", "薛", "闫", "段", "雷", "侯", "龙", "史", "陶", "黎", "贺", "顾", "毛", "郝", "龚", "邵", "万", "钱", "严", "覃", "武", "戴", "莫", "孔", "向", "汤", "习", "戈" ], i = [ "褚", "卫", "尤", "施", "华", "戚", "喻", "柏", "水", "窦", "章", "云", "葛", "奚", "郎", "鲁", "昌", "苗", "凤", "花", "俞", "柳", "酆", "鲍", "费", "廉", "岑", "倪", "滕", "殷", "毕", "邬", "安", "常", "乐", "时", "傅", "皮", "卞", "齐", "康", "伍", "元", "卜", "平", "和", "穆", "萧", "湛", "祁", "禹", "狄", "米", "贝", "明", "臧", "计", "伏", "成", "谈", "茅", "庞", "纪", "舒", "屈", "项", "祝", "阮", "蓝", "闵", "席", "季", "麻", "强", "路", "娄", "危", "童", "颜", "梅", "盛", "刁", "锺", "骆", "樊", "凌", "霍", "虞", "支", "柯", "昝", "管", "经", "房", "裘", "缪", "干", "解", "应", "宗", "宣", "贲", "郁", "单", "杭", "洪", "包", "诸", "左", "吉", "钮", "嵇", "邢", "滑", "裴", "荣", "翁", "荀", "羊", "於", "惠", "甄", "麴", "家", "封", "芮", "羿", "储", "靳", "汲", "邴", "糜", "松", "井", "富", "巫", "乌", "焦", "巴", "弓", "牧", "隗", "山", "谷", "车", "宓", "蓬", "全", "郗", "班", "仰", "秋", "仲", "伊", "宫", "宁", "仇", "栾", "暴", "甘", "钭", "历", "戎", "祖", "符", "景", "詹", "束", "幸", "司", "韶", "郜", "蓟", "溥", "印", "宿", "怀", "蒲", "邰", "从", "鄂", "索", "咸", "籍", "赖", "卓", "蔺", "屠", "蒙", "池", "乔", "阳", "胥", "能", "苍", "双", "闻", "莘", "党", "翟", "贡", "劳", "逄", "姬", "申", "扶", "堵", "冉", "宰", "郦", "雍", "却", "璩", "桑", "桂", "濮", "牛", "寿", "通", "边", "扈", "燕", "冀", "僪", "浦", "尚", "农", "温", "别", "庄", "晏", "柴", "瞿", "阎", "充", "慕", "连", "茹", "宦", "艾", "鱼", "容", "古", "易", "慎", "庾", "终", "暨", "居", "衡", "步", "都", "耿", "满", "弘", "匡", "国", "文", "寇", "广", "禄", "阙", "东", "欧", "殳", "沃", "利", "蔚", "越", "夔", "隆", "师", "巩", "厍", "聂", "晁", "勾", "敖", "融", "冷", "訾", "辛", "阚", "那", "简", "饶", "空", "毋", "沙", "乜", "养", "鞠", "须", "丰", "巢", "关", "蒯", "相", "查", "后", "荆", "红", "游", "竺", "权", "逮", "盍", "益", "桓", "公", "丛", "岳", "召", "有", "舜", "赏", "伯", "佴", "佘", "牟", "商", "鄢", "汝", "法", "楚", "晋", "盖", "逯", "库", "郏", "逢", "阴", "薄", "厉", "稽", "铁" ], u = [ "万俟", "司马", "上官", "欧阳", "夏侯", "诸葛", "闻人", "东方", "赫连", "皇甫", "尉迟", "公羊", "澹台", "公冶", "宗政", "濮阳", "淳于", "单于", "太叔", "申屠", "公孙", "仲孙", "轩辕", "令狐", "钟离", "宇文", "长孙", "慕容", "司徒", "司空", "南宫", "西门", "东门", "左丘", "梁丘", "呼延", "南门", "东郭", "百里", "谷梁", "宰父", "夹谷", "拓跋", "壤驷", "乐正", "漆雕", "公西", "巫马", "端木", "颛孙", "子车", "司寇", "亓官", "鲜于", "锺离", "闾丘", "公良" ];