require("../../@babel/runtime/helpers/Arrayincludes"), require("../../@babel/runtime/helpers/Objectvalues");

var e = require("../../@babel/runtime/helpers/defineProperty"), t = require("../../@babel/runtime/helpers/toConsumableArray"), a = require("../../@babel/runtime/helpers/regeneratorRuntime"), i = require("../../@babel/runtime/helpers/objectSpread2"), l = require("../../@babel/runtime/helpers/asyncToGenerator");

require("../../@babel/runtime/helpers/Objectentries");

var d, n = require("../../@babel/runtime/helpers/slicedToArray"), o = require("../../utils/behavior"), r = require("../../utils/sharedData"), s = require("../../utils/util"), u = require("./helper"), c = require("./util"), v = require("../../analytics/tracking"), p = {
    shared: r.initSharedData,
    pageTitle: "",
    isLoading: !0,
    isShippingAddressAdded: !1,
    showThankYou: !1,
    showNoThankYou: !0,
    thankyouData: {},
    countries: [],
    isCountryListFetching: !1,
    type: 1,
    addressModule: {},
    translations: {},
    saveUrl: "",
    cancelUrl: "",
    alerts: "",
    formListsFields: [],
    errorFields: null,
    addressFields: [],
    localityLookupMap: {},
    stateList: [],
    cityList: [],
    districtList: [],
    stateValue: "",
    cityValue: "",
    districtValue: "",
    formValues: {},
    addressData: {
        keyPath: ""
    },
    mandatoryAdditionalHeaders: {},
    termsChecked: !1,
    invoiceData: null,
    OK: "确定",
    CANCEL: "取消",
    inputText: "",
    inputValue: "",
    inputDisabled: !0,
    index: 0,
    invoiceTypes: [],
    customStateCity: "选择一项",
    invoiceFields: {},
    emailAddress: "",
    mobilePhone: "",
    pickupContactData: null,
    pickupStoreData: null,
    productDisplayName: "",
    userLatLong: {},
    storeMappings: [],
    availability: {},
    updatedAvailibility: {},
    nearerPickupStores: [],
    requestSource: "",
    commonData: {},
    selectedProduct: {},
    selectPickupStore: "",
    pickupContactFields: {},
    pickupTaxData: {},
    searchedPickupStoresList: [],
    searchedFields: {},
    showSearchedStoresByLocation: !1,
    serachedStoresWithMapping: [],
    checkingAvailabilityForStoreNumber: "",
    savedStoresList: [],
    storePickupMethodMapping: {},
    nearbyUpdatedAvailibility: {},
    savedUpdatedAvailibility: {},
    searchedUpdatedAvailibility: {},
    enableSaveButton: !1,
    enablePickupStoreSaveButton: !1,
    termsPickupContactChecked: !1,
    idlShippingData: null,
    IMPORT_WECHAT_TEXT: "从微信导入地址",
    streetValue: "",
    street2Value: "",
    disableIdlShippingBtn: !0,
    idlTimeSlotsData: null,
    selectedIdlDate: "",
    selectedIdlTimeSlot: null,
    daySlotsAvailable: null,
    allSlotsDisabled: null,
    slot_title: "",
    fetchingStoreDetails: !1,
    storeDetails: null,
    storeDetailsResponse: null,
    storeSpecialHoursData: null,
    deliveryLocationData: null,
    postalCodeValue: ""
};

function h(e) {
    if (e) return n(Object.entries(e)[0], 1)[0];
}

Component({
    data: p,
    methods: {
        reloadPage: function() {
            var e = this;
            return l(a().mark(function t() {
                var l, d, n, o, r;
                return a().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (t.prev = 0, d = i({}, null === (l = e.data) || void 0 === l ? void 0 : l.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: e.data.shared.textAssets.loading,
                            mask: !0
                        }), !e.data.cancelUrl) {
                            t.next = 15;
                            break;
                        }
                        return t.next = 6, e.crequest({
                            url: e.data.cancelUrl,
                            method: "POST",
                            header: d
                        }, {
                            formUrlEncoded: !0
                        });

                      case 6:
                        if (r = t.sent, !e.handleAllErrors(null == r ? void 0 : r.data)) {
                            t.next = 9;
                            break;
                        }
                        return t.abrupt("return");

                      case 9:
                        wx.hideLoading(), e.setData({
                            isLoading: !1,
                            landingData: r.data,
                            invoiceData: null,
                            shippingData: null,
                            deliveryLocationData: null,
                            pickupStoreData: null,
                            pickupMethodData: null,
                            pickupContactData: null,
                            pickupContactFields: null,
                            pickUpErrorFields: null,
                            termsPickupContactChecked: null,
                            idlShippingData: null,
                            idlTimeSlotsData: null,
                            shared: i({}, e.data.shared),
                            mandatoryAdditionalHeaders: null === (n = r.data) || void 0 === n || null === (o = n.meta) || void 0 === o ? void 0 : o.mandatoryAdditionalHeaders
                        }), e.getItemsData(r.data), e.getSpokesData(r.data), t.next = 17;
                        break;

                      case 15:
                        wx.hideLoading(), e.setData({
                            tradeInLearnMore: null
                        });

                      case 17:
                        t.next = 25;
                        break;

                      case 19:
                        return t.prev = 19, t.t0 = t.catch(0), console.error("page reload failed", t.t0), 
                        wx.hideLoading(), e.handleAllErrors(), t.abrupt("return");

                      case 25:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 0, 19 ] ]);
            }))();
        },
        handleFocus: function() {
            var e, t, a = this, l = null === (e = this.data) || void 0 === e || null === (t = e.pickupTaxFields) || void 0 === t ? void 0 : t.map(function(e) {
                var t = a.data.pickupTaxData[e.id];
                return e.isMasked && t ? i(i({}, e), {}, {
                    value: ""
                }) : e;
            });
            this.setData({
                pickupTaxFields: l
            });
        },
        onClickLeft: function() {
            this.data.invoiceData || this.data.shippingData || this.data.deliveryLocationData || this.data.pickupStoreData || this.data.pickupMethodData || this.data.pickupContactData || this.data.idlShippingData || this.data.idlTimeSlotsData || this.data.tradeInLearnMore ? (this.reloadPage(), 
            this.data.pickupStoreData && this.setData({
                enablePickupStoreSaveButton: !1
            })) : wx.navigateBack();
        },
        onShow: function() {
            this.loadPage(), this.setData({
                preventReload: !0
            });
        },
        onSaveExitState: function() {
            wx.setStorage({
                key: "cookieJar",
                data: this.data.shared.cookieJar
            });
        },
        onThankyouDone: function() {
            wx.reLaunch({
                url: "../landing/landing"
            });
        },
        showAlerts: function(e) {
            var t, a = null == e || null === (t = e.review) || void 0 === t ? void 0 : t.alerts;
            (null == a ? void 0 : a.length) > 0 && wx.showModal({
                content: a[0],
                confirmText: this.data.shared.textAssets.ok,
                showCancel: !1
            });
        },
        orderStatusCookieCheck: function() {
            if (!this.data.shared.cookieJar.find(function(e) {
                return "rdcStatus" === e.name;
            })) {
                var e = {
                    name: "rdcStatus",
                    value: "1",
                    path: "/",
                    domain: ".apple.com",
                    createdOn: Date.now()
                };
                this.setData({
                    shared: i(i({}, this.data.shared), {}, {
                        cookieJar: [].concat(t(this.data.shared.cookieJar), [ e ])
                    })
                });
            }
        },
        loadPage: function() {
            var t = this;
            return l(a().mark(function l() {
                var d, n, o, r, s, u, c, p, m, f, k, g, D, y, S, b, x, w, L, A, T, M, I, P, C, F, U, E, O, V;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (!t.data.preventReload) {
                            a.next = 2;
                            break;
                        }
                        return a.abrupt("return");

                      case 2:
                        return a.prev = 2, T = t.data.shared.cookieJar.find(function(e) {
                            return e.name === t.data.shared.bootstrap.diwaCookieName;
                        }), M = "", T && (M = "dv=" + encodeURIComponent(T.name + "^" + T.value)), t.orderStatusCookieCheck(), 
                        a.next = 9, t.crequest({
                            url: t.data.shared.urls.checkoutStart,
                            method: "POST",
                            data: M
                        }, {
                            formUrlEncoded: !0
                        });

                      case 9:
                        if (I = a.sent, !t.handleAllErrors(null == I ? void 0 : I.data)) {
                            a.next = 12;
                            break;
                        }
                        return a.abrupt("return");

                      case 12:
                        t.showAlerts(null == I ? void 0 : I.data), t.setData({
                            isLoading: !1,
                            landingData: I.data,
                            pageTitle: t.data.shared.textAssets.checkout,
                            shared: i({}, t.data.shared),
                            mandatoryAdditionalHeaders: null === (d = I.data) || void 0 === d || null === (n = d.meta) || void 0 === n ? void 0 : n.mandatoryAdditionalHeaders
                        }), null !== (o = t.data.landingData) && void 0 !== o && null !== (r = o.review) && void 0 !== r && r.omnitureData && (0, 
                        v.trackLinkOmniture)({
                            type: "PAGE_LOAD",
                            omniture: t.data.landingData.review.omnitureData,
                            data: null
                        }), t.getItemsData(I.data), t.getSpokesData(I.data), P = null === (s = t.data) || void 0 === s || null === (u = s.landingData) || void 0 === u || null === (c = u.review) || void 0 === c || null === (p = c.fulfillment) || void 0 === p || null === (m = p.items) || void 0 === m || null === (f = m[0]) || void 0 === f || null === (k = f.childItems) || void 0 === k ? void 0 : k.find(function(e) {
                            return "TRADEINPART" === e.productId;
                        }), C = h(null == P ? void 0 : P.tradeInEstimatedPriceDetails), F = h(null == P ? void 0 : P.tradeInDeviceDetails), 
                        U = {}, E = null === (g = t.data) || void 0 === g || null === (D = g.landingData) || void 0 === D || null === (y = D.review) || void 0 === y || null === (S = y.terms) || void 0 === S ? void 0 : S.mergeTerms, 
                        O = null === (b = t.data) || void 0 === b || null === (x = b.landingData) || void 0 === x || null === (w = x.review) || void 0 === w || null === (L = w.terms) || void 0 === L || null === (A = L.sections) || void 0 === A ? void 0 : A.map(function(a, l) {
                            var d;
                            U = i(i({}, U), {}, e({}, l, a.termsAccepted));
                            var n = null == a || null === (d = a.links) || void 0 === d ? void 0 : d.map(function(e) {
                                var a, l;
                                return i(i({}, e), {}, {
                                    termsLink: encodeURIComponent((null === (a = t.data.shared) || void 0 === a || null === (l = a.urls) || void 0 === l ? void 0 : l.redirectURLHelper) + "?url=" + (null == e ? void 0 : e.termsLink))
                                });
                            });
                            return i(i({}, a), {}, {
                                links: n
                            });
                        }), V = Object.values(U || {}).some(function(e) {
                            return !e;
                        }), t.setData({
                            tradeInEstimatedPriceDetails: C,
                            tradeInDeviceDetails: F,
                            checkedObjectForTerms: U,
                            mergeTerms: E,
                            mergedAcceptStatus: !V,
                            termSections: O
                        }), a.next = 33;
                        break;

                      case 27:
                        return a.prev = 27, a.t0 = a.catch(2), console.error("checkout failed", a.t0), wx.hideLoading(), 
                        t.handleAllErrors(), a.abrupt("return");

                      case 33:
                      case "end":
                        return a.stop();
                    }
                }, l, null, [ [ 2, 27 ] ]);
            }))();
        },
        isOkayToCheckout: function() {
            var e, t, a, i = null === (e = this.data) || void 0 === e || null === (t = e.landingData) || void 0 === t || null === (a = t.review) || void 0 === a ? void 0 : a.translations, l = this.data.checkedObjectForTerms;
            return !!this.checkAllTrue(l) || (wx.showModal({
                title: i.termsConditionsTitle,
                content: i.termsAcceptMessage,
                confirmText: i.ok,
                showCancel: !1,
                success: function(e) {
                    e.confirm;
                }
            }), !1);
        },
        checkAllTrue: function(e) {
            for (var t in e) if (e.hasOwnProperty(t) && !e[t]) return !1;
            return !0;
        },
        termsAccepted: function() {
            var e = "", t = this.data.checkedObjectForTerms;
            if (this.data.mergeTerms) {
                var a, i, l, d = null === (a = this.data.landingData) || void 0 === a || null === (i = a.review) || void 0 === i || null === (l = i.terms) || void 0 === l ? void 0 : l.keyPath;
                if (this.data.mergedAcceptStatus) return "&".concat(d, ".termsAccepted=1");
            } else {
                var n;
                null === (n = this.data.termSections) || void 0 === n || n.map(function(a, i) {
                    null != t && t.hasOwnProperty(i) && t[i] && (e += "&".concat(a.keyPath, ".termsAccepted=1"));
                });
            }
            return e;
        },
        renderTradeInLearnMore: function() {
            var e, t, a, i = null === (e = this.data) || void 0 === e || null === (t = e.translations) || void 0 === t ? void 0 : t.tradeinRefundPageText, l = null == i ? void 0 : i.split("\\n\\n"), d = n(l, 2), o = d[0], r = d[1];
            r = null === (a = r) || void 0 === a ? void 0 : a.replace(/\[\/?plain\]/gi, ""), 
            this.setData({
                tradeInLearnMore: {
                    title: o,
                    paragraph: r
                }
            });
        },
        checkout: function() {
            var e = this;
            return l(a().mark(function t() {
                var l, d, n, o, r, u, p, h, m, f, k, g, D, y, S, b, x, w, L, A, T, M, I, P, C, F, U, E, O, V, H, q, R, N, j, B, _, W, Y, J, G, K, Z, $, z, X, Q, ee, te, ae, ie, le, de, ne, oe, re, se, ue, ce;
                return a().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if ((u = e.data.landingData).review) {
                            t.next = 3;
                            break;
                        }
                        throw new Error("bad reviewResponse");

                      case 3:
                        if (e.isOkayToCheckout()) {
                            t.next = 5;
                            break;
                        }
                        return t.abrupt("return");

                      case 5:
                        return t.prev = 5, f = e.termsAccepted(), wx.showLoading({
                            title: null !== (p = e.data.shared.textAssets.processingOrder) && void 0 !== p ? p : e.data.shared.textAssets.loading,
                            mask: !0
                        }), k = "", t.prev = 9, t.next = 12, e.crequest({
                            url: e.data.shared.bootstrap.urls.openIdFetchURL
                        });

                      case 12:
                        g = t.sent, k = g.data.openID, e.setData({
                            openIdString: k
                        }), t.next = 23;
                        break;

                      case 17:
                        return t.prev = 17, t.t0 = t.catch(9), console.error("getOpenId failed", t.t0), 
                        wx.hideLoading(), e.handleAllErrors(), t.abrupt("return");

                      case 23:
                        return t.next = 25, e.crequest({
                            url: u.review.transactions.placeOrderUrl,
                            method: "POST",
                            header: u.meta.mandatoryAdditionalHeaders,
                            data: "mSignCookies=&masConfigKey=placeOrder&sessionID=" + e.data.landingData.review.transactions.placeOrderParams.sessionID + "&mSignParameters=sessionID" + f + "&checkout.review.transactions.openid=" + k + "&checkout.review.transactions.tzos=-7&checkout.review.transactions.udid="
                        }, {
                            formUrlEncoded: !0
                        });

                      case 25:
                        D = t.sent, y = (0, c.parseElmoResponse)(D), t.t1 = y.responseType, t.next = "deliveryTimeSlot" === t.t1 ? 30 : "shipping" === t.t1 ? 38 : "timeSlot" === t.t1 ? 53 : "pickupContact" === t.t1 ? 60 : "checkoutStatus" === t.t1 ? 65 : 66;
                        break;

                      case 30:
                        return e.setData({
                            idlTimeSlotsData: null == D ? void 0 : D.data,
                            cancelUrl: null == D || null === (l = D.data) || void 0 === l || null === (d = l.deliveryTimeSlot) || void 0 === d ? void 0 : d.cancelUrl,
                            mandatoryAdditionalHeaders: null === (n = D.data) || void 0 === n || null === (o = n.meta) || void 0 === o ? void 0 : o.mandatoryAdditionalHeaders
                        }), S = (null == D || null === (r = D.data) || void 0 === r ? void 0 : r.deliveryTimeSlot) || {}, 
                        b = S.daySlots, x = S.selectedTimeSlot, w = S.translations, L = !(!b || !b.length), 
                        A = !(b || []).some(function(e) {
                            return (e.timeSlots || []).some(function(e) {
                                return e.enabled;
                            });
                        }), e.setData({
                            daySlotsAvailable: L,
                            allSlotsDisabled: A
                        }), (b || []).some(function(t) {
                            var a = (t.timeSlots || []).find(function(e) {
                                return e.id === x;
                            });
                            return !!a && (e.setData({
                                selectedIdlTimeSlot: a,
                                selectedIdlDate: t.date,
                                slot_title: w.slot_title.indexOf("daySelected") > -1 ? w.slot_title.replace("${daySelected}", t.date) : w.slot_title.replace("null", t.date)
                            }), !0);
                        }), wx.hideLoading(), t.abrupt("return");

                      case 38:
                        return (U = null === (T = y.shippingMessages) || void 0 === T || null === (M = T.messages) || void 0 === M || null === (I = M.errors) || void 0 === I ? void 0 : I[0]) && wx.showToast({
                            title: U,
                            icon: "none",
                            duration: 3e3
                        }), E = y.mobileAddress, O = y.addressData, V = [ null == E || null === (P = E.addressFields) || void 0 === P ? void 0 : P[1] ], 
                        H = y.translations, q = y.saveUrl, R = y.cancelUrl, N = null === (C = y.shippingMessages) || void 0 === C || null === (F = C.messages) || void 0 === F ? void 0 : F.errors, 
                        j = y.mandatoryAdditionalHeaders, e.setData({
                            isLoading: !1,
                            shippingData: D.data,
                            translations: H,
                            saveUrl: q,
                            cancelUrl: R,
                            alerts: N,
                            addressFields: V,
                            addressData: O,
                            mandatoryAdditionalHeaders: j,
                            formValues: i({}, O)
                        }), e.setData({
                            localityLookupMap: require("./localityLookupMap.js").default
                        }), e.setData({
                            stateList: Object.keys(e.data.localityLookupMap)
                        }), wx.hideLoading(), t.abrupt("return");

                      case 53:
                        return (Y = null === (B = y.retailTimeSlotMessages) || void 0 === B || null === (_ = B.messages) || void 0 === _ || null === (W = _.errors) || void 0 === W ? void 0 : W[0]) && wx.showToast({
                            title: Y,
                            icon: "none",
                            duration: 3e3
                        }), (J = y.timeSlot) && e.updatePickupMethodData(J), e.setData({
                            mandatoryAdditionalHeaders: y.mandatoryAdditionalHeaders
                        }), wx.hideLoading(), t.abrupt("return");

                      case 60:
                        return (de = null === (G = y.pickupContactMessages) || void 0 === G || null === (K = G.messages) || void 0 === K || null === (Z = K.errors) || void 0 === Z ? void 0 : Z[0]) && wx.showToast({
                            title: de,
                            icon: "none",
                            duration: 3e3
                        }), e.setData({
                            isLoading: !1,
                            pickupContactData: D.data,
                            pickupTerms: null === ($ = y.pickupContact) || void 0 === $ ? void 0 : $.pickupContactTerms,
                            pickupAddressFields: null === (z = y.pickupContact) || void 0 === z || null === (X = z.mobileAddress) || void 0 === X ? void 0 : X.addressFields,
                            pickupTaxFields: null === (Q = y.pickupContact) || void 0 === Q || null === (ee = Q.taxFields) || void 0 === ee ? void 0 : ee.taxExtendedFields,
                            shippingData: null,
                            invoiceData: null,
                            translations: null == D || null === (te = D.data) || void 0 === te || null === (ae = te.pickupContact) || void 0 === ae ? void 0 : ae.translations,
                            cancelUrl: null == D || null === (ie = D.data) || void 0 === ie || null === (le = ie.pickupContact) || void 0 === le ? void 0 : le.cancelUrl
                        }), wx.hideLoading(), t.abrupt("return");

                      case 65:
                        return t.abrupt("break", 67);

                      case 66:
                        throw new Error("Unhandled checkout response type");

                      case 67:
                        ne = y, null != u && null !== (h = u.review) && void 0 !== h && h.omnitureData && (0, 
                        v.trackLinkOmniture)({
                            type: "save-order",
                            omniture: u.review.omnitureData,
                            data: null
                        }), wx.showLoading({
                            title: null !== (m = e.data.shared.textAssets.processingPay) && void 0 !== m ? m : e.data.shared.textAssets.loading,
                            mask: !0
                        });

                      case 70:
                        if ("checkoutStatus" !== ne.responseType) {
                            t.next = 80;
                            break;
                        }
                        return t.next = 73, (0, s.sleep)(1e3 * y.delay);

                      case 73:
                        return t.next = 75, e.crequest({
                            url: ne.url,
                            method: ne.method,
                            header: ne.mandatoryAdditionalHeaders
                        });

                      case 75:
                        oe = t.sent, re = (0, c.parseElmoResponse)(oe), ne = re, t.next = 70;
                        break;

                      case 80:
                        if ("review" !== ne.responseType) {
                            t.next = 83;
                            break;
                        }
                        return (null === (se = ne.alerts) || void 0 === se ? void 0 : se[0]) && wx.showToast({
                            title: ne.alerts[0],
                            icon: "none",
                            duration: 3e3
                        }), t.abrupt("return");

                      case 83:
                        if ("thankYouStatus" !== ne.responseType) {
                            t.next = 106;
                            break;
                        }
                        return t.next = 86, (0, s.sleep)(2e3);

                      case 86:
                        if ("default" !== ne.view && "weChatStatus" !== ne.view) {
                            t.next = 94;
                            break;
                        }
                        return t.next = 89, e.crequest({
                            url: ne.wechatGeneratePrepayID,
                            method: "POST",
                            header: ne.mandatoryAdditionalHeaders,
                            data: ne.accessToken && "thankYou.transactions.accessToken=" + ne.accessToken
                        }, {
                            formUrlEncoded: !0
                        });

                      case 89:
                        ue = t.sent, ce = (0, c.parseElmoResponse)(ue), ne = ce, t.next = 104;
                        break;

                      case 94:
                        if ("weChatSuccess" !== ne.view) {
                            t.next = 101;
                            break;
                        }
                        return e.setData({
                            thankyouData: ue.data
                        }), e.postAffiliateUrls(), e.requestPayment(), t.abrupt("break", 106);

                      case 101:
                        if ("weChatFailed" !== ne.view) {
                            t.next = 104;
                            break;
                        }
                        return wx.showToast({
                            title: "链接服务器错误",
                            icon: "error"
                        }), t.abrupt("break", 106);

                      case 104:
                        t.next = 83;
                        break;

                      case 106:
                        t.next = 113;
                        break;

                      case 108:
                        return t.prev = 108, t.t2 = t.catch(5), console.error("checkout failed", t.t2), 
                        wx.showToast({
                            title: "服务器错误",
                            icon: "error"
                        }), t.abrupt("return");

                      case 113:
                        wx.hideLoading();

                      case 114:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 5, 108 ], [ 9, 17 ] ]);
            }))();
        },
        fetchMyAppleIdData: function() {
            var e = this;
            return l(a().mark(function t() {
                var l, d, n, o, r, s, u, c, v, p, h;
                return a().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!(o = null === (l = e.data.shared) || void 0 === l || null === (d = l.bootstrap) || void 0 === d || null === (n = d.urls) || void 0 === n ? void 0 : n.myAppleIdURL)) {
                            t.next = 19;
                            break;
                        }
                        return s = i({}, null === (r = e.data) || void 0 === r ? void 0 : r.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), t.prev = 4, t.next = 7, e.crequest({
                            url: o,
                            header: s,
                            data: {
                                type: "json"
                            }
                        }, {
                            formUrlEncoded: !0
                        });

                      case 7:
                        p = t.sent, wx.hideLoading(), h = null == p ? void 0 : p.data, e.setData({
                            isLoading: !1,
                            pickupContactFields: i(i({}, e.data.pickupContactFields), {}, {
                                lastName: (null === (u = e.data.pickupContactFields) || void 0 === u ? void 0 : u.lastName) || (null == h ? void 0 : h.lastName),
                                firstName: (null === (c = e.data.pickupContactFields) || void 0 === c ? void 0 : c.firstName) || (null == h ? void 0 : h.firstName),
                                emailAddress: (null === (v = e.data.pickupContactFields) || void 0 === v ? void 0 : v.emailAddress) || (null == h ? void 0 : h.accountName)
                            })
                        }), t.next = 19;
                        break;

                      case 13:
                        return t.prev = 13, t.t0 = t.catch(4), console.error("My apple id failed", t.t0), 
                        wx.hideLoading(), e.handleAllErrors(), t.abrupt("return");

                      case 19:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 4, 13 ] ]);
            }))();
        },
        requestPayment: function() {
            console.log("requestPayment");
            var e = this, t = this.data.thankyouData.view;
            if (console.log("thankyouStatus", t), "weChatSuccess" == t) {
                var a, i = this.data.thankyouData.weChat;
                console.log("wechat data", i), null !== (a = this.data) && void 0 !== a && a.thankyouData && (0, 
                v.trackLinkOmniture)({
                    type: "PAGE_LOAD",
                    omniture: this.data.thankyouData.omniture
                }), wx.requestPayment({
                    timeStamp: i.timeStamp,
                    nonceStr: i.nonceStr,
                    package: i.package,
                    signType: i.signType,
                    paySign: i.sign,
                    success: function(t) {
                        console.log("checkout success", t), e.setData({
                            showThankYou: !0,
                            showNoThankYou: !1
                        });
                    },
                    fail: function(t) {
                        console.log("checkout failed", t), e.setData({
                            showThankYou: !0,
                            showNoThankYou: !0
                        });
                    }
                });
            }
        },
        postAffiliateUrls: function() {
            var e, t;
            null !== (e = this.data.thankyouData) && void 0 !== e && e.affiliateURLs && (null === (t = this.data.thankyouData) || void 0 === t || t.affiliateURLs.map(function(e) {
                wx.request({
                    url: e,
                    method: "POST"
                });
            }));
        },
        getAddress: function(e, t) {
            if (e) {
                var a = "";
                return e.address && e.address.layout.map(function(e) {
                    e.shipping_address && e.shipping_address.map(function(e) {
                        a += e.join(" ") + "\n";
                    });
                }), {
                    field: t[e.label],
                    value: e.value || a,
                    selectUrl: e.selectUrl
                };
            }
            return null;
        },
        getInvoice: function(e, t, a, i, l) {
            return e ? {
                field: t[e.label],
                value: e.value,
                selectUrl: e.selectUrl,
                showFapioTextinCheckout: a,
                showTradeInSummary: i,
                fapiaoTextInCheckout: l
            } : {};
        },
        getTradeInTotal: function(e, t) {
            if (!e || !e.tradeInAmountLabel) return null;
            var a = e.tradeInAmountLabel.split("：");
            return {
                label: a[0],
                price: a[1],
                show: !t
            };
        },
        getSpokesData: function(e) {
            var t, a, i, l, d, n, o, r, s, u, c, v = null == e || null === (t = e.review) || void 0 === t ? void 0 : t.translations, p = this.getAddress(null === (a = e.review) || void 0 === a ? void 0 : a.spokes.find(function(e) {
                return "shipping" === e.id;
            }), v);
            if (p) {
                var h = null == p ? void 0 : p.value.split("\n");
                p.vs = [];
                for (var m = 0; m < h.length; m++) p.vs.push(h[m]);
                console.log(p.vs);
            }
            var f = this.getInvoice(null === (i = e.review) || void 0 === i ? void 0 : i.spokes.find(function(e) {
                return "invoice" === e.id;
            }), v, null === (l = e.review) || void 0 === l ? void 0 : l.showFapioTextinCheckout, null === (d = e.review) || void 0 === d ? void 0 : d.showTradeInSummary, null === (n = e.review) || void 0 === n ? void 0 : n.fapiaoTextInCheckout), k = this.getAddress(null === (o = e.review) || void 0 === o ? void 0 : o.spokes.find(function(e) {
                return "pickup" === e.id;
            }), v), g = this.getAddress(null === (r = e.review) || void 0 === r ? void 0 : r.spokes.find(function(e) {
                return "3pp" === e.id;
            }), v), D = this.getAddress(null === (s = e.review) || void 0 === s ? void 0 : s.spokes.find(function(e) {
                return "timeSlot" === e.id;
            }), v), y = null === (u = e.review) || void 0 === u ? void 0 : u.checkoutOfferSummary, S = this.getTradeInTotal(y, null === (c = e.review) || void 0 === c ? void 0 : c.showTradeInSummary);
            this.setData({
                address: p,
                invoice: f,
                pickupLabel: k,
                pickupContact: g,
                pickupMethod: D,
                checkoutOfferSummary: y,
                tradeInTotal: S,
                translations: v
            });
        },
        getItemsData: function(e) {
            var t, a, i, l;
            this.setData({
                items: null == e || null === (t = e.review) || void 0 === t || null === (a = t.fulfillment) || void 0 === a ? void 0 : a.items,
                bopisEnabled: null == e || null === (i = e.review) || void 0 === i || null === (l = i.fulfillment) || void 0 === l ? void 0 : l.bopisEnabled
            });
        },
        handleEditButtonClick: function(e) {
            var t = this;
            return l(a().mark(function i() {
                var l, d, n, o, r, s, u, c, v, p;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        s = (null === (l = e.currentTarget) || void 0 === l ? void 0 : l.dataset) || e || {}, 
                        u = s.cell, c = s.item, v = {
                            cartLineItemId: c,
                            deliveryLocationField: null == u ? void 0 : u.deliveryLocationType,
                            deliveryShipMethodCode: null == u ? void 0 : u.id
                        }, null != (p = null === (d = t.data) || void 0 === d || null === (n = d.landingData) || void 0 === n || null === (o = n.review) || void 0 === o || null === (r = o.spokes) || void 0 === r ? void 0 : r.find(function(e) {
                            return "deliveryTimeSlot" === (null == e ? void 0 : e.id);
                        })) && p.selectUrl && t.updateDniDeliveryLocation(p.selectUrl, v);

                      case 4:
                      case "end":
                        return a.stop();
                    }
                }, i);
            }))();
        },
        radioButtonSelect: function(e) {
            var t = this;
            return l(a().mark(function i() {
                var l, d, n, o, r, s, u, c, p, h, m, f, k, g, D, y, S, b, x, w, L, A, T;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (s = null === (l = e.currentTarget) || void 0 === l || null === (d = l.dataset) || void 0 === d ? void 0 : d.item, 
                        u = null === (n = t.data.items) || void 0 === n ? void 0 : n.find(function(e) {
                            return e.lineItemId === s;
                        }), c = t.data.landingData.review || {}, p = c.spokes, h = c.omnitureData, m = u.deliveryOptions, 
                        f = u.keyPath, k = u.changeStoreAction, g = u.selectDeliveryMethod, D = (null === (o = e.currentTarget) || void 0 === o || null === (r = o.dataset) || void 0 === r ? void 0 : r.value) || e.detail.value, 
                        y = null == m ? void 0 : m.find(function(e) {
                            return e.id === D;
                        }), "pickupCell" !== e.detail.value || !y.openStoreLocator) {
                            a.next = 11;
                            break;
                        }
                        h && ((0, v.trackLinkOmniture)({
                            type: "change-store-cold-start",
                            omniture: h,
                            data: null
                        }), (0, v.trackLinkOmniture)({
                            type: "cold-start-potential-purchase",
                            omniture: h,
                            data: null
                        }), (0, v.trackLinkOmniture)({
                            type: "cold-start-retail-store-selected",
                            omniture: h,
                            data: null
                        })), t.goToPickupStore(k), a.next = 23;
                        break;

                      case 11:
                        if (!y.showTimeSlots && !y.showIDLEditButton) {
                            a.next = 17;
                            break;
                        }
                        return S = {
                            cartLineItemId: s,
                            deliveryLocationField: y.deliveryLocationType,
                            deliveryShipMethodCode: D
                        }, y.isIDLReady ? t.handleEditButtonClick({
                            cell: y,
                            item: s
                        }) : (w = p.find(function(e) {
                            return "idlShipping" === (null == e ? void 0 : e.id);
                        }), t.setData({
                            selectedIdlDate: "",
                            selectedIdlTimeSlot: null,
                            daySlotsAvailable: null,
                            disableIdlShippingBtn: !0
                        }), null !== (b = t.data.landingData) && void 0 !== b && null !== (x = b.review) && void 0 !== x && x.omnitureData && (0, 
                        v.trackLinkOmniture)({
                            type: "IDLEdit",
                            omniture: t.data.landingData.review.omnitureData,
                            data: null
                        }), (null == w ? void 0 : w.selectUrl) && t.goToIDLShipping(w.selectUrl, S)), a.abrupt("return");

                      case 17:
                        h && ((0, v.trackLinkOmniture)({
                            type: "change-store-warm-start",
                            omniture: h,
                            data: null
                        }), (0, v.trackLinkOmniture)({
                            type: "warm-start-potential-purchase",
                            omniture: h,
                            data: null
                        }), (0, v.trackLinkOmniture)({
                            type: "warm-start-retail-store-selected",
                            omniture: h,
                            data: null
                        })), (T = {})[f + ".deliveryLocationType"] = y && y.deliveryLocationType, "pickupCell" !== e.detail.value && (T[f + ".deliveryShipMethodCode"] = e.detail.value), 
                        null !== (L = t.data.landingData) && void 0 !== L && null !== (A = L.review) && void 0 !== A && A.omnitureData && (0, 
                        v.trackLinkOmniture)({
                            type: "delivery-option-selected",
                            omniture: t.data.landingData.review.omnitureData,
                            data: null
                        }), t.fetchDeliveryOptionsUpdate(g, T);

                      case 23:
                      case "end":
                        return a.stop();
                    }
                }, i);
            }))();
        },
        fetchDeliveryOptionsUpdate: function(e, t) {
            var d = this;
            return l(a().mark(function l() {
                var n, o, r;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return o = i({}, null === (n = d.data) || void 0 === n ? void 0 : n.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), a.prev = 2, a.next = 5, d.crequest({
                            url: e,
                            method: "POST",
                            header: o,
                            data: t
                        }, {
                            formUrlEncoded: !0
                        });

                      case 5:
                        r = a.sent, d.showAlerts(null == r ? void 0 : r.data), d.setData({
                            landingData: r.data
                        }), d.getItemsData(r.data), d.getSpokesData(r.data), wx.hideLoading(), a.next = 17;
                        break;

                      case 13:
                        return a.prev = 13, a.t0 = a.catch(2), console.error("update delivery option failed", a.t0), 
                        a.abrupt("return");

                      case 17:
                      case "end":
                        return a.stop();
                    }
                }, l, null, [ [ 2, 13 ] ]);
            }))();
        },
        termsAccept: function(e) {
            var t = this.data.checkedObjectForTerms, a = parseInt(e.currentTarget.dataset.indexvalue);
            t[a] = !t[a], this.setData({
                checkedObjectForTerms: t
            });
        },
        termsAcceptMerged: function() {
            var e = this, t = {};
            Object.keys(this.data.checkedObjectForTerms || {}).map(function(a) {
                t[a] = !e.data.mergedAcceptStatus;
            }), this.setData({
                checkedObjectForTerms: t,
                mergedAcceptStatus: !this.data.mergedAcceptStatus
            });
        },
        goToShipping: function() {
            var e = this;
            return l(a().mark(function t() {
                var l, d, n, o, r, s, u, c, p, h, m, f, k, g, D, y, S, b, x, w, L, A, T, M, I, P, C, F, U, E, O, V, H, q, R, N, j, B, _, W, Y;
                return a().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return d = i({}, null === (l = e.data) || void 0 === l ? void 0 : l.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: e.data.shared.textAssets.loading,
                            mask: !0
                        }), t.prev = 2, t.next = 5, e.crequest({
                            url: null === (n = e.data.address) || void 0 === n ? void 0 : n.selectUrl,
                            header: d
                        }, {
                            formUrlEncoded: !0
                        });

                      case 5:
                        if ("mmap-shipping" !== (null == (u = t.sent) || null === (o = u.data) || void 0 === o || null === (r = o.shipping) || void 0 === r ? void 0 : r.view)) {
                            t.next = 24;
                            break;
                        }
                        if (null !== (c = e.data.landingData) && void 0 !== c && null !== (p = c.review) && void 0 !== p && p.omnitureData && (0, 
                        v.trackLinkOmniture)({
                            type: "shipping-selected",
                            omniture: e.data.landingData.review.omnitureData,
                            data: null
                        }), wx.hideLoading(), !e.handleAllErrors(null == u ? void 0 : u.data)) {
                            t.next = 11;
                            break;
                        }
                        return t.abrupt("return");

                      case 11:
                        I = null === (h = u.data) || void 0 === h || null === (m = h.shipping) || void 0 === m ? void 0 : m.mobileAddress, 
                        P = null == I ? void 0 : I.addressData, C = [ null == I || null === (f = I.addressFields) || void 0 === f ? void 0 : f[1] ], 
                        F = null === (k = u.data) || void 0 === k || null === (g = k.shipping) || void 0 === g ? void 0 : g.translations, 
                        U = null === (D = u.data) || void 0 === D || null === (y = D.shipping) || void 0 === y ? void 0 : y.saveUrl, 
                        E = null === (S = u.data) || void 0 === S || null === (b = S.shipping) || void 0 === b ? void 0 : b.cancelUrl, 
                        O = null === (x = u.data) || void 0 === x || null === (w = x.shipping) || void 0 === w || null === (L = w.shippingMessages) || void 0 === L || null === (A = L.messages) || void 0 === A ? void 0 : A.errors, 
                        V = null === (T = u.data) || void 0 === T || null === (M = T.meta) || void 0 === M ? void 0 : M.mandatoryAdditionalHeaders, 
                        H = [], null == C || C.forEach(function(e) {
                            var t;
                            null == e || null === (t = e.cells) || void 0 === t || t.forEach(function(e) {
                                var t, a = (null == e || null === (t = e.fields) || void 0 === t ? void 0 : t[0]) || {}, i = a.isMasked, l = a.id;
                                i && H.push(l);
                            });
                        }), e.setData({
                            isLoading: !1,
                            shippingData: u.data,
                            pageTitle: e.data.shared.textAssets.shipping,
                            translations: F,
                            saveUrl: U,
                            cancelUrl: E,
                            alerts: O,
                            addressFields: C,
                            addressData: P,
                            mandatoryAdditionalHeaders: V,
                            formValues: i({}, P),
                            maskedItems: H
                        }), t.next = 25;
                        break;

                      case 24:
                        null != u && null !== (s = u.data) && void 0 !== s && s.deliveryTimeSlot && (wx.hideLoading(), 
                        e.setData({
                            idlTimeSlotsData: u.data,
                            cancelUrl: u.data.deliveryTimeSlot.cancelUrl,
                            mandatoryAdditionalHeaders: null === (q = u.data) || void 0 === q || null === (R = q.meta) || void 0 === R ? void 0 : R.mandatoryAdditionalHeaders
                        }), N = e.data.idlTimeSlotsData.deliveryTimeSlot, j = N.daySlots, B = N.selectedTimeSlot, 
                        _ = N.translations, W = !(!j || !j.length), Y = !(j || []).some(function(e) {
                            return (e.timeSlots || []).some(function(e) {
                                return e.enabled;
                            });
                        }), e.setData({
                            daySlotsAvailable: W,
                            allSlotsDisabled: Y
                        }), (j || []).some(function(t) {
                            var a = (t.timeSlots || []).find(function(e) {
                                return e.id === B;
                            });
                            return !!a && (e.setData({
                                selectedIdlTimeSlot: a,
                                selectedIdlDate: t.date,
                                slot_title: _.slot_title.indexOf("daySelected") > -1 ? _.slot_title.replace("${daySelected}", t.date) : _.slot_title.replace("null", t.date)
                            }), !0);
                        }));

                      case 25:
                        wx.pageScrollTo({
                            scrollTop: 0,
                            duration: 300
                        }), t.next = 34;
                        break;

                      case 28:
                        return t.prev = 28, t.t0 = t.catch(2), console.error("shipping failed", t.t0), wx.hideLoading(), 
                        e.handleAllErrors(), t.abrupt("return");

                      case 34:
                        e.setData({
                            localityLookupMap: require("./localityLookupMap.js").default
                        }), e.setData({
                            stateList: Object.keys(e.data.localityLookupMap)
                        });

                      case 36:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 2, 28 ] ]);
            }))();
        },
        goToInvoice: function() {
            var e = this;
            return l(a().mark(function t() {
                var l, d, n, o, r, s, u, c, p, h, m, f, k, g, D, y, S, b, x, w, L, A, T, M, I, P, C, F, U, E;
                return a().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return null !== (l = e.data.landingData) && void 0 !== l && null !== (d = l.review) && void 0 !== d && d.omnitureData && (0, 
                        v.trackLinkOmniture)({
                            type: "invoice-selected",
                            omniture: e.data.landingData.review.omnitureData,
                            data: null
                        }), o = i({}, null === (n = e.data) || void 0 === n ? void 0 : n.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), t.prev = 3, t.next = 6, e.crequest({
                            url: null === (r = e.data.invoice) || void 0 === r ? void 0 : r.selectUrl,
                            header: o
                        }, {
                            formUrlEncoded: !0
                        });

                      case 6:
                        if (U = t.sent, wx.hideLoading(), !e.handleAllErrors(null == U ? void 0 : U.data)) {
                            t.next = 10;
                            break;
                        }
                        return t.abrupt("return");

                      case 10:
                        E = null == U || null === (s = U.data) || void 0 === s || null === (u = s.invoice) || void 0 === u ? void 0 : u.invoiceTypes.map(function(e) {
                            return e.label;
                        }), e.setData({
                            isLoading: !1,
                            invoiceData: U.data,
                            invoiceTypes: E,
                            emailAddress: null === (c = U.data) || void 0 === c || null === (p = c.invoice) || void 0 === p || null === (h = p.defaultInvoice) || void 0 === h || null === (m = h.mobileAddress) || void 0 === m || null === (f = m.addressData) || void 0 === f ? void 0 : f.emailAddress,
                            inputText: e.data.inputText ? e.data.inputText : E[0],
                            inputValue: e.data.inputValue ? e.data.inputValue : "none",
                            invoiceHeader: null === (k = U.data) || void 0 === k || null === (g = k.invoice) || void 0 === g || null === (D = g.ePersonalInvoice) || void 0 === D || null === (y = D.invoiceData) || void 0 === y ? void 0 : y.invoiceHeader,
                            addressFields: U.data.invoice.eCompanyInvoice.invoiceAddress.mobileAddress.addressFields,
                            pageTitle: e.data.shared.textAssets.invoice,
                            cancelUrl: null === (S = U.data) || void 0 === S || null === (b = S.invoice) || void 0 === b ? void 0 : b.cancelUrl,
                            mobilePhone: null === (x = U.data) || void 0 === x || null === (w = x.invoice) || void 0 === w || null === (L = w.defaultInvoice) || void 0 === L || null === (A = L.makoAddress) || void 0 === A || null === (T = A.addressFields) || void 0 === T || null === (M = T[0]) || void 0 === M || null === (I = M.cells) || void 0 === I || null === (P = I[0]) || void 0 === P || null === (C = P.fields) || void 0 === C || null === (F = C[0]) || void 0 === F ? void 0 : F.value
                        }), wx.pageScrollTo({
                            scrollTop: 0,
                            duration: 300
                        }), t.next = 21;
                        break;

                      case 15:
                        return t.prev = 15, t.t0 = t.catch(3), console.error("invoice failed", t.t0), wx.hideLoading(), 
                        e.handleAllErrors(), t.abrupt("return");

                      case 21:
                        e.setData({
                            localityLookupMap: require("./localityLookupMap.js").default
                        }), e.setData({
                            stateList: Object.keys(e.data.localityLookupMap)
                        });

                      case 23:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 3, 15 ] ]);
            }))();
        },
        goToPickupContact: function() {
            var e = this;
            return l(a().mark(function t() {
                var l, d, n, o, r, s, u, c, v, p, h, m, f, k, g, D, y, S, b;
                return a().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return d = i({}, null === (l = e.data) || void 0 === l ? void 0 : l.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), t.prev = 2, t.next = 5, e.crequest({
                            url: null === (n = e.data.pickupContact) || void 0 === n ? void 0 : n.selectUrl,
                            header: d
                        }, {
                            formUrlEncoded: !0
                        });

                      case 5:
                        if (S = t.sent, wx.hideLoading(), !e.handleAllErrors(null == S ? void 0 : S.data)) {
                            t.next = 9;
                            break;
                        }
                        return t.abrupt("return");

                      case 9:
                        b = null == S || null === (o = S.data) || void 0 === o || null === (r = o.pickupContact) || void 0 === r ? void 0 : r.cancelUrl, 
                        e.setData({
                            isLoading: !1,
                            pickupContactData: null == S ? void 0 : S.data,
                            pickupTerms: null == S || null === (s = S.data) || void 0 === s || null === (u = s.pickupContact) || void 0 === u ? void 0 : u.pickupContactTerms,
                            pickupAddressFields: null == S || null === (c = S.data) || void 0 === c || null === (v = c.pickupContact) || void 0 === v || null === (p = v.mobileAddress) || void 0 === p ? void 0 : p.addressFields,
                            cancelUrl: b,
                            pickupTaxFields: null == S || null === (h = S.data) || void 0 === h || null === (m = h.pickupContact) || void 0 === m || null === (f = m.taxFields) || void 0 === f ? void 0 : f.taxExtendedFields,
                            shippingData: null,
                            invoiceData: null,
                            translations: null == S || null === (k = S.data) || void 0 === k || null === (g = k.pickupContact) || void 0 === g ? void 0 : g.translations,
                            pageTitle: e.data.shared.textAssets.pickupContact,
                            mandatoryAdditionalHeaders: null == S || null === (D = S.data) || void 0 === D || null === (y = D.meta) || void 0 === y ? void 0 : y.mandatoryAdditionalHeaders
                        }), e.fetchMyAppleIdData(), t.next = 19;
                        break;

                      case 14:
                        return t.prev = 14, t.t0 = t.catch(2), wx.hideLoading(), e.handleAllErrors(), t.abrupt("return");

                      case 19:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 2, 14 ] ]);
            }))();
        },
        goToPickupStore: function(e, t) {
            var d = this;
            return l(a().mark(function l() {
                var n, o, r, s, u, c, p, h, m, f, k, g, D, y, S, b, x, w, L, A, T, M, I, P, C, F, U, E;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (null !== (n = d.data.landingData.review) && void 0 !== n && n.omnitureData && (0, 
                        v.trackLinkOmniture)({
                            type: "pickup-selected",
                            omniture: d.data.landingData.review.omnitureData,
                            data: null
                        }), u = (null == e || null === (o = e.currentTarget) || void 0 === o || null === (r = o.dataset) || void 0 === r ? void 0 : r.url) || e, 
                        c = i({}, null === (s = d.data) || void 0 === s ? void 0 : s.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), p = d.data.shared.bootstrap.urls.allstoresinfolite, h = d.data.shared.bootstrap.urls.baselineDataURL, 
                        p) {
                            a.next = 8;
                            break;
                        }
                        throw new Error("goToPickupStore missing allStoresInfoLiteURL");

                      case 8:
                        if (h) {
                            a.next = 10;
                            break;
                        }
                        throw new Error("goToPickupStore missing baselineDataURL");

                      case 10:
                        return a.prev = 10, a.next = 13, d.crequest({
                            url: u,
                            header: c
                        }, {
                            formUrlEncoded: !0
                        });

                      case 13:
                        if (U = a.sent, wx.hideLoading(), !d.handleAllErrors(null == U ? void 0 : U.data)) {
                            a.next = 17;
                            break;
                        }
                        return a.abrupt("return");

                      case 17:
                        E = null == U || null === (m = U.data) || void 0 === m || null === (f = m.pickup) || void 0 === f ? void 0 : f.cancelUrl, 
                        d.setData({
                            isLoading: !1,
                            pickupStoreData: i(i({}, null == U ? void 0 : U.data), {}, {
                                origin: t
                            }),
                            selectPickupStore: null !== (k = null == U || null === (g = U.data) || void 0 === g || null === (D = g.pickup) || void 0 === D || null === (y = D.summaryData) || void 0 === y ? void 0 : y.storeNumber) && void 0 !== k ? k : "",
                            cancelUrl: E,
                            shippingData: null,
                            invoiceData: null,
                            pickupContactData: null,
                            pickupMethodData: null,
                            stateList: Object.keys(null === (S = U.data) || void 0 === S || null === (b = S.pickup) || void 0 === b ? void 0 : b.localityLookupMap),
                            localityLookupMap: null === (x = U.data) || void 0 === x || null === (w = x.pickup) || void 0 === w ? void 0 : w.localityLookupMap,
                            stateValue: "",
                            cityValue: "",
                            districtValue: "",
                            pageTitle: d.data.shared.textAssets.pickupStore,
                            mandatoryAdditionalHeaders: null == U || null === (L = U.data) || void 0 === L || null === (A = L.meta) || void 0 === A ? void 0 : A.mandatoryAdditionalHeaders
                        }), d.getFormFields(null === (T = d.data.pickupStoreData) || void 0 === T || null === (M = T.pickup) || void 0 === M ? void 0 : M.mobileAddress), 
                        d.getProductInfo(null === (I = d.data.pickupStoreData) || void 0 === I || null === (P = I.pickup) || void 0 === P ? void 0 : P.summaryData, null === (C = d.data.pickupStoreData) || void 0 === C || null === (F = C.pickup) || void 0 === F ? void 0 : F.cartItems, null), 
                        d.fetchStoreMapping(p), d.fetchCommonData(h), d.getLocation(), wx.hideLoading(), 
                        a.next = 32;
                        break;

                      case 27:
                        return a.prev = 27, a.t0 = a.catch(10), wx.hideLoading(), d.handleAllErrors(), a.abrupt("return");

                      case 32:
                      case "end":
                        return a.stop();
                    }
                }, l, null, [ [ 10, 27 ] ]);
            }))();
        },
        goToIDLShipping: function(e, t) {
            var d = this;
            return l(a().mark(function l() {
                var n, o, r, s, u, c, v, p, h, m, f, k, g, D, y;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return o = i({}, null === (n = d.data) || void 0 === n ? void 0 : n.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), a.prev = 2, a.next = 5, d.crequest({
                            url: e,
                            method: "POST",
                            header: o,
                            data: i({}, t)
                        }, {
                            formUrlEncoded: !0
                        });

                      case 5:
                        (r = a.sent).data && (h = r.data, m = null === (s = r.data.idlShipping) || void 0 === s ? void 0 : s.translations, 
                        f = null === (u = r.data.idlShipping) || void 0 === u ? void 0 : u.mobileAddress, 
                        k = d.getSection(f, "sectionHeader"), g = null === (c = r.data.idlShipping) || void 0 === c ? void 0 : c.cancelUrl, 
                        d.setData({
                            localityLookupMap: require("./localityLookupMap.js").default,
                            stateList: Object.keys(require("./localityLookupMap.js").default),
                            mandatoryAdditionalHeaders: null === (v = r.data) || void 0 === v || null === (p = v.meta) || void 0 === p ? void 0 : p.mandatoryAdditionalHeaders
                        }), D = d.getIDLFormListFields(f, m), y = D.formListFields, D.errorFields, d.setData({
                            idlShippingData: i(i({}, h), {}, {
                                idlAddressPageHeader: k,
                                idlRequestData: t
                            }),
                            formListsFields: y,
                            addressFields: null == f ? void 0 : f.addressFields,
                            cancelUrl: g
                        }), d.enableIdlShippingSaveBtn(), wx.hideLoading()), a.next = 13;
                        break;

                      case 9:
                        return a.prev = 9, a.t0 = a.catch(2), console.error("failed", a.t0), a.abrupt("return");

                      case 13:
                      case "end":
                        return a.stop();
                    }
                }, l, null, [ [ 2, 9 ] ]);
            }))();
        },
        handleDeliveryLocation: function() {
            var e = this;
            return l(a().mark(function t() {
                var l, d, n, o, r, s, u, c, v, p, h, m, f, k, g, D, y, S, b;
                return a().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return n = e.data.landingData.review.deliveryLocation, o = i({}, null === (l = e.data.landingData) || void 0 === l || null === (d = l.meta) || void 0 === d ? void 0 : d.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), t.prev = 3, t.next = 6, e.crequest({
                            url: n.selectUrl,
                            method: "POST",
                            header: o
                        }, {
                            formUrlEncoded: !0
                        });

                      case 6:
                        (r = t.sent).data && (f = r.data, k = null === (s = r.data.deliveryLocation) || void 0 === s ? void 0 : s.translations, 
                        g = null === (u = r.data.deliveryLocation) || void 0 === u ? void 0 : u.mobileAddress, 
                        D = e.getSection(g, "sectionHeader"), y = null === (c = r.data.deliveryLocation) || void 0 === c ? void 0 : c.cancelUrl, 
                        e.setData({
                            localityLookupMap: require("./localityLookupMap.js").default,
                            stateList: Object.keys(require("./localityLookupMap.js").default),
                            cancelUrl: y,
                            mandatoryAdditionalHeaders: null === (v = r.data) || void 0 === v || null === (p = v.meta) || void 0 === p ? void 0 : p.mandatoryAdditionalHeaders
                        }), S = e.getIDLFormListFields(g, k), b = S.formListFields, S.errorFields, e.setData({
                            deliveryLocationData: i(i({}, f), {}, {
                                deliveryLocationPageHeader: D
                            }),
                            addressFields: null === (h = r.data.deliveryLocation) || void 0 === h || null === (m = h.mobileAddress) || void 0 === m ? void 0 : m.addressFields,
                            formListsFields: b
                        }), e.enableIdlShippingSaveBtn(), wx.hideLoading()), t.next = 14;
                        break;

                      case 10:
                        return t.prev = 10, t.t0 = t.catch(3), console.error("failed", t.t0), t.abrupt("return");

                      case 14:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 3, 10 ] ]);
            }))();
        },
        returnFormListField: function(e, t) {
            var a = this;
            if (e && e.fields && e.fields.length > 0) {
                var i = [], l = [], d = null, n = null;
                if (e.fields.map(function(e) {
                    if (void 0 !== e.visible && !e.visible) return null;
                    d || (d = e.name), n || (n = "state" === e.id || "city" === e.id || "district" === e.id ? "select" : "input"), 
                    e.required && !e.valid && l.push(e.id), i.push({
                        placeholder: e.required ? t.placeHolderRequired : t.placeHolderOptional,
                        name: e.id,
                        optional: !e.required,
                        constant: !e.allowsEditing,
                        value: e.value,
                        maxLength: e.maxLength,
                        validRegexes: e.validRegexes,
                        invalidValue: e.invalidValue,
                        isMasked: e.isMasked
                    }), "state" === e.id && e.value ? a.setData({
                        stateValue: e.value,
                        cityList: Object.keys(a.data.localityLookupMap[null == e ? void 0 : e.value])
                    }) : "district" === e.id && e.value ? a.setData({
                        districtValue: e.value
                    }) : "city" === e.id && e.value && a.setData({
                        cityValue: e.value,
                        districtList: a.data.localityLookupMap[a.data.stateValue][e.value].districts
                    });
                }), i.length > 0) return {
                    formListField: {
                        type: n,
                        fields: i,
                        key: d,
                        label: d
                    },
                    errors: l
                };
            }
            return {
                formListField: null,
                errors: null
            };
        },
        getIDLFormListFields: function(e, a) {
            var i, l = this, d = [], n = [], o = ((null == e ? void 0 : e.addressFields) || []).find(function(e) {
                return (e.cells || []).find(function(e) {
                    return (e.fields || []).find(function(e) {
                        return "state" === e.id;
                    });
                });
            });
            return null != o && null !== (i = o.cells) && void 0 !== i && i.length && o.cells.map(function(e) {
                var i = l.returnFormListField(e, a), o = i.formListField, r = i.errors;
                o && (d.push(o), r && r.length > 0 && (n = [].concat(t(n), t(r))));
            }), {
                formListFields: d,
                errorFields: n
            };
        },
        getSection: function(e, t) {
            if (e && e.addressFields && e.addressFields.length > 0) for (var a = 0; a < e.addressFields.length; a++) if (e.addressFields[a][t]) return e.addressFields[a][t];
            return null;
        },
        getLocation: function() {
            var e = this;
            wx.getLocation({
                type: "wgs84",
                success: function(t) {
                    e.setData({
                        userLatLong: {
                            latitude: "31.2177103950979",
                            longitude: "121.453084945679",
                            errMsg: "res.errMsg"
                        }
                    }), wx.setStorageSync("userLatLong", {
                        latitude: "31.2177103950979",
                        longitude: "121.453084945679"
                    });
                },
                fail: function(e) {
                    console.log(e);
                }
            });
        },
        openStoreDetails: function(e) {
            var t = this;
            return l(a().mark(function l() {
                var d, n, o, r, s, u, c, v, p, h, m, f, k, g, D;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (n = t.data.shared.bootstrap.urls.storedetails) {
                            a.next = 3;
                            break;
                        }
                        throw new Error("openStoreDetails: Missing storedetails URL");

                      case 3:
                        return o = e.currentTarget.dataset, r = i({}, null === (d = t.data) || void 0 === d ? void 0 : d.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), t.setData({
                            fetchingStoreDetails: !0
                        }), a.prev = 7, a.next = 10, t.crequest({
                            url: n,
                            header: r,
                            data: i({}, o)
                        }, {
                            formUrlEncoded: !0
                        });

                      case 10:
                        u = a.sent, (c = null === (s = u.data.responseModel) || void 0 === s ? void 0 : s.extraStoreInfo) && (D = null === (v = u.data.responseModel) || void 0 === v || null === (p = v.storeHours) || void 0 === p ? void 0 : p.find(function(e) {
                            return e.special;
                        }), t.setData({
                            fetchingStoreDetails: !1,
                            storeDetailsResponse: u.data.responseModel,
                            storeDetails: c,
                            storeSpecialHoursData: D,
                            storePickupMethods: (null === (h = u.data.responseModel) || void 0 === h || null === (m = h.supportedPickupTypes) || void 0 === m ? void 0 : m.map(function(e) {
                                return e.toLowerCase();
                            })) || [],
                            storeDetailsEncodedUrls: {
                                pickupMethodCompareLink: encodeURIComponent(t.data.commonData.translations["pickup_method.compare.link"]),
                                healthAndSafetySectionLink: encodeURIComponent(null === (f = u.data.responseModel) || void 0 === f || null === (k = f.healthAndSafetySection) || void 0 === k || null === (g = k.link) || void 0 === g ? void 0 : g.weChatLink)
                            }
                        }), wx.hideLoading()), a.next = 20;
                        break;

                      case 15:
                        return a.prev = 15, a.t0 = a.catch(7), wx.hideLoading(), t.handleAllErrors(), a.abrupt("return");

                      case 20:
                      case "end":
                        return a.stop();
                    }
                }, l, null, [ [ 7, 15 ] ]);
            }))();
        },
        closeStoreDetails: function() {
            this.setData({
                storeDetailsResponse: null
            });
        },
        fetchCommonData: function(e) {
            var t = this;
            wx.showLoading({
                title: "加载中",
                mask: !0
            }), this.crequest({
                url: e,
                data: {
                    type: "json"
                },
                method: "GET",
                success: function(e) {
                    t.setData({
                        commonData: e.data
                    }), wx.hideLoading();
                },
                fail: function() {
                    console.log("FAILED");
                },
                complete: function() {
                    console.log("COMPLETED");
                }
            });
        },
        fetchNearerStores: function(e) {
            wx.showLoading({
                title: "加载中",
                mask: !0
            });
            var t = wx.getStorageSync("userLatLong") || this.data.userLatLong;
            t = {
                latitude: "31.2177103950979",
                longitude: "121.453084945679"
            };
            for (var a = (0, u.getFourtyMileNearStoreData)(e, t) || [], l = [], d = 0; d < a.length; d++) {
                var n = (0, u.prependAppleToStoreName)(a[d].localizedStoreName || a[d].storeName);
                l.push(i(i({}, a[d]), {}, {
                    storeName: n
                }));
            }
            if ((null == l ? void 0 : l.length) > 0) {
                var o = null == l ? void 0 : l.find(function(e) {
                    return e.checked;
                });
                this.setData({
                    nearerPickupStores: l,
                    requestSource: "nearbyStores",
                    enablePickupStoreSaveButton: !(null == o || !o.storeNumber)
                }), wx.hideLoading();
            }
        },
        fetchStoreMapping: function(e) {
            var t = this;
            return l(a().mark(function l() {
                var d, n, o, r, s, c, v, p, h, m;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return n = i({}, null === (d = t.data) || void 0 === d ? void 0 : d.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), a.prev = 2, a.next = 5, t.crequest({
                            url: e,
                            data: {
                                type: "json"
                            },
                            header: n
                        }, {
                            formUrlEncoded: !0
                        });

                      case 5:
                        o = a.sent, v = (0, u.getStoreMapping)(o.data), t.setData({
                            storeMappings: v
                        }), null !== (r = t.data) && void 0 !== r && r.storeMappings && (t.fetchNearerStores(v), 
                        t.getSavedStores(null === (p = t.data.pickupStoreData) || void 0 === p || null === (h = p.pickup) || void 0 === h ? void 0 : h.summaryData, v)), 
                        (null === (s = t.data) || void 0 === s || null === (c = s.nearerPickupStores) || void 0 === c ? void 0 : c.length) > 0 && t.data.pickupStoreData && t.updateAvailibityOfStores(null === (m = t.data) || void 0 === m ? void 0 : m.nearerPickupStores, "nearbyStores", t.data.pickupStoreData), 
                        wx.hideLoading(), a.next = 18;
                        break;

                      case 13:
                        return a.prev = 13, a.t0 = a.catch(2), wx.hideLoading(), t.handleAllErrors(), a.abrupt("return");

                      case 18:
                      case "end":
                        return a.stop();
                    }
                }, l, null, [ [ 2, 13 ] ]);
            }))();
        },
        getSavedStores: function(e, t) {
            var a = e.storeNumber, i = a && t && t[a];
            i && this.data.pickupStoreData && this.data.selectedProduct && (this.setData({
                checkingAvailabilityForStoreNumber: a
            }), this.updateAvailibityOfStores([ i ], "savedStores", this.data.pickupStoreData));
        },
        setSelectedProduct: function(e) {
            if (e) {
                var t = e.checkAvailabilityItemId, a = e.checkAvailabilityItemName;
                this.setData({
                    selectedProduct: {
                        lineItemId: t,
                        name: a
                    }
                });
            }
        },
        updateAvailibityOfStores: function(t, a, i) {
            var l = i.pickup || {}, d = l.checkAvailabilityUrl, n = l.retailAvailabilityData.keyPath;
            if (d && this.data.selectedProduct) {
                var o, r = "", s = "";
                t.forEach(function(e) {
                    r = r ? r + ";" + e.storeNumber : e.storeNumber, s = s ? s + ";" + e.countryCode : e.countryCode;
                });
                var u = n + (t.length > 1 ? ".currentRetailIds" : ".currentRetailId"), c = n + (t.length > 1 ? ".currentRetailCountries" : ".currentRetailCountry"), v = (e(o = {}, c, s), 
                e(o, u, r), e(o, n + ".cartLineItemId", this.data.selectedProduct.lineItemId), o);
                d && v && this.fetchProductAvailabilityInStores(d, v, a);
            }
        },
        fetchProductAvailabilityInStores: function(t, d, n) {
            var o = this;
            return l(a().mark(function l() {
                var r, s, u, c, v, p, h, m, f, k, g, D, y, S, b, x, w, L, A, T, M;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return s = i({}, null === (r = o.data) || void 0 === r ? void 0 : r.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), a.prev = 2, a.next = 5, o.crequest({
                            url: t,
                            header: s,
                            data: d
                        }, {
                            formUrlEncoded: !0
                        });

                      case 5:
                        if (null != (c = a.sent) && null !== (u = c.data) && void 0 !== u && u.pickup) {
                            for (h = c.data.pickup || {}, m = h.retailAvailabilityData, f = m.results, k = m.recommendedResults, 
                            g = {}, D = {}, (f || []).map(function(e) {
                                D[e.storeNumber] = e.pickupMethodOmniture, g[e.storeNumber] = i(i({}, e), {}, {
                                    requestSource: n
                                });
                            }), f = i(i({}, o.data.availability), {}, (e(p = {}, n, f), e(p, "recommendedStores", "searchedStores" !== n && k ? k : null === (v = o.data.availability) || void 0 === v ? void 0 : v.recommendedStores), 
                            p)), y = [], f && o.data.storeMappings && (b = null === (S = f) || void 0 === S ? void 0 : S.savedStores, 
                            (x = o.data.storeMappings) && (b || []).map(function(e) {
                                x[e.storeNumber] && y.push(x[e.storeNumber]);
                            })), "nearbyStores" === n ? o.setData({
                                nearbyUpdatedAvailibility: g
                            }) : "savedStores" === n ? o.setData({
                                savedUpdatedAvailibility: g
                            }) : o.setData({
                                searchedUpdatedAvailibility: g
                            }), L = 0; L < y.length; L++) A = o.data.savedUpdatedAvailibility[y[L].storeNumber], 
                            "savedStores" === n && (w = o.checkTheStore(y, A, y[L].storeNumber), M = null === (T = w) || void 0 === T ? void 0 : T.find(function(e) {
                                return e.checked;
                            }), o.setData({
                                savedStoresList: w,
                                enablePickupStoreSaveButton: !(null == M || !M.storeNumber)
                            }));
                            o.setData({
                                storePickupMethodMapping: D,
                                requestSource: n,
                                availability: f,
                                updatedAvailibility: g
                            });
                        }
                        wx.hideLoading(), a.next = 15;
                        break;

                      case 10:
                        return a.prev = 10, a.t0 = a.catch(2), wx.hideLoading(), o.handleAllErrors(), a.abrupt("return");

                      case 15:
                      case "end":
                        return a.stop();
                    }
                }, l, null, [ [ 2, 10 ] ]);
            }))();
        },
        getProductInfo: function(e, t, a) {
            var i = "", l = e.checkAvailabilityItemId, d = e.checkAvailabilityItemName, n = a || {
                lineItemId: l,
                name: d
            };
            i = (null == t ? void 0 : t.length) <= 2 ? e && e.checkAvailabilityItemName : n.name;
            var o = null == t ? void 0 : t.map(function(e) {
                return e.name;
            });
            this.setData({
                productDisplayName: i,
                selectedProduct: n,
                cartItemsNameList: o
            });
        },
        handleProductSelectionChange: function(e) {
            var t, a, i, l, d, n, o, r, s, u, c, v, p, h = null === (t = this.data.pickupStoreData) || void 0 === t || null === (a = t.pickup) || void 0 === a || null === (i = a.cartItems) || void 0 === i ? void 0 : i[e.detail.value];
            (this.getProductInfo(null === (l = this.data.pickupStoreData) || void 0 === l || null === (d = l.pickup) || void 0 === d ? void 0 : d.summaryData, null === (n = this.data.pickupStoreData) || void 0 === n || null === (o = n.pickup) || void 0 === o ? void 0 : o.cartItems, h), 
            this.getSavedStores(null === (r = this.data.pickupStoreData) || void 0 === r || null === (s = r.pickup) || void 0 === s ? void 0 : s.summaryData, null === (u = this.data) || void 0 === u ? void 0 : u.storeMappings), 
            (null === (c = this.data) || void 0 === c || null === (v = c.nearerPickupStores) || void 0 === v ? void 0 : v.length) > 0 && this.data.pickupStoreData) && this.updateAvailibityOfStores(null === (p = this.data) || void 0 === p ? void 0 : p.nearerPickupStores, "nearbyStores", this.data.pickupStoreData);
        },
        getFormFields: function(e) {
            var t = this, a = [];
            e && (e.addressFields || []).forEach(function(e) {
                (e.cells || []).forEach(function(e) {
                    (e.fields || []).forEach(function(e) {
                        a.push({
                            type: "select",
                            fields: [ {
                                placeholder: "必填",
                                name: e.id,
                                optional: !e.required,
                                constant: !1,
                                value: t.data.searchedFields && t.data.searchedFields[e.id] || "",
                                maxLength: e.maxLength,
                                keyboardType: "text"
                            } ],
                            key: e.name,
                            label: e.name
                        });
                    });
                });
            }), this.setData({
                formListsFields: a
            });
        },
        selectStore: function(e) {
            var t, a, i = e.detail.value, l = this.data.nearerPickupStores, d = this.data.serachedStoresWithMapping, n = this.data.savedStoresList;
            if ("searchedStores" === this.data.requestSource) {
                var o;
                a = i && this.data.searchedUpdatedAvailibility[i] || {};
                var r = null === (o = t = this.checkTheStore(d, a, i)) || void 0 === o ? void 0 : o.find(function(e) {
                    return e.checked;
                });
                this.setData({
                    serachedStoresWithMapping: t,
                    enableSaveButton: !(null == r || !r.storeNumber)
                });
            } else if ("nearbyStores" === this.data.requestSource) {
                var s, u, c;
                a = i && this.data.nearbyUpdatedAvailibility[i] || {}, t = this.checkTheStore(l, a, i);
                var v = i && this.data.savedUpdatedAvailibility[i] || {};
                n && v && (c = this.checkTheStore(n, v, i));
                var p = null === (s = t) || void 0 === s ? void 0 : s.find(function(e) {
                    return e.checked;
                }), h = null === (u = c) || void 0 === u ? void 0 : u.find(function(e) {
                    return e.checked;
                });
                this.setData({
                    nearerPickupStores: t,
                    savedStoresList: c,
                    enablePickupStoreSaveButton: !(null == p || !p.storeNumber) || !(null == h || !h.storeNumber)
                });
            }
        },
        checkTheStore: function(e, t, a) {
            t && 0 !== Object.keys(t).length && "NOT_AVAILABLE" !== t.availabilityStatus && this.setData({
                selectPickupStore: a
            });
            for (var i = 0; i < (null == e ? void 0 : e.length); i++) e[i].checked = e[i].storeNumber === this.data.selectPickupStore;
            return e;
        },
        savePickupStore: function() {
            var t = this;
            return l(a().mark(function l() {
                var d, n, o, r, s, u, c, v, p, h, m, f, k, g;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (n = (null === (d = t.data.pickupStoreData) || void 0 === d ? void 0 : d.pickup) || {}, 
                        o = n.keyPath, r = n.selectStoreUrl, s = t.data.selectedProduct, u = i({}, t.data.pickupStoreData.meta.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), !s || !t.data.selectPickupStore) {
                            a.next = 22;
                            break;
                        }
                        return e(c = {}, o + ".cartLineItemId", s.lineItemId), e(c, o + ".currentRetailId", t.data.selectPickupStore), 
                        f = c, "PickupMethod" === (null === (v = t.data.pickupStoreData) || void 0 === v ? void 0 : v.origin) && (f = i(i({}, f), {}, {
                            timeSlotRequest: !0
                        })), a.next = 9, t.crequest({
                            url: r,
                            method: "POST",
                            header: u,
                            data: f
                        }, {
                            formUrlEncoded: !0
                        });

                      case 9:
                        if (k = a.sent, !t.handleAllErrors(null == k ? void 0 : k.data)) {
                            a.next = 12;
                            break;
                        }
                        return a.abrupt("return");

                      case 12:
                        if (null == k || null === (p = k.data) || void 0 === p || !p.timeSlot) {
                            a.next = 17;
                            break;
                        }
                        return g = k.data.timeSlot, t.updatePickupMethodData(g), wx.hideLoading(), a.abrupt("return");

                      case 17:
                        t.showAlerts(null == k ? void 0 : k.data), t.setData({
                            isLoading: !1,
                            shippingData: null,
                            invoiceData: null,
                            pickupStoreData: null,
                            landingData: k.data,
                            showSearchedStoresByLocation: !1,
                            pageTitle: t.data.shared.textAssets.checkout,
                            mandatoryAdditionalHeaders: null === (h = k.data) || void 0 === h || null === (m = h.meta) || void 0 === m ? void 0 : m.mandatoryAdditionalHeaders
                        }), t.getItemsData(k.data), t.getSpokesData(k.data), wx.hideLoading();

                      case 22:
                      case "end":
                        return a.stop();
                    }
                }, l);
            }))();
        },
        handleCancel: function() {
            this.setData({
                showSearchedStoresByLocation: !1,
                requestSource: "nearbyStores"
            });
        },
        handlePickUpTaxInput: function(t) {
            var a = t.currentTarget.id, l = t.detail.value;
            this.setData({
                pickupTaxData: i(i({}, this.data.pickupTaxData), {}, e({}, a, l))
            });
        },
        handlePickUpContactInput: function(t) {
            var a = t.currentTarget.id, l = t.detail.value;
            this.setData({
                pickupContactFields: i(i({}, this.data.pickupContactFields), {}, e({}, a, l))
            });
        },
        handlePickupContactSubmit: function() {
            var t = this;
            return l(a().mark(function l() {
                var d, n, o, r, s, u, c, v, p, h, m, f, k, g, D, y, S, b, x, w, L, A, T, M, I, P, C, F, U, E, O, V, H, q, R, N;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (m = [], f = {}, null === (d = t.data) || void 0 === d || null === (n = d.pickupTaxFields) || void 0 === n || n.map(function(e) {
                            var a = t.data.pickupTaxData[e.id];
                            e.required && !a ? (m.push(e.id), e.alertMessage ? g = e.requiredError : a && (e.validRegexes || []).length > 0 && !t.checkValueMatchesRegex(a, e.validRegexes) && (m.push(e.id), 
                            g = e.invalidErrorMsg || e.invalidValue)) : a && (e.validRegexes || []).length > 0 && !t.checkValueMatchesRegex(a, e.validRegexes) && (m.push(e.id), 
                            g = e.invalidErrorMsg || e.invalidValue);
                        }), t.data.pickupAddressFields[1].cells.map(function(e) {
                            e.fields.forEach(function(e) {
                                var a = t.data.pickupContactFields[e.id];
                                e.required && !a ? (m.push(e.id), e.alertMessage && (g = e.alertMessage)) : a && (e.validRegexes || []).length > 0 && !t.checkValueMatchesRegex(a, e.validRegexes) && (m.push(e.id), 
                                g = e.invalidErrorMsg || e.invalidValue);
                            });
                        }), t.setData({
                            pickUpErrorFields: m
                        }), k = t.data.translations.alertMessageText, 1 === (null == m ? void 0 : m.length) && (k = g || k), 
                        !(m.length > 0)) {
                            a.next = 10;
                            break;
                        }
                        return wx.showToast({
                            title: "".concat(k),
                            icon: "none",
                            duration: 3e3
                        }), a.abrupt("return");

                      case 10:
                        if (t.data.termsPickupContactChecked) {
                            a.next = 13;
                            break;
                        }
                        return wx.showToast({
                            title: "".concat(t.data.translations.termsAlertMessageText),
                            icon: "none",
                            duration: 3e3
                        }), a.abrupt("return");

                      case 13:
                        return Object.keys(t.data.pickupContactFields).map(function(a) {
                            var l, d, n, o;
                            f = i(i({}, f), {}, e({}, "".concat(null === (l = t.data.pickupContactData) || void 0 === l || null === (d = l.pickupContact) || void 0 === d || null === (n = d.mobileAddress) || void 0 === n || null === (o = n.addressData) || void 0 === o ? void 0 : o.keyPath, ".").concat(a), t.data.pickupContactFields[a]));
                        }), Object.keys(t.data.pickupTaxData).map(function(a) {
                            var l, d, n;
                            f = i(i({}, f), {}, e({}, "".concat(null === (l = t.data.pickupContactData) || void 0 === l || null === (d = l.pickupContact) || void 0 === d || null === (n = d.taxFields) || void 0 === n ? void 0 : n.keyPath, ".").concat(a), t.data.pickupTaxData[a]));
                        }), f = i(i({}, f), {}, e({}, "".concat(null === (o = t.data.pickupContactData) || void 0 === o || null === (r = o.pickupContact) || void 0 === r || null === (s = r.pickupContactTerms) || void 0 === s ? void 0 : s.keyPath, ".terms-accept"), t.data.termsPickupContactChecked)), 
                        D = i({}, null === (u = t.data) || void 0 === u ? void 0 : u.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), a.next = 20, t.crequest({
                            url: null === (c = t.data.pickupContactData) || void 0 === c || null === (v = c.pickupContact) || void 0 === v ? void 0 : v.saveThirdPartyPickupUrl,
                            method: "POST",
                            header: D,
                            data: f
                        }, {
                            formUrlEncoded: !0
                        });

                      case 20:
                        if (y = a.sent, !t.handleAllErrors(null == y ? void 0 : y.data)) {
                            a.next = 23;
                            break;
                        }
                        return a.abrupt("return");

                      case 23:
                        "mmap-pickup" === (null == y || null === (p = y.data) || void 0 === p || null === (h = p.pickupContact) || void 0 === h ? void 0 : h.view) ? ((q = null === (S = y.data.pickupContact.pickupContactMessages) || void 0 === S || null === (b = S.messages) || void 0 === b || null === (x = b.errors) || void 0 === x ? void 0 : x[0]) && wx.showToast({
                            title: q,
                            icon: "none",
                            duration: 3e3
                        }), t.setData({
                            isLoading: !1,
                            pickupContactData: null == y ? void 0 : y.data,
                            pickupTerms: null == y || null === (w = y.data) || void 0 === w || null === (L = w.pickupContact) || void 0 === L ? void 0 : L.pickupContactTerms,
                            pickupAddressFields: null == y || null === (A = y.data) || void 0 === A || null === (T = A.pickupContact) || void 0 === T || null === (M = T.mobileAddress) || void 0 === M ? void 0 : M.addressFields,
                            pickupTaxFields: null == y || null === (I = y.data) || void 0 === I || null === (P = I.pickupContact) || void 0 === P || null === (C = P.taxFields) || void 0 === C ? void 0 : C.taxExtendedFields,
                            shippingData: null,
                            invoiceData: null,
                            mandatoryAdditionalHeaders: null === (F = y.data) || void 0 === F || null === (U = F.meta) || void 0 === U ? void 0 : U.mandatoryAdditionalHeaders,
                            translations: null == y || null === (E = y.data) || void 0 === E || null === (O = E.pickupContact) || void 0 === O ? void 0 : O.translations,
                            cancelUrl: null == y || null === (V = y.data) || void 0 === V || null === (H = V.pickupContact) || void 0 === H ? void 0 : H.cancelUrl
                        })) : (t.showAlerts(null == y ? void 0 : y.data), t.setData({
                            isLoading: !1,
                            shippingData: null,
                            invoiceData: null,
                            pickupContactData: null,
                            landingData: y.data,
                            pageTitle: t.data.shared.textAssets.checkout,
                            mandatoryAdditionalHeaders: null === (R = y.data) || void 0 === R || null === (N = R.meta) || void 0 === N ? void 0 : N.mandatoryAdditionalHeaders
                        }), t.getItemsData(y.data), t.getSpokesData(y.data), wx.hideLoading());

                      case 24:
                      case "end":
                        return a.stop();
                    }
                }, l);
            }))();
        },
        termsPickupContact: function() {
            this.setData({
                termsPickupContactChecked: !this.data.termsPickupContactChecked
            });
        },
        goToPickupMethod: function() {
            var e = this;
            return l(a().mark(function t() {
                var l, d, n, o, r, s, u, c;
                return a().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return d = i({}, null === (l = e.data) || void 0 === l ? void 0 : l.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), t.prev = 2, t.next = 5, e.crequest({
                            url: null === (n = e.data.pickupMethod) || void 0 === n ? void 0 : n.selectUrl,
                            header: d
                        }, {
                            formUrlEncoded: !0
                        });

                      case 5:
                        if (u = t.sent, !e.handleAllErrors(null == u ? void 0 : u.data)) {
                            t.next = 8;
                            break;
                        }
                        return t.abrupt("return");

                      case 8:
                        e.setData({
                            mandatoryAdditionalHeaders: null === (o = u.data) || void 0 === o || null === (r = o.meta) || void 0 === r ? void 0 : r.mandatoryAdditionalHeaders
                        }), (c = null == u || null === (s = u.data) || void 0 === s ? void 0 : s.timeSlot) && e.updatePickupMethodData(c), 
                        wx.hideLoading(), t.next = 19;
                        break;

                      case 14:
                        return t.prev = 14, t.t0 = t.catch(2), wx.hideLoading(), e.handleAllErrors(), t.abrupt("return");

                      case 19:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 2, 14 ] ]);
            }))();
        },
        handlePickupMethodChange: function(t) {
            var d = this;
            return l(a().mark(function l() {
                var n, o, r, s, u, c, v, p, h, m, f;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), o = d.data.pickupMethodData, r = o.keyPath, s = o.selectPickupMethodUrl, u = e({}, "".concat(r, ".selectedMethod"), t.detail.value), 
                        c = i({}, null === (n = d.data) || void 0 === n ? void 0 : n.mandatoryAdditionalHeaders), 
                        !s) {
                            a.next = 20;
                            break;
                        }
                        return a.prev = 5, a.next = 8, d.crequest({
                            url: s,
                            method: "POST",
                            data: u,
                            header: c
                        }, {
                            formUrlEncoded: !0
                        });

                      case 8:
                        m = a.sent, f = null == m || null === (v = m.data) || void 0 === v ? void 0 : v.timeSlot, 
                        d.setData({
                            mandatoryAdditionalHeaders: null === (p = m.data) || void 0 === p || null === (h = p.meta) || void 0 === h ? void 0 : h.mandatoryAdditionalHeaders
                        }), f && d.updatePickupMethodData(f), wx.hideLoading(), a.next = 20;
                        break;

                      case 15:
                        return a.prev = 15, a.t0 = a.catch(5), wx.hideLoading(), d.handleAllErrors(), a.abrupt("return");

                      case 20:
                      case "end":
                        return a.stop();
                    }
                }, l, null, [ [ 5, 15 ] ]);
            }))();
        },
        updatePickupMethodData: function(e) {
            var t, a;
            this.setData({
                isLoading: !1,
                pickupStoreData: null,
                shippingData: null,
                invoiceData: null,
                pickupContactData: null,
                cancelUrl: null == e ? void 0 : e.cancelUrl,
                showErrorPage: !(null != e && null !== (t = e.availablePickupMethods) && void 0 !== t && t.length) && !(null != e && null !== (a = e.daySlots) && void 0 !== a && a.length) && (null == e ? void 0 : e.translations),
                pickupMethodData: {
                    headerItems: null == e ? void 0 : e.items,
                    availablePickupMethods: null == e ? void 0 : e.availablePickupMethods,
                    translations: null == e ? void 0 : e.translations,
                    daySlots: null == e ? void 0 : e.daySlots,
                    recommendedSlots: null == e ? void 0 : e.recommendedSlots,
                    selectedStoreName: null == e ? void 0 : e.pickupStore,
                    isLoading: !1,
                    manuallySelectDateTime: !1,
                    selectedMethod: e.selectedStorePickupMethod,
                    keyPath: e.keyPath,
                    selectPickupMethodUrl: e.selectPickupMethodUrl,
                    saveUrl: e.saveUrl,
                    switchUrl: e.switchUrl,
                    checkinWindowEnabled: null == e ? void 0 : e.checkinWindowEnabled,
                    selectedTimeSlot: null == e ? void 0 : e.selectedTimeSlot,
                    selectedRecommendedTimeSlot: null == e ? void 0 : e.selectedRecommendedTimeSlot,
                    changeStoreEnabled: null == e ? void 0 : e.changeStoreEnabled,
                    changeStoreUrl: null == e ? void 0 : e.changeStoreUrl
                }
            }), this.setDefaultDateAndTime(), this.setManuallySelectDateTime(), this.updateTimeSlots();
        },
        setDefaultDateAndTime: function() {
            var e, t, a = this.data.pickupMethodData || {}, l = a.recommendedSlots, d = a.selectedTimeSlot, n = a.selectedRecommendedTimeSlot, o = a.daySlots, r = Array.isArray(l) && l.find(function(e) {
                return e.id === d;
            });
            if (d && (!n || n && !r)) e = ((o || []).find(function(e) {
                return e.enabled && (e.timeSlots || []).find(function(e) {
                    return e.id === d && (t = e.time, !0);
                });
            }) || {}).date, this.setData({
                pickupMethodData: i(i({}, this.data.pickupMethodData), {}, {
                    selectedDate: e,
                    selectedTime: t
                })
            }); else if (d && n) this.setData({
                pickupMethodData: i(i({}, this.data.pickupMethodData), {}, {
                    selectedRecommendedSlot: r
                })
            }); else {
                var s = ((o || []).find(function(e) {
                    return e.defaultSelection;
                }) || {}).date;
                this.setData({
                    pickupMethodData: i(i({}, this.data.pickupMethodData), {}, {
                        selectedDate: s
                    })
                });
            }
        },
        setManuallySelectDateTime: function() {
            var e = this.data.pickupMethodData || {}, t = e.recommendedSlots, a = e.selectedTimeSlot, l = e.selectedRecommendedTimeSlot, d = e.checkinWindowEnabled;
            this.setData({
                pickupMethodData: i(i({}, this.data.pickupMethodData), {}, {
                    manuallySelectDateTime: !l && a || !(d && t && t.length > 0) || l && a && Array.isArray(t) && !t.find(function(e) {
                        return e.id === a;
                    })
                })
            });
        },
        recommendedSectionTap: function(e) {
            var t, a, l, d = null == e || null === (t = e.detail) || void 0 === t ? void 0 : t.value, n = null, o = !0;
            d && (n = null === (a = this.data.pickupMethodData) || void 0 === a || null === (l = a.recommendedSlots) || void 0 === l ? void 0 : l.find(function(e) {
                return e.id === d;
            }), o = !1);
            this.setData({
                pickupMethodData: i(i({}, this.data.pickupMethodData), {}, {
                    selectedRecommendedSlot: n,
                    manuallySelectDateTime: o
                })
            });
        },
        updateTimeSlots: function() {
            var e, t, a = this;
            null === (e = this.data.pickupMethodData) || void 0 === e || null === (t = e.daySlots) || void 0 === t || t.forEach(function(e) {
                var t;
                (null == e ? void 0 : e.date) === (null === (t = a.data.pickupMethodData) || void 0 === t ? void 0 : t.selectedDate) && a.setData({
                    pickupMethodData: i(i({}, a.data.pickupMethodData), {}, {
                        timeSlots: null == e ? void 0 : e.timeSlots.map(function(e) {
                            return null == e ? void 0 : e.time;
                        })
                    })
                });
            });
        },
        onDateSelection: function(e) {
            var t;
            this.setData({
                pickupMethodData: i(i({}, this.data.pickupMethodData), {}, {
                    selectedDate: null === (t = e.currentTarget.dataset.id) || void 0 === t ? void 0 : t.date
                })
            }), this.updateTimeSlots();
        },
        onTimeSlotChange: function(e) {
            var t, a;
            this.setData({
                pickupMethodData: i(i({}, this.data.pickupMethodData), {}, {
                    selectedTime: null === (t = this.data.pickupMethodData) || void 0 === t || null === (a = t.timeSlots) || void 0 === a ? void 0 : a[e.detail.value]
                })
            });
        },
        changeStore: function() {
            var e = this;
            return l(a().mark(function t() {
                var i, l;
                return a().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        i = e.data.pickupMethodData || {}, (l = i.changeStoreUrl) && e.goToPickupStore(l, "PickupMethod");

                      case 2:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        switchToDelivery: function() {
            var e = this;
            return l(a().mark(function t() {
                var l, d, n, o, r;
                return a().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (l = e.data.pickupMethodData.switchUrl, wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), !l) {
                            t.next = 20;
                            break;
                        }
                        return t.prev = 3, t.next = 6, e.crequest({
                            url: l,
                            method: "POST",
                            header: null === (d = e.data) || void 0 === d ? void 0 : d.mandatoryAdditionalHeaders
                        }, {
                            formUrlEncoded: !0
                        });

                      case 6:
                        if (r = t.sent, wx.hideLoading(), !e.handleAllErrors(null == r ? void 0 : r.data)) {
                            t.next = 10;
                            break;
                        }
                        return t.abrupt("return");

                      case 10:
                        e.setData(i(i({
                            isLoading: !1,
                            pickupMethodData: null
                        }, r.data), {}, {
                            shared: i({}, e.data.shared),
                            mandatoryAdditionalHeaders: null === (n = r.data) || void 0 === n || null === (o = n.meta) || void 0 === o ? void 0 : o.mandatoryAdditionalHeaders
                        })), e.getItemsData(r.data), e.getSpokesData(r.data), t.next = 20;
                        break;

                      case 15:
                        return t.prev = 15, t.t0 = t.catch(3), wx.hideLoading(), e.handleAllErrors(), t.abrupt("return");

                      case 20:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 3, 15 ] ]);
            }))();
        },
        switchToDeliveryTimeSlot: function() {
            var e = this;
            return l(a().mark(function t() {
                var l, d, n, o, r, s, u;
                return a().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (d = null === (l = e.data.idlTimeSlotsData) || void 0 === l ? void 0 : l.deliveryTimeSlot, 
                        n = d.switchUrl, wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), !n) {
                            t.next = 20;
                            break;
                        }
                        return t.prev = 3, t.next = 6, e.crequest({
                            url: n,
                            method: "POST",
                            header: null === (o = e.data) || void 0 === o ? void 0 : o.mandatoryAdditionalHeaders
                        }, {
                            formUrlEncoded: !0
                        });

                      case 6:
                        if (u = t.sent, wx.hideLoading(), !e.handleAllErrors(null == u ? void 0 : u.data)) {
                            t.next = 10;
                            break;
                        }
                        return t.abrupt("return");

                      case 10:
                        e.setData(i(i({
                            isLoading: !1,
                            idlTimeSlotsData: null
                        }, u.data), {}, {
                            shared: i({}, e.data.shared),
                            mandatoryAdditionalHeaders: null === (r = u.data) || void 0 === r || null === (s = r.meta) || void 0 === s ? void 0 : s.mandatoryAdditionalHeaders
                        })), e.getItemsData(u.data), e.getSpokesData(u.data), t.next = 20;
                        break;

                      case 15:
                        return t.prev = 15, t.t0 = t.catch(3), wx.hideLoading(), e.handleAllErrors(), t.abrupt("return");

                      case 20:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 3, 15 ] ]);
            }))();
        },
        saveSelectedPickupMethod: function() {
            var t = this;
            return l(a().mark(function l() {
                var d, n, o, r, s, u, c, v, p, h, m, f, k, g, D, y, S, b, x, w, L, A, T, M, I, P, C, F, U, E;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (n = t.data.pickupMethodData || {}, o = n.daySlots, r = n.selectedDate, s = n.selectedTime, 
                        u = n.selectedMethod, c = n.selectedRecommendedSlot, v = n.saveUrl, p = n.keyPath, 
                        h = n.manuallySelectDateTime, m = n.checkinWindowEnabled, f = n.translations, k = {}, 
                        c ? k = c : h && o && (D = (null == o ? void 0 : o.find(function(e) {
                            return e.date === r;
                        })) || {}, y = (null == D || null === (g = D.timeSlots) || void 0 === g ? void 0 : g.find(function(e) {
                            return e.time === s;
                        })) || {}, k = i(i({}, D), y)), !(m && o && o.length > 0) || k && k.date && k.time) {
                            a.next = 6;
                            break;
                        }
                        return wx.showToast({
                            title: f.completeYourOrder,
                            icon: "none",
                            duration: 3e3
                        }), a.abrupt("return");

                      case 6:
                        if (S = i({}, null === (d = t.data) || void 0 === d ? void 0 : d.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), b = {
                            selectedMethod: u,
                            date: k.date,
                            timeZone: k.timeZone,
                            startTime: k.startTime,
                            endTime: k.endTime,
                            reservationId: k.reservationId,
                            timeSlotId: k.timeSlotId,
                            selectedTimeSlot: k.id,
                            displayTimeSlotStart: k.displayTimeSlotStart,
                            displayTimeSlotEnd: k.displayTimeSlotEnd,
                            recommendedTimeSlot: !!c
                        }, u || (b.selectedMethod = "INSTORE"), x = {}, Object.keys(b).map(function(t) {
                            void 0 !== b[t] && (x = i(i({}, x), {}, e({}, "".concat(p, ".").concat(t), b[t])));
                        }), !v) {
                            a.next = 29;
                            break;
                        }
                        return a.prev = 13, a.next = 16, t.crequest({
                            url: v,
                            method: "POST",
                            data: x,
                            header: S
                        }, {
                            formUrlEncoded: !0
                        });

                      case 16:
                        if (M = a.sent, wx.hideLoading(), t.setData({
                            mandatoryAdditionalHeaders: null === (w = M.data) || void 0 === w || null === (L = w.meta) || void 0 === L ? void 0 : L.mandatoryAdditionalHeaders
                        }), !t.handleAllErrors(null == M ? void 0 : M.data)) {
                            a.next = 21;
                            break;
                        }
                        return a.abrupt("return");

                      case 21:
                        "mmap-ts" === (null == M || null === (A = M.data) || void 0 === A || null === (T = A.timeSlot) || void 0 === T ? void 0 : T.view) ? ((U = null === (I = M.data.timeSlot.retailTimeSlotMessages) || void 0 === I || null === (P = I.messages) || void 0 === P || null === (C = P.errors) || void 0 === C ? void 0 : C[0]) && wx.showToast({
                            title: U,
                            icon: "none",
                            duration: 3e3
                        }), (E = null == M || null === (F = M.data) || void 0 === F ? void 0 : F.timeSlot) && t.updatePickupMethodData(E)) : (t.setData(i({
                            isLoading: !1,
                            pickupMethodData: null
                        }, M.data)), t.getItemsData(M.data), t.getSpokesData(M.data)), a.next = 29;
                        break;

                      case 24:
                        return a.prev = 24, a.t0 = a.catch(13), wx.hideLoading(), t.handleAllErrors(), a.abrupt("return");

                      case 29:
                      case "end":
                        return a.stop();
                    }
                }, l, null, [ [ 13, 24 ] ]);
            }))();
        },
        handleInput: function(t) {
            var a = t.currentTarget.id, l = t.detail.value, d = this.data.maskedItems;
            null != d && d.includes(a) && (l = "", d.splice(d.indexOf(a), 1)), this.setData({
                formValues: i(i({}, this.data.formValues), {}, e({}, a, l)),
                maskedItems: d
            });
        },
        onStateChange: function(t) {
            var a, l = t.currentTarget.id;
            this.setData({
                stateValue: this.data.stateList[t.detail.value],
                invoiceFields: i(i({}, this.data.invoiceFields), {}, (a = {}, e(a, l, this.data.stateList[t.detail.value]), 
                e(a, "state", this.data.stateList[t.detail.value]), a))
            }), this.setData({
                cityList: Object.keys(this.data.localityLookupMap[this.data.stateList[t.detail.value]])
            }), this.setData({
                cityValue: "",
                districtValue: ""
            }), this.enableIdlShippingSaveBtn();
        },
        onCityChange: function(t) {
            var a, l = t.currentTarget.id;
            this.setData({
                cityValue: this.data.cityList[t.detail.value],
                invoiceFields: i(i({}, this.data.invoiceFields), {}, (a = {}, e(a, l, this.data.cityList[t.detail.value]), 
                e(a, "city", this.data.cityList[t.detail.value]), a))
            }), this.setData({
                districtList: this.data.localityLookupMap[this.data.stateValue][this.data.cityList[t.detail.value]].districts
            }), this.setData({
                districtValue: ""
            }), this.enableIdlShippingSaveBtn();
        },
        onStreetChange: function(e) {
            this.setData({
                streetValue: e.detail.value
            }), this.enableIdlShippingSaveBtn();
        },
        enableIdlShippingSaveBtn: function() {
            if (this.data.idlShippingData || this.data.deliveryLocationData) {
                var e = this.data, t = e.formListsFields, a = e.stateValue, i = e.street2Value, l = e.streetValue, d = e.districtValue, n = e.cityValue, o = e.districtList, r = e.cityList, s = e.stateList, u = e.postalCodeValue, c = {
                    district: o,
                    city: r,
                    state: s
                }, v = {
                    state: a,
                    city: n,
                    district: d,
                    street: l,
                    street2: i,
                    postalCode: u
                }, p = t && t.some(function(e) {
                    return e.fields.some(function(e) {
                        return !e.optional && (!v[e.name] || c[e.name] && !c[e.name].includes(v[e.name]));
                    });
                });
                this.setData({
                    disableIdlShippingBtn: p
                });
            }
        },
        onStreet2Change: function(e) {
            this.setData({
                street2Value: e.detail.value
            }), this.enableIdlShippingSaveBtn();
        },
        onPostalCodeChange: function(e) {
            this.setData({
                postalCodeValue: e.detail.value
            });
        },
        onDistrictChange: function(t) {
            var a, l = t.currentTarget.id;
            this.setData({
                districtValue: this.data.districtList[t.detail.value],
                invoiceFields: i(i({}, this.data.invoiceFields), {}, (a = {}, e(a, l, this.data.districtList[t.detail.value]), 
                e(a, "district", this.data.districtList[t.detail.value]), a))
            }), this.enableIdlShippingSaveBtn();
            var d = this.data || {}, n = d.stateValue, o = d.cityValue, r = d.districtValue;
            if (this.data.pickupStoreData && n && o && r) {
                var s = {
                    state: n,
                    city: o,
                    district: r,
                    type: "json",
                    sba: !0
                }, u = this.data.shared.bootstrap.urls.storesfederatedsearch;
                if (!u) throw new Error("onDistrictChange missing storesFederatedSearchURL");
                this.searchStoreForPickup(u, s);
            }
        },
        searchStoreForPickup: function(e, t) {
            var d = this;
            return l(a().mark(function l() {
                var n, o, r, s, u, c, v, p, h, m, f;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return o = i({}, null === (n = d.data) || void 0 === n ? void 0 : n.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), a.prev = 2, a.next = 5, d.crequest({
                            url: e,
                            data: t,
                            header: o
                        }, {
                            formUrlEncoded: !0
                        });

                      case 5:
                        r = a.sent, null != (s = r.data) && s.storeNumbers && (v = s.storeNumbers, p = d.data.storeMappings, 
                        h = [], p && v && v.forEach(function(e) {
                            p[e] && h.push(p[e]);
                        }), m = h.find(function(e) {
                            return e.checked;
                        }), d.setData({
                            searchedPickupStoresList: s.storeNumbers,
                            searchedFields: i({}, t),
                            showSearchedStoresByLocation: !0,
                            serachedStoresWithMapping: h,
                            requestSource: "searchedStores",
                            enableSaveButton: !(null == m || !m.storeNumber)
                        }), (null === (u = d.data) || void 0 === u || null === (c = u.serachedStoresWithMapping) || void 0 === c ? void 0 : c.length) > 0 && d.data.pickupStoreData && d.updateAvailibityOfStores(null === (f = d.data) || void 0 === f ? void 0 : f.serachedStoresWithMapping, "searchedStores", d.data.pickupStoreData)), 
                        wx.hideLoading(), a.next = 16;
                        break;

                      case 11:
                        return a.prev = 11, a.t0 = a.catch(2), wx.hideLoading(), d.handleAllErrors(), a.abrupt("return");

                      case 16:
                      case "end":
                        return a.stop();
                    }
                }, l, null, [ [ 2, 11 ] ]);
            }))();
        },
        checkValueMatchesRegex: function(e, t) {
            return t.some(function(t) {
                return t = t ? t.replace(/"/g, "") : null, e.match(t);
            });
        },
        onShippingSubmit: (d = l(a().mark(function t() {
            var l, d, n, o, r, s, u, c, v, p, h, m, f, k, g, D, y, S, b, x, w, L, A, T, M, I, P, C, F, U, E, O, V, H, q, R, N, j, B, _, W = this;
            return a().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (u = {}, c = [], this.data.formValues = i(i({}, this.data.formValues), {}, {
                        countryCode: "中国"
                    }), this.data.addressFields[0].cells.map(function(e) {
                        e.fields.forEach(function(e) {
                            if ("state" !== e.id && "city" !== e.id && "district" !== e.id) {
                                var t, a = W.data.formValues[e.id], i = null === (t = W.data.maskedItems) || void 0 === t ? void 0 : t.includes(e.id);
                                e.required && !a ? (c.push(e.id), e.alertMessage && (p = e.alertMessage)) : a && !i && (e.validRegexes || []).length > 0 && !W.checkValueMatchesRegex(a, e.validRegexes) && (c.push(e.id), 
                                p = e.invalidErrorMsg || e.invalidValue);
                            }
                        });
                    }), this.data.stateValue || c.push("state"), this.data.cityValue || c.push("city"), 
                    this.data.districtValue || c.push("district"), this.setData({
                        updatedErrorFields: c
                    }), v = this.data.translations.alertMessageText, 1 === (null == c ? void 0 : c.length) && (v = p || v), 
                    !(c.length > 0)) {
                        t.next = 13;
                        break;
                    }
                    return wx.showToast({
                        title: "".concat(v),
                        icon: "none",
                        duration: 3e3
                    }), t.abrupt("return");

                  case 13:
                    return h = {}, Object.keys(this.data.formValues).map(function(t) {
                        u = i(i({}, u), {}, e({}, "".concat(W.data.addressData.keyPath, ".").concat(t), W.data.formValues[t])), 
                        h = i(i({}, h), {}, e({}, t, W.data.formValues[t]));
                    }), u = i(i({}, u), {}, (e(l = {}, "".concat(this.data.addressData.keyPath, ".state"), this.data.stateValue), 
                    e(l, "".concat(this.data.addressData.keyPath, ".city"), this.data.cityValue), e(l, "".concat(this.data.addressData.keyPath, ".district"), this.data.districtValue), 
                    l)), m = i({}, null === (d = this.data) || void 0 === d ? void 0 : d.mandatoryAdditionalHeaders), 
                    wx.showLoading({
                        title: this.data.shared.textAssets.loading,
                        mask: !0
                    }), t.next = 20, this.crequest({
                        url: this.data.saveUrl,
                        method: "POST",
                        header: m,
                        data: u
                    }, {
                        formUrlEncoded: !0
                    });

                  case 20:
                    if (f = t.sent, wx.hideLoading(), !this.handleAllErrors(null == f ? void 0 : f.data)) {
                        t.next = 24;
                        break;
                    }
                    return t.abrupt("return");

                  case 24:
                    this.setData({
                        mandatoryAdditionalHeaders: null === (n = f.data) || void 0 === n || null === (o = n.meta) || void 0 === o ? void 0 : o.mandatoryAdditionalHeaders
                    }), "mmap-shipping" === (null == f || null === (r = f.data) || void 0 === r || null === (s = r.shipping) || void 0 === s ? void 0 : s.view) ? ((O = null === (k = f.data.shipping.shippingMessages) || void 0 === k || null === (g = k.messages) || void 0 === g || null === (D = g.errors) || void 0 === D ? void 0 : D[0]) && wx.showToast({
                        title: O,
                        icon: "none",
                        duration: 3e3
                    }), V = null === (y = f.data) || void 0 === y || null === (S = y.shipping) || void 0 === S ? void 0 : S.mobileAddress, 
                    H = null == V ? void 0 : V.addressData, q = [ null == V || null === (b = V.addressFields) || void 0 === b ? void 0 : b[1] ], 
                    R = null === (x = f.data) || void 0 === x || null === (w = x.shipping) || void 0 === w ? void 0 : w.translations, 
                    N = null === (L = f.data) || void 0 === L || null === (A = L.shipping) || void 0 === A ? void 0 : A.saveUrl, 
                    j = null === (T = f.data) || void 0 === T || null === (M = T.shipping) || void 0 === M ? void 0 : M.cancelUrl, 
                    B = null === (I = f.data) || void 0 === I || null === (P = I.shipping) || void 0 === P || null === (C = P.shippingMessages) || void 0 === C || null === (F = C.messages) || void 0 === F ? void 0 : F.errors, 
                    _ = null === (U = f.data) || void 0 === U || null === (E = U.meta) || void 0 === E ? void 0 : E.mandatoryAdditionalHeaders, 
                    this.setData({
                        isLoading: !1,
                        shippingData: f.data,
                        translations: R,
                        saveUrl: N,
                        cancelUrl: j,
                        alerts: B,
                        addressFields: q,
                        addressData: H,
                        mandatoryAdditionalHeaders: _,
                        invoiceFields: h
                    })) : (this.showAlerts(null == f ? void 0 : f.data), this.setData({
                        isLoading: !1,
                        shippingData: null,
                        invoiceData: null,
                        landingData: f.data,
                        maskedItems: null,
                        isShippingAddressAdded: !0,
                        pageTitle: this.data.shared.textAssets.checkout
                    }), this.getItemsData(f.data), this.getSpokesData(f.data));

                  case 26:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function() {
            return d.apply(this, arguments);
        }),
        onSaveIdlShipping: function() {
            var t = this.data, a = t.stateValue, l = t.cityValue, d = t.districtValue, n = t.streetValue, o = t.street2Value, r = t.idlShippingData, s = {
                state: a,
                city: l,
                district: d,
                street: n,
                street2: o
            }, u = r.idlShipping.mobileAddress.addressData.keyPath, c = void 0 === u ? "" : u, v = r.idlShipping, p = v.saveUrl, h = v.deliveryShipMethodCode, m = v.cartLineItemId, f = v.idlRequestData;
            if (s && Object.keys(s).length && p && c) {
                var k = {};
                h && m && f && (k = i(i({}, f), {}, {
                    deliveryShipMethodCode: h,
                    cartLineItemId: m
                })), Object.keys(s).map(function(t) {
                    k = i(i({}, k), {}, e({}, "".concat(c, ".").concat(t), s[t]));
                }), this.updateDniDeliveryLocation(p, k);
            }
        },
        onSaveDeliveryLocation: function() {
            var t, a, l = this, d = this.data, n = d.stateValue, o = d.cityValue, r = d.districtValue, s = d.postalCodeValue, u = d.deliveryLocationData, c = {
                state: n,
                city: o,
                district: r,
                postalCode: s
            }, v = [];
            if (this.data.addressFields[0].cells.map(function(e) {
                e.fields.forEach(function(e) {
                    if ("state" !== e.id && "city" !== e.id && "district" !== e.id) {
                        var a = c[e.id];
                        e.required && !a ? (v.push(e.id), e.alertMessage && (t = e.alertMessage)) : a && (e.validRegexes || []).length > 0 && !l.checkValueMatchesRegex(a, e.validRegexes) && (v.push(e.id), 
                        t = e.invalidErrorMsg || e.invalidValue);
                    }
                });
            }), this.setData({
                updatedErrorFields: v
            }), a = this.data.translations.alertMessageText, 1 === (null == v ? void 0 : v.length) && (a = t || a), 
            console.log(v), v.length > 0) wx.showToast({
                title: "".concat(a),
                icon: "none",
                duration: 3e3
            }); else {
                var p = u.deliveryLocation.mobileAddress.addressData.keyPath, h = void 0 === p ? "" : p, m = u.deliveryLocation.saveUrl;
                if (c && Object.keys(c).length && m && h) {
                    var f = {};
                    Object.keys(c).map(function(t) {
                        f = i(i({}, f), {}, e({}, "".concat(h, ".").concat(t), c[t]));
                    }), this.updateDeliveryTimeSlot(m, f);
                }
            }
        },
        updateDniDeliveryLocation: function(e, t) {
            var d = this;
            return l(a().mark(function l() {
                var n, o, r, s, u, c, v, p, h, m, f, k, g, D, y, S, b, x, w, L, A;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return o = i({}, null === (n = d.data) || void 0 === n ? void 0 : n.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), a.prev = 2, a.next = 5, d.crequest({
                            url: e,
                            method: "POST",
                            header: o,
                            data: i({}, t)
                        }, {
                            formUrlEncoded: !0
                        });

                      case 5:
                        (r = a.sent).data && "mmap-crd-review" === r.data.view && r.data.review ? (wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), d.setData({
                            isLoading: !1,
                            shippingData: null,
                            invoiceData: null,
                            pickupStoreData: null,
                            idlTimeSlotsData: null,
                            idlShippingData: null,
                            selectedIdlTimeSlot: null,
                            deliveryLocationData: null,
                            selectedIdlDate: "",
                            landingData: r.data,
                            showSearchedStoresByLocation: !1
                        }), d.getItemsData(r.data), d.getSpokesData(r.data), wx.hideLoading()) : "mmap-crd-review" === r.data.view && r.data.idlShipping ? ((h = null === (s = r.data.idlShipping.shippingMessages) || void 0 === s || null === (u = s.messages) || void 0 === u || null === (c = u.errors) || void 0 === c ? void 0 : c[0]) && wx.showModal({
                            content: h,
                            confirmText: d.data.shared.textAssets.ok,
                            showCancel: !1
                        }), m = null === (v = r.data.idlShipping) || void 0 === v ? void 0 : v.translations, 
                        f = null === (p = r.data.idlShipping) || void 0 === p ? void 0 : p.mobileAddress, 
                        k = d.getIDLFormListFields(f, m), k.formListFields, g = k.errorFields, d.setData({
                            updatedErrorFields: g
                        })) : r.data.deliveryTimeSlot && (d.setData({
                            idlTimeSlotsData: r.data,
                            cancelUrl: r.data.deliveryTimeSlot.cancelUrl,
                            mandatoryAdditionalHeaders: null === (D = r.data) || void 0 === D || null === (y = D.meta) || void 0 === y ? void 0 : y.mandatoryAdditionalHeaders
                        }), S = d.data.idlTimeSlotsData.deliveryTimeSlot, b = S.daySlots, x = S.selectedTimeSlot, 
                        w = S.translations, L = !(!b || !b.length), A = !(b || []).some(function(e) {
                            return (e.timeSlots || []).some(function(e) {
                                return e.enabled;
                            });
                        }), d.setData({
                            daySlotsAvailable: L,
                            allSlotsDisabled: A
                        }), (b || []).some(function(e) {
                            var t = (e.timeSlots || []).find(function(e) {
                                return e.id === x;
                            });
                            return !!t && (d.setData({
                                selectedIdlTimeSlot: t,
                                selectedIdlDate: e.date,
                                slot_title: w.slot_title.indexOf("daySelected") > -1 ? w.slot_title.replace("${daySelected}", e.date) : w.slot_title.replace("null", e.date)
                            }), !0);
                        })), wx.hideLoading(), a.next = 14;
                        break;

                      case 10:
                        return a.prev = 10, a.t0 = a.catch(2), console.error("failed", a.t0), a.abrupt("return");

                      case 14:
                      case "end":
                        return a.stop();
                    }
                }, l, null, [ [ 2, 10 ] ]);
            }))();
        },
        handleDateSelection: function(e) {
            var t = e.currentTarget.dataset.seldate;
            this.setData({
                selectedIdlDate: t
            });
        },
        onTimeSlotSelected: function(e) {
            var t = e.currentTarget.dataset.slot;
            t.enabled && this.setData({
                selectedIdlTimeSlot: t
            });
        },
        saveDeliveryTimeSlot: function() {
            var t = this.data, a = t.selectedIdlTimeSlot, l = t.selectedIdlDate, d = t.idlTimeSlotsData, n = null == d ? void 0 : d.deliveryTimeSlot, o = n.keyPath, r = n.saveUrl;
            if (o && a && Object.keys(a).length && l) {
                var s = {}, u = Object.keys(d.deliveryTimeSlot);
                Object.keys(a).map(function(t) {
                    var n;
                    u.includes(t) && (s = i(i({}, s), {}, e({}, "".concat(o, ".").concat(t), a[t])));
                    var r = d.deliveryTimeSlot.daySlots.find(function(e) {
                        return e.date === l;
                    });
                    s = i(i({}, s), {}, (e(n = {}, "".concat(o, ".selectedTimeSlot"), a.id), e(n, "".concat(o, ".signKey"), a.reservationId), 
                    e(n, "".concat(o, ".date"), l), e(n, "".concat(o, ".timeZone"), r.timeZone), n));
                }), this.updateDeliveryTimeSlot(r, s);
            }
        },
        updateDeliveryTimeSlot: function(e, t) {
            var d = this;
            return l(a().mark(function l() {
                var n, o, r, s, u, c;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return u = i({}, (null === (n = d.data.idlTimeSlotsData) || void 0 === n ? void 0 : n.meta.mandatoryAdditionalHeaders) || (null === (o = d.data.deliveryLocationData) || void 0 === o ? void 0 : o.meta.mandatoryAdditionalHeaders)), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), a.next = 4, d.crequest({
                            url: e,
                            method: "POST",
                            header: u,
                            data: t
                        }, {
                            formUrlEncoded: !0
                        });

                      case 4:
                        c = a.sent, d.showAlerts(null == c ? void 0 : c.data), d.setData({
                            isLoading: !1,
                            shippingData: null,
                            invoiceData: null,
                            pickupStoreData: null,
                            idlTimeSlotsData: null,
                            idlShippingData: null,
                            selectedIdlTimeSlot: null,
                            deliveryLocationData: null,
                            selectedIdlDate: "",
                            landingData: c.data,
                            showSearchedStoresByLocation: !1,
                            mandatoryAdditionalHeaders: null === (r = c.data) || void 0 === r || null === (s = r.meta) || void 0 === s ? void 0 : s.mandatoryAdditionalHeaders
                        }), d.getItemsData(c.data), d.getSpokesData(c.data), wx.hideLoading();

                      case 10:
                      case "end":
                        return a.stop();
                    }
                }, l);
            }))();
        },
        addSelection: function(e) {
            var t, a, i, l, d, n, o, r;
            this.setData({
                index: e.detail.value,
                inputText: null === (t = this.data) || void 0 === t || null === (a = t.invoiceData) || void 0 === a || null === (i = a.invoice) || void 0 === i || null === (l = i.invoiceTypes) || void 0 === l ? void 0 : l[e.detail.value].label,
                inputValue: null === (d = this.data) || void 0 === d || null === (n = d.invoiceData) || void 0 === n || null === (o = n.invoice) || void 0 === o || null === (r = o.invoiceTypes) || void 0 === r ? void 0 : r[e.detail.value].value
            });
        },
        handleInputInvoice: function(t) {
            var a = t.currentTarget.id, l = t.detail.value;
            this.setData(e({
                invoiceFields: i(i({}, this.data.invoiceFields), {}, e({}, a, null != l ? l : ""))
            }, a, l));
        },
        onSubmitInvoice: function() {
            var e = this;
            return l(a().mark(function t() {
                var l, d, n, o, r, s, u, c, v, p, h, m, f, k, g, D, y, S, b, x, w, L, A, T, M, I, P, C, F, U, E, O, V, H, q, R, N, j, B, _, W, Y, J, G, K, Z, $, z, X, Q, ee, te, ae, ie, le, de, ne, oe, re, se, ue, ce, ve, pe, he, me, fe, ke, ge, De, ye, Se, be, xe, we, Le, Ae, Te, Me, Ie, Pe, Ce, Fe, Ue, Ee, Oe, Ve, He, qe, Re, Ne, je, Be, _e, We, Ye, Je, Ge, Ke, Ze, $e, ze, Xe, Qe, et, tt, at, it, lt, dt, nt, ot, rt, st, ut, ct, vt, pt, ht, mt, ft, kt, gt, Dt, yt, St, bt, xt, wt, Lt, At, Tt, Mt, It, Pt, Ct, Ft, Ut, Et, Ot, Vt;
                return a().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (oe = {}, re = [], null !== (l = e.data.invoiceData) && void 0 !== l && null !== (d = l.invoice) && void 0 !== d && null !== (n = d.defaultInvoice.mobileAddress) && void 0 !== n && null !== (o = n.addressFields) && void 0 !== o && null !== (r = o[0]) && void 0 !== r && null !== (s = r.cells) && void 0 !== s && null !== (u = s[0]) && void 0 !== u && null !== (c = u.fields) && void 0 !== c && null !== (v = c[0]) && void 0 !== v && v.required && (e.data.invoiceFields.emailAddress || e.data.emailAddress ? (e.data.invoiceFields.emailAddress && !e.checkValueMatchesRegex(e.data.invoiceFields.emailAddress, e.data.invoiceData.invoice.defaultInvoice.mobileAddress.addressFields[0].cells[0].fields[0].validRegexes) || e.data.emailAddress && !e.checkValueMatchesRegex(e.data.emailAddress, e.data.invoiceData.invoice.defaultInvoice.mobileAddress.addressFields[0].cells[0].fields[0].validRegexes)) && re.push("emailAddress") : re.push("emailAddress")), 
                        null !== (p = e.data.invoiceData) && void 0 !== p && null !== (h = p.invoice) && void 0 !== h && null !== (m = h.defaultInvoice) && void 0 !== m && null !== (f = m.makoAddress) && void 0 !== f && null !== (k = f.addressFields) && void 0 !== k && null !== (g = k[0]) && void 0 !== g && null !== (D = g.cells) && void 0 !== D && null !== (y = D[0]) && void 0 !== y && null !== (S = y.fields) && void 0 !== S && null !== (b = S[0]) && void 0 !== b && b.required && (null !== (se = e.data) && void 0 !== se && null !== (ue = se.invoiceFields) && void 0 !== ue && ue.mobilePhone || null !== (ce = e.data) && void 0 !== ce && ce.mobilePhone || re.push("mobilePhone")), 
                        "e_personal" !== e.data.inputValue || e.data.invoiceFields.invoiceHeader || re.push(null === (ve = e.data) || void 0 === ve || null === (pe = ve.invoiceData) || void 0 === pe || null === (he = pe.invoice) || void 0 === he || null === (me = he.personalInvoice) || void 0 === me || null === (fe = me.invoiceData) || void 0 === fe || null === (ke = fe.invoiceFields) || void 0 === ke || null === (ge = ke[0]) || void 0 === ge || null === (De = ge.cells[0]) || void 0 === De || null === (ye = De.fields) || void 0 === ye || null === (Se = ye[0]) || void 0 === Se ? void 0 : Se.id), 
                        "e_company" === e.data.inputValue && (null === (be = e.data) || void 0 === be || null === (xe = be.invoiceData) || void 0 === xe || null === (we = xe.invoice) || void 0 === we || null === (Le = we.eCompanyInvoice) || void 0 === Le || null === (Ae = Le.invoiceData) || void 0 === Ae || null === (Te = Ae.invoiceFields) || void 0 === Te || null === (Me = Te[0]) || void 0 === Me || null === (Ie = Me.cells) || void 0 === Ie || Ie.map(function(t) {
                            var a, i, l, d, n, o, r, s, u, c, v, p, h, m, f, k, g;
                            if (null !== (a = t.fields) && void 0 !== a && null !== (i = a[0]) && void 0 !== i && i.required) if (null !== (l = e.data.invoiceFields) && void 0 !== l && l[null === (d = t.fields) || void 0 === d || null === (n = d[0]) || void 0 === n ? void 0 : n.id]) {
                                if (null !== (o = t.fields) && void 0 !== o && null !== (r = o[0]) && void 0 !== r && r.validRegexes && null !== (s = e.data.invoiceFields) && void 0 !== s && s[null === (u = t.fields) || void 0 === u || null === (c = u[0]) || void 0 === c ? void 0 : c.id] && !e.checkValueMatchesRegex(null === (v = e.data.invoiceFields) || void 0 === v ? void 0 : v[null === (p = t.fields) || void 0 === p || null === (h = p[0]) || void 0 === h ? void 0 : h.id], null === (m = t.fields) || void 0 === m || null === (f = m[0]) || void 0 === f ? void 0 : f.validRegexes)) {
                                    var D, y;
                                    re.push(null === (D = t.fields) || void 0 === D || null === (y = D[0]) || void 0 === y ? void 0 : y.id);
                                }
                            } else re.push(null === (k = t.fields) || void 0 === k || null === (g = k[0]) || void 0 === g ? void 0 : g.id);
                        }), e.data.stateValue && ($e = i(i({}, $e = {
                            state: "",
                            city: "",
                            district: ""
                        }), {}, {
                            state: e.data.stateValue
                        }), null !== (Pe = e.data) && void 0 !== Pe && Pe.cityValue && ($e = i(i({}, $e), {}, {
                            city: e.data.cityValue
                        })), null !== (Ce = e.data) && void 0 !== Ce && Ce.districtValue && ($e = i(i({}, $e), {}, {
                            district: e.data.districtValue
                        })), null === (Fe = e.data) || void 0 === Fe || null === (Ue = Fe.invoiceData) || void 0 === Ue || null === (Ee = Ue.invoice) || void 0 === Ee || null === (Oe = Ee.eCompanyInvoice) || void 0 === Oe || null === (Ve = Oe.invoiceAddress) || void 0 === Ve || null === (He = Ve.mobileAddress) || void 0 === He || null === (qe = He.addressFields) || void 0 === qe || null === (Re = qe[1]) || void 0 === Re || null === (Ne = Re.cells) || void 0 === Ne || Ne.map(function(t) {
                            var a, i, l, d, n, o, r, s;
                            null != t && null !== (a = t.fields) && void 0 !== a && null !== (i = a[0]) && void 0 !== i && i.required && (null !== (l = e.data.invoiceFields) && void 0 !== l && l[null === (d = t.fields) || void 0 === d || null === (n = d[0]) || void 0 === n ? void 0 : n.id] || null !== (o = $e) && void 0 !== o && o[null === (r = t.fields) || void 0 === r || null === (s = r[0]) || void 0 === s ? void 0 : s.id] || re.push(t.fields[0].id));
                        }), null === (je = e.data) || void 0 === je || null === (Be = je.invoiceData) || void 0 === Be || null === (_e = Be.invoice) || void 0 === _e || null === (We = _e.eCompanyInvoice) || void 0 === We || null === (Ye = We.invoiceAddress) || void 0 === Ye || null === (Je = Ye.invoiceData) || void 0 === Je || null === (Ge = Je.invoiceFields) || void 0 === Ge || null === (Ke = Ge[0]) || void 0 === Ke || null === (Ze = Ke.cells) || void 0 === Ze || Ze.map(function(t) {
                            var a, i, l, d, n, o, r, s, u, c, v, p, h, m, f;
                            if (null != t && null !== (a = t.fields) && void 0 !== a && null !== (i = a[0]) && void 0 !== i && i.required) if (null !== (l = e.data.invoiceFields) && void 0 !== l && l[null == t || null === (d = t.fields) || void 0 === d || null === (n = d[0]) || void 0 === n ? void 0 : n.id]) {
                                if (null !== (o = t.fields) && void 0 !== o && null !== (r = o[0]) && void 0 !== r && r.validRegexes && null !== (s = e.data.invoiceFields) && void 0 !== s && s[null === (u = t.fields) || void 0 === u || null === (c = u[0]) || void 0 === c ? void 0 : c.id] && !e.checkValueMatchesRegex(null === (v = e.data.invoiceFields) || void 0 === v ? void 0 : v[null === (p = t.fields) || void 0 === p || null === (h = p[0]) || void 0 === h ? void 0 : h.id], null === (m = t.fields) || void 0 === m || null === (f = m[0]) || void 0 === f ? void 0 : f.validRegexes)) {
                                    var k, g;
                                    re.push(null === (k = t.fields) || void 0 === k || null === (g = k[0]) || void 0 === g ? void 0 : g.id);
                                }
                            } else re.push(t.fields[0].id);
                        }))), e.setData({
                            invoiceErrorFields: re
                        }), !(re.length > 0)) {
                            t.next = 11;
                            break;
                        }
                        return tt = null === (ze = e.data) || void 0 === ze || null === (Xe = ze.invoiceData) || void 0 === Xe || null === (Qe = Xe.invoice) || void 0 === Qe || null === (et = Qe.translations) || void 0 === et ? void 0 : et["validation-failed"], 
                        wx.showModal({
                            content: tt,
                            confirmText: e.data.shared.textAssets.ok,
                            showCancel: !1
                        }), t.abrupt("return");

                      case 11:
                        return at = null === (x = e.data.invoiceData) || void 0 === x || null === (w = x.invoice) || void 0 === w ? void 0 : w.keyPath, 
                        it = null === (L = e.data.invoiceData) || void 0 === L || null === (A = L.invoice) || void 0 === A || null === (T = A.defaultInvoice) || void 0 === T || null === (M = T.mobileAddress) || void 0 === M || null === (I = M.addressData) || void 0 === I ? void 0 : I.keyPath, 
                        lt = null === (P = e.data.invoiceData) || void 0 === P || null === (C = P.invoice) || void 0 === C || null === (F = C.defaultInvoice) || void 0 === F ? void 0 : F.keyPath, 
                        dt = null === (U = e.data) || void 0 === U || null === (E = U.invoiceData) || void 0 === E || null === (O = E.invoice) || void 0 === O || null === (V = O.personalInvoice) || void 0 === V || null === (H = V.invoiceData) || void 0 === H ? void 0 : H.keyPath, 
                        nt = null === (q = e.data) || void 0 === q || null === (R = q.invoiceData) || void 0 === R || null === (N = R.invoice) || void 0 === N || null === (j = N.ePersonalInvoice) || void 0 === j || null === (B = j.invoiceData) || void 0 === B ? void 0 : B.keyPath, 
                        ot = null === (_ = e.data) || void 0 === _ || null === (W = _.invoiceData) || void 0 === W || null === (Y = W.invoice) || void 0 === Y || null === (J = Y.eCompanyInvoice) || void 0 === J || null === (G = J.invoiceData) || void 0 === G ? void 0 : G.keyPath, 
                        rt = null === (K = e.data) || void 0 === K || null === (Z = K.invoiceData) || void 0 === Z || null === ($ = Z.invoice) || void 0 === $ || null === (z = $.eCompanyInvoice) || void 0 === z || null === (X = z.invoiceAddress) || void 0 === X || null === (Q = X.mobileAddress) || void 0 === Q ? void 0 : Q.keyPath, 
                        st = null === (ee = e.data) || void 0 === ee || null === (te = ee.invoiceData) || void 0 === te || null === (ae = te.invoice) || void 0 === ae || null === (ie = ae.eCompanyInvoice) || void 0 === ie || null === (le = ie.invoiceAddress) || void 0 === le || null === (de = le.invoiceData) || void 0 === de ? void 0 : de.keyPath, 
                        lt && e.data.mobilePhone && (oe["".concat(lt, ".mobilePhone")] = e.data.mobilePhone), 
                        at && (oe["".concat(at, ".invoice")] = e.data.inputValue || "none"), it && (oe["".concat(it, ".emailAddress")] = e.data.invoiceFields.emailAddress || e.data.emailAddress), 
                        dt && "personal" === e.data.inputValue && (oe["".concat(dt, ".invoiceHeader")] = null === (ut = e.data) || void 0 === ut ? void 0 : ut.invoiceData.invoice.personalInvoice.invoiceData.invoiceFields[0].cells[0].fields[0].value), 
                        nt && "e_personal" === e.data.inputValue && (oe["".concat(nt, ".invoiceHeader")] = e.data.invoiceFields.invoiceHeader || e.data.invoiceHeader), 
                        ot && rt && st && "e_company" === e.data.inputValue && (oe["".concat(ot, ".invoiceHeader")] = e.data.invoiceFields.invoiceHeader, 
                        oe["".concat(ot, ".taxPayerId")] = e.data.invoiceFields.taxPayerId, oe["".concat(rt, ".street")] = null !== (ct = e.data.invoiceFields.street) && void 0 !== ct ? ct : "", 
                        oe["".concat(rt, ".street2")] = null !== (vt = e.data.invoiceFields.street2) && void 0 !== vt ? vt : "", 
                        oe["".concat(rt, ".state")] = e.data.stateValue, oe["".concat(rt, ".city")] = e.data.cityValue, 
                        oe["".concat(rt, ".district")] = e.data.districtValue, oe["".concat(rt, ".fullDaytimePhone")] = null !== (pt = e.data.invoiceFields.fullDaytimePhone) && void 0 !== pt ? pt : "", 
                        oe["".concat(rt, ".postalCode")] = null !== (ht = e.data.invoiceFields.postalCode) && void 0 !== ht ? ht : "", 
                        oe["".concat(st, ".bankAccountName")] = null !== (mt = e.data.invoiceFields.bankAccountName) && void 0 !== mt ? mt : "", 
                        oe["".concat(st, ".bankAccountNumber")] = null !== (ft = e.data.invoiceFields.bankAccountNumber) && void 0 !== ft ? ft : ""), 
                        kt = i({}, null === (ne = e.data) || void 0 === ne ? void 0 : ne.mandatoryAdditionalHeaders), 
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), t.prev = 27, t.next = 30, e.crequest({
                            url: null === (gt = e.data.invoiceData) || void 0 === gt || null === (Dt = gt.invoice) || void 0 === Dt ? void 0 : Dt.saveUrl,
                            method: "POST",
                            header: kt,
                            data: oe
                        }, {
                            formUrlEncoded: !0
                        });

                      case 30:
                        if (wt = t.sent, wx.hideLoading(), !e.handleAllErrors(null == wt ? void 0 : wt.data)) {
                            t.next = 34;
                            break;
                        }
                        return t.abrupt("return");

                      case 34:
                        e.setData({
                            mandatoryAdditionalHeaders: null === (yt = wt.data) || void 0 === yt || null === (St = yt.meta) || void 0 === St ? void 0 : St.mandatoryAdditionalHeaders
                        }), "mmap-invoice" === (null == wt || null === (bt = wt.data) || void 0 === bt || null === (xt = bt.invoice) || void 0 === xt ? void 0 : xt.view) ? ((Ot = null === (Lt = wt.data.invoice.invoiceMessages) || void 0 === Lt || null === (At = Lt.messages) || void 0 === At || null === (Tt = At.errors) || void 0 === Tt ? void 0 : Tt[0]) && wx.showToast({
                            title: Ot,
                            icon: "none",
                            duration: 3e3
                        }), Vt = null == wt || null === (Mt = wt.data) || void 0 === Mt || null === (It = Mt.invoice) || void 0 === It ? void 0 : It.invoiceTypes.map(function(e) {
                            return e.label;
                        }), e.setData({
                            isLoading: !1,
                            invoiceData: wt.data,
                            invoiceTypes: Vt,
                            emailAddress: null === (Pt = wt.data) || void 0 === Pt || null === (Ct = Pt.invoice) || void 0 === Ct || null === (Ft = Ct.defaultInvoice) || void 0 === Ft || null === (Ut = Ft.mobileAddress) || void 0 === Ut || null === (Et = Ut.addressData) || void 0 === Et ? void 0 : Et.emailAddress,
                            inputText: e.data.inputText ? e.data.inputText : Vt[0]
                        })) : (e.showAlerts(null == wt ? void 0 : wt.data), e.setData({
                            isLoading: !1,
                            shippingData: null,
                            invoiceData: null,
                            landingData: wt.data,
                            pageTitle: e.data.shared.textAssets.checkout
                        }), e.getItemsData(wt.data), e.getSpokesData(wt.data)), t.next = 42;
                        break;

                      case 38:
                        return t.prev = 38, t.t0 = t.catch(27), console.error("save invoice failed", t.t0), 
                        t.abrupt("return");

                      case 42:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 27, 38 ] ]);
            }))();
        },
        openWeChatAddress: function() {
            var e = this;
            wx.chooseAddress({
                trigger: function() {
                    console.log("chooseAddress triggered");
                },
                success: function(t) {
                    if (t.cityName) {
                        var a, i, l, d, n, o, r = null === (a = e.data.addressFields) || void 0 === a || null === (i = a[0]) || void 0 === i ? void 0 : i.cells;
                        if (e.data.invoiceData) r = null === (l = e.data.addressFields) || void 0 === l || null === (d = l[1]) || void 0 === d ? void 0 : d.cells;
                        if (e.data.idlShippingData) r = null === (n = e.data.addressFields) || void 0 === n || null === (o = n[1]) || void 0 === o ? void 0 : o.cells;
                        var s = [];
                        r && r.forEach(function(e) {
                            e.fields.forEach(function(e) {
                                s.push(e.id);
                            });
                        }), e.setData({
                            preventReload: !0
                        }), e.validateWeChatAddress(t, s, e.data.localityLookupMap);
                    }
                },
                fail: function(t) {
                    console.log(t), e.setData({
                        preventReload: !0
                    });
                }
            });
        },
        validateWeChatAddress: function(e, t, a) {
            var l = {
                city: "cityName",
                district: "countyName",
                state: "provinceName",
                street: "detailInfo",
                postalCode: "postalCode",
                fullPhoneNumber: "telNumber",
                daytimePhone: "telNumber",
                fullDaytimePhone: "telNumber",
                emailAddress: "accountName"
            }, d = e.userName && (0, u.getFirstLast)(e.userName), n = {}, o = [];
            t.forEach(function(t) {
                if ("country" === t || "countryCode" === t) n[t] = "中国"; else if ("lastName" === t) n[t] = null == d ? void 0 : d[1]; else if ("firstName" === t) n[t] = null == d ? void 0 : d[0]; else if ("state" === t) {
                    var i = a && Object.keys(a), r = l[t] && e[l[t]], s = "";
                    if (i && i.indexOf(r) > -1) s = i[i.indexOf(r)]; else if (i) for (var u = 0; u < i.length; u++) if (i[u].indexOf(r.substring(0, 2)) > -1) {
                        s = i[u];
                        break;
                    }
                    n[t] = s;
                } else if ("city" === t) {
                    var c = l[t] && e[l[t]], v = "", p = n.state;
                    if (1 === c.length) v = p.substring(0, 2), o = a && p && a[p] && a[p][v] && a[p][v].districts; else {
                        var h = a && a[p];
                        if (h = h && Object.keys(h), c = c.length > 2 ? c.substring(0, 2) : c, h) for (var m = 0; m < h.length; m++) {
                            if ((h[m] && h[m].length > 2 ? h[m].substring(0, 2) : h[m]).indexOf(c) > -1) {
                                v = h[m], o = a[p][v] && a[p][v].districts;
                                break;
                            }
                        }
                    }
                    n[t] = v;
                } else if ("district" === t) {
                    var f = "", k = o, g = e[l[t]];
                    k.indexOf(g) > -1 ? f = k[k.indexOf(g)] : k.indexOf(g.replace("县", "区")) > -1 && (f = k[k.indexOf(g.replace("县", "区"))]), 
                    n[t] = f;
                } else if (l[t] && e[l[t]]) {
                    var D = e[l[t]];
                    n[t] = D;
                } else n[t] = "";
            }), null != n && n.state && (this.setData({
                cityList: Object.keys(this.data.localityLookupMap[n.state])
            }), (null != n && n.cityValue || null != n && n.city) && this.setData({
                districtList: this.data.localityLookupMap[n.state][n.city].districts
            })), (this.data.idlShippingData || this.data.deliveryLocationData) && (this.setData({
                stateValue: n.state,
                districtValue: n.district,
                cityValue: n.city,
                streetValue: n.street,
                street2Value: n.street2,
                postalCodeValue: n.postalCode
            }), this.enableIdlShippingSaveBtn()), this.data.invoiceData && this.setData({
                invoiceFields: i(i({}, this.data.invoiceFields), n)
            }), this.setData({
                formValues: i({}, n),
                stateValue: n.state,
                districtValue: n.district,
                cityValue: n.city
            });
        },
        handleAllErrors: function(e) {
            var t = this;
            if (!e) return wx.showModal({
                content: this.data.shared.textAssets.genericDataError,
                confirmText: this.data.shared.textAssets.ok,
                showCancel: !1,
                success: function(e) {
                    e.confirm;
                }
            }), !0;
            if ("session_expired" === e.sorryKey) {
                var a, i, l = null === (a = e.alerts) || void 0 === a || null === (i = a[0]) || void 0 === i ? void 0 : i.message;
                return wx.showModal({
                    content: l,
                    confirmText: e.translations.ok,
                    showCancel: !1,
                    success: function(e) {
                        e.confirm && t.loadPage();
                    }
                }), !0;
            }
            if (e.sorryKey) {
                var d, n, o = null === (d = e.alerts) || void 0 === d || null === (n = d[0]) || void 0 === n ? void 0 : n.message;
                return this.setData({
                    isLoading: !1,
                    showSorryPage: !0,
                    sorryMessage: o
                }), !0;
            }
            return !1;
        }
    },
    behaviors: [ o.sharedDataBehavior, o.requestWithSharedCookies ]
});