function e(e) {
    var a, r = e.meta.mandatoryAdditionalHeaders;
    if (e.review) {
        a = "review";
        var t = e.review;
        return {
            responseType: a,
            mandatoryAdditionalHeaders: r,
            spokes: t.spokes,
            terms: t.terms,
            translations: t.translations,
            transactions: t.transactions,
            showFapioTextinCheckout: t.showFapioTextinCheckout,
            showTradeInSummary: t.showTradeInSummary,
            checkoutOfferSummary: t.checkoutOfferSummary,
            fapiaoTextInCheckout: t.fapiaoTextInCheckout,
            fulfillment: t.fulfillment,
            alerts: t.alerts
        };
    }
    if (e.shipping) {
        a = "shipping";
        var s = e.shipping, i = s.view, o = s.saveUrl, n = s.cancelUrl, d = s.mobileAddress;
        return {
            responseType: a,
            mandatoryAdditionalHeaders: r,
            view: i,
            saveUrl: o,
            cancelUrl: n,
            addressData: s.mobileAddress.addressData,
            addressFields: s.mobileAddress.addressFields,
            mobileAddress: d,
            translations: s.translations,
            shippingMessages: s.shippingMessages
        };
    }
    if (e.invoice) {
        a = "invoice";
        var p = e.invoice;
        return {
            responseType: a,
            mandatoryAdditionalHeaders: r,
            view: p.view,
            saveUrl: p.saveUrl,
            cancelUrl: p.cancelUrl,
            invoiceTypes: p.invoiceTypes,
            defaultInvoice: p.defaultInvoice,
            personalInvoice: p.personalInvoice,
            ePersonalInvoice: p.ePersonalInvoice,
            eCompanyInvoice: p.eCompanyInvoice,
            invoiceMessages: p.invoiceMessages
        };
    }
    if (e.pickup) return {
        responseType: a = "pickup",
        mandatoryAdditionalHeaders: r,
        pickup: e.pickup
    };
    if (e.pickupContact) {
        a = "pickupContact";
        var c = e.pickupContact;
        return {
            responseType: a,
            mandatoryAdditionalHeaders: r,
            pickupContact: c,
            pickupContactMessages: c.pickupContactMessages
        };
    }
    if (e.timeSlot) {
        a = "timeSlot";
        var l = e.timeSlot;
        return {
            responseType: a,
            mandatoryAdditionalHeaders: r,
            timeSlot: l,
            retailTimeSlotMessages: l.retailTimeSlotMessages
        };
    }
    return e.deliveryLocation ? {
        responseType: a = "deliveryLocation",
        mandatoryAdditionalHeaders: r,
        deliveryLocation: e.deliveryLocation
    } : e.idlShipping ? {
        responseType: a = "idlShipping",
        mandatoryAdditionalHeaders: r,
        idlShipping: e.idlShipping
    } : e.deliveryTimeSlot ? {
        responseType: a = "deliveryTimeSlot",
        mandatoryAdditionalHeaders: r,
        deliveryTimeSlot: e.deliveryTimeSlot
    } : {
        responseType: a = "parseError"
    };
}

function a(e) {
    return {
        responseType: "checkoutStatus",
        delay: e.head.data.delay,
        method: e.head.data.method,
        url: e.head.data.url,
        status: e.head.data.status,
        mandatoryAdditionalHeaders: e.meta.mandatoryAdditionalHeaders
    };
}

function r(e) {
    return {
        responseType: "thankYouStatus",
        mandatoryAdditionalHeaders: e.mandatoryAdditionalHeaders,
        wechatGeneratePrepayID: e.transactions.wechatGeneratePrepayID,
        transactionsKeyPath: e.transactions.keyPath,
        accessToken: e.transactions.accessToken,
        view: e.view
    };
}

function t(e) {
    return {
        responseType: "sorry",
        alerts: e.alerts
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.parseCheckoutResponse = e, exports.parseCheckoutStatus = a, exports.parseElmoResponse = function(s) {
    var i = s.data;
    return i.sorryKey ? t(i) : i.head ? a(i) : i.pageType ? r(i) : e(i);
}, exports.parseSorry = t, exports.parseThankYouStatus = r, exports.termsAccepted = function(e, a) {
    var r;
    if ("terms-accept-bfi-tradein-recycle" == (null === (r = e.review) || void 0 === r ? void 0 : r.terms.sections[0].formKey)) return "&checkout.review.terms.termsAccepted=1";
    var t = "", s = a;
    for (var i in s) s.hasOwnProperty(i) && s[i] && (t += "&checkout.review.terms.sections." + i + ".termsAccepted=1");
    return t;
};