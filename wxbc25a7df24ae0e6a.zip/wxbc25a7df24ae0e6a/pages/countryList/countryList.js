var t = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../../utils/behavior"), a = require("../../utils/sharedData");

Component({
    data: {
        shared: a.initSharedData,
        countries: [],
        isCountryListFetching: !1,
        type: 1
    },
    methods: {
        onLoad: function(t) {
            wx.setStorageSync("pageTitle", ""), this.setData({
                type: t.id
            }), wx.setStorageSync("type", this.data.type);
        },
        onReady: function() {
            this.fetchCountryList();
        },
        fetchCountryList: function() {
            var e = this;
            this.setData({
                isCountryListFetching: !0
            }), wx.request({
                url: this.data.shared.bootstrap.urls.resellerCountryList,
                method: "GET",
                success: function(a) {
                    var n, r, o;
                    e.setData({
                        isCountryListFetching: !1
                    });
                    var i = e.getListOfCountries(a.data), s = null == a || null === (n = a.data) || void 0 === n || null === (r = n.responseModel) || void 0 === r || null === (o = r.dataItem) || void 0 === o ? void 0 : o.countries, u = (null == s ? void 0 : s.length) > 0 && s.map(function(e) {
                        return t(t({}, e), {}, {
                            translatedCountryName: i[e.name] || e.name
                        });
                    });
                    e.setData({
                        countries: u
                    });
                },
                fail: function() {
                    console.log("FAILED");
                },
                complete: function() {
                    e.setData({
                        isCountryListFetching: !1
                    }), console.log("COMPLETED");
                }
            });
        },
        getListOfCountries: function(t) {
            var e = {}, a = {};
            if (a.aprCountryMapping = t.aprCountryMapping, a.countries = t.responseModel.dataItem.countries, 
            a && a.countries.forEach(function(t) {
                t && t.name && a.aprCountryMapping[t.name] && (e[t.name] = a.aprCountryMapping[t.name]);
            }), 0 !== Object.keys(e).length) {
                var n = {};
                return Object.keys(e).sort().forEach(function(t) {
                    n[t] = e[t];
                }), n;
            }
        },
        onJumpCountryStoreList: function(t) {
            var e = this.data.type, a = t.currentTarget.dataset.id.translatedCountryName;
            if ("allAprStores" === e) {
                var n = t.currentTarget.dataset.id.code;
                wx.setStorageSync("pageTitle", a), wx.navigateTo({
                    url: "../countryStoreList/countryStoreList?id=" + n
                });
            } else {
                var r = t.currentTarget.dataset.id.code;
                wx.setStorageSync("pageTitle", a), wx.navigateTo({
                    url: "../countryStateStoreList/countryStateStoreList?id=" + r
                });
            }
        },
        onnav: function() {
            wx.navigateTo({
                url: "../second/second"
            });
        }
    },
    behaviors: [ e.sharedDataBehavior ]
});