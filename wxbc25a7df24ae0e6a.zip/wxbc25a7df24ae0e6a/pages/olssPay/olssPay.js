var a = require("../../utils/behavior"), t = require("../../utils/sharedData");

Component({
    data: {
        shared: t.initSharedData,
        payData: {},
        status: !1,
        assets: {
            pendingTitle: "为你的订单付款",
            paybtn: "使用微信支付",
            successTitle: "感谢你的购买",
            orderTitle: "订单信息"
        }
    },
    methods: {
        onLoad: function(a) {
            if (a && a.url) {
                var t = JSON.parse(decodeURIComponent(a.url));
                this.setData({
                    payData: t
                });
                var e = this;
                wx.requestPayment({
                    timeStamp: t.timeStamp,
                    nonceStr: t.nonceStr,
                    package: t.package,
                    signType: t.signType,
                    paySign: t.paySign,
                    success: function(a) {
                        e.setData({
                            status: !0
                        }), console.log("olss success", a);
                    },
                    fail: function(a) {
                        e.setData({
                            status: !1
                        }), console.log("olss failed", a);
                    }
                });
            }
        },
        onReady: function() {},
        onShow: function() {},
        onHide: function() {},
        onUnload: function() {},
        onPullDownRefresh: function() {},
        onReachBottom: function() {},
        onShareAppMessage: function() {},
        onRequestPayment: function() {
            var a = this;
            wx.requestPayment({
                timeStamp: this.data.payData.timeStamp,
                nonceStr: this.data.payData.nonceStr,
                package: this.data.payData.package,
                signType: this.data.payData.signType,
                paySign: this.data.payData.paySign,
                success: function(t) {
                    a.setData({
                        status: !0
                    }), console.log("olss success", t);
                },
                fail: function(t) {
                    a.setData({
                        status: !1
                    }), console.log("olss failed", t);
                }
            });
        },
        onOrderStatus: function() {
            var a;
            wx.redirectTo({
                url: "/pages/pageView/pageView?url=" + encodeURIComponent(this.data.shared.bootstrap.urls.orderStatusUrl + "?orderNumber=" + (null === (a = this.data.payData) || void 0 === a ? void 0 : a.oderNumber))
            });
        }
    },
    behaviors: [ a.sharedDataBehavior ]
});