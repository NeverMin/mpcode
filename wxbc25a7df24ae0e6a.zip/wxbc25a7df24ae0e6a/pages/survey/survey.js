var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../utils/sharedData"), a = require("../../utils/behavior"), n = require("../../utils/util"), i = {
    shared: s.initSharedData,
    domain: "https://web-it.apple.com",
    bindingTitle: "我们十分重视您的意见",
    bindingTitleDetail: "请协助使我们的维修服务精益求精",
    bindingDetail: "留下您的电子邮件地址，或同时扫描二维码，绑定 Apple 微信小程序；维修完成后，您可能会收到一份简短问卷，邀请您与我们分享您的维修体验。",
    bindingButtonText: "绑定 Apple ID",
    subscribeTitle: "谢谢，您的账户已绑定",
    subscribeTitleDetail: "",
    subscribeDetail: "",
    subscribeButtonText: "点击进入“订阅信息”设置",
    completeTitle: "谢谢，",
    completeDetail: "如果需要更改订阅设置，请进入微信小程序“设置”。",
    isSubscribed: !1,
    isBind: !1,
    openSettingButtonText: "打开设置页"
};

Component({
    data: i,
    methods: {
        onLoad: function() {
            wx.getSetting({
                withSubscriptions: !0,
                success: function(e) {
                    console.log("getSetting", e), console.log(e.subscriptionsSetting);
                }
            });
        },
        onShow: function() {
            var e = this;
            void 0 !== this.data.shared.isAppReady ? this.data.shared.isAppReady && this.disaCheck() : getApp().watch(function(t) {
                t && e.disaCheck();
            });
        },
        onSubscribe: function() {
            var e = this, t = !1;
            wx.requestSubscribeMessage({
                tmplIds: [ this.data.shared.notifications.survey ],
                success: function(r) {
                    var s = e.data.shared.notifications.survey, a = r[s];
                    e.sendResponseToiConsent(s, a), t = !0, e.setData({
                        isSubscribed: t
                    });
                },
                fail: function(e) {
                    console.log("requestSubscribeMessage fail", e);
                },
                complete: function() {
                    console.log("requestSubscribeMessage complete"), e.data.isSubscribed && e.setData({
                        message: "已订阅"
                    });
                }
            });
        },
        sendResponseToiConsent: function(e, s) {
            var a = this;
            return r(t().mark(function r() {
                var i;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.prev = 0, t.next = 3, (0, n.requestWithCookies)({
                            url: a.data.domain + "/miniprogram-merch/p/wechat/push/subscription",
                            method: "POST",
                            data: {
                                templateId: e,
                                status: s
                            }
                        }, a.data.shared.cookieJar);

                      case 3:
                        i = t.sent, i.res, t.next = 12;
                        break;

                      case 7:
                        return t.prev = 7, t.t0 = t.catch(0), console.error("sendResponseToiConsent failed", t.t0), 
                        a.handleAllErrors(), t.abrupt("return");

                      case 12:
                      case "end":
                        return t.stop();
                    }
                }, r, null, [ [ 0, 7 ] ]);
            }))();
        },
        disaCheck: function() {
            var s = this;
            return r(t().mark(function r() {
                var a, i, o, c, u, d;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (a = s.data.shared.cookieJar.find(function(e) {
                            return e.name === s.data.shared.bootstrap.disaCookieName;
                        }), console.log("found", a), !a || (0, n.isExpired)(a, 21600)) {
                            t.next = 7;
                            break;
                        }
                        return s.setData({
                            isBind: !0
                        }), t.abrupt("return", s.data.shared.cookieJar);

                      case 7:
                        if (i = s.data.shared.bootstrap.urls.disaFetchURL) {
                            t.next = 12;
                            break;
                        }
                        return console.error("Bad DISA Fetch URLs", i), s.handleAllErrors(), t.abrupt("return");

                      case 12:
                        return t.prev = 12, t.next = 15, (0, n.requestWithCookies)({
                            url: i
                        }, s.data.shared.cookieJar);

                      case 15:
                        if (c = t.sent, u = c.res, d = c.cookieJar, "DISA Cookie Not Added" !== u.data.Error && "OpenId is not found" !== u.data.Error) {
                            t.next = 22;
                            break;
                        }
                        return t.abrupt("return");

                      case 22:
                        return o = d, s.setData({
                            shared: e(e({}, s.data.shared), {}, {
                                cookieJar: o
                            }),
                            isBind: !0
                        }), wx.setStorageSync("cookieJar", o), t.abrupt("return", o);

                      case 26:
                        t.next = 33;
                        break;

                      case 28:
                        return t.prev = 28, t.t0 = t.catch(12), console.error("disaFetch failed", t.t0), 
                        s.handleAllErrors(), t.abrupt("return");

                      case 33:
                      case "end":
                        return t.stop();
                    }
                }, r, null, [ [ 12, 28 ] ]);
            }))();
        },
        onDisaCall: function() {
            var e = this;
            return r(t().mark(function r() {
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        wx.navigateTo({
                            url: "../pageView/pageView?url=" + encodeURIComponent(e.data.shared.bootstrap.urls.idmsLoginUrlWithBindingRedirect + "?page=survey")
                        });

                      case 1:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        handleAllErrors: function() {
            return wx.showModal({
                content: this.data.shared.textAssets.genericDataError,
                confirmText: this.data.shared.textAssets.ok,
                showCancel: !1,
                success: function(e) {
                    e.confirm;
                }
            }), !0;
        },
        openSettings: function() {
            wx.openSetting({
                withSubscriptions: !1,
                success: function(e) {
                    console.log("openSetting", e.authSetting);
                }
            });
        }
    },
    behaviors: [ a.sharedDataBehavior ]
});