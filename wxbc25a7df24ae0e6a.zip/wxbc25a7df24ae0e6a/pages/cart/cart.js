var e = require("../../@babel/runtime/helpers/toConsumableArray"), t = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), n = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var a = l(t);
    if (a && a.has(e)) return a.get(e);
    var r = {}, n = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
        var o = n ? Object.getOwnPropertyDescriptor(e, i) : null;
        o && (o.get || o.set) ? Object.defineProperty(r, i, o) : r[i] = e[i];
    }
    r.default = e, a && a.set(e, r);
    return r;
}(require("../../utils/tabbarUtil")), i = require("../../utils/behavior"), o = require("../../utils/sharedData"), s = require("../../utils/util"), d = require("../../analytics/tracking");

function l(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), a = new WeakMap();
    return (l = function(e) {
        return e ? a : t;
    })(e);
}

var u = {
    edit: "编辑",
    editing: !1,
    isEmpty: !0,
    price: 0,
    shared: o.initSharedData,
    isLoading: !0,
    tabIndex: 3,
    startX: 0,
    isLeft: 0,
    delBtnw: 148,
    bagDetails: null,
    shippingUrl: "",
    isEditingGiftPackage: !1,
    apuUrl: "",
    affiliateKey: "",
    affiliateVal: ""
};

Component({
    data: u,
    methods: {
        onLoad: function(e) {
            var t = this;
            return r(a().mark(function r() {
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        e.url && t.setData({
                            shippingUrl: decodeURIComponent(decodeURIComponent(e.url))
                        }), e.apu && t.setData({
                            apuUrl: decodeURIComponent(decodeURIComponent(e.apu))
                        }), e.affiliateKey && e.affiliateVal && t.setData({
                            affiliateKey: e.affiliateKey,
                            affiliateVal: e.affiliateVal
                        });

                      case 3:
                      case "end":
                        return a.stop();
                    }
                }, r);
            }))();
        },
        onShow: function() {
            var e = this;
            void 0 !== this.data.shared.isAppReady ? this.data.shared.isAppReady && this.onRender() : getApp().watch(function(t) {
                t && e.onRender();
            });
        },
        onRender: function() {
            var e = this;
            return r(a().mark(function r() {
                var i, o, l, u, c, h, g;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return a.next = 2, e.disaCheck();

                      case 2:
                        if (i = a.sent) {
                            a.next = 5;
                            break;
                        }
                        return a.abrupt("return");

                      case 5:
                        return a.next = 7, e.shippingLocCookieCheck(i);

                      case 7:
                        return i = a.sent, a.next = 10, e.apuCookieCheck(i);

                      case 10:
                        return i = a.sent, a.next = 13, e.affiliateCookieCheck(i);

                      case 13:
                        if (i = a.sent, o = e.data.shared.bootstrap.urls.elmoBagLandingURL) {
                            a.next = 19;
                            break;
                        }
                        return console.error("Bad Elmo Bag Landing URLs", o), e.handleAllErrors(), a.abrupt("return");

                      case 19:
                        return wx.showLoading({
                            title: e.data.shared.textAssets.loading,
                            mask: !0
                        }), a.prev = 20, a.next = 23, (0, s.requestWithCookies)({
                            url: o
                        }, i);

                      case 23:
                        if (u = a.sent, c = u.res, h = u.cookieJar, i = h, wx.hideLoading(), e.setData({
                            shared: t(t({}, e.data.shared), {}, {
                                cookieJar: i
                            })
                        }), "string" != typeof c.data) {
                            a.next = 33;
                            break;
                        }
                        return console.error("something went wrong with the bag response, got string"), 
                        e.handleAllErrors(), a.abrupt("return");

                      case 33:
                        if ("ArrayBuffer" !== c.data.constructor.name) {
                            a.next = 37;
                            break;
                        }
                        return console.error("something went wrong with the bag response, got ArrayBuffer"), 
                        e.handleAllErrors(), a.abrupt("return");

                      case 37:
                        g = c.data, e.setData({
                            isEmpty: g.isEmptyCart,
                            isLoading: !1,
                            bagDetails: g,
                            translations: g.translations,
                            disableCheckout: !1,
                            editing: !1,
                            edit: e.data.shared.textAssets.editing,
                            isReset: !1
                        }), null !== (l = e.data.bagDetails) && void 0 !== l && l.omniture && (0, d.trackLinkOmniture)({
                            type: "PAGE_LOAD",
                            omniture: e.data.bagDetails.omniture,
                            data: null
                        }), a.next = 49;
                        break;

                      case 42:
                        return a.prev = 42, a.t0 = a.catch(20), console.error("bag failed", a.t0), wx.hideLoading(), 
                        e.setData({
                            isLoading: !1
                        }), e.handleAllErrors(), a.abrupt("return");

                      case 49:
                        n.switchTab(e, e.data.tabIndex);

                      case 50:
                      case "end":
                        return a.stop();
                    }
                }, r, null, [ [ 20, 42 ] ]);
            }))();
        },
        disaCheck: function() {
            var e = this;
            return r(a().mark(function r() {
                var n, i, o, d, l, u;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (!(n = e.data.shared.cookieJar.find(function(t) {
                            return t.name === e.data.shared.bootstrap.disaCookieName;
                        })) || (0, s.isExpired)(n, 21600)) {
                            a.next = 5;
                            break;
                        }
                        return a.abrupt("return", e.data.shared.cookieJar);

                      case 5:
                        if (i = e.data.shared.bootstrap.urls.disaFetchURL) {
                            a.next = 10;
                            break;
                        }
                        return console.error("Bad DISA Fetch URLs", i), e.handleAllErrors(), a.abrupt("return");

                      case 10:
                        return a.prev = 10, a.next = 13, (0, s.requestWithCookies)({
                            url: i
                        }, e.data.shared.cookieJar);

                      case 13:
                        return d = a.sent, l = d.res, u = d.cookieJar, "DISA Cookie Not Added" !== l.data.Error && "OpenId is not found" !== l.data.Error || !e.data.shared.bootstrap.urls.idmsLoginUrlWithBindingRedirect || wx.navigateTo({
                            url: "../pageView/pageView?url=" + encodeURIComponent(e.data.shared.bootstrap.urls.idmsLoginUrlWithBindingRedirect)
                        }), o = u, e.setData({
                            shared: t(t({}, e.data.shared), {}, {
                                cookieJar: o
                            })
                        }), wx.setStorageSync("cookieJar", o), a.abrupt("return", o);

                      case 23:
                        return a.prev = 23, a.t0 = a.catch(10), console.error("disaFetch failed", a.t0), 
                        e.handleAllErrors(), a.abrupt("return");

                      case 28:
                      case "end":
                        return a.stop();
                    }
                }, r, null, [ [ 10, 23 ] ]);
            }))();
        },
        onNocheckout: function(e) {
            this.data.editing || this.setData({
                disableCheckout: e.detail
            });
        },
        shippingLocCookieCheck: function(e) {
            var n = this;
            return r(a().mark(function r() {
                var i, o, d, l;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if ("" === n.data.shippingUrl) {
                            a.next = 10;
                            break;
                        }
                        return a.next = 3, (0, s.requestWithCookies)({
                            url: decodeURIComponent(n.data.shippingUrl)
                        }, e);

                      case 3:
                        return i = a.sent, o = i.cookieJar, n.setData({
                            shippingUrl: ""
                        }), wx.setStorageSync("cookieJar", o), a.abrupt("return", o);

                      case 10:
                        if (!(d = e.find(function(e) {
                            return e.name.startsWith("as_loc");
                        }))) {
                            a.next = 20;
                            break;
                        }
                        if ((0, s.isExpired)(d)) {
                            a.next = 16;
                            break;
                        }
                        return a.abrupt("return", e);

                      case 16:
                        return l = e.filter(function(e) {
                            return !e.name.startsWith("as_loc");
                        }), n.setData({
                            shared: t(t({}, n.data.shared), {}, {
                                cookieJar: l
                            })
                        }), wx.setStorageSync("cookieJar", l), a.abrupt("return", l);

                      case 20:
                        return a.abrupt("return", e);

                      case 21:
                      case "end":
                        return a.stop();
                    }
                }, r);
            }))();
        },
        apuCookieCheck: function(e) {
            var n = this;
            return r(a().mark(function r() {
                var i, o, d, l;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if ("" === n.data.apuUrl) {
                            a.next = 10;
                            break;
                        }
                        return a.next = 3, (0, s.requestWithCookies)({
                            url: decodeURIComponent(n.data.apuUrl)
                        }, e);

                      case 3:
                        return i = a.sent, o = i.cookieJar, n.setData({
                            apuUrl: ""
                        }), wx.setStorageSync("cookieJar", o), a.abrupt("return", o);

                      case 10:
                        if (!(d = e.find(function(e) {
                            return e.name.startsWith("rtsid");
                        }))) {
                            a.next = 20;
                            break;
                        }
                        if ((0, s.isExpired)(d)) {
                            a.next = 16;
                            break;
                        }
                        return a.abrupt("return", e);

                      case 16:
                        return l = e.filter(function(e) {
                            return !e.name.startsWith("rtsid");
                        }), n.setData({
                            shared: t(t({}, n.data.shared), {}, {
                                cookieJar: l
                            })
                        }), wx.setStorageSync("cookieJar", l), a.abrupt("return", l);

                      case 20:
                        return a.abrupt("return", e);

                      case 21:
                      case "end":
                        return a.stop();
                    }
                }, r);
            }))();
        },
        affiliateCookieCheck: function(n) {
            var i = this;
            return r(a().mark(function r() {
                var o, s, d;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if ("" === i.data.affiliateKey || "" === i.data.affiliateVal) {
                            a.next = 9;
                            break;
                        }
                        return 60, (o = new Date()).setDate(o.getDate() + 60), s = {
                            name: i.data.affiliateKey,
                            value: i.data.affiliateVal,
                            path: "/",
                            expires: o,
                            domain: ".apple.com",
                            createdOn: Date.now()
                        }, d = [].concat(e(n), [ s ]), i.setData({
                            shared: t(t({}, i.data.shared), {}, {
                                cookieJar: d
                            })
                        }), wx.setStorageSync("cookieJar", d), a.abrupt("return", d);

                      case 9:
                        return a.abrupt("return", n);

                      case 10:
                      case "end":
                        return a.stop();
                    }
                }, r);
            }))();
        },
        clickEdit: function(e) {
            var t;
            if (!this.data.isEditingGiftPackage) {
                var a;
                if (null !== (t = this.data.bagDetails) && void 0 !== t && t.omniture) (0, d.trackLinkOmniture)({
                    type: "cartEdit",
                    omniture: null === (a = this.data.bagDetails) || void 0 === a ? void 0 : a.omniture,
                    data: null
                });
                if (this.data.editing) {
                    var r;
                    this.selectComponent("#cartProduct").hideAll(), this.setData({
                        edit: this.data.shared.textAssets.editing,
                        editing: !1,
                        disableCheckout: !1
                    });
                    var n = this.selectComponent("#cartProduct"), i = this.compareCart(n.data.cartdata, null === (r = this.data.bagDetails) || void 0 === r ? void 0 : r.lineItems);
                    "" !== i ? (console.log("editCart Update"), this.onUpdateQuantity(i)) : console.log("editCart No Update");
                } else this.setData({
                    edit: this.data.shared.textAssets.finish,
                    editing: !0,
                    disableCheckout: !0
                });
            }
        },
        compareCart: function(e, t) {
            for (var a = "", r = 0; r < t.length; r++) if (t[r].quantity !== e[r].quantity) {
                var n = "cart-" + e[r].lineItemId + "-quantity=" + e[r].quantity;
                a = "" === a ? n : a + "&" + n;
            }
            return a;
        },
        dni: function() {
            var e, t = this;
            if (!this.data.bagDetails) return console.error("Missing bag details"), void this.handleAllErrors();
            if (null !== (e = this.data.bagDetails) && void 0 !== e && e.hasAlerts) {
                var a, r;
                null === (a = this.data.bagDetails) || void 0 === a || null === (r = a.alerts) || void 0 === r || r.forEach(function(e) {
                    var a;
                    return wx.showModal({
                        content: e,
                        confirmText: null === (a = t.data.bagDetails) || void 0 === a ? void 0 : a.translations.ok,
                        showCancel: !1
                    });
                });
            } else {
                var n;
                this.setData({
                    "shared.urls.checkoutStart": this.data.bagDetails.transactions.checkoutURL
                }), null !== (n = this.data.bagDetails) && void 0 !== n && n.omniture && (0, d.trackLinkOmniture)({
                    type: "saveItem",
                    omniture: this.data.bagDetails.omniture,
                    data: null
                });
                var i = this;
                wx.navigateTo({
                    url: "../checkout/checkout",
                    events: {
                        acceptDataFromOpenedPage: function(e) {
                            console.log(e);
                        },
                        someEvent: function(e) {
                            console.log(e);
                        }
                    },
                    success: function(e) {
                        e.eventChannel.emit("acceptDataFromOpenerPage", {
                            data: i.data.bagDetails
                        });
                    }
                });
            }
        },
        onItemDelete: function(e) {
            var a, r = null === (a = this.data.bagDetails) || void 0 === a ? void 0 : a.omniture;
            if (r) {
                var n, i, o, s, l, u = null === (n = this.data) || void 0 === n || null === (i = n.bagDetails) || void 0 === i || null === (o = i.lineItems) || void 0 === o ? void 0 : o[null == e || null === (s = e.detail) || void 0 === s ? void 0 : s.id], c = null == u ? void 0 : u.omnitureProductString;
                u && c && null !== (l = r) && void 0 !== l && l.trackPage && (r = t(t({}, r), {}, {
                    trackPage: t(t({}, r.trackPage), {}, {
                        products: c
                    })
                })), (0, d.trackLinkOmniture)({
                    type: "removeItemCart",
                    omniture: r,
                    data: null
                });
            }
            this.onDelete(e.detail.id);
        },
        tradeInDelete: function(e) {
            this.onDeleteTradeIn(e.detail.child, e.detail.parent);
        },
        onAddGiftPackage: function(e) {
            var t, a = e.detail.item, r = e.detail.message;
            this.setData({
                disableCheckout: this.data.isEditingGiftPackage
            }), null !== (t = this.data.bagDetails) && void 0 !== t && t.omniture && (0, d.trackLinkOmniture)({
                type: "addGiftPackageCart",
                omniture: this.data.bagDetails.omniture,
                data: null
            }), this.addGiftPackage(a, r);
        },
        onDeleteGiftPackage: function(e) {
            var t;
            this.setData({
                disableCheckout: this.data.isEditingGiftPackage
            }), null !== (t = this.data.bagDetails) && void 0 !== t && t.omniture && (0, d.trackLinkOmniture)({
                type: "removeGiftPackageCart",
                omniture: this.data.bagDetails.omniture,
                data: null
            }), this.deleteGiftPackage(e.detail.url);
        },
        onEditGiftPackage: function(e) {
            this.setData({
                isEditingGiftPackage: e.detail,
                disableCheckout: !this.data.isEditingGiftPackage
            });
        },
        addGiftPackage: function(e, n) {
            var i = this;
            return r(a().mark(function r() {
                var o, d, l, u, c, h, g, f, p;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (e) {
                            a.next = 4;
                            break;
                        }
                        return console.error("invalid ID addGiftPackage"), i.handleAllErrors(), a.abrupt("return");

                      case 4:
                        if (o = e.lineItemId, d = e && e.gifting && e.gifting.addGiftPackage, l = "gift-message-" + o, 
                        i.data.bagDetails) {
                            a.next = 11;
                            break;
                        }
                        return console.error("add gift package, no bag details"), i.handleAllErrors(), a.abrupt("return");

                      case 11:
                        return wx.showLoading({
                            title: i.data.shared.textAssets.loading,
                            mask: !0
                        }), a.prev = 12, a.next = 15, (0, s.requestWithCookies)({
                            url: d,
                            method: "POST",
                            header: t(t({}, i.data.bagDetails.mandatoryAdditionalHeaders), {}, {
                                "content-type": "application/x-www-form-urlencoded"
                            }),
                            data: l + "=" + n
                        }, i.data.shared.cookieJar);

                      case 15:
                        if (u = a.sent, c = u.res, h = u.cookieJar, "string" != typeof c.data) {
                            a.next = 22;
                            break;
                        }
                        return console.error("something went wrong with the bag response, got string"), 
                        i.handleAllErrors(), a.abrupt("return");

                      case 22:
                        if ("ArrayBuffer" !== c.data.constructor.name) {
                            a.next = 26;
                            break;
                        }
                        return console.error("something went wrong with the bag response, got ArrayBuffer"), 
                        i.handleAllErrors(), a.abrupt("return");

                      case 26:
                        g = c.data, wx.hideLoading(), i.setData({
                            isEmpty: g.isEmptyCart,
                            bagDetails: g,
                            shared: t(t({}, i.data.shared), {}, {
                                cookieJar: h
                            })
                        }), null != g && g.hasAlerts && (null === (f = i.data.bagDetails) || void 0 === f || null === (p = f.alerts) || void 0 === p || p.forEach(function(e) {
                            var t;
                            return wx.showModal({
                                content: e,
                                confirmText: null === (t = i.data.bagDetails) || void 0 === t ? void 0 : t.translations.ok,
                                showCancel: !1
                            });
                        })), a.next = 38;
                        break;

                      case 32:
                        return a.prev = 32, a.t0 = a.catch(12), console.error("onUpdateQuantity failed", a.t0), 
                        wx.hideLoading(), i.handleAllErrors(), a.abrupt("return");

                      case 38:
                      case "end":
                        return a.stop();
                    }
                }, r, null, [ [ 12, 32 ] ]);
            }))();
        },
        deleteGiftPackage: function(e) {
            var n = this;
            return r(a().mark(function r() {
                var i, o, d, l;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (n.data.bagDetails) {
                            a.next = 4;
                            break;
                        }
                        return console.error("delete gift package, no bag details"), n.handleAllErrors(), 
                        a.abrupt("return");

                      case 4:
                        return wx.showLoading({
                            title: n.data.shared.textAssets.loading,
                            mask: !0
                        }), a.prev = 5, a.next = 8, (0, s.requestWithCookies)({
                            url: e,
                            method: "POST",
                            header: t(t({}, n.data.bagDetails.mandatoryAdditionalHeaders), {}, {
                                "content-type": "application/x-www-form-urlencoded"
                            })
                        }, n.data.shared.cookieJar);

                      case 8:
                        if (i = a.sent, o = i.res, d = i.cookieJar, "string" != typeof o.data) {
                            a.next = 15;
                            break;
                        }
                        return console.error("something went wrong with the bag response, got string"), 
                        n.handleAllErrors(), a.abrupt("return");

                      case 15:
                        if ("ArrayBuffer" !== o.data.constructor.name) {
                            a.next = 19;
                            break;
                        }
                        return console.error("something went wrong with the bag response, got ArrayBuffer"), 
                        n.handleAllErrors(), a.abrupt("return");

                      case 19:
                        l = o.data, wx.hideLoading(), n.setData({
                            isEmpty: l.isEmptyCart,
                            bagDetails: l,
                            shared: t(t({}, n.data.shared), {}, {
                                cookieJar: d
                            })
                        }), a.next = 30;
                        break;

                      case 24:
                        return a.prev = 24, a.t0 = a.catch(5), console.error("onRemoveGiftPackage failed", a.t0), 
                        wx.hideLoading(), n.handleAllErrors(), a.abrupt("return");

                      case 30:
                      case "end":
                        return a.stop();
                    }
                }, r, null, [ [ 5, 24 ] ]);
            }))();
        },
        onUpdateQuantity: function(e) {
            var n = this;
            return r(a().mark(function r() {
                var i, o, d, l, u, c, h, g;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (wx.showLoading({
                            title: n.data.shared.textAssets.loading,
                            mask: !0
                        }), n.data.bagDetails) {
                            a.next = 5;
                            break;
                        }
                        return console.error("Error: missing bag details"), n.handleAllErrors(), a.abrupt("return");

                      case 5:
                        return i = n.data.bagDetails.transactions, o = i.changeQuantityURL, a.prev = 7, 
                        a.next = 10, (0, s.requestWithCookies)({
                            url: o,
                            method: "POST",
                            header: t(t({}, n.data.bagDetails.mandatoryAdditionalHeaders), {}, {
                                "content-type": "application/x-www-form-urlencoded"
                            }),
                            data: e
                        }, n.data.shared.cookieJar);

                      case 10:
                        if (d = a.sent, l = d.res, u = d.cookieJar, "string" != typeof l.data) {
                            a.next = 17;
                            break;
                        }
                        return console.error("something went wrong with the bag response, got string"), 
                        n.handleAllErrors(), a.abrupt("return");

                      case 17:
                        if ("ArrayBuffer" !== l.data.constructor.name) {
                            a.next = 21;
                            break;
                        }
                        return console.error("something went wrong with the bag response, got ArrayBuffer"), 
                        n.handleAllErrors(), a.abrupt("return");

                      case 21:
                        c = l.data, wx.hideLoading(), n.setData({
                            isEmpty: c.isEmptyCart,
                            bagDetails: c,
                            shared: t(t({}, n.data.shared), {}, {
                                cookieJar: u
                            })
                        }), null != c && c.hasAlerts && (null === (h = n.data.bagDetails) || void 0 === h || null === (g = h.alerts) || void 0 === g || g.forEach(function(e) {
                            var t;
                            return wx.showModal({
                                content: e,
                                confirmText: null === (t = n.data.bagDetails) || void 0 === t ? void 0 : t.translations.ok,
                                showCancel: !1
                            });
                        })), a.next = 33;
                        break;

                      case 27:
                        return a.prev = 27, a.t0 = a.catch(7), console.error("onUpdateQuantity failed", a.t0), 
                        wx.hideLoading(), n.handleAllErrors(), a.abrupt("return");

                      case 33:
                      case "end":
                        return a.stop();
                    }
                }, r, null, [ [ 7, 27 ] ]);
            }))();
        },
        onDelete: function(e) {
            var n = this;
            return r(a().mark(function r() {
                var i, o, d, l, u;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (n.data.bagDetails) {
                            a.next = 4;
                            break;
                        }
                        return console.error("Missing bag, but onDelete called"), n.handleAllErrors(), a.abrupt("return");

                      case 4:
                        return i = n.data.bagDetails.lineItems[e], a.prev = 5, wx.showLoading({
                            title: n.data.shared.textAssets.loading,
                            mask: !0
                        }), a.next = 9, (0, s.requestWithCookies)({
                            url: i.deleteItem,
                            method: "POST",
                            header: n.data.bagDetails.mandatoryAdditionalHeaders
                        }, n.data.shared.cookieJar);

                      case 9:
                        if (o = a.sent, d = o.res, l = o.cookieJar, wx.hideLoading(), "string" != typeof d.data) {
                            a.next = 17;
                            break;
                        }
                        return console.error("something went wrong with the bag response, got string"), 
                        n.handleAllErrors(), a.abrupt("return");

                      case 17:
                        if ("ArrayBuffer" !== d.data.constructor.name) {
                            a.next = 21;
                            break;
                        }
                        return console.error("something went wrong with the bag response, got ArrayBuffer"), 
                        n.handleAllErrors(), a.abrupt("return");

                      case 21:
                        u = d.data, n.setData({
                            edit: n.data.shared.textAssets.editing,
                            editing: !1,
                            isEmpty: u.isEmptyCart,
                            bagDetails: u,
                            disableCheckout: !1,
                            shared: t(t({}, n.data.shared), {}, {
                                cookieJar: l
                            })
                        }), a.next = 31;
                        break;

                      case 25:
                        return a.prev = 25, a.t0 = a.catch(5), console.error("onDelete failed", a.t0), wx.hideLoading(), 
                        n.handleAllErrors(), a.abrupt("return");

                      case 31:
                      case "end":
                        return a.stop();
                    }
                }, r, null, [ [ 5, 25 ] ]);
            }))();
        },
        onDeleteTradeIn: function(e, n) {
            var i = this;
            return r(a().mark(function r() {
                var o, d, l, u, c;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (i.data.bagDetails) {
                            a.next = 4;
                            break;
                        }
                        return console.error("Missing bag, but onDelete called"), i.handleAllErrors(), a.abrupt("return");

                      case 4:
                        return o = i.data.bagDetails.lineItems[n].childItems[e], a.prev = 5, wx.showLoading({
                            title: i.data.shared.textAssets.loading,
                            mask: !0
                        }), a.next = 9, (0, s.requestWithCookies)({
                            url: o.deleteItem,
                            method: "POST",
                            header: i.data.bagDetails.mandatoryAdditionalHeaders
                        }, i.data.shared.cookieJar);

                      case 9:
                        if (d = a.sent, l = d.res, u = d.cookieJar, wx.hideLoading(), "string" != typeof l.data) {
                            a.next = 17;
                            break;
                        }
                        return console.error("something went wrong with the bag response, got string"), 
                        i.handleAllErrors(), a.abrupt("return");

                      case 17:
                        if ("ArrayBuffer" !== l.data.constructor.name) {
                            a.next = 21;
                            break;
                        }
                        return console.error("something went wrong with the bag response, got ArrayBuffer"), 
                        i.handleAllErrors(), a.abrupt("return");

                      case 21:
                        c = l.data, i.setData({
                            bagDetails: c,
                            shared: t(t({}, i.data.shared), {}, {
                                cookieJar: u
                            })
                        }), a.next = 31;
                        break;

                      case 25:
                        return a.prev = 25, a.t0 = a.catch(5), console.error("onDelete failed", a.t0), wx.hideLoading(), 
                        i.handleAllErrors(), a.abrupt("return");

                      case 31:
                      case "end":
                        return a.stop();
                    }
                }, r, null, [ [ 5, 25 ] ]);
            }))();
        },
        handleAllErrors: function() {
            return wx.showModal({
                content: this.data.shared.textAssets.genericDataError,
                confirmText: this.data.shared.textAssets.ok,
                showCancel: !1,
                success: function(e) {
                    e.confirm;
                }
            }), !0;
        }
    },
    behaviors: [ i.sharedDataBehavior ]
});