var t = require("../../utils/behavior"), e = require("../../utils/sharedData");

Component({
    data: {
        shared: e.initSharedData,
        aprStoreDetails: {},
        translations: {},
        isAprStoreDetailsFetching: !1
    },
    methods: {
        onLoad: function(t) {
            var e = JSON.parse(t.id);
            this.fetchAprStoreDetails(e);
        },
        fetchAprStoreDetails: function(t) {
            var e, a, s, r, i = this;
            this.setData({
                isAprStoreDetailsFetching: !0
            });
            var o = t, n = o.storeID, l = o.latitude, d = o.longitude;
            wx.request({
                url: null === (e = this.data) || void 0 === e || null === (a = e.shared) || void 0 === a || null === (s = a.bootstrap) || void 0 === s || null === (r = s.urls) || void 0 === r ? void 0 : r.aprstoredetails,
                data: {
                    type: "json",
                    storeId: n,
                    userLat: l,
                    userLong: d
                },
                method: "GET",
                success: function(t) {
                    var e = t.data.responseModel, a = t.data.translations;
                    i.setData({
                        aprStoreDetails: e,
                        translations: a,
                        isAprStoreDetailsFetching: !1
                    });
                },
                fail: function() {
                    console.log("FAILED");
                },
                complete: function() {
                    console.log("COMPLETED"), i.setData({
                        isAprStoreDetailsFetching: !1
                    });
                }
            });
        }
    },
    behaviors: [ t.sharedDataBehavior ]
});