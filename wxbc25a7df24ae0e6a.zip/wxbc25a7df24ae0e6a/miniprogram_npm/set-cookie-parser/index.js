var e, t, r = require("../../@babel/runtime/helpers/typeof");

module.exports = (e = {}, t = function(t, o) {
    if (!e[t]) return require(o);
    if (!e[t].status) {
        var s = e[t].m;
        s._exports = s._tempexports;
        var n = Object.getOwnPropertyDescriptor(s, "exports");
        n && n.configurable && Object.defineProperty(s, "exports", {
            set: function(e) {
                "object" === r(e) && e !== s._exports && (s._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(t) {
                    s._exports[t] = e[t];
                })), s._tempexports = e;
            },
            get: function() {
                return s._tempexports;
            }
        }), e[t].status = 1, e[t].func(e[t].req, s, s.exports);
    }
    return e[t].m.exports;
}, function(t, r, o) {
    e[t] = {
        status: 0,
        func: r,
        req: o,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1688958427026, function(e, t, r) {
    var o = {
        decodeValues: !0,
        map: !1,
        silent: !1
    };
    function s(e) {
        return "string" == typeof e && !!e.trim();
    }
    function n(e, t) {
        var r = e.split(";").filter(s), n = function(e) {
            var t = "", r = "", o = e.split("=");
            return o.length > 1 ? (t = o.shift(), r = o.join("=")) : r = e, {
                name: t,
                value: r
            };
        }(r.shift()), i = n.name, a = n.value;
        t = t ? Object.assign({}, o, t) : o;
        try {
            a = t.decodeValues ? decodeURIComponent(a) : a;
        } catch (e) {
            console.error("set-cookie-parser encountered an error while decoding a cookie with value '" + a + "'. Set options.decodeValues to false to disable this feature.", e);
        }
        var u = {
            name: i,
            value: a
        };
        return r.forEach(function(e) {
            var t = e.split("="), r = t.shift().trimLeft().toLowerCase(), o = t.join("=");
            "expires" === r ? u.expires = new Date(o) : "max-age" === r ? u.maxAge = parseInt(o, 10) : "secure" === r ? u.secure = !0 : "httponly" === r ? u.httpOnly = !0 : "samesite" === r ? u.sameSite = o : u[r] = o;
        }), u;
    }
    function i(e, t) {
        if (t = t ? Object.assign({}, o, t) : o, !e) return t.map ? {} : [];
        if (e.headers) if ("function" == typeof e.headers.getSetCookie) e = e.headers.getSetCookie(); else if (e.headers["set-cookie"]) e = e.headers["set-cookie"]; else {
            var r = e.headers[Object.keys(e.headers).find(function(e) {
                return "set-cookie" === e.toLowerCase();
            })];
            r || !e.headers.cookie || t.silent || console.warn("Warning: set-cookie-parser appears to have been called on a request object. It is designed to parse Set-Cookie headers from responses, not Cookie headers from requests. Set the option {silent: true} to suppress this warning."), 
            e = r;
        }
        return Array.isArray(e) || (e = [ e ]), (t = t ? Object.assign({}, o, t) : o).map ? e.filter(s).reduce(function(e, r) {
            var o = n(r, t);
            return e[o.name] = o, e;
        }, {}) : e.filter(s).map(function(e) {
            return n(e, t);
        });
    }
    t.exports = i, t.exports.parse = i, t.exports.parseString = n, t.exports.splitCookiesString = function(e) {
        if (Array.isArray(e)) return e;
        if ("string" != typeof e) return [];
        var t, r, o, s, n, i = [], a = 0;
        function u() {
            for (;a < e.length && /\s/.test(e.charAt(a)); ) a += 1;
            return a < e.length;
        }
        for (;a < e.length; ) {
            for (t = a, n = !1; u(); ) if ("," === (r = e.charAt(a))) {
                for (o = a, a += 1, u(), s = a; a < e.length && "=" !== (r = e.charAt(a)) && ";" !== r && "," !== r; ) a += 1;
                a < e.length && "=" === e.charAt(a) ? (n = !0, a = s, i.push(e.substring(t, o)), 
                t = a) : a = o + 1;
            } else a += 1;
            (!n || a >= e.length) && i.push(e.substring(t, e.length));
        }
        return i;
    };
}, function(e) {
    return t({}[e], e);
}), t(1688958427026));