var t, e, r = require("../../@babel/runtime/helpers/typeof");

module.exports = (t = {}, e = function(e, o) {
    if (!t[e]) return require(o);
    if (!t[e].status) {
        var n = t[e].m;
        n._exports = n._tempexports;
        var u = Object.getOwnPropertyDescriptor(n, "exports");
        u && u.configurable && Object.defineProperty(n, "exports", {
            set: function(t) {
                "object" === r(t) && t !== n._exports && (n._exports.__proto__ = t.__proto__, Object.keys(t).forEach(function(e) {
                    n._exports[e] = t[e];
                })), n._tempexports = t;
            },
            get: function() {
                return n._tempexports;
            }
        }), t[e].status = 1, t[e].func(t[e].req, n, n.exports);
    }
    return t[e].m.exports;
}, function(e, r, o) {
    t[e] = {
        status: 0,
        func: r,
        req: o,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1688958427025, function(t, e, r) {
    var o, n, u, a = (o = {
        km: 6371,
        mile: 3960,
        meter: 6371e3,
        nmi: 3440
    }, n = function(t) {
        return t * Math.PI / 180;
    }, u = function(t, e) {
        switch (t) {
          case "[lat,lon]":
            return {
                latitude: e[0],
                longitude: e[1]
            };

          case "[lon,lat]":
            return {
                latitude: e[1],
                longitude: e[0]
            };

          case "{lon,lat}":
            return {
                latitude: e.lat,
                longitude: e.lon
            };

          case "{lat,lng}":
            return {
                latitude: e.lat,
                longitude: e.lng
            };

          case "geojson":
            return {
                latitude: e.geometry.coordinates[1],
                longitude: e.geometry.coordinates[0]
            };

          default:
            return e;
        }
    }, function(t, e, r) {
        var a = (r = r || {}).unit in o ? o[r.unit] : o.km, i = u(r.format, t), s = u(r.format, e), l = n(s.latitude - i.latitude), c = n(s.longitude - i.longitude), p = n(i.latitude), d = n(s.latitude), f = Math.sin(l / 2) * Math.sin(l / 2) + Math.sin(c / 2) * Math.sin(c / 2) * Math.cos(p) * Math.cos(d), m = 2 * Math.atan2(Math.sqrt(f), Math.sqrt(1 - f));
        return r.threshold ? r.threshold > a * m : a * m;
    });
    void 0 !== e && e.exports && (e.exports = a);
}, function(t) {
    return e({}[t], t);
}), e(1688958427025));