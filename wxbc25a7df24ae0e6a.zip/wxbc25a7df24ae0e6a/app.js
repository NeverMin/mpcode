var e, a, t = require("@babel/runtime/helpers/regeneratorRuntime"), o = require("@babel/runtime/helpers/asyncToGenerator"), r = require("./utils/sharedData"), i = require("./utils/util"), s = (e = require("./analytics/AdobeSDK-1.0.0")) && e.__esModule ? e : {
    default: e
};

App({
    globalData: {
        shared: r.initSharedData
    },
    onLaunch: function() {
        this.bootstrap();
        var e = s.default;
        e.init({
            "analytics.server": "securemetrics.apple.com.cn",
            "analytics.rsids": "applestorewwwechat",
            "app.id": "wechat-mini-program",
            "app.version": "2.30.0",
            "analytics.offlineEnabled": !0,
            "session.timeout": 30
        }), e.setDebugLoggingEnabled(!0), e.setDebugModeEnabled(!0);
    },
    bootstrap: (a = o(t().mark(function e() {
        var a, o, r, i = this;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return (a = wx.getStorageSync("bootstrapURL")) ? this.globalData.shared.bootstrapURL = a : a = this.globalData.shared.bootstrapURL, 
                e.next = 4, this.bootstrapRequest(a);

              case 4:
                o = e.sent, (r = o.res).data ? this.globalData.shared.bootstrap = r.data : console.log(r.errMsg), 
                Promise.all([ this.diwaCheck(), this.getLocation() ]).then(function() {
                    i.globalData.shared.isAppReady = !0;
                });

              case 8:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function() {
        return a.apply(this, arguments);
    }),
    diwaCheck: function() {
        var e = this;
        return new Promise(function(a, t) {
            var o = e.globalData.shared.bootstrap.diwaCookieName, r = e.globalData.shared.bootstrap.urls.diwaFetchURL, s = wx.getStorageSync("cookieJar") || [], n = s.find(function(e) {
                return e.name === o;
            });
            if (n && !(0, i.isExpired)(n, 604800)) e.globalData.shared.cookieJar = s, a("diwa cookie"); else {
                var c = e;
                wx.login({
                    success: function(e) {
                        if (e.code) {
                            if (!r) throw new Error("error, missing diwaFetchURL");
                            wx.request({
                                url: (0, i.appendUrlParams)(r, "code=" + encodeURIComponent(e.code)),
                                method: "GET",
                                header: {
                                    "content-type": "application/json"
                                },
                                success: function(e) {
                                    var t = (0, i.parseAllCookies)(e.header);
                                    wx.setStorageSync("cookieJar", t), c.globalData.shared.cookieJar = t, a("diwa cookie");
                                },
                                fail: function(e) {
                                    t(e);
                                }
                            });
                        } else t("login failed");
                    }
                });
            }
        });
    },
    getLocation: function() {
        var e = this;
        return new Promise(function(a) {
            var t = e;
            wx.getLocation({
                type: "wgs84",
                success: function(e) {
                    t.globalData.shared.location = {
                        latitude: e.latitude,
                        longitude: e.longitude
                    }, a("location value");
                },
                fail: function(e) {
                    a("no location access");
                }
            });
        });
    },
    watch: function(e) {
        var a = this.globalData.shared;
        Object.defineProperty(a, "isAppReady", {
            configurable: !0,
            enumerable: !0,
            set: function(a) {
                this._isAppReady = a, e(a);
            },
            get: function() {
                return this._isAppReady;
            }
        });
    },
    bootstrapRequest: function(e) {
        return (0, i.requestWithCookies)({
            url: e,
            method: "GET"
        }, this.globalData.shared.cookieJar);
    }
});