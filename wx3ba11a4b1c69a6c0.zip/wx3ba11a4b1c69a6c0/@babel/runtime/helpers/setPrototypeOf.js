function _setPrototypeOf(t, o) {
    return module.exports = _setPrototypeOf = Object.setPrototypeOf || function(t, o) {
        return t.__proto__ = o, t;
    }, _setPrototypeOf(t, o);
}

module.exports = _setPrototypeOf;