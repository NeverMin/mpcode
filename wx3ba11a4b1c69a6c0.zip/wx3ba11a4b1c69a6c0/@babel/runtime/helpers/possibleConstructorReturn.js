var _typeof = require("./typeof"), assertThisInitialized = require("./assertThisInitialized");

function _possibleConstructorReturn(e, t) {
    return !t || "object" !== _typeof(t) && "function" != typeof t ? assertThisInitialized(e) : t;
}

module.exports = _possibleConstructorReturn;