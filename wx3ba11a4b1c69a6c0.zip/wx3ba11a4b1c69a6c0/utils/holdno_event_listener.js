var e = {
    debug: !0,
    _store: [],
    emit: function(e, o) {
        for (var t = this._store, n = t.length, s = 0; s < n; s++) e == t[s].event && this._store[s].callback(o), 
        s >= n && this.debug && console.error("Emit error: The event is not defined");
    },
    on: function(e, o, t) {
        console.log("event on key", t);
        this._store.length;
        if (e && o) {
            this.debug && console.log("Add new listener: " + e);
            var n = {
                event: e,
                callback: o,
                key: t
            };
            this._store.push(n);
        } else this.debug && console.warn("The two argument must not be empty");
    },
    off: function(e) {
        var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
        console.log("event off key", o);
        for (var t = this._store, n = t.length, s = 0, r = 0; r < n; r++) t[r] && e === t[r].event && t[r].key == o && (t.splice(r, 1), 
        s = 1);
        this.debug && (1 === s ? console.log("Remove listener: " + e) : console.error("Remove listener error:" + e + " is not defined"));
    }
};

module.exports = e;