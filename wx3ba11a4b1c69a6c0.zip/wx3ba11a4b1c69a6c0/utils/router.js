require("../@babel/runtime/helpers/Arrayincludes");

var e = require("../contants/routes"), t = e.TabRoutes, r = e.RouterMap;

function a(e) {
    return r.get(e);
}

module.exports = {
    navigateBack: function() {
        for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            url: ""
        }, t = getCurrentPages(), r = 0, a = e.url, n = t.length - 1; n >= 0; n--) {
            if ("/" + t[n].route === a) {
                if (0 === r) return;
                return void wx.navigateBack({
                    delta: r
                });
            }
            r++;
        }
        wx.navigateTo({
            url: a
        });
    },
    hlNavigateTo: function(e) {
        var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = a(e);
        if (n) {
            var o = n.format ? n.format(n.path, r) : n.path;
            n.isTab ? wx.switchTab({
                url: o
            }) : wx.navigateTo({
                url: o
            });
        } else t.some(function(t) {
            return e.includes(t);
        }) ? wx.switchTab({
            url: e
        }) : wx.navigateTo({
            url: e,
            fail: function(e) {
                wx.showToast({
                    title: "无效配置，请联系管理员",
                    icon: "none"
                }), console.error(e);
            }
        });
    },
    getRouteInfoByPopup: a
};