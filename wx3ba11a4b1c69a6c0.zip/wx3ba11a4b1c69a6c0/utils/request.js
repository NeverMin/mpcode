require("../@babel/runtime/helpers/Arrayincludes");

var e = require("promise").Promise, t = "https://svc.heartlylab.com", a = function(t) {
    return function(a) {
        return new e(function(e, o) {
            var r = getApp(), n = {
                "content-type": "application/x-www-form-urlencoded",
                platform: "miniprogram"
            };
            r && r.globalData.userInfo.token && (t.includes("gateWay") ? (n["Content-Type"] = "application/json", 
            n["r.x-token"] = r.globalData.userInfo.token) : n["x-token"] = r.globalData.userInfo.token), 
            a.header && Object.assign(n, a.header), wx.request({
                url: t + a.url,
                method: a.method,
                data: a.data,
                header: n,
                success: function(t) {
                    (t = t.data).meta && 0 == t.meta.code || void 0 === t.meta || wx.hideLoading(), 
                    e(t);
                },
                fail: function() {
                    wx.hideLoading(), o();
                }
            });
        });
    };
};

module.exports = {
    request: a(t),
    gateRequest: a("https://gateWay.heartlylab.com"),
    baseUrl: t
};