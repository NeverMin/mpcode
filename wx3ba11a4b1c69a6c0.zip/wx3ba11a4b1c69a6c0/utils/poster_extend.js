var e = require("../@babel/runtime/helpers/objectSpread2");

module.exports = {
    name: "getTmpPath",
    handler: function(t) {
        var i = this;
        return new Promise(function(r, h) {
            var a = e({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                destWidth: 0,
                destHeight: 0,
                modalOption: {}
            }, t);
            wx.canvasToTempFilePath({
                x: a.x,
                y: a.y,
                width: a.width,
                height: a.height,
                destWidth: i.xDpr(a.destWidth),
                destHeight: i.xDpr(a.destHeight),
                canvas: i.canvas,
                success: function(e) {
                    r(e.tempFilePath);
                },
                fail: function() {
                    i.debugLogout("生成图片失败", "error"), h(Error("生成图片失败"));
                }
            });
        });
    }
};