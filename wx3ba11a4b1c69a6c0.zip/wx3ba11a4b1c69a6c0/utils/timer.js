Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../@babel/runtime/helpers/classCallCheck"), e = require("../@babel/runtime/helpers/createClass"), i = function() {
    function i() {
        t(this, i), this.startTime = Date.now(), this.lastTime = this.startTime, this.isStop = !1, 
        this.stopTime = 0, this.pauseDuration = 0;
    }
    return e(i, [ {
        key: "reset",
        value: function() {
            this.startTime = Date.now(), this.lastTime = this.startTime, this.isStop = !1, this.stopTime = 0, 
            this.pauseDuration = 0;
        }
    }, {
        key: "getPauseDuration",
        value: function() {
            return this.isStop ? Date.now() - this.stopTime + this.pauseDuration : this.pauseDuration;
        }
    }, {
        key: "pause",
        value: function() {
            this.isStop || (this.isStop = !0, this.stopTime = Date.now());
        }
    }, {
        key: "play",
        value: function() {
            if (this.isStop) {
                this.isStop = !1;
                var t = Date.now() - this.stopTime;
                this.pauseDuration += t, this.stopTime = 0;
            }
        }
    }, {
        key: "updateAndGetDelta",
        value: function() {
            var t = Date.now(), e = t - this.lastTime;
            return this.lastTime = t, this.timing += e, e;
        }
    }, {
        key: "updateAndGetTotal",
        value: function() {
            var t = Date.now(), e = t - this.startTime;
            return this.lastTime = t, e;
        }
    }, {
        key: "updateAndGetTiming",
        value: function() {
            return Date.now() - this.startTime - this.getPauseDuration();
        }
    } ]), i;
}();

exports.default = i;