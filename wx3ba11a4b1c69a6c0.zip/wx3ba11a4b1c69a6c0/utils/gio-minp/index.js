var e = require("../../@babel/runtime/helpers/assertThisInitialized"), t = require("../../@babel/runtime/helpers/toConsumableArray");

require("../../@babel/runtime/helpers/Arrayincludes");

var n = require("../../@babel/runtime/helpers/get"), i = require("../../@babel/runtime/helpers/getPrototypeOf"), r = require("../../@babel/runtime/helpers/inherits"), o = require("../../@babel/runtime/helpers/createSuper");

require("../../@babel/runtime/helpers/Objectentries");

var s = require("../../@babel/runtime/helpers/slicedToArray"), a = require("../../@babel/runtime/helpers/classCallCheck"), u = require("../../@babel/runtime/helpers/createClass"), c = require("../../@babel/runtime/helpers/typeof"), g = require("../../@babel/runtime/helpers/createForOfIteratorHelper");

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var l, h = {
    devVer: 1,
    guid: function() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
            var t = 16 * Math.random() | 0;
            return ("x" == e ? t : 3 & t | 8).toString(16);
        });
    },
    getScreenHeight: function(e) {
        return e.pixelRatio ? Math.round(e.screenHeight * e.pixelRatio) : e.screenHeight;
    },
    getScreenWidth: function(e) {
        return e.pixelRatio ? Math.round(e.screenWidth * e.pixelRatio) : e.screenWidth;
    },
    getOS: function(e) {
        if (e) {
            var t = e.toLowerCase();
            return -1 != t.indexOf("android") ? "".concat(gioGlobal.platformConfig.name, "-Android") : -1 != t.indexOf("ios") ? "".concat(gioGlobal.platformConfig.name, "-iOS") : e;
        }
    },
    getOSV: function(e) {
        return "".concat(gioGlobal.platformConfig.name, " ").concat(e);
    },
    isEmpty: function(e) {
        for (var t in e) if (Object.prototype.hasOwnProperty.call(e, t)) return !1;
        return !0;
    },
    compareVersion: function(e, t) {
        e = e.split("."), t = t.split(".");
        for (var n = Math.max(e.length, t.length); n > e.length; ) e.push("0");
        for (;n > t.length; ) t.push("0");
        for (var i = 0; n > i; i++) {
            var r = parseInt(e[i]), o = parseInt(t[i]);
            if (r > o) return 1;
            if (o > r) return -1;
        }
        return 0;
    },
    queryParse: function(e) {
        var t = {};
        if (e) {
            var n, i = e.split("&"), r = g(i);
            try {
                for (r.s(); !(n = r.n()).done; ) {
                    var o = n.value.split("="), s = o.length;
                    2 == s ? t[o[0]] = o[1] : 1 == s && o[0] && (t[o[0]] = "");
                }
            } catch (e) {
                r.e(e);
            } finally {
                r.f();
            }
        }
        return t;
    },
    queryStringify: function(e) {
        for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) n[i - 1] = arguments[i];
        return Object.keys(e).filter(function(e) {
            return !n || !n.includes(e);
        }).map(function(t) {
            return "".concat(t, "=").concat(e[t]);
        }).join("&");
    },
    clearShareQuery: function(e) {
        if (e) {
            var t = h.queryParse(e);
            return delete t.shareId, delete t.contentType, h.queryStringify(t);
        }
    }
}, p = function() {
    var e = gioGlobal.vdsConfig.taro;
    return !(!e.vue && (e && e.taro && (e = e.taro), !e || e.createApp || !document.getElementById));
}, f = function(e) {
    return e.replace(e[0], e[0].toLowerCase());
}, v = function(e, t) {
    if (!e) return e;
    for (var n = t.split("."), i = e[n.shift()], r = 0, o = n.length; o > r; r++) {
        var s = n.shift();
        if (!i) return i;
        i = i[s];
    }
    return i;
}, d = function(e) {
    var t = {
        eventId: void 0,
        properties: {}
    };
    try {
        if (e.hasOwnProperty("gioTrack") && "object" == c(e.gioTrack)) return t.eventId = e.gioTrack.name, 
        t.properties = e.gioTrack.properties, t;
        if (!e.gioImpTrack) return t;
        t.eventId = e.gioImpTrack;
        var n = /^gioTrack(.+)/, i = /^\w+$/;
        for (var r in e) {
            var o = void 0, s = r.match(n);
            if (s && ("track" === (o = f(s[1])) ? t.eventId = e[r] : t.properties[o] = e[r]), 
            !i.test(t.eventId) || 10 > parseInt(t.eventId[0])) throw t.eventId = null, Error();
        }
    } catch (e) {
        console.warn("半打点IMP格式不正确, 事件名只能包含数字，字母和下划线，且不以数字开头, 请参考文档");
    }
    return t;
}, y = function(e) {
    var t = e.split(/[\r\n]/);
    return function(e) {
        var t = [];
        if (e && e.length > 0) for (var n = 0; e.length > n; n++) {
            var i = e[n];
            if (t[0] = e[n - 1], t[1] = i, /at /.test(i)) break;
        }
        if (!t.some(function(e) {
            return !e;
        })) {
            var r = t[0].split(/: ?/);
            if (r && !(2 > r.length)) {
                var o = t[1].match(/at (.*?) \((.*)\)/);
                return o && o.length >= 3 ? {
                    key: r[0],
                    error: r[1],
                    function: o[1],
                    page: o[2]
                } : void 0;
            }
        }
    }(t) || function(e) {
        var t;
        if (e && e.length > 1) {
            var n = e[1].split(";");
            if (n && n.length > 1) {
                var i = n[1].match(/at ([^ ]+) page (.*) function/);
                t = {
                    key: e[0],
                    error: n[0]
                }, i && i.length > 2 && (t.page = i[1], t.function = i[2]);
            }
        }
        return t;
    }(t) || function(e) {
        if (e && e.length > 0) return {
            error: e.join("")
        };
    }(t);
};

Object.hasOwnProperty("getOwnPropertyDescriptors") || (l = "object" == ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.ownKeys ? Reflect.ownKeys : "function" == typeof Object.getOwnPropertySymbols ? function(e) {
    return Object.getOwnPropertyNames(e).concat(Object.getOwnPropertySymbols(e));
} : Object.getOwnPropertyNames, Object.defineProperty(Object, "getOwnPropertyDescriptors", {
    configurable: !0,
    writable: !0,
    value: function(e) {
        return l(e).reduce(function(t, n) {
            return Object.defineProperty(t, n, {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                value: Object.getOwnPropertyDescriptor(e, n)
            });
        }, {});
    }
}));

Object.entries || (Object.entries = function(e) {
    for (var t = Object.keys(e), n = t.length, i = Array(n); n--; ) i[n] = [ t[n], e[t[n]] ];
    return i;
});

var m = function() {
    function e(t) {
        a(this, e), this.growingio = t;
    }
    return u(e, [ {
        key: "setDataCollect",
        value: function(e) {
            "boolean" == typeof e ? (this.growingio.vdsConfig.dataCollect = e, console.log("GrowingIO：已".concat(e ? "开启" : "关闭", "数据采集"))) : console.log("GrowingIO：开启/关闭数据采集失败，请检查参数");
        }
    }, {
        key: "enableDebug",
        value: function(e) {
            e && console && (this.growingio.vdsConfig.debug = e);
        }
    }, {
        key: "setTrackerScheme",
        value: function(e) {
            var t = (e + "").toLocaleLowerCase();
            "http" !== t && "https" !== t || (this.growingio.vdsConfig.scheme = "".concat(e, "://"));
        }
    }, {
        key: "setTrackerHost",
        value: function(e) {
            (function(e) {
                return e && "string" == typeof e && e.constructor === String;
            })(e) && (this.growingio.vdsConfig.host = e);
        }
    }, {
        key: "setAutotrack",
        value: function(e) {
            "boolean" == typeof e ? (this.growingio.vdsConfig.autotrack = e, console.log("GrowingIO：已".concat(e ? "开启" : "关闭", "无埋点事件"))) : console.log("GrowingIO：开启/关闭无埋点事件失败，请检查参数");
        }
    } ]), e;
}();

function w() {}

var b = w.prototype, _ = exports.EventEmitter;

function k(e, t) {
    for (var n = e.length; n--; ) if (e[n].listener === t) return n;
    return -1;
}

function P(e) {
    return function() {
        return this[e].apply(this, arguments);
    };
}

b.getListeners = function(e) {
    var t, n, i = this._getEvents();
    if (e instanceof RegExp) for (n in t = {}, i) i.hasOwnProperty(n) && e.test(n) && (t[n] = i[n]); else t = i[e] || (i[e] = []);
    return t;
}, b.flattenListeners = function(e) {
    var t, n = [];
    for (t = 0; e.length > t; t += 1) n.push(e[t].listener);
    return n;
}, b.getListenersAsObject = function(e) {
    var t, n = this.getListeners(e);
    return n instanceof Array && ((t = {})[e] = n), t || n;
}, b.addListener = function(e, t) {
    if (!function e(t) {
        return "function" == typeof t || t instanceof RegExp || !(!t || "object" != c(t)) && e(t.listener);
    }(t)) throw new TypeError("listener must be a function");
    var n, i = this.getListenersAsObject(e), r = "object" == c(t);
    for (n in i) i.hasOwnProperty(n) && -1 === k(i[n], t) && i[n].push(r ? t : {
        listener: t,
        once: !1
    });
    return this;
}, b.on = P("addListener"), b.addOnceListener = function(e, t) {
    return this.addListener(e, {
        listener: t,
        once: !0
    });
}, b.once = P("addOnceListener"), b.defineEvent = function(e) {
    return this.getListeners(e), this;
}, b.defineEvents = function(e) {
    for (var t = 0; e.length > t; t += 1) this.defineEvent(e[t]);
    return this;
}, b.removeListener = function(e, t) {
    var n, i, r = this.getListenersAsObject(e);
    for (i in r) r.hasOwnProperty(i) && -1 !== (n = k(r[i], t)) && r[i].splice(n, 1);
    return this;
}, b.off = P("removeListener"), b.addListeners = function(e, t) {
    return this.manipulateListeners(!1, e, t);
}, b.removeListeners = function(e, t) {
    return this.manipulateListeners(!0, e, t);
}, b.manipulateListeners = function(e, t, n) {
    var i, r, o = e ? this.removeListener : this.addListener, s = e ? this.removeListeners : this.addListeners;
    if ("object" != c(t) || t instanceof RegExp) for (i = n.length; i--; ) o.call(this, t, n[i]); else for (i in t) t.hasOwnProperty(i) && (r = t[i]) && ("function" == typeof r ? o.call(this, i, r) : s.call(this, i, r));
    return this;
}, b.removeEvent = function(e) {
    var t, n = c(e), i = this._getEvents();
    if ("string" === n) delete i[e]; else if (e instanceof RegExp) for (t in i) i.hasOwnProperty(t) && e.test(t) && delete i[t]; else delete this._events;
    return this;
}, b.removeAllListeners = P("removeEvent"), b.emitEvent = function(e, t) {
    var n, i, r, o, s = this.getListenersAsObject(e);
    for (o in s) if (s.hasOwnProperty(o)) for (n = s[o].slice(0), r = 0; n.length > r; r++) !0 === (i = n[r]).once && this.removeListener(e, i.listener), 
    i.listener.apply(this, t || []) === this._getOnceReturnValue() && this.removeListener(e, i.listener);
    return this;
}, b.trigger = P("emitEvent"), b.emit = function(e) {
    var t = Array.prototype.slice.call(arguments, 1);
    return this.emitEvent(e, t);
}, b.setOnceReturnValue = function(e) {
    return this._onceReturnValue = e, this;
}, b._getOnceReturnValue = function() {
    return !this.hasOwnProperty("_onceReturnValue") || this._onceReturnValue;
}, b._getEvents = function() {
    return this._events || (this._events = {});
}, w.noConflict = function() {
    return exports.EventEmitter = _, w;
};

var C = new w(), I = void 0;

function S(e, t, n) {
    var i = e.growingio;
    if (i && i.vdsConfig.followShare) {
        var r = i.info.uid;
        n || (n = {}), n.title || (n.title = e.info.getPageTitle(t));
        var o = e.currentPage, a = function(e) {
            if (e) {
                var t = e.indexOf("?");
                if (-1 !== t) return [ e.substring(0, t), e.substring(t + 1) ];
            }
            return [ e, "" ];
        }(n.path), u = s(a, 2), c = u[0], g = function(e, t, n) {
            var i = {
                gioShareId: h.guid(),
                suid: t
            }, r = Object.assign(h.queryParse(e), i), o = r.contentType || n.contentType, s = r.contentId || n.contentId;
            return o && (i.contentType = o), s && (i.contentId = s), I && (i.gioPreShareId = I), 
            [ h.queryStringify(r), i ];
        }(u[1] || n.query, r, n), l = s(g, 2), p = l[0], f = l[1];
        n.query = p, n.path = function(e) {
            return /^\//.test(e) ? e : "/" + e;
        }((c || o.path) + "?" + p), n.attributes = f;
    }
    return n;
}

var O = {};

function E(e) {
    return !e || !e.target || !e.type;
}

function x(e, t) {
    if (!E(t)) return e.includes(t.type) && !function(e) {
        var t = e.target.id, n = e.currentTarget.id;
        return !(!n || n === t || !O[t]);
    }(t);
}

function A(e) {
    E(e) || e.isPropagationStopped && (O[e.target.id] = e.isPropagationStopped());
}

var T = function(e, t, n) {
    return S(q.observer, e, n);
}, G = void 0;

function j(e) {
    var t = (null == e ? void 0 : e[0]) ? e[0] : G;
    return t && t.type && function(e) {
        return "[object Object]" === Object.prototype.toString.apply(e);
    }(t.target) && -1 !== q.actionEventTypes.indexOf(t.type) ? t : G;
}

var q = {
    defaultPageCallbacks: {},
    defaultAppCallbacks: {},
    appHandlers: null,
    pageHandlers: null,
    actionEventTypes: null,
    originalPage: null,
    originalApp: null,
    originalComponent: null,
    originalBehavior: null,
    observer: null,
    hook: function(e, t, n) {
        return function() {
            var i, r = n || this || {}, o = j(arguments), s = v(q.observer.growingio, "vdsConfig.".concat("octopus")), a = function() {
                if (o && (o.currentTarget || o.target) && -1 != q.actionEventTypes.indexOf(o.type) && (n || !p())) try {
                    q.observer.actionListener(o, e);
                } catch (e) {
                    console.error(e);
                }
            };
            s || a();
            var u = gioGlobal.platformConfig.lisiteners.app, c = gioGlobal.platformConfig.lisiteners.page;
            if (gioGlobal.vdsConfig.taro.vue && o && (G = o), r._growing_app_ && e !== u.appShow || r._growing_page_ && -1 === [ c.pageShow, c.pageClose, c.pageLoad, c.pageHide, c.tabTap ].indexOf(e) ? i = t.apply(this, arguments) : r._growing_app_ || r._growing_page_ || (i = t.apply(this, arguments)), 
            G = void 0, r._growing_app_) {
                if (-1 !== q.appHandlers.indexOf(e)) try {
                    q.defaultAppCallbacks[e].apply(this, arguments);
                } catch (e) {
                    console.error(e);
                }
                e === u.appShow && (i = t.apply(this, arguments));
            }
            if (r._growing_page_ && -1 !== q.pageHandlers.indexOf(e)) {
                (c.shareTime == e || c.shareApp == e) && (i = T(r, 0, i));
                var g = Array.prototype.slice.call(arguments);
                i && g.push(i);
                try {
                    q.defaultPageCallbacks[e].apply(r, g);
                } catch (e) {
                    console.error(e);
                }
                -1 !== [ c.pageShow, c.pageClose, c.pageLoad, c.pageHide, c.tabTap ].indexOf(e) && (i = t.apply(this, arguments));
            }
            return s && x(q.actionEventTypes, o) && a(), A(o), i;
        };
    },
    hookComponent: function(e, t) {
        return function() {
            var n = arguments ? arguments[0] : void 0;
            if (n && (n.currentTarget || n.target) && -1 != q.actionEventTypes.indexOf(n.type)) try {
                q.observer.actionListener(n, e);
            } catch (e) {
                console.error(e);
            }
            return t.apply(this, arguments);
        };
    },
    hookPage: function(e, t) {
        return function() {
            var n = t.apply(this, arguments);
            (e === gioGlobal.platformConfig.lisiteners.page.shareTime || e === gioGlobal.platformConfig.lisiteners.page.shareApp) && (n = T(this, 0, n));
            var i = Array.prototype.slice.call(arguments);
            return n && i.push(n), q.observer.pageListener(this, e, i), n;
        };
    },
    instrument: function(e) {
        var t = this, n = {}, i = function(i) {
            n[i] = "function" == typeof e[i] && "constructor" !== i ? t.hook(i, e[i]) : e[i];
        };
        return Object.getOwnPropertyNames(e).forEach(i), e.__proto__ !== Object.prototype && Object.getOwnPropertyNames(e.__proto__).forEach(i), 
        n._growing_app_ && q.appHandlers.map(function(e) {
            n[e] || (n[e] = q.defaultAppCallbacks[e]);
        }), n._growing_page_ && q.pageHandlers.map(function(e) {
            n[e] || e === gioGlobal.platformConfig.lisiteners.page.shareApp || e === gioGlobal.platformConfig.lisiteners.page.shareTime || (n[e] = q.defaultPageCallbacks[e]);
        }), n;
    },
    instrumentPageComponent: function(e) {
        if (e) return q.pageHandlers.map(function(t) {
            if ("function" == typeof e[t]) e[t] = q.hookPage(t, e[t]); else if (t !== gioGlobal.platformConfig.lisiteners.page.shareApp && t !== gioGlobal.platformConfig.lisiteners.page.shareTime) {
                var n = t;
                e[t] = function() {
                    q.observer.pageListener(this, n, arguments);
                };
            }
        }), e;
    },
    instrumentComponent: function(e) {
        var t = this, n = e._growing_aspage_, i = e.methods || {};
        return Object.entries(i).forEach(function(e) {
            var r = s(e, 2), o = r[0], a = r[1];
            "function" == typeof a && (i[o] = function(e) {
                return -1 != q.pageHandlers.indexOf(e);
            }(o) ? n ? t.hookPage(o, a) : a : t.hookComponent(o, a));
        }), n && q.pageHandlers.map(function(e) {
            if (!i[e] && !function(e) {
                return e == gioGlobal.platformConfig.lisiteners.page.shareApp || e == gioGlobal.platformConfig.lisiteners.page.shareTime;
            }(e)) {
                var t = e;
                i[e] = function() {
                    q.observer.pageListener(this, t, arguments);
                };
            }
        }), e.methods = i, e;
    },
    GrowingPage: function(e) {
        return e._growing_page_ = !0, q.originalPage(q.instrument(e));
    },
    GrowingComponent: function(e) {
        return e._growing_aspage_ = gioGlobal.vdsConfig.comAsPage, q.originalComponent(q.instrumentComponent(e));
    },
    GrowingBehavior: function(e) {
        return q.originalBehavior(q.instrumentComponent(e));
    },
    GrowingApp: function(e) {
        return e._growing_app_ = !0, q.originalApp(q.instrument(e));
    },
    initPlatformInfo: function(e) {
        q.appHandlers = e.appHandlers, q.pageHandlers = e.pageHandlers, q.actionEventTypes = e.actionEventTypes, 
        q.originalApp = e.originalApp, q.originalPage = e.originalPage, q.originalComponent = e.originalComponent, 
        q.originalBehavior = e.originalBehavior;
    },
    initInstrument: function(e) {
        if (q.initPlatformInfo(gioGlobal.platformConfig), q.observer = e, q.pageHandlers.forEach(function(e) {
            var t = e;
            q.defaultPageCallbacks[e] = function() {
                q.observer.pageListener(this, t, arguments);
            };
        }), q.appHandlers.forEach(function(e) {
            var t = e;
            q.defaultAppCallbacks[e] = function() {
                q.observer.appListener(this, t, arguments);
            };
        }), gioGlobal.platformConfig.canHook) {
            var t = gioGlobal.platformConfig.hooks;
            if (t.App && !gioGlobal.growingAppInited) {
                if (App = function() {
                    return q.GrowingApp(arguments[0]);
                }, "swan" === gioGlobal.gio__platform) for (var n in q.originalApp) App[n] = q.originalApp[n];
                gioGlobal.growingAppInited = !0;
            }
            if (t.Page && !gioGlobal.growingPageInited) {
                if (Page = function() {
                    return q.GrowingPage(arguments[0]);
                }, "swan" === gioGlobal.gio__platform) for (var i in q.originalPage) Page[i] = q.originalPage[i];
                gioGlobal.growingPageInited = !0;
            }
            t.Component && !gioGlobal.growingComponentInited && (Component = function() {
                return q.GrowingComponent(arguments[0]);
            }, gioGlobal.growingComponentInited = !0), t.Behavior && !gioGlobal.growingBehaviorInited && (Behavior = function() {
                return q.GrowingBehavior(arguments[0]);
            }, gioGlobal.growingBehaviorInited = !0);
        }
        gioGlobal.GioPage = q.GrowingPage, gioGlobal.GioApp = q.GrowingApp, gioGlobal.GioComponent = q.GrowingComponent, 
        gioGlobal.GioBehavior = q.GrowingBehavior, gioGlobal.trackApp = function() {
            var e = arguments[0];
            return e._growing_app_ = !0, q.instrument(e);
        }, gioGlobal.trackPage = function() {
            var e = arguments[0];
            return e._growing_page_ = !0, q.instrument(e);
        }, gioGlobal.trackComponent = function() {
            return q.instrument(arguments[0]);
        }, gioGlobal.trackBehavior = function() {
            return q.instrument(arguments[0]);
        };
    }
}, V = String.fromCharCode, M = {
    compressToUTF16: function(e) {
        return null == e ? "" : M._compress(e, 15, function(e) {
            return V(e + 32);
        }) + " ";
    },
    _compress: function(e, t, n) {
        if (null == e) return "";
        var i, r, o, s = {}, a = {}, u = "", c = "", g = "", l = 2, h = 3, p = 2, f = [], v = 0, d = 0;
        for (o = 0; e.length > o; o += 1) if (u = e.charAt(o), Object.prototype.hasOwnProperty.call(s, u) || (s[u] = h++, 
        a[u] = !0), Object.prototype.hasOwnProperty.call(s, c = g + u)) g = c; else {
            if (Object.prototype.hasOwnProperty.call(a, g)) {
                if (256 > g.charCodeAt(0)) {
                    for (i = 0; p > i; i++) v <<= 1, d == t - 1 ? (d = 0, f.push(n(v)), v = 0) : d++;
                    for (r = g.charCodeAt(0), i = 0; 8 > i; i++) v = v << 1 | 1 & r, d == t - 1 ? (d = 0, 
                    f.push(n(v)), v = 0) : d++, r >>= 1;
                } else {
                    for (r = 1, i = 0; p > i; i++) v = v << 1 | r, d == t - 1 ? (d = 0, f.push(n(v)), 
                    v = 0) : d++, r = 0;
                    for (r = g.charCodeAt(0), i = 0; 16 > i; i++) v = v << 1 | 1 & r, d == t - 1 ? (d = 0, 
                    f.push(n(v)), v = 0) : d++, r >>= 1;
                }
                0 == --l && (l = Math.pow(2, p), p++), delete a[g];
            } else for (r = s[g], i = 0; p > i; i++) v = v << 1 | 1 & r, d == t - 1 ? (d = 0, 
            f.push(n(v)), v = 0) : d++, r >>= 1;
            0 == --l && (l = Math.pow(2, p), p++), s[c] = h++, g = u + "";
        }
        if ("" !== g) {
            if (Object.prototype.hasOwnProperty.call(a, g)) {
                if (256 > g.charCodeAt(0)) {
                    for (i = 0; p > i; i++) v <<= 1, d == t - 1 ? (d = 0, f.push(n(v)), v = 0) : d++;
                    for (r = g.charCodeAt(0), i = 0; 8 > i; i++) v = v << 1 | 1 & r, d == t - 1 ? (d = 0, 
                    f.push(n(v)), v = 0) : d++, r >>= 1;
                } else {
                    for (r = 1, i = 0; p > i; i++) v = v << 1 | r, d == t - 1 ? (d = 0, f.push(n(v)), 
                    v = 0) : d++, r = 0;
                    for (r = g.charCodeAt(0), i = 0; 16 > i; i++) v = v << 1 | 1 & r, d == t - 1 ? (d = 0, 
                    f.push(n(v)), v = 0) : d++, r >>= 1;
                }
                0 == --l && (l = Math.pow(2, p), p++), delete a[g];
            } else for (r = s[g], i = 0; p > i; i++) v = v << 1 | 1 & r, d == t - 1 ? (d = 0, 
            f.push(n(v)), v = 0) : d++, r >>= 1;
            0 == --l && (l = Math.pow(2, p), p++);
        }
        for (r = 2, i = 0; p > i; i++) v = v << 1 | 1 & r, d == t - 1 ? (d = 0, f.push(n(v)), 
        v = 0) : d++, r >>= 1;
        for (;;) {
            if (v <<= 1, d == t - 1) {
                f.push(n(v));
                break;
            }
            d++;
        }
        return f.join("");
    }
}, L = function() {
    function e(t) {
        a(this, e), this.growingio = t, this.maxRequests = 3, this.requestCount = 0, this.timeout = 5e3, 
        this.messageQueue = [], this.uploadingQueue = [], this.uploadTimer = null, this.projectId = this.growingio.vdsConfig.projectId, 
        this.appId = this.growingio.vdsConfig.appId, this.host = this.growingio.vdsConfig.host, 
        this.compress = this.growingio.vdsConfig.compress, this.url = "".concat(this.host, "/projects/").concat(this.projectId, "/apps/").concat(this.appId, "/collect");
    }
    return u(e, [ {
        key: "upload",
        value: function(e) {
            var t = this;
            this.messageQueue.push(e);
            var n = this.messageQueue.length;
            n > 100 && (this.messageQueue = this.messageQueue.slice(n - 100)), this.uploadTimer || (this.uploadTimer = setTimeout(function() {
                t._flush(), t.uploadTimer = null;
            }, 1e3));
        }
    }, {
        key: "forceFlush",
        value: function() {
            this.uploadTimer && (clearTimeout(this.uploadTimer), this.uploadTimer = null), this._flush();
        }
    }, {
        key: "_flush",
        value: function() {
            var e = this;
            if (!(this.requestCount >= this.maxRequests)) {
                var t = function() {
                    e.messageQueue.length > 0 && e._flush();
                };
                if (this.uploadingQueue = this.messageQueue.slice(), this.messageQueue = [], this.uploadingQueue.length > 0) {
                    this.uploadingQueue.find(function(e) {
                        return "vst" === e.t || "VISIT" === e.eventType;
                    }) && (this.growingio.observer.vstSended = !0), this.requestCount++;
                    var n = this.uploadingQueue, i = {
                        "content-type": "application/json"
                    };
                    this.compress && (n = M.compressToUTF16(JSON.stringify(n)), i["X-Compress-Codec"] = "1"), 
                    this.growingio.info.request({
                        url: "".concat(this.url, "?stm=").concat(Date.now()),
                        method: "POST",
                        header: i,
                        data: n,
                        timeout: this.timeout,
                        success: function() {
                            e.requestCount--, t();
                        },
                        fail: function(n) {
                            return function(i) {
                                e.requestCount--, 204 !== i.status ? e.messageQueue = n.concat(e.messageQueue) : t();
                            };
                        }(this.uploadingQueue)
                    });
                }
            }
        }
    } ]), e;
}(), R = Object.assign(Object.assign({}, {
    name: "Weixin",
    path: "./weixin"
}), {
    platform: "MinP",
    scnPrefix: "",
    appHandlers: [ "onShow", "onHide", "onError" ],
    pageHandlers: [ "onLoad", "onShow", "onShareAppMessage", "onShareTimeline", "onTabItemTap", "onHide", "onUnload" ],
    actionEventTypes: [ "onclick", "tap", "longpress", "blur", "change", "submit", "confirm", "getuserinfo", "getphonenumber", "contact" ],
    originalApp: App,
    originalPage: Page,
    originalComponent: Component,
    originalBehavior: Behavior,
    canHook: !0,
    hooks: {
        App: !0,
        Page: !0,
        Component: !0,
        Behavior: !0
    },
    lisiteners: {
        app: {
            appShow: "onShow",
            appClose: "onHide",
            appError: "onError"
        },
        page: {
            pageLoad: "onLoad",
            pageShow: "onShow",
            pageHide: "onHide",
            pageClose: "onUnload",
            tabTap: "onTabItemTap",
            shareApp: "onShareAppMessage",
            shareTime: "onShareTimeline"
        },
        actions: {
            click: [ "onclick", "tap", "longpress", "getuserinfo", "getphonenumber", "contact" ],
            change: [ "blur", "change", "confirm" ],
            submit: [ "submit" ]
        }
    }
}), H = Object.assign({}, R), K = function(e, t) {
    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
    if (t.__gio__) return t;
    var i = q.hook(n || t.name, t, e);
    return i.__gio__ = !0, "boolean" == typeof t._stop && (i._stop = t._stop), i;
}, D = function(e) {
    return function() {
        var t = arguments[0], n = v(this, "_root.ctx") || {
            _growing_page_: !0
        }, i = this.__handlers[t.type];
        return Array.isArray(i) && i.forEach(function(e, t) {
            i[t] = K(n, i[t]);
        }), e.apply(this, arguments);
    };
}, $ = function(e, t, n, i) {
    return "function" != typeof n ? n : function() {
        var r = v(e, "$el._root.ctx");
        return r || (r = i.info.getCurrentPage() || {}), K(r, n, t).apply(this, arguments);
    };
};

var B = function(e, t) {
    void 0 !== e.mixin && e.mixin({
        created: function() {
            if (this.$options.methods) for (var e = Object.keys(this.$options.methods), t = 0, n = Object.keys(this); t < n.length; t++) {
                var i = n[t];
                0 > e.indexOf(i) || "function" != typeof this[i] || (Object.defineProperty(this[i], "proxiedName", {
                    value: i
                }), Object.defineProperty(this[i], "isProxied", {
                    value: !0
                }));
            }
        },
        beforeMount: function() {
            var e = this.$root;
            e.$mp && "page" === e.$mp.mpType ? e.$mp.page && (t.vueRootVMs[e.$mp.page.route] = e) : "page" === e.mpType && "page" === this.mpType && e.$mp.page && (t.vueRootVMs[e.$mp.page.route || e.$mp.page.is] = e, 
            -1 !== [ "wx", "qq", "tt" ].indexOf(gioGlobal.gio__platform) && q.instrumentPageComponent(e.$mp.page));
        }
    }), console.log("prox", t.vueRootVMs);
}, N = function(e, t, n) {
    if (p()) return function(e, t) {
        if (e.vue) e.vue.mixin({
            created: function() {
                var e = this.$options.methods;
                if (e) {
                    var n = this;
                    Object.keys(e).forEach(function(e) {
                        Object.defineProperty(n, e, {
                            value: $(n, e, n[e], t),
                            configurable: !0,
                            writable: !0
                        });
                    });
                }
            }
        }); else {
            var n = document.__proto__.__proto__;
            Object.defineProperty(n, "dispatchEvent", {
                value: D(n.dispatchEvent),
                enumerable: !1,
                configurable: !0
            });
        }
    }(e, t);
    var i = e.createComponent, r = n.usePlugin;
    if (i && (e.createComponent = function(e, n) {
        for (var o = e; o && o.prototype; ) {
            for (var s = Object.keys(Object.getOwnPropertyDescriptors(o.prototype) || {}), a = 0; s.length > a; a++) if (s[a].startsWith("func__")) {
                var u = o.name, c = s[a].slice(6);
                t.taroRootVMs[s[a]] = u + "_" + ("" + e.prototype[s[a]]).match(/this\.__triggerPropsFn\("(.+)",/)[1] + "_" + c;
            }
            o = Object.getPrototypeOf(o);
        }
        var g = i(e, n), l = -1 !== [ "MinP", "qq" ].indexOf(H.platform), h = l ? g && g.methods : g;
        return r ? n && q.instrumentPageComponent(h) : n && l && q.instrumentPageComponent(h), 
        g;
    }), r && e.createApp) {
        var o = e.createApp;
        e.createApp = function(e) {
            var t = o(e);
            return t._growing_app_ = !0, q.instrument(t), t;
        };
    }
}, Q = function() {
    function e(t) {
        a(this, e), this.growing = t, this._uid = void 0, this._esid = void 0, this._gioId = void 0, 
        this._userId = void 0, this._systemInfo = null, this.uidKey = "_growing_uid_", this.esidKey = "_growing_esid_", 
        this.gioIdKey = "_growing_gioId_", this.userIdKey = "_growing_userId_", this.userKeyKey = "_growing_userKey_", 
        this.platform = gioGlobal.platformConfig.platform, this.sdkVer = this.growing.vdsConfig.sdkVer, 
        this.scnPrefix = gioGlobal.platformConfig.scnPrefix, "quickapp" !== gioGlobal.platformConfig.platform && this.initUserInfo();
    }
    return u(e, [ {
        key: "enableIdMapping",
        get: function() {
            return v(this.growing, "vdsConfig.enableIdMapping");
        }
    }, {
        key: "esid",
        get: function() {
            return this._esid;
        },
        set: function(e) {
            this._esid = e, this.setStorage(this.esidKey, this._esid);
        }
    }, {
        key: "uid",
        get: function() {
            return this._uid;
        },
        set: function(e) {
            this._uid = e, this.setStorage(this.uidKey, this._uid);
        }
    }, {
        key: "gioId",
        get: function() {
            return this._gioId;
        },
        set: function(e) {
            this._gioId = e, this.setStorage(this.gioIdKey, this._gioId);
        }
    }, {
        key: "userKey",
        get: function() {
            if (this.enableIdMapping) return this._userKey;
        },
        set: function(e) {
            this.enableIdMapping && (this._userKey = e, this.setStorage(this.userKeyKey, this._userKey));
        }
    }, {
        key: "userId",
        get: function() {
            return this._userId;
        },
        set: function(e) {
            this._userId = e, this.setStorage(this.userIdKey, this._userId);
        }
    }, {
        key: "systemInfo",
        get: function() {
            return this._systemInfo;
        }
    }, {
        key: "initUserInfo",
        value: function() {
            this.uid = this.getStorageSync(this.uidKey) || h.guid(), this.esid = +this.getStorageSync(this.esidKey), 
            this.gioId = this.getStorageSync(this.gioIdKey), this._userId = this.getStorageSync(this.userIdKey), 
            this.enableIdMapping && (this._userKey = this.getStorageSync(this.userKeyKey));
        }
    }, {
        key: "syncStorage",
        value: function() {
            var e = this;
            this.getStorage(this.uidKey).then(function(t) {
                t || e.setStorage(e.uidKey, e._uid);
            });
        }
    }, {
        key: "getAppId",
        value: function() {
            throw Error("this a interface function");
        }
    }, {
        key: "getAppSource",
        value: function() {
            throw Error("this a interface function");
        }
    }, {
        key: "getPageTitle",
        value: function(e) {
            throw Error("this a interface function");
        }
    }, {
        key: "getPagePath",
        value: function(e) {
            throw Error("this a interface function");
        }
    }, {
        key: "getStorage",
        value: function(e) {
            throw Error("this a interface function");
        }
    }, {
        key: "getStorageSync",
        value: function(e) {
            throw Error("this a interface function");
        }
    }, {
        key: "setStorage",
        value: function(e, t) {
            throw Error("this a interface function");
        }
    }, {
        key: "getSystemInfo",
        value: function() {
            throw Error("this a interface function");
        }
    }, {
        key: "getNetworkType",
        value: function() {
            throw Error("this a interface function");
        }
    }, {
        key: "request",
        value: function(e) {
            e.url, e.header, e.method, e.data, e.timeout, e.success, e.fail;
            throw Error("this a interface function");
        }
    }, {
        key: "collectImp",
        value: function(e) {
            throw Error("this a interface function");
        }
    }, {
        key: "initShareAppMessage",
        value: function(e) {
            throw Error("this a interface function");
        }
    }, {
        key: "getCurrentPage",
        value: function() {
            throw Error("this a interface function");
        }
    }, {
        key: "getQuery",
        value: function() {
            throw Error("this a interface function");
        }
    }, {
        key: "getReferrer",
        value: function() {
            throw Error("this a interface function");
        }
    }, {
        key: "getInitPath",
        value: function() {
            throw Error("this a interface function");
        }
    }, {
        key: "onAppShow",
        value: function(e) {
            throw Error("this is a interdace function");
        }
    }, {
        key: "onAppHide",
        value: function(e) {
            throw Error("this is a interface function");
        }
    }, {
        key: "timeoutAbort",
        value: function(e, t) {
            e && e.abort && setTimeout(function() {
                e.abort();
            }, (t || 1e4) + 10);
        }
    }, {
        key: "navigateToMiniProgram",
        value: function() {
            throw Error("this is a interface function");
        }
    } ]), e;
}(), U = function(e) {
    r(s, Q);
    var t = o(s);
    function s(e) {
        var n;
        return a(this, s), (n = t.call(this, e)).growingio = e, n;
    }
    return u(s, [ {
        key: "getAppId",
        value: function() {
            this._systemInfo || (this._systemInfo = wx.getSystemInfoSync());
            var e = void 0;
            return 0 > h.compareVersion(this._systemInfo.SDKVersion, "2.2.2") || (e = wx.getAccountInfoSync().miniProgram.appId), 
            e;
        }
    }, {
        key: "getPagePath",
        value: function() {
            var e = this.getCurrentPage();
            return e && e.route;
        }
    }, {
        key: "getCurrentPage",
        value: function() {
            var e = getCurrentPages();
            return e[e.length - 1];
        }
    }, {
        key: "getPageTitle",
        value: function(e) {
            var t = "";
            try {
                if (e.data.title && e.data.title.length > 0 && (t = Array.isArray(e.data.title) ? e.data.title.join(" ") : e.data.title), 
                0 === t.length && __wxConfig) {
                    if (__wxConfig.tabBar) {
                        var n = __wxConfig.tabBar.list.find(function(t) {
                            return t.pathPath == e.route || t.pagePath == "".concat(e.route, ".html");
                        });
                        n && n.text && (t = n.text);
                    }
                    if (0 == t.length) {
                        var i = __wxConfig.page[e.route] || __wxConfig.page["".concat(e.route, ".html")];
                        t = i ? i.window.navigationBarTitleText : __wxConfig.global.window.navigationBarTitleText;
                    }
                }
            } catch (e) {
                return "";
            }
            return t;
        }
    }, {
        key: "getStorage",
        value: function(e) {
            return new Promise(function(t) {
                wx.getStorage({
                    key: e,
                    success: function(e) {
                        return t(e.data);
                    },
                    fail: function() {
                        return t("");
                    }
                });
            });
        }
    }, {
        key: "getStorageSync",
        value: function(e) {
            return wx.getStorageSync(e);
        }
    }, {
        key: "setStorage",
        value: function(e, t) {
            wx.setStorage({
                key: e,
                data: t
            });
        }
    }, {
        key: "getSystemInfo",
        value: function() {
            var e = this;
            return new Promise(function(t) {
                wx.getSystemInfo({
                    success: function(n) {
                        e._systemInfo = n, t(n);
                    },
                    fail: function() {
                        return t(null);
                    }
                });
            });
        }
    }, {
        key: "getNetworkType",
        value: function() {
            return new Promise(function(e) {
                wx.getNetworkType({
                    success: function(t) {
                        return e(t);
                    },
                    fail: function() {
                        return e(null);
                    }
                });
            });
        }
    }, {
        key: "getSetting",
        value: function() {
            return new Promise(function(e) {
                wx.getSetting({
                    success: e,
                    fail: e
                });
            });
        }
    }, {
        key: "request",
        value: function(e) {
            var t = e.url, r = e.header, o = e.method, a = e.data, u = e.timeout, c = e.success, g = e.fail, l = e.complete, h = wx.request({
                url: t,
                header: r,
                method: o,
                data: a,
                timeout: u,
                success: c,
                fail: g,
                complete: l
            });
            return n(i(s.prototype), "timeoutAbort", this).call(this, h, u), h;
        }
    }, {
        key: "getImageInfo",
        value: function(e) {
            return wx.getImageInfo(e);
        }
    }, {
        key: "collectImp",
        value: function(e) {
            var t = this, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
            this.growingio.vdsConfig.vue && (e = e.$mp.page), this.growingio.vdsConfig.taro && (e = e.$scope);
            var i = {};
            this.growingio._observer && this.growingio._observer.disconnect(), this.growingio._observer = e.isComponent ? e.createIntersectionObserver({
                observeAll: !0
            }) : wx.createIntersectionObserver(e, {
                observeAll: !0
            }), (n ? this.growingio._observer.relativeTo(n) : this.growingio._observer.relativeToViewport()).observe(".growing_collect_imp", function(e) {
                if (e.id && !i[e.id]) {
                    var n = d(e.dataset), r = n.eventId, o = n.properties;
                    r && e.id && !i[e.id] && (t.growingio.observer.track(r, o), i[e.id] = !0);
                }
            });
        }
    }, {
        key: "setStorageSync",
        value: function(e, t) {
            wx.setStorageSync(e, JSON.stringify(t));
        }
    }, {
        key: "removeStorageSync",
        value: function(e) {
            wx.removeStorageSync(e);
        }
    }, {
        key: "navigateTo",
        value: function(e) {
            wx.navigateTo(e);
        }
    }, {
        key: "switchTab",
        value: function(e) {
            wx.switchTab(e);
        }
    }, {
        key: "onAppShow",
        value: function(e) {
            wx.onAppShow(e);
        }
    }, {
        key: "onAppHide",
        value: function(e) {
            wx.onAppHide(e);
        }
    }, {
        key: "navigateToMiniProgram",
        value: function(e) {
            wx.navigateToMiniProgram(e);
        }
    } ]), s;
}(), F = function() {
    function e(t) {
        a(this, e), this.growingio = t, this.esid = 0, this.info = t.info;
    }
    return u(e, [ {
        key: "setUserAttributes",
        value: function() {
            throw Error("this a interface function");
        }
    }, {
        key: "setUserId",
        value: function() {
            throw Error("this a interface function");
        }
    }, {
        key: "clearUserId",
        value: function() {
            throw Error("this a interface function");
        }
    }, {
        key: "updateSessionId",
        value: function() {
            this._sessionId = h.guid();
        }
    }, {
        key: "sendVisitEvent",
        value: function() {
            throw Error("this a interface function");
        }
    }, {
        key: "track",
        value: function() {
            throw Error("this a interface function");
        }
    }, {
        key: "_sendEvent",
        value: function() {
            throw Error("this a interface function");
        }
    } ]), e;
}();

function J(e) {
    return null !== e && "[object Object]" === Object.prototype.toString.call(e) && Object.keys(e).length > 0;
}

var W = {
    tap: [ "tap", "click" ],
    longtap: [ "longtap" ],
    input: [ "input" ],
    blur: [ "change", "blur" ],
    submit: [ "submit" ],
    focus: [ "focus" ]
}, X = /^function[^(]*\([^)]+\).*[^.]+\.([^(]+)\(.*/;

function z(e) {
    return e && e.$attrs ? e.$attrs.mpcomid : "0";
}

function Y(e, t, n) {
    return !(!e || !t || t !== e && 0 !== t.indexOf(e + n));
}

var Z = function() {
    function e(t) {
        a(this, e), this.vueVM = t;
    }
    return u(e, [ {
        key: "getHandle",
        value: function(e) {
            var t = e.type, n = e.target;
            void 0 === n && (n = {});
            var i = (e.currentTarget || n).dataset;
            void 0 === i && (i = {});
            var r = i.comkey;
            void 0 === r && (r = "");
            var o = i.eventid, s = -1 !== r.indexOf("_") ? "_" : ",", a = function(e, t, n) {
                void 0 === t && (t = []);
                var i = t.slice(1);
                if (!i.length) return e;
                var r = i.join(n), o = "";
                return i.reduce(function(e) {
                    for (var t = e.$children.length, i = 0; t > i; i++) {
                        var s = e.$children[i], a = z(s);
                        if (o && (a = o + n + a), Y(a, r, n)) return o = a, s;
                    }
                    return e;
                }, e);
            }(this.vueVM, r.split(s), s);
            if (a) {
                var u = function e(t, n, i) {
                    void 0 === i && (i = []);
                    var r = [];
                    if (!t || !t.tag) return r;
                    var o = t || {}, s = o.data;
                    void 0 === s && (s = {});
                    var a = o.children;
                    void 0 === a && (a = []);
                    var u = o.componentInstance;
                    u ? Object.keys(u.$slots).forEach(function(t) {
                        var o = u.$slots[t];
                        (Array.isArray(o) ? o : [ o ]).forEach(function(t) {
                            r = r.concat(e(t, n, i));
                        });
                    }) : a.forEach(function(t) {
                        r = r.concat(e(t, n, i));
                    });
                    var c = s.attrs, g = s.on;
                    return c && g && c.eventid === n && i.forEach(function(e) {
                        var t = g[e];
                        "function" == typeof t ? r.push(t) : Array.isArray(t) && (r = r.concat(t));
                    }), r;
                }(a._vnode, o, W[t] || [ t ]);
                if (u.length) {
                    var c = u[0];
                    if (c.isProxied) return c.proxiedName;
                    try {
                        var g = ("" + c).replace("\n", "");
                        if (g.match(X)) {
                            var l = X.exec(g);
                            if (l && l.length > 1) return l[1];
                        }
                    } catch (e) {}
                    return c.name;
                }
            }
        }
    }, {
        key: "handleEvent",
        value: function(e) {
            var t, n = e.type, i = (e.currentTarget || e.target).dataset;
            return (i.eventOpts || i["event-opts"]).forEach(function(e) {
                var i = e[0], r = e[1];
                i = "~" === (i = "^" === i.charAt(0) ? i.slice(1) : i).charAt(0) ? i.slice(1) : i, 
                r && function(e, t) {
                    return e === t || "regionchange" === t && ("begin" === e || "end" === e);
                }(n, i) && r.forEach(function(e) {
                    t = e[0];
                });
            }), t;
        }
    } ]), e;
}(), ee = function() {
    function e() {
        a(this, e), this.queries = {}, this.pvar = {};
    }
    return u(e, [ {
        key: "touch",
        value: function(e) {
            this.path = e.route || e.__route__, this.time = Date.now(), this.query = this.queries[e.route] ? this.queries[e.route] : void 0;
        }
    }, {
        key: "addQuery",
        value: function(e, t) {
            this.queries[e.route] = t ? this._getQuery(t) : null;
        }
    }, {
        key: "_getQuery",
        value: function(e) {
            return Object.keys(e || {}).filter(function(e) {
                return "wxShoppingListScene" !== e;
            }).map(function(t) {
                return "".concat(t, "=").concat(e[t]);
            }).join("&");
        }
    }, {
        key: "touchRelatedPvarData",
        value: function(e) {
            var t = "".concat(e.p, "?").concat(e.q);
            this.pvar[t] ? this.pvar[t].push(e) : this.pvar[t] = [ e ];
        }
    }, {
        key: "equalsPage",
        value: function(e) {
            return e.p == this.path && e.q == this.query;
        }
    } ]), e;
}(), te = {
    tap: "clck",
    longpress: "lngprss",
    longtap: "lngprss"
}, ne = function(e) {
    r(n, F);
    var t = o(n);
    function n(e) {
        var i;
        return a(this, n), (i = t.call(this, e)).growingio = e, i.info = e.info, i.currentPage = new ee(), 
        i.scene = null, i._sessionId = null, i.cs1 = e.storage.getCs1(), i.lastPageEvent = null, 
        i.lastVstArgs = void 0, i.lastCloseTime = null, i.lastScene = void 0, i.keepAlive = e.vdsConfig.keepAlive, 
        i.isPauseSession = !1, i.isGettingUid = !1, i.esid = 0 === i.info.esid ? 1 : i.info.esid, 
        i.uploadingMessages = [], i.visitSentSuccess = !1, i.vstSended = !1, i;
    }
    return u(n, [ {
        key: "isOctopus",
        get: function() {
            return this.growingio.vdsConfig.octopus;
        }
    }, {
        key: "sessionId",
        get: function() {
            return null === this._sessionId && (this._sessionId = h.guid()), this._sessionId;
        }
    }, {
        key: "resetSessionId",
        value: function() {
            this._sessionId = null;
        }
    }, {
        key: "pauseSession",
        value: function() {
            this.isPauseSession = !0;
        }
    }, {
        key: "getVisitorId",
        value: function() {
            return this.info.uid;
        }
    }, {
        key: "getUserId",
        value: function() {
            return this.cs1;
        }
    }, {
        key: "getGioInfo",
        value: function() {
            return "giou=".concat(this.getVisitorId(), "&giocs1=").concat(this.getUserId(), "&gios=").concat(this.sessionId, "&gioprojectid=").concat(this.growingio.vdsConfig.projectId, "&gioappid=").concat(this.growingio.vdsConfig.appId, "&gioplatform=").concat(gioGlobal.platformConfig.platform);
        }
    }, {
        key: "setUserId",
        value: function(e) {
            var t = e + "";
            t && 100 > t.length && (this.cs1 = t, C.emitEvent("setCs1", [ t ]), this.lastPageEvent && (this.updateSessionId(), 
            this._sendEvent(this.lastPageEvent)));
        }
    }, {
        key: "clearUserId",
        value: function() {
            this.cs1 = null, C.emitEvent("clearCs1");
        }
    }, {
        key: "appListener",
        value: function(e, t, n) {
            var i = gioGlobal.platformConfig.lisiteners.app;
            this.isPauseSession || (this.growingio.vdsConfig.debug && console.log("App.", t, Date.now()), 
            t == i.appShow ? (C.emitEvent("appShow"), this._parseScene(n), !this.lastCloseTime || Date.now() - this.lastCloseTime > this.keepAlive || this.lastScene && this.scene !== this.lastScene ? (this.resetSessionId(), 
            this.sendVisitEvent(n), this.lastVstArgs = n, this.useLastPageTime = !1, this.lastPageEvent = void 0) : this.lastPageEvent && (this.useLastPageTime = !0)) : t == i.appClose ? (this.lastScene = this.scene, 
            this.growingio.forceFlush(), this.info.syncStorage(), this.isPauseSession || (this.lastCloseTime = Date.now(), 
            this.sendVisitCloseEvent())) : t == i.appError && this.sendErrorEvent(n));
        }
    }, {
        key: "pageListener",
        value: function(e, t, n) {
            var i = gioGlobal.platformConfig.lisiteners.page;
            if (this.growingio.vdsConfig.wepy && (e.route = e.$is), e.route || (e.route = this.info.getPagePath(e)), 
            this.growingio.vdsConfig.debug && console.log("Page.", e.route, "#", t, Date.now()), 
            t === i.pageShow) {
                O = {};
                var r = v(e, "$page.query");
                h.isEmpty(r) || "quickApp" !== gioGlobal.gio__platform || this.currentPage.addQuery(e, r), 
                this.isPauseSession ? this.isPauseSession = !1 : (this.currentPage.touch(e), this.useLastPageTime && this.currentPage.equalsPage(this.lastPageEvent) && (this.currentPage.time = this.lastPageEvent.tm, 
                this.useLastPageTime = !1), this.sendPage(e)), function(e) {
                    var t = h.queryParse(e.query);
                    t.gioShareId && (I = t.gioShareId);
                }(this.currentPage);
            } else if (t === i.pageLoad) {
                var o = n[0];
                h.isEmpty(o) || "quickApp" === gioGlobal.gio__platform || this.currentPage.addQuery(e, o);
            } else if (t === i.pageHide) this.growingio._observer && this.growingio._observer.disconnect(); else if (t === i.pageClose) this.currentPage.pvar["".concat(this.currentPage.path, "?").concat(this.currentPage.query)] = void 0; else if (t === i.shareApp || t === i.shareTime) {
                var s = null, a = null;
                2 > n.length ? 1 === n.length && (n[0].from ? s = n[0] : n[0].title && (a = n[0])) : (s = n[0], 
                a = n[1]), this.pauseSession(), this.sendPageShare(e, s, a, t);
            } else "onTabItemTap" === t && this.sendTabClick(n[0]);
        }
    }, {
        key: "actionListener",
        value: function(e, t) {
            if (!v(e, "currentTarget.dataset.growingIgnore") && !v(e, "target.dataset.growingIgnore")) {
                var n = gioGlobal.platformConfig.lisiteners.actions;
                if ("_cmlEventProxy" !== t) {
                    if ("handleProxy" === t && this.growingio.vueRootVMs && this.growingio.vueRootVMs[this.currentPage.path]) {
                        var i = new Z(this.growingio.vueRootVMs[this.currentPage.path]).getHandle(e);
                        i && (t = i);
                    }
                    if ("__e" === t && this.growingio.vueRootVMs && this.growingio.vueRootVMs[this.currentPage.path]) {
                        var r = new Z(this.growingio.vueRootVMs[this.currentPage.path]).handleEvent(e);
                        r && (t = r);
                    }
                    if ("_proxy" === t && this.growingio.wepyRootVMs) {
                        var o = e.currentTarget.dataset.wpyEvt, s = e.type;
                        v(this, "growingio.wepyRootVMs.".concat(o, ".").concat(s)) && (t = this.growingio.wepyRootVMs[o][s]);
                    }
                    v(this, "growingio.taroRootVMs.".concat(t)) && (t = this.growingio.taroRootVMs[t]), 
                    this.growingio.vdsConfig.debug && console.log("Click on ", t, Date.now()), -1 !== n.click.indexOf(e.type) ? (this.sendClick(e, t), 
                    "getuserinfo" === e.type && v(e, "detail.userInfo") && this.setVisitor(e.detail.userInfo)) : -1 !== n.change.indexOf(e.type) ? this.sendChange(e, t) : -1 !== n.submit.indexOf(e.type) && this.sendSubmit(e, t);
                }
            }
        }
    }, {
        key: "sendVideoCstm",
        value: function(e) {
            this.track("video-".concat(e.type), e.var);
        }
    }, {
        key: "track",
        value: function(e, t) {
            if ("string" != typeof e || null == e || 0 === e.length || !e.match(/^\w+$/) || 10 > parseInt(e[0])) console.warn("埋点格式不正确, 事件名只能包含数字，字母和下划线，且不以数字开头, 请参考文档"); else {
                var n = {
                    t: "cstm",
                    ptm: this.currentPage.time,
                    p: this.currentPage.path,
                    q: this.currentPage.query,
                    n: e
                };
                J(t) && (n.var = t), this._sendEvent(n);
            }
        }
    }, {
        key: "identify",
        value: function(e, t) {
            null != e && 0 !== e.length && (this.growingio.login(e), this._sendEvent({
                t: "vstr",
                var: {
                    openid: e,
                    unionid: t
                }
            }));
        }
    }, {
        key: "setVisitor",
        value: function(e) {
            J(e) && this._sendEvent({
                t: "vstr",
                var: e
            });
        }
    }, {
        key: "setUser",
        value: function(e) {
            this.cs1 && J(e) && this._sendEvent({
                t: "ppl",
                var: e
            });
        }
    }, {
        key: "setPage",
        value: function(e) {
            if (J(e)) {
                var t = {
                    t: "pvar",
                    ptm: this.currentPage.time,
                    p: this.currentPage.path,
                    q: this.currentPage.query,
                    var: e
                };
                this.currentPage.touchRelatedPvarData(t), this._sendEvent(t);
            }
        }
    }, {
        key: "setEvar",
        value: function(e) {
            J(e) && this._sendEvent({
                t: "evar",
                var: e
            });
        }
    }, {
        key: "sendVisitEvent",
        value: function(e) {
            var t = this;
            this.info.getSystemInfo().then(function(n) {
                var i = n || {}, r = {
                    t: "vst",
                    tm: Date.now(),
                    av: t.info.sdkVer,
                    db: i.brand,
                    dm: i.model && i.model.replace(/<.*>/, ""),
                    sh: h.getScreenHeight(i),
                    sw: h.getScreenWidth(i),
                    os: h.getOS(i.platform),
                    osv: h.getOSV(i.version),
                    l: i.language
                };
                if (t.growingio.vdsConfig.appVer && (r.cv = t.growingio.vdsConfig.appVer + ""), 
                e.length > 0) {
                    var o = e[0];
                    r.p = o.path || t.info.getPagePath(), h.isEmpty(o.query) || (r.q = t.currentPage._getQuery(o.query)), 
                    r.ch = "scn:".concat(t.info.scnPrefix).concat(t.scene), "quickapp" === t.info.platform ? r.rf = t.info.appSource.packageName : o.referrerInfo && o.referrerInfo.appId && v(o, "referrerInfo.appId") && (r.rf = o.referrerInfo.appId), 
                    t.info.getNetworkType().then(function(e) {
                        e && (r.nt = e.networkType, t._sendEvent(r), t.visitSentSuccess = !0);
                    });
                }
            });
        }
    }, {
        key: "sendVisitCloseEvent",
        value: function() {
            this._sendEvent({
                t: "cls",
                p: this.currentPage.path,
                q: this.currentPage.query
            });
        }
    }, {
        key: "sendErrorEvent",
        value: function(e) {
            if (e && e.length > 0) {
                var t = e[0];
                if ("string" != typeof t) return;
                var n = {
                    t: "cstm",
                    ptm: this.currentPage.time,
                    p: this.currentPage.path,
                    q: this.currentPage.query,
                    n: "onError",
                    var: y(t)
                };
                this._sendEvent(n);
            }
        }
    }, {
        key: "sendPage",
        value: function(e) {
            var t = this, n = {
                t: "page",
                tm: this.currentPage.time,
                p: this.currentPage.path,
                q: this.currentPage.query
            };
            n.rp = this.lastPageEvent ? this.lastPageEvent.p : this.scene ? "scn:".concat(this.info.scnPrefix).concat(this.scene) : null;
            var i = this.info.getPageTitle(e);
            i && i.length > 0 && (n.tl = i), this.visitSentSuccess ? this._sendEvent(n) : setTimeout(function() {
                return t._sendEvent(n);
            }, 100), this.lastPageEvent = n;
            var r = this.currentPage.pvar["".concat(this.currentPage.path, "?").concat(this.currentPage.query)];
            r && r.length > 0 && r.map(function(e) {
                e.ptm = t.currentPage.time, t._sendEvent(e);
            });
        }
    }, {
        key: "sendPageShare",
        value: function(e, t, n) {
            var i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "onShareAppMessage", r = {
                t: "cstm",
                ptm: this.currentPage.time,
                p: this.currentPage.path,
                q: this.currentPage.query,
                n: i,
                var: Object.assign({
                    from: t ? t.from : void 0,
                    target: t && t.target ? t.target.id : void 0,
                    title: n ? n.title : void 0,
                    path: n ? decodeURI(n.path) : void 0
                }, n.attributes)
            };
            this._sendEvent(r);
        }
    }, {
        key: "getNodeXpath",
        value: function(e, t) {
            var n = (e.currentTarget || e.target).id;
            if ((!n || "swan" === gioGlobal.gio__platform && /^_[0-9a-f]+/.test(n) || p() && /^_n_[0-9]+$/.test(n)) && (n = ""), 
            !this.isOctopus || (/^bound .*/.test(t = e.handler) && (t = t.replace("bound ", "")), 
            /^t[0-9]+$/.test(n) && (n = ""), n && !t && (t = "anonymousFunc"), n || t)) return "".concat(n, "#").concat(t);
        }
    }, {
        key: "sendClick",
        value: function(e, t) {
            var n = {
                t: te[e.type] || "clck",
                ptm: this.currentPage.time,
                p: this.currentPage.path,
                q: this.currentPage.query
            }, i = e.currentTarget || e.target, r = this.getNodeXpath(e, t);
            if (r) {
                var o = {
                    x: r
                };
                i.dataset.title && (o.v = i.dataset.title), i.dataset.src && (o.h = i.dataset.src), 
                void 0 !== i.dataset.index && (o.idx = /^[\d]+$/.test(i.dataset.index) ? parseInt(i.dataset.index) : -1), 
                n.e = [ o ], this._sendEvent(n);
            }
        }
    }, {
        key: "sendSubmit",
        value: function(e, t) {
            var n = {
                t: "sbmt",
                ptm: this.currentPage.time,
                p: this.currentPage.path,
                q: this.currentPage.query
            }, i = this.getNodeXpath(e, t);
            i && (n.e = [ {
                x: i
            } ], this._sendEvent(n));
        }
    }, {
        key: "sendChange",
        value: function(e, t) {
            var n = {
                t: "chng",
                ptm: this.currentPage.time,
                p: this.currentPage.path,
                q: this.currentPage.query
            }, i = e.currentTarget || e.target, r = this.getNodeXpath(e, t);
            if (r) {
                var o = {
                    x: r
                }, s = v(e, "detail.value") || v(e, "target.attr.value");
                i.dataset && (i.dataset.growingTrack || i.dataset.growingtrack) && ("boolean" == typeof s || s && 0 !== s.length) && ("[object Array]" === Object.prototype.toString.call(s) ? (s = s.join(",")) && (o.v = s) : o.v = s), 
                "change" === e.type && "autoplay" === v(e, "detail.source") || (n.e = [ o ], this._sendEvent(n));
            }
        }
    }, {
        key: "sendTabClick",
        value: function(e) {
            var t = {
                t: "clck",
                ptm: this.currentPage.time,
                p: this.currentPage.path,
                q: this.currentPage.query,
                e: [ {
                    x: "#onTabItemTap",
                    v: e.text,
                    idx: e.index,
                    h: "string" == typeof e.pagePath ? e.pagePath : JSON.stringify(e.pagePath)
                } ]
            };
            this._sendEvent(t);
        }
    }, {
        key: "_sendEvent",
        value: function(e) {
            var t = this;
            if (this.growingio.vdsConfig.dataCollect) {
                if (this.growingio.vdsConfig.autotrack || ![ "clck", "chng", "sbmt" ].includes(e.t)) if (this.info.uid && this.esid) {
                    var n = this._buildEvent(e, this.info);
                    this.growingio.upload(n);
                } else if (this.isGettingUid) this.uploadingMessages.push(e); else {
                    this.isGettingUid = !0;
                    var i = this.info.getStorage(this.info.uidKey), r = this.info.getStorage(this.info.esidKey);
                    Promise.all([ i, r ]).then(function(n) {
                        var i = s(n, 2), r = i[0], o = i[1];
                        r || (r = h.guid()), o || (o = 1), t.info.uid = r, t.esid = o, t.isGettingUid = !1;
                        var a = t._buildEvent(e, t.info);
                        for (t.growingio.upload(a); 0 !== t.uploadingMessages.length; ) {
                            var u = t.uploadingMessages.shift();
                            u = t._buildEvent(u, t.info), t.growingio.upload(u);
                        }
                    });
                }
            } else this.vstSended || "vst" !== e.t || this.growingio.uploadingMessages.push(e);
        }
    }, {
        key: "_buildEvent",
        value: function(e, t) {
            if (e.u = t.uid, e.s = this.sessionId, e.tm = e.tm || Date.now(), e.d = this.growingio.vdsConfig.appId, 
            e.b = t.platform, null !== this.cs1 && (e.cs1 = this.cs1), e.var) {
                var n = e.var;
                Object.keys(n).forEach(function(t) {
                    "string" != typeof n[t] && (e.var[t] = JSON.stringify(n[t]));
                });
            }
            return this.esid > 1e9 && (this.esid = 1), e.esid = this.esid++, this.info.esid = this.esid, 
            e;
        }
    }, {
        key: "_parseScene",
        value: function(e) {
            if ("quickapp" === this.info.platform) {
                var t = this.info.getAppSource(), n = t.extra || {}, i = t.type || "";
                this.scene = i, this.setVisitor({
                    extra: JSON.stringify(n)
                });
            } else if (e.length > 0) {
                var r = e[0];
                this.scene = r.query && r.query.wxShoppingListScene ? r.query.wxShoppingListScene : r.scene ? r.scene : "NA";
            }
        }
    } ]), n;
}(), ie = function() {
    function e() {
        a(this, e), this.uploadingMessages = [], this.start = !1;
    }
    return u(e, [ {
        key: "init",
        value: function(e, t, n) {
            this.start || (t && "string" != typeof t && (n = t, t = ""), t || n || (t = "", 
            n = {}), "alip" === H.platform && (n.vue || n.taro || n.cml || n.wepy || n.octopus) && (H.canHook = !0), 
            n.usePlugin && (H.canHook = !1), this.vdsConfig = {
                projectId: e,
                appId: t,
                appVer: n.version || "",
                debug: n.debug || !1,
                forceLogin: n.forceLogin || !1,
                followShare: void 0 === n.followShare || n.followShare,
                usePlugin: n.usePlugin || !1,
                dataCollect: !("boolean" == typeof n.stopTrack && n.stopTrack || "boolean" == typeof n.dataCollect && !n.dataCollect),
                keepAlive: +n.keepAlive || 3e5,
                vue: n.vue || !1,
                taro: n.taro || !1,
                cml: n.cml || !1,
                wepy: n.wepy || !1,
                octopus: n.octopus || !1,
                host: n.host && n.host.indexOf("http") >= 0 ? "https://".concat(n.host.slice(n.host.indexOf("://") + 3)) : "https://wxapi.growingio.com",
                sdkVer: "3.7.5",
                comAsPage: n.comAsPage || !1,
                autotrack: !1 !== n.autotrack || n.autotrack,
                enableEventStore: !0 === n.enableEventStore
            }, gioGlobal.vdsConfig = this.vdsConfig, gioGlobal.platformConfig = H, this.info = new U(this), 
            t || (this.vdsConfig.appId = this.info.getAppId() || e), this.observer = new ne(this), 
            this.uploader = new L(this), this.config = new m(this), this.start = !0, n.vue && (this.vueRootVMs = {}, 
            B(n.vue, this)), n.taro && (this.taroRootVMs = {}, N(n.taro, this, this.vdsConfig)), 
            n.cml && (gioGlobal.platformConfig.hooks.Component = !1, function(e, t) {
                var n = e.createApp, i = e.createComponent;
                e.createApp = function(e) {
                    return e._growing_app_ = !0, n(q.instrument(e));
                }, e.createComponent = function(e) {
                    return i(e.data && e.data.isComponent ? Object.assign(Object.assign({}, e), {
                        methods: q.instrument(e.methods)
                    }) : e);
                };
            }(n.cml)), n.wepy && (this.wepyRootVMs = {}, function(e, t, n) {
                var i = e.page, r = function(e) {
                    for (var i = Object.keys(e), r = 0; i.length > r; r++) for (var o = Object.keys(e[i[r]]), s = 0; o.length > s; s++) if ("function" == typeof e[i[r]][o[s]]) {
                        var a = ("" + e[i[r]][o[s]]).match(/_vm\.(.+)\(.*\)/);
                        a && a[1] && (t.wepyRootVMs[i[r]] || (t.wepyRootVMs[i[r]] = {}), t.wepyRootVMs[i[r]][o[s]] = a[1]), 
                        n.usePlugin && (e[i[r]][o[s]] = q.hook("_proxy", e[i[r]][o[s]]));
                    }
                };
                e.page = function(e, t) {
                    return t.handlers && r(t.handlers), q.instrumentPageComponent(e), i(e, t);
                };
                var o = e.component;
                if (e.component = function(e, t) {
                    return t.handlers && r(t.handlers), o(e, t);
                }, n.usePlugin) {
                    var s = e.app;
                    e.app = function(e, t) {
                        return e._growing_app_ = !0, s(q.instrument(e), t);
                    };
                }
            }(n.wepy, this, this.vdsConfig)), "quickapp" === gioGlobal.platformConfig.platform && this.info.initShareAppMessage(this), 
            this._start());
        }
    }, {
        key: "setConfig",
        value: function(e) {
            this.init(e.projectId, e.appId, e);
        }
    }, {
        key: "setVue",
        value: function(e) {
            this.vueRootVMs || (this.vueRootVMs = {}), this.vdsConfig.vue = !0, B(e, this);
        }
    }, {
        key: "_start",
        value: function() {
            q.initInstrument(this.observer);
            try {
                gioGlobal && H.canHook && (H.hooks.App && (gioGlobal.App = App), H.hooks.Page && (gioGlobal.Page = Page), 
                H.hooks.Component && (gioGlobal.Component = Component), H.hooks.Behavior && (gioGlobal.Behavior = Behavior));
            } catch (e) {}
        }
    }, {
        key: "setDataCollect",
        value: function(e) {
            if (this.config.setDataCollect(e), e && !this.observer.vstSended) {
                var t = this.uploadingMessages.find(function(e) {
                    return "vst" === e.t;
                });
                t && (this.observer._sendEvent(t), this.uploadingMessages = []);
            }
        }
    }, {
        key: "setAutotrack",
        value: function(e) {
            this.config.setAutotrack(e);
        }
    }, {
        key: "login",
        value: function(e) {
            if (this.vdsConfig.forceLogin && (this.info.uid = e, this.vdsConfig.forceLogin = !1, 
            this.vdsConfig.dataCollect)) {
                var t, n = g(this.uploadingMessages);
                try {
                    for (n.s(); !(t = n.n()).done; ) {
                        var i = t.value;
                        i.u = e, this.upload(i);
                    }
                } catch (e) {
                    n.e(e);
                } finally {
                    n.f();
                }
            }
        }
    }, {
        key: "upload",
        value: function(e) {
            this.vdsConfig.forceLogin ? (console.error("GrowingIO: [ForceLogin] is set to true, but openID is null, data collection has been suspended! Call the [identify] function to report openID to resume data collection."), 
            this.uploadingMessages.push(e)) : (this.vdsConfig.debug && console.info("generate new event", JSON.stringify(e, 0, 2)), 
            C.emitEvent("upload", [ e ]), this.uploader.upload(e));
        }
    }, {
        key: "forceFlush",
        value: function() {
            this.info.esid = this.observer.esid, this.uploader.forceFlush();
        }
    }, {
        key: "proxy",
        value: function(e, t) {
            try {
                if ("setVue" === e) this.setVue(t[0]); else if ("setDataCollect" === e) this.setDataCollect(t[0]); else if ("setStopTrack" === e) this.setDataCollect(!t[0]); else if ("collectImp" === e) this.collectImp(t[0], t[1]); else if ("setAutotrack" === e) this.setAutotrack(t[0]); else if (this.observer && this.observer[e]) return this.observer[e].apply(this.observer, t);
            } catch (e) {
                console.error(e);
            }
        }
    }, {
        key: "collectImp",
        value: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
            this.info.collectImp(e, t);
        }
    } ]), e;
}(), re = function(e, t) {
    if ("string" == typeof t) {
        "?" !== t[0] && (t = "?" + t), e = e.replace(/[[\]]/g, "\\$&");
        var n = RegExp("[?&]" + e + "(=([^&#]*)|&|#|$)").exec(t);
        return n ? n[2] ? decodeURIComponent(n[2].replace(/\+/g, " ")) : "" : null;
    }
};

var oe = function() {
    function e(t) {
        a(this, e), this.growingio = t, this.namespace = "push-user-status", this.userTagDuration = 432e7, 
        this.eventTagDuration = 864e5, this.handleCs1 = this.handleCs1.bind(this), this.handleClearCs1 = this.handleClearCs1.bind(this);
    }
    return u(e, [ {
        key: "handleCs1",
        value: function(e) {
            e !== this.get("cs1") && (this.set("cs1", e), this.set("bcs", void 0), C.emit("cs1Refresh"));
        }
    }, {
        key: "handleClearCs1",
        value: function() {
            this.set("cs1", void 0), this.set("bcs", void 0);
        }
    }, {
        key: "setIsPreview",
        value: function(e) {
            if (e.q) {
                var t = re("scene", e.q);
                if (t) {
                    var n = re("gioMessageId", t);
                    if (n) {
                        var i = {
                            s: "splash",
                            pw: "popupWindow",
                            p: "push",
                            b: "banner",
                            ab: "abTest"
                        }[re("mt", t)] || "";
                        gioGlobal.__growing__.marketingPreview = {
                            messageId: n,
                            msgType: i
                        };
                    }
                }
            }
        }
    }, {
        key: "storeFilters",
        value: function(e, n, i) {
            var r = n(), o = this.get(r, this.eventTagDuration) || [], s = i.call(this, e);
            if (!this.growingio.vdsConfig.enableEventStore && r.indexOf("triggerAttrs") > -1) this.set(r, []); else {
                var a = [].concat(t(o), t(s));
                this.set(r, a);
            }
        }
    }, {
        key: "generateEventKey",
        value: function(e) {
            return "".concat(e, "#").concat(this.get("cs1") || "");
        }
    }, {
        key: "_get",
        value: function(e) {
            return this.growingio.info.getStorageSync("".concat(this.namespace, "#").concat(e));
        }
    }, {
        key: "getUserAttrs",
        value: function() {
            var e = this.generateEventKey("userAttrs");
            return this.get(e) || [];
        }
    }, {
        key: "getTriggerAttrs",
        value: function() {
            var e = this.generateEventKey("triggerAttrs");
            return this.get(e) || [];
        }
    }, {
        key: "set",
        value: function(e, t) {
            var n = this._get(e), i = new Date();
            i.setHours(0), i.setMinutes(0), i.setSeconds(0);
            var r = {
                startAt: i.getTime(),
                value: t
            };
            n && function e(t, n) {
                if (c(t) != c(n)) return !1;
                if ("string" == typeof t || "number" == typeof t || "boolean" == typeof t || "function" == typeof t || null == t || null == n) return Object.is(t, n);
                if (Array.isArray(t) && Array.isArray(n)) return t.length === n.length && t.every(function(t, i) {
                    return e(t, n[i]);
                });
                if ("[object Object]" === Object.prototype.toString.call(t) && "[object Object]" === Object.prototype.toString.call(n)) {
                    var i = Object.keys(t), r = Object.keys(n);
                    return !(!i.every(function(i) {
                        return n.hasOwnProperty(i) && e(t[i], n[i]);
                    }) || !r.every(function(i) {
                        return t.hasOwnProperty(i) && e(n[i], t[i]);
                    }));
                }
                return !1;
            }(r.value, JSON.parse(n).value) || this.growingio.info.setStorageSync("".concat(this.namespace, "#").concat(e), r);
        }
    }, {
        key: "get",
        value: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.userTagDuration, n = this._get(e);
            if (n) {
                var i = JSON.parse(n);
                return Date.now() > i.startAt + t ? void 0 : i.value;
            }
        }
    }, {
        key: "getCs1",
        value: function() {
            return this.get("cs1");
        }
    } ]), e;
}(), se = function(t) {
    r(i, oe);
    var n = o(i);
    function i(t) {
        var r;
        return a(this, i), (r = n.call(this, t)).growingio = t, r.handleEvent = r.handleEvent.bind(e(r)), 
        r.addEventListener(), r;
    }
    return u(i, [ {
        key: "addEventListener",
        value: function() {
            C.on("appOpen", this.handleEvent), C.on("upload", this.handleEvent), C.on("setCs1", this.handleCs1), 
            C.on("clearCs1", this.handleClearCs1);
        }
    }, {
        key: "handleEvent",
        value: function(e) {
            if (e) switch (e.t) {
              case "vst":
              case "vstr":
              case "ppl":
                this.storeFilters(e, this.generateEventKey.bind(this, "userAttrs"), this.formatUserFilterVars);
                break;

              case "cstm":
                this.storeFilters(e, this.generateEventKey.bind(this, "triggerAttrs"), this.formatEventFilterVars);

              case "page":
                this.setIsPreview(e);
            }
        }
    }, {
        key: "formatUserFilterVars",
        value: function(e) {
            var t = e.var;
            return t ? Object.keys(t).map(function(e) {
                return {
                    key: e,
                    value: t[e]
                };
            }) : [];
        }
    }, {
        key: "formatEventFilterVars",
        value: function(e) {
            var t = e.var;
            return [ {
                key: e.n,
                value: "",
                event_variable: t ? Object.keys(t).map(function(e) {
                    return {
                        key: e,
                        value: t[e]
                    };
                }) : []
            } ];
        }
    } ]), i;
}();

try {
    (function(e) {
        Object.defineProperty(Object.prototype, "gioGlobal", {
            get: function() {
                return "quickApp" === e ? global.__proto__ : "my" === e ? $global : global;
            },
            configurable: !1,
            enumerable: !1
        });
    })("wx"), gioGlobal.gio__platform = "wx";
} catch (l) {}

var ae = new ie(), ue = function() {
    var e = arguments[0];
    if (e) {
        var t = 2 > arguments.length ? [] : [].slice.call(arguments, 1);
        if ("init" === e) {
            if (gioGlobal.vdsConfig) return void console.warn("SDK已经初始化成功，请检查是否加载过其他平台sdk");
            if (1 > t.length) return void console.log('初始化 GrowingIO SDK 失败。请使用 gio("init", "你的GrowingIO项目ID", "你的应用APP_ID", options);');
            var n = t[0], i = t[1], r = t[2];
            r && !1 === r.autotrack && console.log("GrowingIO：已关闭无埋点事件"), ae.init(n, i, r);
        } else {
            if ("setConfig" !== e) return ae.proxy(e, t);
            if (!t[0]) return void console.log("初始化 GrowingIO SDK 失败。请检查你的config文件是否引入正确");
            if (!t[0].projectId) return void console.log("初始化 GrowingIO SDK 失败。请检查你的 GrowingIO项目ID, 你的应用APP_ID 是否填写正确");
            ae.setConfig(t[0]);
        }
    }
};

console.log("init growingio...");

var ce = q.GrowingPage, ge = q.GrowingApp, le = q.GrowingComponent, he = q.GrowingBehavior, pe = C, fe = ae.storage = new se(ae);

gioGlobal.__growing__ = {
    gioEmitter: pe,
    gio: ue,
    growingio: ae,
    userStorage: fe,
    marketingPreview: void 0,
    entry: "saas"
}, gioGlobal.gio = ue, exports.GioApp = ge, exports.GioBehavior = he, exports.GioComponent = le, 
exports.GioPage = ce, exports.default = ue, exports.gioEmitter = pe, exports.growingio = ae;