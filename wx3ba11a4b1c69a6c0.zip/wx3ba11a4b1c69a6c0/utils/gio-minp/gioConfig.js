Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    projectId: "a4a4718d03b941d1",
    appId: "wx3ba11a4b1c69a6c0",
    version: "1.0",
    followShare: !0
};