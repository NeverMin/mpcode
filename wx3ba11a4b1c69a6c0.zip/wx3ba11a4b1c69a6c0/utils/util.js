require("../@babel/runtime/helpers/Arrayincludes");

var e = require("../@babel/runtime/helpers/typeof"), t = require("../@babel/runtime/helpers/slicedToArray");

require("../@babel/runtime/helpers/Objectentries");

module.exports = {
    delay: function(e) {
        return new Promise(function(t) {
            setTimeout(function() {
                t();
            }, e);
        });
    },
    formatTime: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "yyyy/MM/dd hh:mm:ss", r = {
            "M+": e.getMonth() + 1,
            "d+": e.getDate(),
            "h+": e.getHours(),
            "m+": e.getMinutes(),
            "s+": e.getSeconds(),
            "q+": Math.floor((e.getMonth() + 3) / 3),
            S: e.getMilliseconds()
        };
        for (var n in /(y+)/.test(t) && (t = t.replace(RegExp.$1, (e.getFullYear() + "").substr(4 - RegExp.$1.length))), 
        r) new RegExp("(" + n + ")").test(t) && (t = t.replace(RegExp.$1, 1 == RegExp.$1.length ? r[n] : ("00" + r[n]).substr(("" + r[n]).length)));
        return t;
    },
    doubleClick: function() {
        var e = !1;
        return function() {
            return !e && (e = !0, setTimeout(function() {
                e = !1;
            }, 2e3), !0);
        };
    },
    currentYearDate: function() {
        var e = new Date(), t = {};
        t.year = e.getFullYear();
        var r = e.getMonth() < 9 ? "0" + (e.getMonth() + 1) : e.getMonth() + 1, n = e.getDate() < 10 ? "0" + e.getDate() : e.getDate();
        return t.date = r + "." + n, t.year + "." + t.date;
    },
    currentYearDateObject: function() {
        var e = new Date(), t = {};
        t.year = e.getFullYear();
        var r = e.getMonth() < 9 ? "0" + (e.getMonth() + 1) : e.getMonth() + 1, n = e.getDate() < 10 ? "0" + e.getDate() : e.getDate();
        return {
            year: t.year,
            month: r,
            day: n
        };
    },
    zoomCanvasDrawInfoSeries: function(r, n) {
        return r.map(function(r) {
            return function r(n, i) {
                var a = {};
                return Object.entries(n).forEach(function(n) {
                    var l = t(n, 2), o = l[0], g = l[1];
                    "object" === e(g) ? a[o] = r(g) : [ "width", "height", "x", "y", "radius", "fontSize", "lineHeight" ].includes(o) && "number" == typeof g ? a[o] = g * i : a[o] = g;
                }), a;
            }(r, n);
        });
    },
    obj2query: function(e) {
        var t = [];
        for (var r in e) e.hasOwnProperty(r) && e[r] && t.push(encodeURIComponent(r) + "=" + encodeURIComponent(e[r]));
        return t.join("&");
    },
    formatRichText: function(e) {
        return "<p></p>" === e ? "" : (e || "").replace(/<img([\s\w"-=\/\.:;]+)((?:(height="[^"]+")))/gi, "<img$1").replace(/<img([\s\w"-=\/\.:;]+)((?:(width="[^"]+")))/gi, "<img$1").replace(/<img([\s\w"-=\/\.:;]+)((?:(style="[^"]+")))/gi, "<img$1").replace(/<img([\s\w"-=\/\.:;]+)((?:(alt="[^"]+")))/gi, "<img$1").replace(/<img([\s\w"-=\/\.:;]+)/gi, '<img style="max-width: 100%" $1').replace(/<ol([\s\w"-=\/\.:;]+)((?:(style="[^"]+")))/gi, "<ol$1").replace(/<ol([\s\w"-=\/\.:;]+)?>/gi, '<ol$1 style="padding: 0; margin: 0">').replace(/<ul([\s\w"-=\/\.:;]+)((?:(style="[^"]+")))/gi, "<ul$1").replace(/<ul([\s\w"-=\/\.:;]+)?>/gi, '<ul$1 style="padding: 0; margin: 0">').replace(/<li([\s\w"-=\/\.:;]+)((?:(style="[^"]+")))/gi, "<li$1").replace(/<li>/gi, '<li style="list-style: none;">').replace(/<p><\/p>/gi, "<p> </p>");
    },
    navigateBack: function() {
        for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            url: ""
        }, t = getCurrentPages(), r = 0, n = e.url, i = t.length - 1; i >= 0; i--) {
            if ("/" + t[i].route == n) {
                if (0 === r) return;
                return void wx.navigateBack({
                    delta: r
                });
            }
            r++;
        }
        wx.navigateTo({
            url: n
        });
    }
};