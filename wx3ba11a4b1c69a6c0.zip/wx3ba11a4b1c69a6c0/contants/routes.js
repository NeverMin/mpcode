var e = {
    HOME: "/pages/index/index",
    MEDITATION: "/pages/tabBar/exercise/exercise",
    SQUARE: "/pages/tabBar/square/square",
    ME: "/pages/tabBar/user/center",
    GOODS: "/pages/goods/goods",
    INVITATION: "/pages/user/invitation/invitation",
    COURSE: "/pages/course/course",
    REPORT2022: "/pages/year_end_report/2022/index/index",
    PUNCHIN: "/pages/camp/punch_in/punch_in",
    THEMED_PAGE: "/pages/themed_page/index",
    DEFAULT: ""
}, a = [ e.HOME, e.MEDITATION, e.SQUARE, e.ME ], t = new Map([ [ "home", {
    path: e.HOME,
    isTab: !0
} ], [ "meditation", {
    path: e.MEDITATION,
    isTab: !0
} ], [ "square", {
    path: e.SQUARE,
    isTab: !0
} ], [ "me", {
    path: e.ME,
    isTab: !0
} ], [ "subscribe", {
    path: e.GOODS
} ], [ "goShare", {
    path: e.INVITATION
} ], [ "goMeditationCourse", {
    path: e.COURSE,
    format: function(e, a) {
        return e + "?course_id=".concat(a.courseID);
    }
} ], [ "report2022", {
    path: e.REPORT2022
} ], [ "punchIn", {
    path: e.PUNCHIN
} ], [ "themedPage", {
    path: e.THEMED_PAGE,
    format: function(e, a) {
        return e + "?id=".concat(a.id, "&flag=").concat(a.flag);
    }
} ] ]);

module.exports = {
    RouteEnum: e,
    TabRoutes: a,
    RouterMap: t
};