exports.FINISH_CHECK_LOCAL_GUIDE = "finish_check_local_guide", exports.FINISH_CHECK_LOCAL_LESSON = "finish_check_local_lesson", 
exports.FINISH_CHECK_LOCAL_QA = "finish_check_local_qa", exports.FINISH_CHECK_LOCAL_ACTION = "finish_check_local_actionn", 
exports.STEP_GUIDED = "guided", exports.STEP_LESSON = "lesson", exports.STEP_QA = "qa", 
exports.STEP_ACTION = "action", exports.PAGE_INDEX = "discovery", exports.PAGE_EXERCRISE = "meditation", 
exports.PAGE_SQUARE = "square", exports.PAGE_CENTER = "me", exports.PAGE_SUBSCRIBE = "subscribe";