var e = require("@babel/runtime/helpers/interopRequireDefault")(require("@babel/runtime/regenerator")), t = require("@babel/runtime/helpers/asyncToGenerator"), i = require("utils/holdno_event_listener.js"), n = require("./utils/md5.js").default, a = require("/api/user.js"), o = a.login, r = a.getVipInfo, s = require("/api/bg_setting.js"), l = s.bgList, u = s.updateBgSetting, c = require("/api/index.js"), d = c.getAccountQrcodeAddress, g = c.getPopupList, h = require("./api/punch_in"), p = h.checkUnread, f = h.reportUnread, v = require("/utils/util.js"), b = v.formatTime, _ = v.obj2query, m = require("/utils/request.js").baseUrl, x = require("utils/gio-minp/index.js").default, w = require("utils/gio-minp/gioConfig.js").default;

x("setConfig", w), App({
    businessCallback: null,
    init: !1,
    serviceAccountQrcodeAddress: "https://mp.weixin.qq.com/s/dTxYY_R6eyqbdHIAMtKtag",
    subAccountQrcodeAddress: "https://mp.weixin.qq.com/s?__biz=Mzg2MzYzMTk4Ng==&mid=2247483659&idx=1&sn=6dce99f9bcd907844ad08679a1109fa6&chksm=ce74ee16f9036700603dcdfc3cbf13b9a22ca72534ddade2e23763a4f86828d4190400b88342#rd",
    shareImg: "https://heartlylab.holdno.com/heartlylab/share/share_box.png",
    appid: "wx3ba11a4b1c69a6c0",
    store: i,
    hideBgPlayIcon: !0,
    events: {
        hideTabBar: "hideTabbar",
        levelUp: "levelUp",
        register: "register",
        changeColumn: "changeColumn",
        badgeChange: "badgeChange"
    },
    exerciseColumnID: 0,
    bgSetting: [],
    goods: [],
    userShareQrcode: "",
    inviter: 0,
    giftCode: "",
    giftCodeShow: !1,
    lunchOpts: {},
    activityLogicMap: [],
    onHide: function() {
        var e = this;
        if (this.globalData.userInfo.id && null != this.openTime) {
            var t = wx.getBackgroundAudioManager(), i = this.globalData.userInfo, n = i.id, a = i.isFirst;
            if (t && null != t.webUrl && !t.paused) this.usedRangeInterval = setInterval(function() {
                if (t.paused) {
                    var i = (new Date() - e.openTime) / 1e3;
                    console.log("上报用户使用时长"), wx.reportAnalytics("used_range", {
                        uid: n,
                        login_result: "" == e.globalData.userInfo.avatar ? "Failed" : "Success",
                        view_time: i
                    }), x("track", "use_time", {
                        userID: n,
                        Duration: i,
                        isFirst: a
                    }), e.resetOpenTime();
                }
            }, 1e3); else {
                var o = (new Date() - this.openTime) / 1e3;
                wx.reportAnalytics("used_range", {
                    uid: n,
                    login_result: "" == this.globalData.userInfo.avatar ? "Failed" : "Success",
                    view_time: o
                }), x("track", "use_time", {
                    userID: n,
                    Duration: o,
                    isFirst: a
                }), this.resetOpenTime();
            }
        }
    },
    onShow: function(e) {
        var t = this;
        null != this.usedRangeInterval ? (clearInterval(this.usedRangeInterval), this.usedRangeInterval = null) : this.resetOpenTime(), 
        null != this.__bgAudioContext && setTimeout(function() {
            t.hideBgPlayIcon && t.getBgAudio() && t.getBgAudio().play();
        }, 1e3), console.log("ooooo", e);
        var i = this.getScene(e.query);
        !i.gift || 1008 != e.scene && 1007 != e.scene && 1047 != e.scene && 1048 != e.scene ? this.giftCode = "" : (this.giftCode = i.gift, 
        this.giftCodeShow = !0), this.init || (this.init = !0);
    },
    reloadUserVipInfo: function() {
        var i = this;
        this.jwtReady(t(e.default.mark(function t() {
            var n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, r();

                  case 3:
                    (n = e.sent).meta && 0 == n.meta.code && i.globalData.userInfo.vip_expire_date != n.data.vip_expire_date && (i.globalData.userInfo.level = n.data.level, 
                    i.globalData.userInfo.vip_expire_date = n.data.vip_expire_date, i.globalData.userInfo.isNew = n.data.is_new, 
                    i.store.emit(i.events.levelUp, n.data)), e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(0), console.log(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 7 ] ]);
        })));
    },
    resetOpenTime: function() {
        this.openTime = new Date();
    },
    usedRangeInterval: null,
    openTime: null,
    aldContract: function(e) {
        if (e && e.userid) try {
            var t = Date.parse(new Date()) / 1e3, i = n(t + "heartl");
            wx.request({
                url: "https://www.cloudfi.cn/index.php/Interface/Scale/minicount",
                method: "post",
                data: {
                    channel: "heartl",
                    userid: e.userid,
                    orgid: "gh_19b2ec804d0d",
                    timestamp: t,
                    sign: i
                },
                success: function(e) {
                    console.log("阿拉丁计数请求", e);
                },
                fail: function(e) {
                    console.log("阿拉丁计数请求失败", e);
                }
            }), this.businessCallback = function() {
                wx.navigateToMiniProgram({
                    appId: "wx25026314b1d39ef8",
                    path: "/pages/index/index?" + _(e)
                });
            };
        } catch (e) {
            console.log("阿拉丁合作请求失败", e);
        }
    },
    isALDActivity: function(e) {
        return !(!e || "Y9JxkaYP" != e.gio_link_id);
    },
    isGameActivity: function(e) {
        return !(!e || "EoZAeaqP" != e.gio_link_id);
    },
    checkIsIphoneX: function() {
        var e = this;
        wx.getSystemInfo({
            success: function(t) {
                for (var i = t.model, n = !1, a = [ "X", "11", "12", "13" ], o = 0; o < a.length; o++) if (-1 != i.search(a[o])) {
                    n = !0;
                    break;
                }
                e.globalData.isIphoneX = n;
            }
        });
    },
    gioLinkID: 0,
    onLaunch: function(e) {
        var t = this;
        this.checkIsIphoneX(), e.query.gio_link_id && (this.gioLinkID = e.query.gio_link_id), 
        this.openTime = new Date();
        var i = this.getScene(e.query);
        try {
            if (this.lunchOpts = i, i.inviter) {
                var n = parseInt(i.inviter);
                n && (this.inviter = n, wx.setStorageSync("inviter", this.inviter));
            }
            i.gift && (this.giftCode = i.gift), this.login(i), setInterval(function() {
                t.hideBgPlayIcon && null != t.__bgAudioContext && t.__bgAudioContext.paused && t.getBgAudio().play();
            }, 500);
            var a = wx.getUpdateManager();
            a.onUpdateReady(function() {
                wx.showModal({
                    title: "更新提示",
                    content: "新版本已经准备好，是否立即打开？",
                    success: function(e) {
                        e.confirm && a.applyUpdate();
                    }
                });
            }), wx.setInnerAudioOption({
                mixWithOther: !0,
                obeyMuteSwitch: !1
            }), l().then(function(e) {
                0 == e.meta.code && (t.bgSetting = e.data);
            });
        } catch (e) {
            console.log(e);
        }
        try {
            d().then(function(e) {
                0 == e.meta.code && (t.serviceAccountQrcodeAddress = e.data.service, t.subAccountQrcodeAddress = e.data.sub);
            });
        } catch (e) {
            console.log(e);
        }
        this.loadCustomStyle();
    },
    login: function(e) {
        var t = this;
        wx.login({
            success: function(i) {
                o(i.code, t.appid, "").then(function(i) {
                    console.log("login: ", i);
                    var n = i.data.setting;
                    t.userSetting = {
                        bgID: n.bg_id,
                        bgUrl: n.bg_url,
                        bgIconUrl: n.bg_icon,
                        bgAudioUrl: n.bg_audio_url,
                        guideVolume: n.guide_volume,
                        bgVolume: n.bg_volume
                    }, t.bgAudioPlayer(n.bg_audio_url, n.bg_volume, !0);
                    var a = i.data;
                    a.activity && (t.activityLogicMap = a.activity), t.globalData.serviceVersion = i.data.service_version, 
                    t.globalData.userInfo = {
                        id: a.id,
                        name: a.nick_name,
                        level: t.isReleased() ? a.level : 1,
                        vip_expire_date: a.vip_expire_date,
                        isNew: a.is_new,
                        tel: a.tel,
                        token: a.token,
                        avatar: a.avatar,
                        isFirst: a.is_first,
                        if_login: a.tel ? 1 : 0
                    }, t.checkUnread(), x("identify", i.data.openid, i.data.unionid), x("setUserId", a.id), 
                    x("setUser", {
                        id: a.id,
                        name: a.nick_name,
                        level: a.level,
                        vip_expire_date: a.vip_expire_date,
                        isNew: a.is_new,
                        tel: a.tel,
                        avatar: a.avatar,
                        isFirst: a.is_first,
                        if_zdkuser: /^\d*[0-5]$/gi.test(a.id) ? 1 : 0
                    }), x("setVisitor", {
                        if_login: a.tel ? 1 : 0,
                        dkz_uid: a.id,
                        isFirst: a.is_first
                    });
                    var o = {
                        uid: a.id,
                        time: b(new Date()),
                        remark: "",
                        type: options.scene,
                        if_referral: 0,
                        invite_id: ""
                    };
                    e.ad ? (o.source_type = "ad", o.source = e.ad) : t.inviter ? (o.if_referral = 1, 
                    o.invite_id = t.inviter, o.source = t.inviter, o.source_type = "invitation") : t.giftCode && (o.if_referral = 1, 
                    o.invite_id = t.giftCode, o.source_type = "gift"), wx.reportAnalytics("user_source", o);
                });
            }
        });
    },
    getScene: function(e) {
        console.log("op", e);
        var t = decodeURIComponent(e.scene);
        t = t.split(";");
        for (var i = {}, n = 0; n < t.length; n++) {
            var a = t[n].split(":");
            i[a[0]] = a[1];
        }
        return i;
    },
    getGiftCodeQrcode: function(e, t) {
        var i = this;
        wx.downloadFile({
            url: m + "/api/v1/gift/qrcode?code=" + e,
            header: {
                "x-token": this.globalData.userInfo.token
            },
            success: function(e) {
                console.log(e), 200 === e.statusCode ? (i.userShareQrcode = e.tempFilePath, t(e.tempFilePath, !0)) : t(null, !1);
            },
            fail: function(e) {
                console.log(e), t(null, !1);
            }
        });
    },
    getShareQrcode: function(e) {
        var t = this;
        t.userShareQrcode && "" != t.userShareQrcode ? e(t.userShareQrcode, !0) : wx.downloadFile({
            url: m + "/api/v1/user/invitation/qrcode",
            header: {
                "x-token": this.globalData.userInfo.token
            },
            success: function(i) {
                console.log(i), 200 === i.statusCode ? (t.userShareQrcode = i.tempFilePath, e(i.tempFilePath, !0)) : e(null, !1);
            },
            fail: function(t) {
                console.log(t), e(null, !1);
            }
        });
    },
    loadCustomStyle: function() {
        try {
            var e = wx.getSystemInfoSync();
            console.log(e), this.globalData.StatusBar = e.statusBarHeight, this.globalData.ScreenHeight = e.screenHeight, 
            this.globalData.PixelRatio = e.pixelRatio, this.globalData.WindowWidth = e.windowWidth, 
            this.globalData.WindowHeight = e.windowHeight;
            var t = wx.getMenuButtonBoundingClientRect();
            this.globalData.Custom = t, this.globalData.CustomBar = t.bottom + t.top - e.statusBarHeight;
        } catch (e) {
            wx.showModal({
                title: "初始化失败",
                content: "获取配置信息失败，请尝试重开小程序或升级微信版本"
            });
        }
    },
    jwtReady: function(e) {
        var t = this, i = setInterval(function() {
            t.globalData.userInfo.token && (clearInterval(i), e());
        }, 100);
    },
    isReleased: function() {
        return this.globalData.version <= this.globalData.serviceVersion;
    },
    getUserSetting: function() {
        return this.userSetting;
    },
    userSetting: {
        bgID: null,
        bgUrl: null,
        bgIconUrl: null,
        bgAudioUrl: null,
        guideVolume: null,
        bgVolume: null
    },
    setBgVolume: function(e) {
        var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        this.userSetting.bgVolume = e, null != this.__bgAudioContext && (this.__bgAudioContext.volume = e / 100), 
        t && this.updateRemoteUserBgSetting(0);
    },
    updateRemoteUserBgSetting: function(e) {
        try {
            u(e, this.userSetting.bgVolume, this.userSetting.guideVolume);
        } catch (e) {
            console.log(e);
        }
    },
    updateBgSetting: function(e) {
        if (e != this.userSetting.bgUrl) for (var t = 0; t < this.bgSetting.length; t++) if (this.bgSetting[t].id == e) return this.userSetting.bgID = e, 
        this.userSetting.bgUrl = this.bgSetting[t].bg_url, this.userSetting.bgIconUrl = this.bgSetting[t].bg_icon_url, 
        this.userSetting.bgAudioUrl = this.bgSetting[t].bg_audio_url, this.bgAudioPlayer(this.bgSetting[t].bg_audio_url, this.userSetting.bgVolume, !0), 
        void this.updateRemoteUserBgSetting(e);
    },
    __bgAudioContext: null,
    getBgAudio: function() {
        return null == this.__bgAudioContext && (this.__bgAudioContext = wx.createInnerAudioContext()), 
        this.__bgAudioContext;
    },
    needRegister: function(e, t) {
        return "" == this.globalData.userInfo.tel && (console.log(e, t), wx.navigateTo({
            url: "/pages/register/register?redirect=" + encodeURIComponent(e) + "&type=" + t
        }), !0);
    },
    bgAudioPlayer: function(e, t) {
        var i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        if (console.log("bgAudioPlayer", e, t, i), "" != e) {
            t > 1 && (t /= 100);
            var n = null;
            return null != this.__bgAudioContext && (this.__bgAudioContext.destroy(), this.__bgAudioContext = null), 
            null == this.__bgAudioContext ? (n = wx.createInnerAudioContext(), this.__bgAudioContext = n, 
            n.loop = !0, n.onCanplay(function() {
                n.play();
            })) : n = this.__bgAudioContext, n.volume = t, n.src = e, n;
        }
    },
    goLessonEvent: function(e) {
        0 != this.globalData.userInfo.id && wx.reportAnalytics("view_lesson", {
            uid: this.globalData.userInfo.id,
            lesson_id: e.lessonID,
            lesson_name: e.lessonName,
            if_trial: e.useLevel,
            purchase_type: e.useLevel,
            page_column: e.pageName,
            course_id: e.courseID,
            course_name: e.courseName
        });
    },
    checkUnread: function() {
        var i = this;
        return t(e.default.mark(function t() {
            var n, a, o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, p();

                  case 3:
                    n = e.sent, a = n.meta, o = n.data, 0 === a.code && o.unread && (i.globalData.showBadge.square = !0, 
                    i.store.emit(i.events.badgeChange)), e.next = 12;
                    break;

                  case 9:
                    e.prev = 9, e.t0 = e.catch(0), console.error(e.t0);

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 9 ] ]);
        }))();
    },
    reportUnread: function() {
        var i = this;
        return t(e.default.mark(function t() {
            var n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, f();

                  case 3:
                    n = e.sent, 0 === n.meta.code && (i.globalData.showBadge.square = !1, i.store.emit(i.events.badgeChange)), 
                    e.next = 11;
                    break;

                  case 8:
                    e.prev = 8, e.t0 = e.catch(0), console.error(e.t0);

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 8 ] ]);
        }))();
    },
    loadPopupList: function() {
        var i = this;
        return t(e.default.mark(function t() {
            var n, a, o, r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n = i.globalData.popupData || {}, !(Object.keys(n).length > 0)) {
                        e.next = 3;
                        break;
                    }
                    return e.abrupt("return", n);

                  case 3:
                    return e.prev = 3, e.next = 6, g();

                  case 6:
                    if (a = e.sent, o = a.meta, r = a.data, 0 !== o.code) {
                        e.next = 12;
                        break;
                    }
                    return i.globalData.popupData = r, e.abrupt("return", r);

                  case 12:
                    e.next = 17;
                    break;

                  case 14:
                    e.prev = 14, e.t0 = e.catch(3), console.error(e.t0);

                  case 17:
                    return e.abrupt("return", n);

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 3, 14 ] ]);
        }))();
    },
    globalData: {
        StatusBar: null,
        PixelRatio: null,
        WindowWidth: null,
        ScreenHeight: null,
        Custom: null,
        CustomBar: null,
        serviceVersion: 1,
        version: 91,
        isIphoneX: !1,
        userInfo: {
            id: 0,
            name: "",
            level: 0,
            avatar: "",
            vip_expire_date: ""
        },
        showBadge: {
            square: !1
        },
        popupData: {}
    }
});