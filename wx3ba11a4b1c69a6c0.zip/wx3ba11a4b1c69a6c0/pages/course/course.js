var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = getApp(), s = require("../../api/course"), i = s.getCouseLessons, r = s.getLessonDetail, n = s.getSimilarList, o = s.getSkillOtherCourses, u = s.getCourseCurrentStudyUsers, l = require("../../utils/util"), c = l.doubleClick, d = l.formatTime, f = c(), h = require("../../api/user.js").receiveVIP, g = require("../../utils/gio-minp/index.js").default;

Page({
    data: {
        course: {},
        audios: [],
        teachers: [],
        lessons: [],
        isVip: 0,
        loading: !0,
        showTeacherInfo: !1,
        showGift: !1,
        showGoodBtn: !1,
        playButtonContent: "开始练习",
        giftButtonContent: "领取7天免费体验",
        activeTeacherIndex: 0,
        currentStudyCount: 0,
        currCourseList: [],
        activeSkill: {},
        showSkillDetail: !1,
        currSkillCourseList: [],
        audioPicker: null,
        showAudioDetail: !1,
        activeAudioIndex: 0,
        isIphoneX: !1
    },
    onUnload: function() {
        a.store.off(a.events.levelUp, "courseLevelUp");
    },
    onLoad: function(e) {
        var t = this;
        this.setData({
            isIphoneX: a.globalData.isIphoneX
        }), a.store.on(a.events.levelUp, function(e) {
            t.setData({
                isVip: a.globalData.userInfo.level,
                playButtonContent: "开始练习"
            });
        }, "courseLevelUp"), a.jwtReady(function() {
            t.setData({
                isVip: a.globalData.userInfo.level
            }), t.getCourseLessons(e.course_id, 1, 50), t.loadSimilarList(e.course_id), t.loadCourseCurrentStudyUsers(e.course_id), 
            wx.reportAnalytics("user_coming", {
                is_first_time: a.globalData.userInfo.isFirst,
                time: d(new Date()),
                uid: a.globalData.userInfo.id,
                type: "Lesson列表页"
            }), g("track", "userComming", {
                isFirst: a.globalData.userInfo.isFirst,
                time: d(new Date()),
                userID: a.globalData.userInfo.id,
                pageTitle: "Lesson列表页"
            });
        });
    },
    loadLessonDetail: function(a) {
        var s = this;
        return t(e.default.mark(function t() {
            var i, n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, r(a);

                  case 2:
                    i = e.sent, n = i.data, 0 === i.meta.code && s.setData({
                        audios: n.audios.map(function(e, t) {
                            return e.text = e.title, e.index = t, e;
                        }) || []
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    getCourseLessons: function(s, r, n) {
        var o = this;
        return t(e.default.mark(function t() {
            var u, l, c;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return o.setData({
                        loading: !0
                    }), e.prev = 1, e.next = 4, i(s, r, n);

                  case 4:
                    0 == (u = e.sent).meta.code && (o.setData({
                        course: u.data.course,
                        teachers: u.data.course.teachers,
                        lessons: null != u.data.list ? u.data.list : []
                    }), wx.reportAnalytics("view_course", {
                        uid: a.globalData.userInfo.id,
                        purchase_type: "免费" == u.data.course.tag ? 0 : 1,
                        course_id: u.data.course.id,
                        course_name: u.data.course.title,
                        time: d(new Date()),
                        page_column: u.data.course.column_id
                    }), u.data.list ? (1 === u.data.list.length && o.loadLessonDetail(u.data.list[0].id), 
                    0 !== (l = o.getNextPlayLesson()).use_level && 0 === o.data.isVip ? o.setData({
                        showGoodBtn: !0,
                        playButtonContent: "HEARTLY Pro 专享"
                    }) : o.data.lessons.length > 1 && (c = o.data.lessons.findIndex(function(e) {
                        return e.id === l.id;
                    }), o.setData({
                        playButtonContent: "开始练习第 ".concat(c + 1, " 章")
                    }))) : o.lessonNotReady()), e.next = 11;
                    break;

                  case 8:
                    e.prev = 8, e.t0 = e.catch(1), console.log(e.t0);

                  case 11:
                    o.setData({
                        loading: !1
                    });

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 8 ] ]);
        }))();
    },
    loadCourseCurrentStudyUsers: function(a) {
        var s = this;
        return t(e.default.mark(function t() {
            var i, r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, u(a);

                  case 2:
                    i = e.sent, r = i.data, 0 === i.meta.code && s.setData({
                        currentStudyCount: r.count || 0
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    loadSimilarList: function(a) {
        var s = this;
        return t(e.default.mark(function t() {
            var i, r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, n(a);

                  case 2:
                    i = e.sent, r = i.data, 0 === i.meta.code && s.setData({
                        currCourseList: r.list || []
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    loadSkillOtherCourses: function(a) {
        var s = this;
        return t(e.default.mark(function t() {
            var i, r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, o(s.data.course.id, a);

                  case 2:
                    i = e.sent, r = i.data, 0 === i.meta.code && s.setData({
                        currSkillCourseList: r.list || []
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    lessonNotReady: function() {
        wx.showToast({
            title: "课程还未准备好",
            icon: "none"
        });
    },
    onShow: function() {
        var e = this;
        this.data.course.id && a.jwtReady(function() {
            e.setData({
                isVip: a.globalData.userInfo.level
            }), e.getCourseLessons(e.data.course.id, 1, 50);
        });
    },
    stopScroll: function() {},
    showTeacher: function() {
        this.setData({
            showTeacherInfo: !0
        }), wx.reportAnalytics("view_teacher", {
            uid: a.globalData.userInfo.id,
            purchase_type: "免费" == this.data.course.tag ? 0 : 1,
            course_id: this.data.course.id,
            course_name: this.data.course.title,
            time: d(new Date()),
            button_name: "WriterInfo"
        });
    },
    closeTeacher: function() {
        this.setData({
            showTeacherInfo: !1
        });
    },
    handleClickSkill: function(e) {
        var t = e.currentTarget.dataset.index, a = this.data.course.skills, s = (void 0 === a ? [] : a)[t];
        s && (this.loadSkillOtherCourses(s.id), this.setData({
            activeSkill: s,
            showSkillDetail: !0
        }));
    },
    closeSkill: function() {
        this.setData({
            showSkillDetail: !1
        });
    },
    goLesson: function(e) {
        if (f()) if (e.currentTarget.dataset.ok) wx.navigateTo({
            url: "/pages/lesson/lesson?id=" + e.currentTarget.dataset.id + "&pagetype=LessonClick"
        }); else {
            if (a.needRegister()) return;
            wx.navigateTo({
                url: "/pages/goods/goods"
            });
        }
    },
    getNextPlayLesson: function() {
        var e = this.data.lessons;
        if (e && 0 != e.length) {
            for (var t = 0, a = !1, s = 0; s < e.length; s++) 0 == s && (t = e[s]), 1 != e[s].study_finished ? a && (a = !1, 
            t = e[s]) : a = !0;
            return t;
        }
        this.lessonNotReady();
    },
    goPlayPage: function() {
        if (f()) {
            var e = this.getNextPlayLesson();
            if (e) if (e.use_level > 0 && 0 == a.globalData.userInfo.level) {
                if (a.needRegister()) return;
                1 == a.globalData.userInfo.isNew ? this.setData({
                    showGift: !0
                }) : a.isReleased() && (wx.reportAnalytics("user_click", {
                    uid: a.globalData.userInfo.id,
                    button_name: "Upgrade",
                    type: "课程-升级为会员"
                }), wx.navigateTo({
                    url: "/pages/goods/goods"
                }));
            } else {
                var t = "/pages/lesson/lesson?id=" + e.id + "&pagetype=LessonPlay";
                1 === this.data.lessons.length && this.data.audios.length > 1 && (t += "&choose_audio=".concat(this.data.activeAudioIndex, "&auto_play=1")), 
                wx.navigateTo({
                    url: t
                });
            }
        }
    },
    closeGift: function() {
        wx.reportAnalytics("receive_rewards", {
            uid: a.globalData.userInfo.id,
            receive_result: "Reject",
            rewards_type: a.inviter ? "Refrral" : "RewardforNew",
            page_name: "Course",
            invite_id: a.inviter ? a.inviter : "NA"
        }), this.setData({
            showGift: !1
        });
    },
    getGift: function() {
        var s = this;
        return t(e.default.mark(function t() {
            var i, r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!a.needRegister("/pages/index/index", "switch")) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return s.setData({
                        giftLoading: !0,
                        giftButtonContent: ""
                    }), i = {
                        giftLoading: !1,
                        giftButtonContent: "领取7天免费体验"
                    }, e.prev = 4, e.next = 7, h();

                  case 7:
                    0 == (r = e.sent).meta.code ? (a.globalData.userInfo.level = r.data.level, a.globalData.userInfo.vip_expire_date = r.data.expire_date, 
                    i.giftButtonContent = "领取成功", i.isVip = 1, wx.reportAnalytics("receive_rewards", {
                        uid: a.globalData.userInfo.id,
                        receive_result: "Accept",
                        rewards_type: a.inviter ? "Refrral" : "RewardforNew",
                        page_name: "Course",
                        invite_id: a.inviter ? a.inviter : "NA"
                    }), setTimeout(function() {
                        s.setData({
                            showGiftConfirm: !0,
                            showGift: !1
                        });
                    }, 500), wx.reportAnalytics("user_click", {
                        uid: a.globalData.userInfo.id,
                        button_name: "7DaysFree",
                        type: "LessonList"
                    })) : (wx.reportAnalytics("receive_rewards", {
                        uid: a.globalData.userInfo.id,
                        receive_result: "Failed",
                        rewards_type: a.inviter ? "Refrral" : "RewardforNew",
                        page_name: "Course",
                        invite_id: a.inviter ? a.inviter : "NA"
                    }), wx.showToast({
                        title: r.meta.message,
                        icon: "none"
                    })), e.next = 14;
                    break;

                  case 11:
                    e.prev = 11, e.t0 = e.catch(4), console.log(e.t0);

                  case 14:
                    setTimeout(function() {
                        s.setData(i);
                    }, 500);

                  case 15:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 4, 11 ] ]);
        }))();
    },
    handleClickAvatar: function(e) {
        this.setData({
            activeTeacherIndex: e.currentTarget.dataset.index
        });
    },
    showAudioSelect: function() {
        this.data.audios.length <= 1 || this.setData({
            showAudioDetail: !0
        });
    },
    getAudioPicker: function() {
        return null == this.audioPicker && (this.audioPicker = this.selectComponent("#audio-picker")), 
        this.audioPicker;
    },
    handleAudioPickerClick: function(e) {
        var t = (this.getAudioPicker().getIndexes() || [])[0] || 0;
        t !== this.data.activeAudioIndex ? (this.setData({
            activeAudioIndex: t
        }), this.stopAudio()) : this.stopAudio();
    },
    stopAudio: function() {
        this.setData({
            showAudioDetail: !1
        });
    },
    onShareAppMessage: function() {
        return wx.reportAnalytics("share_common", {
            button_name: "Share",
            channel: "Friends",
            page_name: "Course",
            uid: a.globalData.userInfo.id
        }), {
            title: this.data.course.title,
            path: "/pages/course/course?course_id=" + this.data.course.id + "&scene=inviter:" + a.globalData.userInfo.id,
            imageUrl: this.data.course.img || a.shareImg
        };
    }
});