var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = require("../../@babel/runtime/helpers/objectSpread2"), a = t(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/asyncToGenerator"), s = t(require("../../miniprogram_npm/@vant/weapp/dialog/dialog.js")), i = require("../../utils/util"), o = require("../../api/course.js"), n = require("../../utils/gio-minp/index.js").default, c = (0, 
i.doubleClick)();

Page({
    data: {
        keyword: "",
        showSearchResult: !1,
        historyList: [],
        searchPlaceholder: "",
        popularList: [],
        list: [],
        loading: !1,
        page: 1,
        pagesize: 8,
        total: null,
        noMore: !1
    },
    onLoad: function(t) {
        try {
            var e = wx.getStorageSync("search_history_list"), a = JSON.parse(e);
            this.setData({
                historyList: a
            });
        } catch (t) {}
        this.getSearchPopularList();
    },
    bindKeyInput: function(t) {
        "" === t.detail.value && this.setData({
            showSearchResult: !1
        }), this.setData({
            keyword: t.detail.value
        });
    },
    handleSearch: function() {
        var t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        if (this.setData({
            list: [],
            page: 1,
            pagesize: 8,
            noMore: !1,
            showSearchResult: !0
        }), !this.data.keyword) {
            var e = this.data.popularList[0];
            if (!e) return void wx.showToast({
                title: "数据异常，请稍后再试！",
                icon: "none"
            });
            this.setData({
                keyword: e.title
            });
        }
        t && this.recordSearchHistory(), this.getList();
    },
    handleClickPopular: function(t) {
        var e = t.currentTarget.dataset.title;
        e ? (this.setData({
            keyword: e
        }), this.handleSearch(!0)) : wx.showToast({
            title: "数据异常，请稍后再试！",
            icon: "none"
        });
    },
    handleDelete: function() {
        var t = this;
        s.default.confirm({
            message: "确定要删除历史搜索记录吗？",
            confirmButtonText: "删除",
            cancelButtonText: "取消"
        }).then(function() {
            wx.removeStorageSync("search_history_list"), t.setData({
                historyList: []
            });
        }).catch(function() {});
    },
    recordSearchHistory: function() {
        var t = this;
        if (this.data.keyword) {
            var e = this.data.historyList, a = e.findIndex(function(e) {
                return e === t.data.keyword;
            });
            a >= 0 && e.splice(a, 1), e.unshift(this.data.keyword), e.length > 4 && e.pop(), 
            this.setData({
                historyList: e
            }), wx.setStorageSync("search_history_list", JSON.stringify(e));
        }
    },
    handleClickHistory: function(t) {
        var e = t.target.dataset.keyword;
        this.setData({
            keyword: e
        }), this.handleSearch(!1);
    },
    handleClear: function() {
        this.setData({
            keyword: "",
            showSearchResult: !1
        });
    },
    getSearchPopularList: function() {
        var t = this;
        return r(a.default.mark(function e() {
            var r, s, i;
            return a.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, (0, o.getSearchPopularList)();

                  case 3:
                    r = e.sent, s = r.meta, i = r.data, 0 === s.code ? t.setData({
                        popularList: i,
                        searchPlaceholder: i[0] ? i[0].title : ""
                    }) : wx.showToast({
                        title: s.message,
                        icon: "none"
                    }), e.next = 12;
                    break;

                  case 9:
                    e.prev = 9, e.t0 = e.catch(0), console.log(e.t0);

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, e, null, [ [ 0, 9 ] ]);
        }))();
    },
    onReachBottom: function() {
        this.data.noMore || this.getList();
    },
    getList: function() {
        var t = this;
        return r(a.default.mark(function r() {
            var s, i, n, c, l;
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return t.setData({
                        loading: !0
                    }), a.prev = 1, s = {}, a.next = 5, (0, o.getSearchList)(t.data.keyword, t.data.page, t.data.pagesize);

                  case 5:
                    i = a.sent, n = i.data, 0 === (c = i.meta).code ? (s.total = n.total, 0 === n.total ? s.noMore = !0 : (l = [], 
                    n && n.list && (l = n.list.map(function(t) {
                        var a = e({}, t.course);
                        switch (a.tag) {
                          case "免费":
                            a.tag_img = "free_tag";
                            break;

                          case "上新":
                            a.tag_img = "new_course";
                            break;

                          case "精选":
                            a.tag_img = "good_teacher";
                        }
                        return a;
                    }), console.log(l)), 1 === t.data.page ? s.list = l : s.list = t.data.list.concat(l), 
                    t.data.page * t.data.pagesize >= n.total ? s.noMore = !0 : s.page = t.data.page + 1), 
                    t.setData(s)) : wx.showToast({
                        title: c.message,
                        icon: "none"
                    }), a.next = 14;
                    break;

                  case 11:
                    a.prev = 11, a.t0 = a.catch(1), console.log(a.t0);

                  case 14:
                    t.setData({
                        loading: !1
                    });

                  case 15:
                  case "end":
                    return a.stop();
                }
            }, r, null, [ [ 1, 11 ] ]);
        }))();
    },
    goCourse: function(t) {
        if (c()) {
            var e = t.currentTarget.dataset.id;
            wx.navigateTo({
                url: "/pages/course/course?course_id=" + e
            }), n("track", "LeaveSearch", {
                userID: app.globalData.userInfo.id,
                ContentID: e,
                SearchWords: this.data.keyword
            });
        }
    }
});