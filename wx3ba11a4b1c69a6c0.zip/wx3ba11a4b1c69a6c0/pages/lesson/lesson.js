var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../contants/common"), s = require("wx-canvas-2d"), o = require("../../utils/util"), i = getApp(), n = require("../../api/bg_setting.js").updateBgSetting, r = require("../../api/course.js"), l = r.getLessonDetail, d = r.reportStudyRecord, u = r.reportFinishedLesson, c = require("../../api/user.js"), h = c.follow, g = c.receiveVIP, p = require("../../utils/util.js"), f = p.formatTime, m = p.currentYearDateObject, y = p.doubleClick, w = p.zoomCanvasDrawInfoSeries, v = require("../../api/banner.js").getBanner, x = require("../../utils/poster_extend.js"), I = require("../../api/user.js").studyEndShare, _ = require("../../api/score.js").createUserLessonScore, D = require("../../api/camp.js").submitCampStepReport, b = require("../../utils/timer.js").default, S = y(), T = m(), P = require("../../utils/gio-minp/index.js").default, k = null;

s.WxCanvas2d.use(s.SaveToAlbum), s.WxCanvas2d.use(x);

var A = new s.WxCanvas2d();

function L(e) {
    Math.floor(e / 3600);
    var t = Math.floor(e / 60 % 60), a = Math.floor(e % 60);
    return t + ":" + (a < 10 ? "0" + a : a);
}

var B = [ {
    icon: "/images/icons/score_0.png",
    score: 0,
    title: "非常不喜欢"
}, {
    icon: "/images/icons/score_1.png",
    score: 1,
    title: ""
}, {
    icon: "/images/icons/score_2.png",
    score: 2,
    title: "一般"
}, {
    icon: "/images/icons/score_3.png",
    score: 3,
    title: ""
}, {
    icon: "/images/icons/score_4.png",
    score: 4,
    title: "非常喜欢"
} ];

Page({
    data: {
        maxScoreRemarkLength: 800,
        audioInstance: null,
        audioStatusPlay: !1,
        showDuration: "",
        currentDuration: 0,
        showCurrentDuration: "",
        totalDuration: 0,
        loading: !0,
        shareLoading: !1,
        showAudioConfig: !1,
        chooseAudioIndex: 0,
        detail: {},
        followed: null,
        showCampFinish: !1,
        userSettingClass: 0,
        studyTotalDays: 0,
        guideVolume: 10,
        bgVolume: 0,
        setting: {},
        hideBgPlayIcon: !0,
        bgSetting: [],
        currentAudio: null,
        showShareButton: !1,
        endingContent: "",
        showAudioContro: "opacity: 0;",
        postGenerated: !1,
        reportTimer: null,
        showStudyScore: !1,
        studyScoreLoading: !1,
        likelyScore: null,
        feelScore: null,
        scoreRemark: "",
        scoreList: [ {
            title: "你喜欢这篇练习的内容吗？",
            items: B,
            selected: null,
            label: "likely_score"
        }, {
            title: "你学习的感受如何？",
            items: B,
            selected: null,
            label: "feel_score"
        } ],
        maxScoreHeigth: 1e3,
        scoreScrollTop: 0,
        keyboardHeight: 0,
        onFocus: !1,
        scrollTo: "",
        needLogin: !1,
        showGift: !1,
        giftButtonContent: "领取免费体验",
        giftLoading: !1,
        showContral: !1,
        needToBuy: !1,
        camp: {
            id: null,
            subPartId: null
        },
        isReportTimer: !1
    },
    closeGift: function() {
        this.setData({
            showGift: !1
        });
    },
    getGift: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var s, o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!i.needRegister("/pages/lesson/lesson?id=" + a.data.detail.lesson.id, "back")) {
                        e.next = 4;
                        break;
                    }
                    return a.closeGift(), i.store.on(i.events.register, function() {
                        a.getGift();
                    }, "levelRegister"), e.abrupt("return");

                  case 4:
                    return a.setData({
                        giftLoading: !0,
                        giftButtonContent: ""
                    }), s = {
                        giftLoading: !1,
                        giftButtonContent: "领取成功"
                    }, e.prev = 6, e.next = 9, g();

                  case 9:
                    0 == (o = e.sent).meta.code ? (i.globalData.userInfo.level = o.data.level, i.globalData.userInfo.vip_expire_date = o.data.expire_date, 
                    i.globalData.userInfo.isNew = 0, wx.reportAnalytics("receive_rewards", {
                        uid: i.globalData.userInfo.id,
                        receive_result: "Accept",
                        rewards_type: i.inviter ? "Refrral" : "RewardforNew",
                        page_name: "HomePage",
                        invite_id: i.inviter ? i.inviter : "NA"
                    }), wx.showToast({
                        title: "领取成功",
                        icon: "none",
                        duration: 3e3
                    }), s.showGift = !1, wx.reportAnalytics("user_click", {
                        uid: i.globalData.userInfo.id,
                        button_name: "7DaysFree",
                        type: "LessonPage"
                    })) : (wx.reportAnalytics("receive_rewards", {
                        uid: i.globalData.userInfo.id,
                        receive_result: "Failed",
                        rewards_type: i.inviter ? "Refrral" : "RewardforNew",
                        page_name: "LessonPage",
                        invite_id: i.inviter ? i.inviter : "NA"
                    }), 500 != o.meta.code && (s.showGift = !1), wx.showToast({
                        title: o.meta.message,
                        icon: "none",
                        duration: 3e3
                    }), s.giftButtonContent = "领取免费体验"), e.next = 16;
                    break;

                  case 13:
                    e.prev = 13, e.t0 = e.catch(6), console.log(e.t0);

                  case 16:
                    a.setData(s), a.playOrPause();

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 6, 13 ] ]);
        }))();
    },
    goLogin: function() {
        var e = this;
        this.setData({
            needLogin: !1
        }), i.store.on(i.events.register, function() {
            e.playOrPause();
        }, "levelRegister"), i.needRegister("/pages/lesson/lesson?id=" + this.data.detail.lesson.id, "back");
    },
    clickTextarea: function() {
        var e = this;
        this.setData({
            keyboardHeight: 400
        }), wx.nextTick(function() {
            e.setData({
                scrollTo: "textarea"
            }), setTimeout(function() {
                e.setData({
                    onFocus: !0
                });
            }, 400);
        });
    },
    reportPracurnal: function(e) {
        var t = "Failed";
        e && (t = "Success"), wx.reportAnalytics("submit_pracurnal", {
            uid: i.globalData.userInfo.id,
            lesson_id: this.data.detail.lesson.id,
            lesson_name: this.data.detail.lesson.title,
            submit_result: t
        });
    },
    onInputRemark: function(e) {},
    onInputRemarkConfirm: function() {
        this.setData({
            keyboardHeight: 0,
            scrollTo: "",
            onFocus: !1
        });
    },
    keyboardheightchange: function(e) {
        console.log(e);
    },
    postScore: function(e) {
        var t = this, a = e.currentTarget.dataset, s = this.data.scoreList;
        s[a.index].selected = a.score, s[a.index].items = JSON.parse(JSON.stringify(B)), 
        s[a.index].items.forEach(function(e, t, s) {
            e.score == a.score && (e.icon = "/images/icons/score_selected_" + a.score + ".png");
        });
        var o = {
            scoreList: s
        }, n = Number(750 / i.globalData.WindowWidth);
        console.log(n), 1 == a.index ? (o.maxScoreHeigth = Number(i.globalData.ScreenHeight * n * .7), 
        console.log(o), setTimeout(function() {
            t.setData({
                scoreScrollTop: 9999
            });
        }, 400)) : (o.maxScoreHeigth = 844, console.log(Number(i.globalData.ScreenHeight)), 
        o.maxScoreHeigth > Number(i.globalData.ScreenHeight * n * .7) && (o.maxScoreHeigth = Number(i.globalData.ScreenHeight * n * .7), 
        o.scoreScrollTop = 9999)), this.setData(o), console.log(o);
    },
    inputRemark: function(e) {
        console.log(e), this.setData({
            scoreRemark: e.detail.value
        });
    },
    submitScore: function(a) {
        var s = this;
        return t(e.default.mark(function t() {
            var o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (a.currentTarget.dataset.ok && S()) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    if (!(s.data.scoreRemark.length > s.data.maxScoreRemarkLength)) {
                        e.next = 5;
                        break;
                    }
                    return wx.showToast({
                        title: "记录内容限制".concat(s.data.maxScoreRemarkLength, "字以内"),
                        icon: "none"
                    }), e.abrupt("return");

                  case 5:
                    return s.setData({
                        studyScoreLoading: !0
                    }), e.prev = 6, e.next = 9, _({
                        likely_score: s.data.scoreList[0].selected,
                        feel_score: s.data.scoreList[1].selected,
                        lesson_id: s.data.detail.lesson.id,
                        remark: s.data.scoreRemark
                    });

                  case 9:
                    (o = e.sent).meta && 0 == o.meta.code ? (s.closeStudyScore(), s.reportPracurnal(!0), 
                    wx.reportAnalytics("prac_jurnal_answer", {
                        uid: i.globalData,
                        lesson_id: s.data.detail.lesson.id,
                        lesson_name: s.data.detail.lesson.title,
                        quest1: s.data.scoreList[0].title,
                        quest1answer: s.data.scoreList[0].selected,
                        quest2: s.data.scoreList[1].title,
                        quest2answer: s.data.scoreList[1].selected,
                        open_question: s.data.scoreRemark
                    }), wx.showToast({
                        title: "记录成功"
                    }), s.goEndingPage()) : wx.showToast({
                        title: o.meta.message,
                        icon: "none"
                    }), e.next = 16;
                    break;

                  case 13:
                    e.prev = 13, e.t0 = e.catch(6), console.log(e.t0);

                  case 16:
                    s.setData({
                        showStudyScore: !1,
                        studyScoreLoading: !1
                    });

                  case 17:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 6, 13 ] ]);
        }))();
    },
    goEndingPage: function() {
        var e = this.data, t = e.detail, a = e.chooseAudioIndex, s = e.camp, o = t.lesson, i = "/pages/ending/ending?course_id=" + t.course.id;
        i += "&lesson_id=".concat(o.id), i += "&choose_audio_index=".concat(a), i += "&title=".concat(o.title), 
        i += "&shareinfo=".concat(o.share_info), i += "&cover=".concat((o.img, o.img)), 
        this.isFromCamp() && (i += "&camp_id=".concat(s.id), i += "&sub_part_id=".concat(s.subPartId)), 
        wx.redirectTo({
            url: i
        });
    },
    onHide: function() {
        console.log("on hide");
    },
    saveSharePost: function() {
        var a = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, A.save({
                        destWidth: 1500,
                        destHeight: 2668
                    });

                  case 3:
                    e.sent, a.closeShareButton(), wx.showToast({
                        title: "分享图已保存至系统相册，快去分享给朋友吧",
                        icon: "none"
                    }), e.next = 11;
                    break;

                  case 8:
                    e.prev = 8, e.t0 = e.catch(0), console.log(e.t0);

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 8 ] ]);
        }))();
    },
    openShareButton: function() {
        var a = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    try {
                        a.data.postGenerated || (a.setData({
                            shareLoading: !0
                        }), i.getShareQrcode(function(e, t) {
                            if (!t) return console.log("分享二维码下载失败"), void a.setData({
                                shareLoading: !1
                            });
                            a.testPoster(e);
                        }));
                    } catch (e) {
                        console.log("捕获画图错误", e);
                    }
                    a.setData({
                        postGenerated: !0
                    }), wx.reportAnalytics("share", {
                        uid: i.globalData.userInfo.id,
                        button_name: "Share",
                        lesson_id: a.data.detail.lesson.id,
                        lesson_name: a.data.detail.lesson.title,
                        course_id: a.data.detail.course.id,
                        course_name: a.data.detail.course.title
                    }), a.setData({
                        showShareButton: !0
                    });

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    closeShareButton: function() {
        this.setData({
            showShareButton: !1
        });
    },
    getEndingContent: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, v("ending");

                  case 3:
                    0 == (s = e.sent).meta.code && (a.setData({
                        endingContent: s.data.content
                    }), a.testPoster()), e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(0), console.log(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 7 ] ]);
        }))();
    },
    onReady: function() {
        A.create({
            query: ".poster-canvas",
            rootWidth: 1500
        });
    },
    testPoster: function(a) {
        var o = this;
        return t(e.default.mark(function t() {
            var n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, o.getEndingBanner();

                  case 3:
                    return e.next = 5, A.draw({
                        series: w([ {
                            type: s.Image,
                            url: o.data.detail.lesson.img ? o.data.detail.lesson.img : o.data.detail.course.img,
                            x: 0,
                            y: 0,
                            width: 500,
                            height: 667,
                            mode: "aspectFill",
                            radius: 0,
                            zIndex: 0
                        }, {
                            type: s.Image,
                            url: "https://cdn.heartlylab.com/heartlylab/imgs/share_logo.png",
                            width: 158,
                            height: 45.38,
                            x: 20,
                            y: 30
                        }, {
                            type: s.Rect,
                            x: 302.52,
                            y: 30,
                            width: 52.48,
                            height: 64,
                            lineStyle: {
                                color: "#fff",
                                width: 2
                            },
                            zIndex: 0,
                            radius: 10
                        }, {
                            type: s.Text,
                            text: T.year,
                            color: "rgba(250,250,246,0.8)",
                            fontSize: 14,
                            width: 34.56,
                            align: "center",
                            x: 311.48,
                            y: 35.12,
                            lineHeight: 20,
                            ellipsis: 1
                        }, {
                            type: s.Text,
                            text: "/",
                            color: "rgba(250,250,246,0.8)",
                            fontSize: 14,
                            width: 7.68,
                            align: "center",
                            x: 324.28,
                            y: 58.16,
                            lineHeight: 8,
                            ellipsis: 1
                        }, {
                            type: s.Text,
                            text: T.month + "." + T.day,
                            color: "rgba(250,250,246,0.8)",
                            fontSize: 14,
                            width: 38.4,
                            align: "center",
                            x: 308.92,
                            y: 68.4,
                            lineHeight: 20,
                            ellipsis: 1
                        }, {
                            type: s.Image,
                            url: "https://heartlylab.holdno.com/heartlylab/icon/share_page_icon.png",
                            x: 143,
                            y: 220,
                            width: 88,
                            height: 88
                        }, {
                            type: s.Text,
                            text: "#每日冥想: " + o.data.detail.lesson.title,
                            color: "rgba(250,250,246,0.8)",
                            fontSize: 12,
                            width: 335,
                            x: 20,
                            y: 443,
                            lineHeight: 18,
                            ellipsis: 1
                        }, {
                            type: s.Text,
                            text: o.data.detail.lesson.share_info,
                            color: "#fff",
                            fontSize: 16,
                            width: 335,
                            x: 20,
                            y: 465,
                            lineHeight: 24,
                            ellipsis: 3
                        }, {
                            type: s.Rect,
                            x: 0,
                            y: 547,
                            width: 375,
                            height: 120,
                            bgColor: "#fff",
                            lineStyle: {
                                color: "#fff",
                                width: 0
                            },
                            zIndex: 0
                        }, {
                            type: s.Image,
                            url: i.globalData.userInfo.avatar,
                            width: 51,
                            height: 51,
                            x: 20,
                            y: 582,
                            radius: 25
                        }, {
                            type: s.Text,
                            text: i.globalData.userInfo.name,
                            color: "#000",
                            fontSize: 16,
                            x: 79,
                            y: 582,
                            lineHeight: 24
                        }, {
                            type: s.Text,
                            text: "累计冥想 " + o.data.studyTotalDays + " 天",
                            color: "#878792",
                            fontSize: 14,
                            x: 79,
                            y: 610,
                            lineHeight: 20
                        }, {
                            type: s.Image,
                            url: a,
                            width: 76,
                            height: 76,
                            x: 275,
                            y: 569
                        } ], 4)
                    });

                  case 5:
                    return e.next = 7, A.getTmpPath({
                        destWidth: 1500,
                        destHeight: 2668
                    });

                  case 7:
                    n = e.sent, o.setData({
                        shareTmpImage: n
                    }), e.next = 14;
                    break;

                  case 11:
                    e.prev = 11, e.t0 = e.catch(0), console.log(e.t0);

                  case 14:
                    o.setData({
                        shareLoading: !1
                    });

                  case 15:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 11 ] ]);
        }))();
    },
    getEndingBanner: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, I();

                  case 3:
                    0 == (s = e.sent).meta.code && a.setData({
                        studyTotalDays: s.data.total_days
                    }), e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(0), console.log(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 7 ] ]);
        }))();
    },
    updateSetting: function(e, t, a) {
        try {
            n(e, t, a);
        } catch (e) {
            console.log(e);
        }
    },
    onShow: function() {
        null != this.data.audioInstance && (console.log("audioInstance.paused", this.data.audioInstance.paused), 
        this.setData({
            audioStatusPlay: 0 == this.data.audioInstance.paused
        })), "function" == typeof this.getTabBar && this.getTabBar() && this.getTabBar().setData({
            selected: 0
        });
    },
    stopScroll: function() {},
    onGuideVolumeChange: function(e) {
        var t = {
            guideVolume: e.detail
        };
        this.data.audioInstance.volume = e.detail / 100, 0 == e.detail && "mute" != this.data.guideIcon ? t.guideIcon = "mute" : 0 != e.detail && "mute" == this.data.guideIcon && (t.guideIcon = "sound"), 
        i.userSetting.guideVolume = e.detail, this.setData(t), this.updateSetting(0, this.data.bgVolume, e.detail);
    },
    playOrPauseBg: function() {
        if (i.getBgAudio().paused) return this.setData({
            hideBgPlayIcon: !0
        }), i.hideBgPlayIcon = !0, void i.getBgAudio().play();
        this.setData({
            hideBgPlayIcon: !1
        }), i.hideBgPlayIcon = !1, i.getBgAudio().pause();
    },
    onLoad: function(e) {
        var t = this;
        e.camp_id && e.sub_part_id && this.setData({
            camp: {
                id: e.camp_id,
                subPartId: e.sub_part_id
            }
        }), e.scene || e.auto_play ? this.setData({
            chooseAudioIndex: e.choose_audio || 0
        }) : this.setData({
            showAudioConfig: !0
        }), i.jwtReady(function() {
            var a = i.getUserSetting();
            t.setData({
                username: i.globalData.userInfo.name,
                setting: a,
                fromtype: e.pagetype
            }), t.getLessonDetail(e.id, e.scene || e.auto_play), wx.reportAnalytics("user_coming", {
                is_first_time: i.globalData.userInfo.isFirst,
                time: f(new Date()),
                uid: i.globalData.userInfo.id,
                type: "Lesson播放页"
            });
        });
    },
    follow: function() {
        var a = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (a.data.detail.lesson) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return e.prev = 2, a.setData({
                        followed: 1 == a.data.followed ? 2 : 1
                    }), 1 == a.data.followed && wx.reportAnalytics("follow_lesson", {
                        uid: i.globalData.userInfo.id,
                        button_name: "Favorite",
                        lesson_id: a.data.detail.lesson.id,
                        lesson_name: a.data.detail.lesson.title,
                        course_id: a.data.detail.course.id,
                        course_name: a.data.detail.course.title
                    }), e.next = 7, h(a.data.detail.lesson.id);

                  case 7:
                    0 != e.sent.meta.code && (wx.showToast({
                        title: "收藏失败，请稍后再试",
                        icon: "none"
                    }), a.setData({
                        followed: 1 == a.data.followed ? 2 : 1
                    })), e.next = 14;
                    break;

                  case 11:
                    e.prev = 11, e.t0 = e.catch(2), console.log(e.t0);

                  case 14:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 2, 11 ] ]);
        }))();
    },
    getLessonDetail: function(a, s) {
        var o = this;
        return t(e.default.mark(function t() {
            var n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, o.setData({
                        loading: !0
                    }), e.next = 4, l(a);

                  case 4:
                    0 == (n = e.sent).meta.code ? (o.setData({
                        detail: n.data,
                        followed: n.data.is_follow
                    }), s && o.goPlay()) : wx.showToast({
                        title: n.meta.message,
                        icon: "none"
                    }), wx.reportAnalytics("view_lesson", {
                        uid: i.globalData.userInfo.id,
                        lesson_id: o.data.detail.lesson.id,
                        lesson_name: o.data.detail.lesson.title,
                        course_id: o.data.detail.course.id,
                        course_name: o.data.detail.course.title,
                        page_column: o.data.fromtype,
                        if_trial: o.data.detail.lesson.use_level,
                        purchase_type: o.data.detail.lesson.use_level,
                        time: f(new Date())
                    }), e.next = 12;
                    break;

                  case 9:
                    e.prev = 9, e.t0 = e.catch(0), console.log(e.t0);

                  case 12:
                    o.setData({
                        loading: !1
                    });

                  case 13:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 9 ] ]);
        }))();
    },
    showSetting: function() {
        wx.reportAnalytics("user_click", {
            uid: i.globalData.userInfo.id,
            button_name: "BackSetting",
            type: "LessonPlay"
        });
        var e = this.selectComponent("#bg-settings-sheet");
        e && e.show();
    },
    onBgSettingsChange: function() {
        var e = this;
        this.setData({
            setting: i.getUserSetting()
        }), this.data.audioStatusPlay && setTimeout(function() {
            i.getBgAudio().play(), e.data.audioInstance.play(), k && k.play();
        }, 1e3);
    },
    selectAudio: function(e) {
        this.setData({
            chooseAudioIndex: e.currentTarget.dataset.index
        });
    },
    canPlay: function(e) {
        return !(1 != i.globalData.userInfo.isNew && 0 != this.data.detail.lesson.use_level || !e || !(Math.floor(this.data.currentDuration / 60 % 60) < e)) || (1 == i.globalData.userInfo.isNew && 0 == i.globalData.userInfo.level && this.data.detail.lesson.use_level > 0 ? (this.setData({
            showGift: !0
        }), !1) : "" == i.globalData.userInfo.avatar ? (this.setData({
            needLogin: !0
        }), !1) : !(0 == i.globalData.userInfo.level && this.data.detail.lesson.use_level > 0) || (this.setData({
            needToBuy: !0
        }), !1));
    },
    closeBuyBox: function() {
        this.setData({
            needToBuy: !1
        });
    },
    goBuy: function() {
        var e = this;
        i.store.on(i.events.levelUp, function(t) {
            e.goPlay();
        }, "lessonLevelUp"), wx.navigateTo({
            url: "/pages/goods/goods"
        }), this.closeBuyBox();
    },
    goPlay: function() {
        var e = this;
        if (this.canPlay(this.data.detail.lesson.experience_time)) {
            (k = new b()).reset();
            var t = setInterval(function() {
                console.log("interval"), "" != i.globalData.userInfo.avatar || e.data.audioInstance.paused || e.canPlay(e.data.detail.lesson.experience_time) ? null == e.data.audioInstance || e.data.audioInstance.paused || e.reportStudyRecord(!1) : (e.data.audioInstance.pause(), 
                k && k.pause());
            }, 5e3);
            this.data.detail.audios.length - 1 < this.data.chooseAudioIndex && (this.data.chooseAudioIndex = 0);
            var a = this.data.detail.audios[this.data.chooseAudioIndex];
            wx.reportAnalytics("user_click", {
                uid: i.globalData.userInfo.id,
                button_name: "播放",
                type: "lesson选择播放时长"
            }), wx.reportAnalytics("audio_time_event", {
                uid: i.globalData.userInfo.id,
                audio_time: a.title.replace(/[^\x00-\xff]/g, ""),
                if_change_time: 0 == this.data.chooseAudioIndex ? 0 : 1
            }), this.setData({
                showAudioConfig: !1,
                audioStatusPlay: !0,
                loading: !0,
                reportTimer: t
            }), null == this.data.audioInstance && (this.data.audioInstance = wx.getBackgroundAudioManager(), 
            wx.onAudioInterruptionEnd(function(t) {
                e.data.audioStatusPlay && e.data.audioInstance && "function" == typeof e.data.audioInstance.play && (e.data.audioInstance.play(), 
                k && k.play());
            }));
            var s = this.data.setting, o = s.bgVolume;
            s.bgVolume = 8, this.setData({
                setting: s,
                userBgVolume: o
            }), i.setBgVolume(s.bgVolume, !1), this.data.audioInstance.src == a.audio_src ? (this.data.audioInstance.play(), 
            k && k.play()) : this.data.audioInstance.src = a.audio_src, this.data.audioInstance.title = this.data.detail.lesson.title, 
            this.data.audioInstance.coverImgUrl = this.data.detail.lesson.img ? this.data.detail.lesson.img : this.data.detail.course.img, 
            this.data.audioInstance.loop = !1, i.getBgAudio().play(), this.data.audioInstance.onPause(function() {}), 
            this.reportStudyRecord(!1);
            var n = null;
            this.data.audioInstance.onWaiting(function() {
                console.log("start waiting"), null != n && clearTimeout(n), e.setData({
                    loading: !0
                }), n = setTimeout(function() {
                    e.setData({
                        loading: !1
                    });
                }, 3e3);
            }), this.data.audioInstance.onCanplay(function() {
                null != n && clearTimeout(n), console.log(e.data.audioInstance.paused);
            }), this.data.audioInstance.onStop(function() {
                e.data.audioInstance = null, i.getBgAudio().pause(), i.hideBgPlayIcon = !1, e.setData({
                    audioStatusPlay: !1
                });
            }), this.data.audioInstance.onPlay(function() {
                0 == e.data.totalDuration && setTimeout(function() {
                    var t = e.data.audioInstance.duration;
                    0 != t && e.setData({
                        totalDuration: t,
                        showDuration: L(t),
                        showAudioControl: "opacity: 1;"
                    });
                }, 500);
            }), this.data.audioInstance.onEnded(function() {
                e.isFromCamp() ? (e.setData({
                    showCampFinish: !0,
                    audioStatusPlay: !1
                }), e.reportCamp()) : e.setData({
                    audioStatusPlay: !1,
                    showStudyScore: !0
                }), e.reportStudyRecord(!0), e.gioReportTimer();
            }), this.onTimeUpdate();
        } else this.setData({
            showAudioControl: "opacity: 1",
            showContral: !0
        });
    },
    onTimeUpdate: function() {
        var e = this, t = "";
        this.data.audioInstance.onTimeUpdate(function() {
            var a, s;
            e.data.loading && e.setData({
                loading: !1
            }), e.data.audioInstance && (a = e.data.audioInstance.currentTime, (s = L(a)) != t && (t = s, 
            e.data.totalDuration > 0 && null != e.data.audioInstance && e.setData({
                currentDuration: a,
                showCurrentDuration: s
            }), "" != i.globalData.userInfo.avatar || e.canPlay(e.data.detail.lesson.experience_time) || e.playOrPause()));
        });
    },
    seek: function(e) {
        this.data.audioInstance && null != this.data.audioInstance && (this.data.audioInstance.paused && this.setData({
            currentDuration: this.data.audioInstance.currentTime,
            showCurrentDuration: L(this.data.audioInstance.currentTime)
        }), this.data.audioInstance.seek(e.detail.value));
    },
    playOrPause: function() {
        var e = "";
        this.data.audioStatusPlay ? (null != this.data.audioInstance && (this.data.audioInstance.pause(), 
        k && k.pause()), i.getBgAudio().pause(), i.hideBgPlayIcon = !1, e = "AudioPause", 
        this.setData({
            audioStatusPlay: !1
        })) : (i.getBgAudio().play(), i.hideBgPlayIcon = !0, console.log("audio instance", this.data.audioInstance), 
        null == this.data.audioInstance ? this.goPlay() : this.canPlay(this.data.detail.lesson.experience_time) && (this.data.audioInstance.play(), 
        k && k.play(), this.setData({
            audioStatusPlay: !0
        })), e = "AudioStart"), wx.reportAnalytics("user_click", {
            uid: 0,
            button_name: e,
            type: "LessonPlay"
        });
    },
    onUnload: function() {
        i.store.off(i.events.levelUp, "lessonLevelUp"), i.store.off(i.events.register, "levelRegister"), 
        this.gioReportTimer(), k = null, null != this.data.audioInstance && (this.data.audioInstance.pause(), 
        this.data.audioInstance = null, null != this.data.reportTimer && clearInterval(this.data.reportTimer), 
        i.setBgVolume(this.data.userBgVolume));
    },
    closeStudyScore: function() {
        this.reportPracurnal(!1), this.goEndingPage(), this.setData({
            showStudyScore: !1,
            studyScoreLoading: !1
        });
    },
    reportStudyRecord: function(e) {
        var t = 2;
        e && (t = 1);
        var a = 1;
        if (this.data.audioInstance.currentTime > 1 && (a = this.data.audioInstance.currentTime), 
        d(this.data.detail.lesson.id, t, parseInt(a), 5).then(function(e) {
            console.log("report", e);
        }), this.data.audioInstance.currentTime / this.data.audioInstance.duration * 100 > 85 && !this.data.finishReported) {
            this.setData({
                finishReported: !0
            }), wx.reportAnalytics("play_finished", {
                lesson_name: this.data.detail.lesson.title,
                lesson_id: this.data.detail.lesson.id,
                course_name: this.data.detail.course.title,
                course_id: this.data.detail.course.id,
                column_id: this.data.detail.course.column_id
            });
            var s = i.globalData.userInfo, o = s.id, n = s.name, r = this.data.detail.lesson;
            P("track", "MediLessonComplete", {
                userID: o,
                UserName: n,
                LessonID: r.id,
                LessonName: r.title
            }), u(r.id);
        }
    },
    onShareAppMessage: function() {
        wx.reportAnalytics("share_common", {
            button_name: "Share",
            channel: "Friends",
            page_name: "LessonPlay",
            uid: i.globalData.userInfo.id
        });
        var e = this.isFromCamp() ? "/pages/index/index" : "/pages/lesson/lesson?id=" + this.data.detail.lesson.id + "&choose_audio=" + this.data.chooseAudioIndex + "&scene=inviter:" + i.globalData.userInfo.id;
        return {
            title: this.data.detail.lesson.title,
            path: e,
            imageUrl: this.data.detail.lesson.img || i.shareImg
        };
    },
    isFromCamp: function() {
        var e = this.data.camp, t = e.id, a = e.subPartId;
        return t && a;
    },
    reportCamp: function() {
        var e = this.data.camp, t = e.id, s = e.subPartId;
        this.isFromCamp() && (D(t, s, a.STEP_LESSON), wx.setStorageSync(a.FINISH_CHECK_LOCAL_LESSON, s));
    },
    gioReportTimer: function() {
        if (!this.data.isReportTimer && k) {
            this.setData({
                isReportTimer: !0
            });
            var e = i.globalData.userInfo, t = e.id, a = e.name, s = this.data.detail.lesson, o = k.updateAndGetTiming();
            P("track", "MediLessonPlayTime", {
                userID: t,
                UserName: a,
                LessonID: s.id,
                LessonName: s.title,
                Duration: o
            });
        }
    },
    backToCamp: function(e) {
        if ("writing" === e.target.dataset.type) {
            var t = this.data.camp, a = t.id, s = t.subPartId, i = this.data.detail.lesson, n = "/pages/camp/free_writing/writing_v2?id=".concat(s, "&camp_id=").concat(a, "&lesson_id=").concat(i.id, "&title=进入书写");
            wx.redirectTo({
                url: n
            });
        } else (0, o.navigateBack)({
            url: "/pages/camp/course_catalog/course_catalog"
        });
    },
    closeCamp: function() {
        this.setData({
            showCampFinish: !1
        });
    }
});