Page({
    data: {
        isWidescreen: !1,
        bgImage: "https://cdn.heartlylab.com/heartlylab/imgs/xiaozhushou1.png",
        qrcode: "https://cdn.heartlylab.com/heartlylab/imgs/xiaozhushou2.png"
    },
    onLoad: function(e) {
        var a = this;
        wx.getSystemInfo({
            success: function(e) {
                var t = e.windowHeight, i = e.windowWidth;
                a.setData({
                    isWidescreen: i / t > .7
                });
            }
        });
    },
    previewImage: function() {
        wx.previewImage({
            urls: [ this.data.qrcode ]
        });
    }
});