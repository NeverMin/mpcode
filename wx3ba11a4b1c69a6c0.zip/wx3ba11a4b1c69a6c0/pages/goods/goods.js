var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = getApp(), r = require("../../api/goods.js"), n = r.getGoodsList, o = r.createOrder, i = r.getPayResult, s = require("../../api/gift_code.js").exchangeGiftCode, c = require("../../utils/util"), u = c.doubleClick, d = c.formatTime, l = require("../../contants/common").PAGE_SUBSCRIBE, p = u();

function g(e) {
    var t = new Date(e);
    return d(t, "yyyy/MM/dd");
}

function f(e, t) {
    return e.toFixed(t);
}

Page({
    data: {
        pushPopupKey: l,
        goods: [],
        choosed: 0,
        loading: !1,
        vipExpireDate: "",
        showExchangeBox: !1,
        exchangeError: "",
        giftLoading: !1,
        giftCode: "",
        valentineDay: !1,
        username: "",
        avatar: "",
        isVip: !0
    },
    onLoad: function() {
        var r = this;
        return t(e.default.mark(function t() {
            var o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a.jwtReady(function() {
                        var e = a.globalData.userInfo, t = e.vip_expire_date, n = e.name, o = e.avatar;
                        r.setData({
                            valentineDay: a.activityLogicMap.valentineDay,
                            vipExpireDate: t ? g(t) : "",
                            username: n,
                            avatar: o
                        }), a.loadPopupList().then(function() {
                            var e = r.selectComponent("#push-popup");
                            e && e.initPopup();
                        });
                    }), r.setData({
                        loading: !0
                    }), e.prev = 2, e.next = 5, n();

                  case 5:
                    o = e.sent, console.log(o.data), 0 == o.meta.code && r.setData({
                        goods: o.data.map(function(e) {
                            var t = e.subscription_period_in_days, a = e.price, r = e.introductory_price, n = 0 !== r, o = n ? r : a;
                            switch (t) {
                              case 30:
                                n && (e.badge = "首月特惠", e.desc = f(a, 2)), e.finalPrice = f(o, 2);
                                break;

                              case 90:
                                e.desc = f(o / 3, 2) + "/月", e.finalPrice = f(o, 2);
                                break;

                              case 365:
                                var i = f(n ? a : o / 12, n ? 2 : 1);
                                e.finalPrice = f(o, n ? 2 : 1), e.badge = n ? "首年特惠" : "最优惠", e.desc = n ? i : i + "/月";
                            }
                            return e.price_every_day = f(o / t, 2), e.isFirst = n, e;
                        })
                    }), e.next = 13;
                    break;

                  case 10:
                    e.prev = 10, e.t0 = e.catch(2), console.log(e.t0);

                  case 13:
                    r.setData({
                        loading: !1
                    });

                  case 14:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 2, 10 ] ]);
        }))();
    },
    onUnload: function() {
        var e = this.selectComponent("#push-popup");
        e && e.unMounted();
    },
    doCreateOrder: function(r) {
        var n = this;
        return t(e.default.mark(function t() {
            var r, s, c;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (p()) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    if (n.setData({
                        loading: !0
                    }), r = n.data.goods[n.data.choosed]) {
                        e.next = 8;
                        break;
                    }
                    return n.setData({
                        loading: !1
                    }), wx.showToast({
                        title: "请选择正确的套餐后再试！"
                    }), e.abrupt("return");

                  case 8:
                    return s = n, e.prev = 9, e.next = 12, o(r.id);

                  case 12:
                    0 == (c = e.sent).meta.code && wx.requestPayment({
                        nonceStr: c.data.nonceStr,
                        package: c.data.package,
                        paySign: c.data.paySign,
                        timeStamp: c.data.timestamp,
                        signType: c.data.signType,
                        success: function(e) {
                            var t = setInterval(function() {
                                i(c.data.order_code).then(function(e) {
                                    0 == e.meta.code ? 1 == e.data.status && (clearInterval(t), a.globalData.userInfo.level = e.data.level, 
                                    a.globalData.userInfo.vip_expire_date = e.data.vip_expire_date, a.store.emit(a.events.levelUp, e.data), 
                                    s.setData({
                                        vipExpireDate: g(e.data.vip_expire_date),
                                        loading: !1
                                    }), wx.showToast({
                                        title: "购买成功"
                                    }), "valentineDay" == e.data.activity && wx.redirectTo({
                                        url: "/pages/user/valentine/valentine?ordercode=" + c.data.order_code
                                    })) : wx.showToast({
                                        title: e.meta.message,
                                        icon: "none"
                                    });
                                });
                            }, 2e3);
                        },
                        fail: function(e) {
                            s.setData({
                                loading: !1
                            }), wx.showToast({
                                title: "取消支付",
                                icon: "none"
                            });
                        }
                    }), wx.reportAnalytics("user_click", {
                        uid: a.globalData.userInfo.id,
                        button_name: "会员购买",
                        type: n.properties.pagetype
                    }), e.next = 20;
                    break;

                  case 17:
                    e.prev = 17, e.t0 = e.catch(9), console.log(e.t0);

                  case 20:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 9, 17 ] ]);
        }))();
    },
    stopScroll: function() {},
    showGiftCodeExchangeBox: function() {
        this.setData({
            showExchangeBox: !0
        });
    },
    closeGiftCodeExchangeBox: function() {
        var e = this;
        this.setData({
            showExchangeBox: !1
        }), setTimeout(function() {
            e.setData({
                exchangeError: "",
                giftCode: ""
            });
        }, 1e3);
    },
    bindKeyInput: function(e) {
        this.setData({
            giftCode: e.detail.value
        });
    },
    exchangeGiftCode: function() {
        var r = this;
        return t(e.default.mark(function t() {
            var n, o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = {
                        giftLoading: !1,
                        exchangeError: ""
                    }, e.prev = 1, e.next = 4, s(r.data.giftCode);

                  case 4:
                    0 == (o = e.sent).meta.code ? (r.closeGiftCodeExchangeBox(), wx.showToast({
                        title: "领取成功"
                    }), n.giftCode = "", a.globalData.userInfo.level = o.data.level, a.globalData.userInfo.vip_expire_date = o.data.expire_date, 
                    a.store.emit(a.events.levelUp, {
                        vip_expire_date: o.data.expire_date,
                        level: o.data.level
                    }), n.vipExpireDate = g(o.data.expire_date)) : n.exchangeError = o.meta.message, 
                    e.next = 11;
                    break;

                  case 8:
                    e.prev = 8, e.t0 = e.catch(1), console.log(e.t0);

                  case 11:
                    r.setData(n);

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 8 ] ]);
        }))();
    },
    choose: function(e) {
        this.setData({
            choosed: e.currentTarget.dataset.index
        }), wx.reportAnalytics("user_click", {
            uid: a.globalData.userInfo.id,
            button_name: "PurchaseSourse",
            type: this.properties.pagetype
        });
    },
    goUserService: function() {
        wx.navigateTo({
            url: "/pages/user/agreement/index?type=vip"
        });
    },
    onShareAppMessage: function() {
        return {
            title: "开通会员畅享冥想内容",
            path: "/pages/goods/goods?scene=inviter:" + a.globalData.userInfo.id,
            imageUrl: a.shareImg
        };
    }
});