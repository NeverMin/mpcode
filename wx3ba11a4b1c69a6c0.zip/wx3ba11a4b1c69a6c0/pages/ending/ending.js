var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("wx-canvas-2d"), n = getApp(), r = require("../../api/course.js"), o = r.getSimilarLesson, s = r.getLessonStudyRecord, i = require("../../api/user.js").studyEndShare, l = require("../../utils/util.js"), c = l.doubleClick, u = l.formatTime, d = l.currentYearDateObject, h = l.zoomCanvasDrawInfoSeries, p = require("../../utils/poster_extend.js"), g = d(), f = c();

a.WxCanvas2d.use(a.SaveToAlbum), a.WxCanvas2d.use(p);

var m = new a.WxCanvas2d();

Page({
    data: {
        lessons: [],
        loading: !0,
        banner: {},
        cover: "",
        showShareButton: !1,
        title: "",
        shareInfo: "",
        showFocus: !1,
        postGenerated: !1,
        lessonID: 0,
        chooseAudioIndex: 0,
        camp: {
            id: null,
            subPartId: null
        }
    },
    stopScroll: function() {},
    openShareButton: function() {
        var a = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    try {
                        a.data.postGenerated || (a.setData({
                            loading: !0
                        }), n.getShareQrcode(function(e, t) {
                            if (!t) return console.log("分享二维码下载失败"), void a.setData({
                                loading: !1
                            });
                            a.createPoster(e);
                        }));
                    } catch (e) {
                        console.log("捕获画图错误", e);
                    }
                    a.setData({
                        postGenerated: !0,
                        showShareButton: !0
                    }), wx.reportAnalytics("user_click", {
                        uid: n.globalData.userInfo.id,
                        button_name: "Share",
                        type: "Lesson结束页"
                    });

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    closeShareButton: function() {
        this.setData({
            showShareButton: !1
        });
    },
    onReady: function() {
        m.create({
            query: ".poster-canvas",
            rootWidth: 1500
        });
    },
    createPoster: function(r) {
        var o = this;
        return t(e.default.mark(function t() {
            var s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return o.setData({
                        loading: !0
                    }), e.next = 3, m.draw({
                        series: h([ {
                            type: a.Image,
                            url: o.data.cover,
                            x: 0,
                            y: 0,
                            width: 500,
                            height: 667,
                            mode: "aspectFill",
                            radius: 0,
                            zIndex: 0
                        }, {
                            type: a.Image,
                            url: "https://cdn.heartlylab.com/heartlylab/imgs/share_logo.png",
                            width: 158,
                            height: 45.38,
                            x: 20,
                            y: 30
                        }, {
                            type: a.Rect,
                            x: 302.52,
                            y: 30,
                            width: 52.48,
                            height: 64,
                            lineStyle: {
                                color: "#fff",
                                width: 2
                            },
                            zIndex: 0,
                            radius: 10
                        }, {
                            type: a.Text,
                            text: g.year,
                            color: "rgba(250,250,246,0.8)",
                            fontSize: 14,
                            width: 34.56,
                            align: "center",
                            x: 311.48,
                            y: 35.12,
                            lineHeight: 20,
                            ellipsis: 1
                        }, {
                            type: a.Text,
                            text: "/",
                            color: "rgba(250,250,246,0.8)",
                            fontSize: 14,
                            width: 7.68,
                            align: "center",
                            x: 324.28,
                            y: 58.16,
                            lineHeight: 8,
                            ellipsis: 1
                        }, {
                            type: a.Text,
                            text: g.month + "." + g.day,
                            color: "rgba(250,250,246,0.8)",
                            fontSize: 14,
                            width: 38.4,
                            align: "center",
                            x: 308.92,
                            y: 68.4,
                            lineHeight: 20,
                            ellipsis: 1
                        }, {
                            type: a.Image,
                            url: "https://heartlylab.holdno.com/heartlylab/icon/share_page_icon.png",
                            x: 143,
                            y: 220,
                            width: 88,
                            height: 88
                        }, {
                            type: a.Text,
                            text: "#每日冥想: " + o.data.title,
                            color: "rgba(250,250,246,0.8)",
                            fontSize: 12,
                            width: 335,
                            x: 20,
                            y: 443,
                            lineHeight: 18,
                            ellipsis: 1
                        }, {
                            type: a.Text,
                            text: o.data.shareInfo,
                            color: "#fff",
                            fontSize: 16,
                            width: 335,
                            x: 20,
                            y: 465,
                            lineHeight: 24,
                            ellipsis: 3
                        }, {
                            type: a.Rect,
                            x: 0,
                            y: 547,
                            width: 375,
                            height: 120,
                            bgColor: "#fff",
                            lineStyle: {
                                color: "#fff",
                                width: 0
                            },
                            zIndex: 0
                        }, {
                            type: a.Image,
                            url: n.globalData.userInfo.avatar,
                            width: 51,
                            height: 51,
                            x: 20,
                            y: 582,
                            radius: 25
                        }, {
                            type: a.Text,
                            text: n.globalData.userInfo.name,
                            color: "#000",
                            fontSize: 16,
                            x: 79,
                            y: 582,
                            lineHeight: 24
                        }, {
                            type: a.Text,
                            text: "累计冥想 " + o.data.banner.total_days + " 天",
                            color: "#878792",
                            fontSize: 14,
                            x: 79,
                            y: 610,
                            lineHeight: 20
                        }, {
                            type: a.Image,
                            url: r,
                            width: 76,
                            height: 76,
                            x: 275,
                            y: 569
                        } ], 4)
                    });

                  case 3:
                    return e.prev = 3, e.next = 6, m.getTmpPath({
                        destWidth: 1500,
                        destHeight: 2668
                    });

                  case 6:
                    s = e.sent, o.setData({
                        shareTmpImage: s
                    }), e.next = 13;
                    break;

                  case 10:
                    e.prev = 10, e.t0 = e.catch(3), console.log(e.t0);

                  case 13:
                    o.setData({
                        loading: !1
                    });

                  case 14:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 3, 10 ] ]);
        }))();
    },
    saveSharePost: function() {
        var a = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, m.save({
                        destWidth: 1500,
                        destHeight: 2668
                    });

                  case 3:
                    e.sent, a.closeShareButton(), wx.showToast({
                        title: "分享图已保存至系统相册，快去分享给朋友吧",
                        icon: "none"
                    }), wx.reportAnalytics("share_common", {
                        button_name: "Share",
                        channel: "SavePic",
                        page_name: "LessonResult",
                        uid: n.globalData.userInfo.id
                    }), e.next = 12;
                    break;

                  case 9:
                    e.prev = 9, e.t0 = e.catch(0), console.log(e.t0);

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 9 ] ]);
        }))();
    },
    onUnload: function() {
        n.store.off(n.events.levelUp, "endingLevelUp");
    },
    onLoad: function(e) {
        var t = this;
        e.camp_id && e.sub_part_id && this.setData({
            camp: {
                id: e.camp_id,
                subPartId: e.sub_part_id
            }
        }), n.store.on(n.events.levelUp, function(e) {
            t.setData({
                isVip: n.globalData.userInfo.level
            });
        }, "endingLevelUp"), this.setData({
            cover: e.cover,
            title: e.title,
            shareInfo: e.shareinfo,
            offset: n.globalData.ScreenHeight < 750 ? 200 : 0,
            rpx: n.WindowWidth / 750,
            lessonID: e.lesson_id,
            chooseAudioIndex: e.choose_audio_index
        }), n.jwtReady(function() {
            t.setData({
                isVip: n.globalData.userInfo.level
            }), t.getStudyRecord(), t.loadSimilarLesson(e.course_id, e.lesson_id), wx.reportAnalytics("user_coming", {
                is_first_time: n.globalData.userInfo.isFirst,
                time: u(new Date()),
                uid: n.globalData.userInfo.id,
                type: "Lesson结束页"
            });
        });
    },
    loadSimilarLesson: function(a, r) {
        var s = this;
        return t(e.default.mark(function t() {
            var i, l;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return i = {
                        loading: !1
                    }, e.prev = 1, e.next = 4, s.getEndingBanner();

                  case 4:
                    return e.next = 6, o(a, r);

                  case 6:
                    0 == (l = e.sent).meta.code && (i.lessons = l.data, l.data && 0 != l.data.length || wx.reportAnalytics("recommend", {
                        uid: n.globalData.userInfo.id,
                        lesson_id: 0,
                        lesson_name: "",
                        course_id: 0,
                        course_name: "",
                        if_recommend: 0,
                        time: u(new Date())
                    })), e.next = 13;
                    break;

                  case 10:
                    e.prev = 10, e.t0 = e.catch(1), console.log(e.t0);

                  case 13:
                    s.setData(i);

                  case 14:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 10 ] ]);
        }))();
    },
    getEndingBanner: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, i();

                  case 3:
                    0 == (n = e.sent).meta.code && (n.data.duration = parseInt(n.data.duration / 60), 
                    a.setData({
                        banner: n.data
                    })), e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(0), console.log(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 7 ] ]);
        }))();
    },
    goLesson: function(e) {
        if (f()) {
            if (!e.currentTarget.dataset.ok) return wx.reportAnalytics("user_click", {
                uid: n.globalData.userInfo.id,
                button_name: "会员购买",
                type: "结束页-推荐"
            }), void wx.navigateTo({
                url: "/pages/goods/goods"
            });
            wx.reportAnalytics("recommend", {
                uid: n.globalData.userInfo.id,
                lesson_id: e.currentTarget.dataset.id,
                lesson_name: e.currentTarget.dataset.lessontitle,
                course_id: e.currentTarget.dataset.courseid,
                course_name: e.currentTarget.dataset.coursetitle,
                purchase_type: "免费" == e.currentTarget.dataset.coursetag ? 0 : 1,
                if_recommend: 1,
                time: u(new Date())
            }), wx.redirectTo({
                url: "/pages/lesson/lesson?id=" + e.currentTarget.dataset.id + "&pagetype=recommend"
            });
        }
    },
    onShareAppMessage: function() {
        wx.reportAnalytics("share_common", {
            button_name: "Share",
            channel: "Friends",
            page_name: "LessonResult",
            uid: n.globalData.userInfo.id
        });
        var e = this.isFromCamp() ? "/pages/index/index" : "/pages/lesson/lesson?id=" + this.data.lessonID + "&choose_audio=" + this.data.chooseAudioIndex + "&scene=inviter:" + n.globalData.userInfo.id;
        return {
            title: this.data.title,
            path: e,
            imageUrl: this.data.cover || n.shareImg
        };
    },
    getStudyRecord: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, s(1, 1);

                  case 3:
                    0 == (n = e.sent).meta.code ? n.data.total < 1 && a.showServiceAccountBox() : wx.showToast({
                        title: n.meta.message,
                        icon: "none"
                    }), e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(0), console.log(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 7 ] ]);
        }))();
    },
    goFocus: function() {
        wx.navigateTo({
            url: "/pages/webview/webview?url=" + n.serviceAccountQrcodeAddress
        });
    },
    showServiceAccountBox: function() {
        this.setData({
            showFocus: !0
        });
    },
    closeFocus: function() {
        this.setData({
            showFocus: !1
        });
    },
    isFromCamp: function() {
        var e = this.data.camp, t = e.id, a = e.subPartId;
        return t && a;
    }
});