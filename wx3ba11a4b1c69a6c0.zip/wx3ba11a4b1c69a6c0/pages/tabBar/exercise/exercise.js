var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/regenerator")), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = getApp(), n = require("../../../utils/util"), r = n.doubleClick, o = n.formatTime, s = require("../../../api/column.js").getColumnList, i = require("../../../api/course.js").getColumnCourseList, u = require("../../../api/course").getSearchPopularList, c = require("../../../contants/common").PAGE_EXERCRISE, l = require("../../../utils/gio-minp/index").default, d = r();

Page({
    data: {
        pageTitle: "冥想",
        pushPopupKey: c,
        columns: [],
        popularTitle: "",
        page: 1,
        pagesize: 8,
        loading: !0,
        columnID: 0,
        list: [],
        total: null,
        noMore: !1,
        nextTick: !1
    },
    onLoad: function(e) {
        var t = this;
        this.data.nextTick = !0, a.jwtReady(function() {
            t.loadColumnList(), t.getSearchPopularList(), a.exerciseColumnID == t.data.columnID && 0 == a.exerciseColumnID && t.getList(), 
            wx.reportAnalytics("user_coming", {
                is_first_time: a.globalData.userInfo.isFirst,
                time: o(new Date()),
                uid: a.globalData.userInfo.id,
                type: "Practice"
            });
        });
    },
    loadColumnList: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a.setData({
                        loading: !0
                    }), e.prev = 1, e.next = 4, s(1, 1, 100);

                  case 4:
                    0 == (n = e.sent).meta.code ? a.setData({
                        columns: n.data
                    }) : wx.showToast({
                        title: n.meta.message,
                        icon: "none"
                    }), e.next = 11;
                    break;

                  case 8:
                    e.prev = 8, e.t0 = e.catch(1), console.log(e.t0);

                  case 11:
                    a.setData({
                        loading: !1
                    });

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 8 ] ]);
        }))();
    },
    onShow: function(e) {
        var t = this;
        a.exerciseColumnID != this.data.columnID && this.changeColumn({
            currentTarget: {
                dataset: {
                    columnid: a.exerciseColumnID
                }
            }
        }), "function" == typeof this.getTabBar && this.getTabBar() && (this.getTabBar().setData({
            selected: 1
        }), this.getTabBar().reloadTabBar()), a.jwtReady(function() {
            a.loadPopupList().then(function() {
                var e = t.selectComponent("#push-popup");
                e && e.initPopup();
            });
        });
    },
    onHide: function() {
        var e = this.selectComponent("#push-popup");
        e && e.unMounted();
    },
    getSearchPopularList: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var n, r, o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, u();

                  case 3:
                    n = e.sent, r = n.meta, o = n.data, 0 === r.code ? a.setData({
                        popularTitle: o[0] ? o[0].title : ""
                    }) : wx.showToast({
                        title: r.message,
                        icon: "none"
                    }), e.next = 12;
                    break;

                  case 9:
                    e.prev = 9, e.t0 = e.catch(0), console.log(e.t0);

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 9 ] ]);
        }))();
    },
    changeColumn: function(n) {
        var r = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a.exerciseColumnID = n.currentTarget.dataset.columnid, r.setData({
                        list: [],
                        page: 1,
                        pagesize: 8,
                        noMore: !1,
                        columnID: n.currentTarget.dataset.columnid
                    }), r.data.nextTick && (r.data.nextTick = !1, setTimeout(function() {
                        r.setData({
                            columnID: r.data.columnID
                        });
                    }, 500)), e.next = 5, r.getList();

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onReachBottom: function() {
        this.data.noMore || this.getList();
    },
    getList: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var n, r, o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a.setData({
                        loading: !0
                    }), e.prev = 1, n = {}, e.next = 5, i(a.data.columnID, a.data.page, a.data.pagesize);

                  case 5:
                    if (0 != (r = e.sent).meta.code) {
                        e.next = 33;
                        break;
                    }
                    if (n.total = r.data.total, 0 != r.data.total) {
                        e.next = 12;
                        break;
                    }
                    n.noMore = !0, e.next = 30;
                    break;

                  case 12:
                    if (!r.data || !r.data.list) {
                        e.next = 28;
                        break;
                    }
                    o = 0;

                  case 14:
                    if (!(o < r.data.list.length)) {
                        e.next = 28;
                        break;
                    }
                    e.t0 = r.data.list[o].tag, e.next = "免费" === e.t0 ? 18 : "上新" === e.t0 ? 20 : "精选" === e.t0 ? 22 : 24;
                    break;

                  case 18:
                    return r.data.list[o].tag_img = "free_tag", e.abrupt("break", 25);

                  case 20:
                    return r.data.list[o].tag_img = "new_course", e.abrupt("break", 25);

                  case 22:
                    return r.data.list[o].tag_img = "good_teacher", e.abrupt("break", 25);

                  case 24:
                    return e.abrupt("break", 25);

                  case 25:
                    o++, e.next = 14;
                    break;

                  case 28:
                    1 == a.data.page ? n.list = r.data.list : n.list = a.data.list.concat(r.data.list), 
                    a.data.page * a.data.pagesize >= r.data.total ? n.noMore = !0 : n.page = a.data.page + 1;

                  case 30:
                    a.setData(n), e.next = 34;
                    break;

                  case 33:
                    wx.showToast({
                        title: r.meta.message,
                        icon: "none"
                    });

                  case 34:
                    e.next = 39;
                    break;

                  case 36:
                    e.prev = 36, e.t1 = e.catch(1), console.log(e.t1);

                  case 39:
                    a.setData({
                        loading: !1
                    });

                  case 40:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 36 ] ]);
        }))();
    },
    goCourse: function(e) {
        d() && wx.navigateTo({
            url: "/pages/course/course?course_id=" + e.currentTarget.dataset.id
        });
    },
    goColumnList: function(e) {
        var t = e.currentTarget.dataset;
        wx.navigateTo({
            url: "/pages/exercise/list?id=" + t.id + "&title=" + t.title
        });
    },
    goSearch: function() {
        wx.navigateTo({
            url: "/pages/search/search"
        }), l("track", "ClickSearch", {
            userID: a.globalData.userInfo.id,
            PageLocation: "冥想页"
        });
    },
    onShareAppMessage: function() {
        return wx.reportAnalytics("share_common", {
            button_name: "Share",
            channel: "Friends",
            page_name: "Practice",
            uid: a.globalData.userInfo.id
        }), {
            title: "与好友一起静享正念时刻",
            path: "/pages/index/index?scene=inviter:" + a.globalData.userInfo.id,
            imageUrl: a.shareImg
        };
    }
});