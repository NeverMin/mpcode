var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/regenerator")), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = getApp(), r = require("../../../api/user.js"), n = r.studyInfo, i = r.receiveVIP, s = r.delegateMessage, o = (require("../../../api/course.js").getLessonStudyRecord, 
require("../../../utils/util.js")), u = o.doubleClick, l = o.formatTime, c = require("../../../utils/request").baseUrl, d = require("../../../contants/common").PAGE_CENTER;

u();

function p(e) {
    var t = new Date(e);
    return l(t, "yyyy/MM/dd");
}

Page({
    data: {
        pushPopupKey: d,
        baseUrl: c,
        calendarVersion: 1,
        avatar: "",
        userID: null,
        username: "",
        desc: "",
        userVipStatusImg: "",
        isVip: 0,
        studyBar: [],
        goods: [],
        showGift: !1,
        showGiftConfirm: !1,
        giftLoading: !1,
        giftButtonContent: "立即领取",
        pageFresh: !1
    },
    getGift: function() {
        var r = this;
        return t(e.default.mark(function t() {
            var n, s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r.setData({
                        giftLoading: !0,
                        giftButtonContent: ""
                    }), n = {
                        giftLoading: !1,
                        giftButtonContent: "领取成功"
                    }, e.prev = 2, e.next = 5, i();

                  case 5:
                    0 == (s = e.sent).meta.code ? (a.globalData.userInfo.level = s.data.level, a.globalData.userInfo.vip_expire_date = s.data.expire_date, 
                    a.store.emit(a.events.levelUp, {
                        vip_expire_date: s.data.expire_date,
                        level: s.data.level
                    }), wx.reportAnalytics("receive_rewards", {
                        uid: a.globalData.userInfo.id,
                        receive_result: "Accept",
                        rewards_type: a.inviter ? "Refrral" : "RewardforNew",
                        page_name: "Me",
                        invite_id: a.inviter ? a.inviter : "NA"
                    }), setTimeout(function() {
                        r.setData({
                            showGiftConfirm: !0,
                            showGift: !1
                        });
                    }, 500), wx.reportAnalytics("user_click", {
                        uid: a.globalData.userInfo.id,
                        button_name: "7DaysFree",
                        type: "Me"
                    })) : (wx.reportAnalytics("receive_rewards", {
                        uid: a.globalData.userInfo.id,
                        receive_result: "Failed",
                        rewards_type: a.inviter ? "Refrral" : "RewardforNew",
                        page_name: "Me",
                        invite_id: a.inviter ? a.inviter : "NA"
                    }), wx.showToast({
                        title: s.meta.message,
                        icon: "none"
                    }), n.giftButtonContent = "立即领取"), e.next = 12;
                    break;

                  case 9:
                    e.prev = 9, e.t0 = e.catch(2), console.log(e.t0);

                  case 12:
                    setTimeout(function() {
                        r.setData(n);
                    }, 500);

                  case 13:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 2, 9 ] ]);
        }))();
    },
    closeGoods: function() {
        this.selectComponent("#goods").close();
    },
    accountWeb: function() {
        this.setData({
            pageFresh: !0
        }), wx.navigateTo({
            url: "/pages/webview/webview?url=" + a.subAccountQrcodeAddress
        });
    },
    showGoods: function() {
        wx.reportAnalytics("user_click", {
            uid: a.globalData.userInfo.id,
            button_name: "SubPurchase",
            type: "Me"
        }), this.setData({
            pageFresh: !0
        }), wx.navigateTo({
            url: "/pages/goods/goods"
        });
    },
    loadGoodsList: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, getGoodsList();

                  case 3:
                    0 == (r = e.sent).meta.code && a.setData({
                        goods: r.data
                    }), e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(0), console.log(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 7 ] ]);
        }))();
    },
    onShow: function() {
        var e = this;
        "function" == typeof this.getTabBar && this.getTabBar() && (this.getTabBar().setData({
            selected: 3
        }), this.getTabBar().reloadTabBar()), a.jwtReady(function() {
            a.reloadUserVipInfo(), e.data.pageFresh ? e.setData({
                pageFresh: !1
            }) : (e.setData({
                calendarVersion: new Date().getTime(),
                page: 1
            }), e.getStudyBar()), a.loadPopupList().then(function() {
                var t = e.selectComponent("#push-popup");
                t && t.initPopup();
            });
        });
    },
    onHide: function() {
        var e = this.selectComponent("#push-popup");
        e && e.unMounted();
    },
    onLoad: function(e) {
        var t = this;
        a.store.on("unbuy", function(e) {
            "notpay" == e && 1 == a.globalData.userInfo.isNew && t.setData({
                showGift: !0
            });
        }), a.store.on(a.events.levelUp, function(e) {
            var r = "", n = "";
            a.isReleased() && (0 == e.level ? (r = "畅享所有内容", n = "/images/icons/pro=off.png") : (r = "订阅有效期至 " + p(e.vip_expire_date), 
            n = "/images/icons/pro=on.png")), t.setData({
                desc: r,
                isVip: e.level,
                userVipStatusImg: n
            }), console.log("pay_result", e.level);
        }, "userCenter"), a.jwtReady(function() {
            if (!a.needRegister()) {
                var e = a.globalData.userInfo, r = e.name, n = "", i = "", s = e.level;
                a.isReleased() && (0 == e.level ? (n = "畅享所有内容", i = "/images/icons/pro=off.png") : (n = "有效期至 " + p(e.vip_expire_date), 
                i = "/images/icons/pro=on.png")), t.setData({
                    username: r,
                    desc: n,
                    avatar: e.avatar,
                    userID: e.id,
                    tel: e.tel,
                    userVipStatusImg: i,
                    goods: a.goods,
                    isVip: s
                }), wx.reportAnalytics("user_coming", {
                    is_first_time: a.globalData.userInfo.isFirst,
                    time: l(new Date()),
                    uid: a.globalData.userInfo.id,
                    type: "Me"
                });
            }
        });
    },
    completeInformation: function() {
        var e = this;
        "" != this.data.tel && -1 == this.data.avatar.indexOf("/heartlylab/imgs/default_avatar.png") || (a.store.on(a.events.register, function() {
            var t = a.globalData.userInfo;
            e.setData({
                username: t.name,
                avatar: t.avatar,
                userID: t.id,
                tel: t.tel
            });
        }, "completeInformation"), wx.navigateTo({
            url: "/pages/register/register"
        }));
    },
    getStudyBar: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, n();

                  case 3:
                    0 == (r = e.sent).meta.code && a.setData({
                        studyBar: [ {
                            title: "冥想分钟",
                            number: parseInt(r.data.duration / 60)
                        }, {
                            title: "冥想天数",
                            number: r.data.total_days
                        }, {
                            title: "冥想次数",
                            number: r.data.times
                        } ]
                    }), e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(0), console.log(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 7 ] ]);
        }))();
    },
    goStudyRecordList: function(e) {
        wx.navigateTo({
            url: "/pages/user/study_record/record_list"
        });
    },
    goMyCollection: function(e) {
        wx.navigateTo({
            url: "/pages/user/my_collection/index"
        });
    },
    delegateMessage: function() {
        wx.requestSubscribeMessage({
            tmplIds: [ "cZ5JhwwD8fhT6SpYDqlfFzDizKlFTiICM5zXmCMUql0" ],
            success: function(e) {
                "accept" == e.cZ5JhwwD8fhT6SpYDqlfFzDizKlFTiICM5zXmCMUql0 && s([ "cZ5JhwwD8fhT6SpYDqlfFzDizKlFTiICM5zXmCMUql0" ]).then(function(e) {
                    0 == e.meta.code ? wx.showToast({
                        title: "订阅成功"
                    }) : wx.showToast({
                        title: "订阅失败",
                        icon: "none"
                    });
                });
            }
        });
    },
    closeGift: function() {
        wx.reportAnalytics("receive_rewards", {
            uid: a.globalData.userInfo.id,
            receive_result: "Reject",
            rewards_type: a.inviter ? "Refrral" : "RewardforNew",
            page_name: "Me",
            invite_id: a.inviter ? a.inviter : "NA"
        }), this.setData({
            showGift: !1
        });
    },
    redirectInvitation: function() {
        this.setData({
            pageFresh: !0
        }), wx.navigateTo({
            url: "/pages/user/invitation/invitation"
        });
    },
    onGiftConfirmClose: function() {
        this.setData({
            showGiftConfirm: !1
        });
    },
    onShareAppMessage: function() {
        return wx.reportAnalytics("share_common", {
            button_name: "Share",
            channel: "Friends",
            page_name: "Me",
            uid: a.globalData.userInfo.id
        }), {
            title: "与好友一起静享正念时刻",
            path: "/pages/index/index?scene=inviter:" + a.globalData.userInfo.id,
            imageUrl: a.shareImg
        };
    }
});