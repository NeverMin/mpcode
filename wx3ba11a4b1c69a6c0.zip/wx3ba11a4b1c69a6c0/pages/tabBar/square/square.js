var t = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/regenerator")), a = require("../../../@babel/runtime/helpers/asyncToGenerator"), e = require("../../../api/camp.js").getCampList, n = require("../../../contants/common").PAGE_SQUARE, i = require("../../../utils/gio-minp/index").default, o = getApp();

Page({
    data: {
        paddingTop: 0,
        pageTitle: "广场",
        pushPopupKey: n,
        page: 1,
        pagesize: 8,
        loading: !0,
        list: [],
        total: null,
        noMore: !1,
        showPunchIn: !1,
        showUnreadBadge: !1,
        inited: !1,
        triggered: !1
    },
    onLoad: function(t) {
        var a = this;
        this.setData({
            paddingTop: 2 * o.globalData.CustomBar
        }), o.jwtReady(function() {
            a.getList(), a.setData({
                inited: !0,
                showPunchIn: !0
            });
        });
    },
    onReady: function() {},
    onShow: function() {
        var t = this;
        "function" == typeof this.getTabBar && this.getTabBar() && (this.getTabBar().setData({
            selected: 2
        }), this.getTabBar().reloadTabBar()), this.setData({
            showUnreadBadge: o.globalData.showBadge.square || !1
        }), this.data.inited && (this.data.list && 0 != this.data.list.length || this.getList()), 
        o.jwtReady(function() {
            o.loadPopupList().then(function() {
                var a = t.selectComponent("#push-popup");
                a && a.initPopup();
            });
        });
    },
    onHide: function() {
        var t = this.selectComponent("#push-popup");
        t && t.unMounted();
    },
    onReachBottom: function() {
        this.data.noMore || this.getList();
    },
    getList: function() {
        var n = this;
        return a(t.default.mark(function a() {
            var i, o;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n.setData({
                        loading: !0
                    }), i = {}, t.next = 4, e(n.data.page, n.data.pagesize);

                  case 4:
                    0 == (o = t.sent).meta.code ? (0 == o.data.total ? i.noMore = !0 : (1 == n.data.page ? i.list = o.data.list : i.list = n.data.list.concat(o.data.list), 
                    n.data.page * n.data.pagesize >= o.data.total ? i.noMore = !0 : i.page = n.data.page + 1), 
                    n.setData(i)) : wx.showToast({
                        title: o.meta.message,
                        icon: "none"
                    }), n.setData({
                        loading: !1,
                        triggered: !1
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    goRecruit: function(t) {
        var a = t.currentTarget.dataset, e = a.id, n = a.paid, r = a.title, s = a.customStatus;
        i("track", "ClickBanner", {
            userID: o.globalData.userInfo.id,
            BannerName: r,
            BannerLocation: "Square"
        }), n || 3 === s ? wx.navigateTo({
            url: "/pages/camp/course_catalog/course_catalog?id=" + e
        }) : wx.navigateTo({
            url: "/pages/camp/recruit/recruit?id=" + e
        });
    },
    goPunchIn: function() {
        o.globalData.showBadge.square && o.reportUnread(), wx.navigateTo({
            url: "/pages/camp/punch_in/punch_in"
        });
    },
    onShareAppMessage: function() {},
    onScrollRefresh: function() {
        this.setData({
            triggered: !0,
            page: 1
        }), this.getList();
    }
});