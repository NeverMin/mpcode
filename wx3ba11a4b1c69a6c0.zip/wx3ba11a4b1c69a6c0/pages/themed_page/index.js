var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../api/index").getThemedPage, r = getApp();

Page({
    data: {
        loading: !1,
        title: "",
        description: "",
        header_image: "",
        blocks: []
    },
    onLoad: function(a) {
        var n = this;
        this.setData({
            loading: !0
        }), r.jwtReady(t(e.default.mark(function t() {
            var r, i;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = a.id, i = a.flag, e.next = 3, n.loadThemedPage(r, i);

                  case 3:
                    n.setData({
                        loading: !1
                    });

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, t);
        })));
    },
    loadThemedPage: function(r, n) {
        var i = this;
        return t(e.default.mark(function t() {
            var o, s, c;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, a(r, n);

                  case 3:
                    o = e.sent, s = o.meta, c = o.data, 0 === s.code ? i.setData({
                        title: c.title,
                        description: c.description,
                        blocks: c.blocks,
                        header_image: c.header_image
                    }) : wx.showToast({
                        title: s.message,
                        icon: "none"
                    }), e.next = 12;
                    break;

                  case 9:
                    e.prev = 9, e.t0 = e.catch(0), console.error("loadThemedPage: ", e.t0);

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 9 ] ]);
        }))();
    }
});