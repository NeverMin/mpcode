var e = getApp();

Page({
    data: {
        url: ""
    },
    onLoad: function(e) {
        this.setData({
            url: decodeURIComponent(e.url)
        });
    },
    onShareAppMessage: function() {
        return {
            title: "与好友一起静享正念时刻",
            path: "/pages/index/index?scene=inviter:" + e.globalData.userInfo.id,
            imageUrl: e.shareImg
        };
    }
});