var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = getApp(), o = require("../../api/course.js").getColumnCourseLessons, i = require("../../utils/util"), s = i.doubleClick, n = i.formatTime, r = s();

Page({
    data: {
        isVip: null,
        pageTitle: "",
        page: 1,
        pagesize: 5,
        list: [],
        total: 0,
        noMore: !1
    },
    onUnload: function() {
        a.store.off(a.events.levelUp, "theoryLevelUp");
    },
    onLoad: function(e) {
        var t = this;
        a.store.on(a.events.levelUp, function(e) {
            t.setData({
                isVip: e.level
            });
        }, "theoryLevelUp"), this.setData({
            loading: !0
        }), a.jwtReady(function() {
            t.loadList(), wx.reportAnalytics("user_coming", {
                is_first_time: a.globalData.userInfo.isFirst,
                time: n(new Date()),
                uid: a.globalData.userInfo.id,
                type: "Theory"
            });
        });
    },
    loadList: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var i, s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!a.data.noMore) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return a.setData({
                        loading: !0
                    }), e.prev = 3, i = {}, e.next = 7, o(4, a.data.page, a.data.pagesize);

                  case 7:
                    0 == (s = e.sent).meta.code && (i.total = s.data.total, 0 == s.data.total ? i.noMore = !0 : (1 == a.data.page ? i.list = s.data.list ? s.data.list : [] : i.list = a.data.list.concat(s.data.list), 
                    a.data.page * a.data.pagesize >= s.data.total ? i.noMore = !0 : i.page = a.data.page + 1), 
                    a.setData(i)), e.next = 14;
                    break;

                  case 11:
                    e.prev = 11, e.t0 = e.catch(3), console.log(e.t0);

                  case 14:
                    a.setData({
                        loading: !1
                    });

                  case 15:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 3, 11 ] ]);
        }))();
    },
    onShow: function() {
        var e = this;
        "function" == typeof this.getTabBar && this.getTabBar() && this.getTabBar().setData({
            selected: 1
        }), a.jwtReady(function() {
            e.setData({
                isVip: a.globalData.userInfo.level
            });
        });
    },
    onReachBottom: function() {
        this.data.noMore || this.loadList();
    },
    closeGoods: function() {
        this.selectComponent("#goods").close();
    },
    goLesson: function(e) {
        if (r()) {
            if (!e.currentTarget.dataset.ok) {
                if (a.needRegister()) return;
                return wx.reportAnalytics("user_click", {
                    uid: a.globalData.userInfo.id,
                    button_name: "会员购买",
                    type: "理论列表"
                }), void wx.navigateTo({
                    url: "/pages/goods/goods"
                });
            }
            wx.navigateTo({
                url: "/pages/lesson/lesson?id=" + e.currentTarget.dataset.id + "&pagetype=Theory"
            });
        }
    },
    onPageScroll: function(e) {
        console.log(e), e.scrollTop > 100 && "理论" != this.data.pageTitle ? this.setData({
            pageTitle: "理论"
        }) : e.scrollTop < 100 && "理论" == this.data.pageTitle && this.setData({
            pageTitle: ""
        });
    },
    onViewScroll: function(e) {
        e.detail.scrollTop > 100 && "理论" != this.data.pageTitle ? this.setData({
            pageTitle: "理论"
        }) : e.detail.scrollTop < 100 && "理论" == this.data.pageTitle && this.setData({
            pageTitle: ""
        });
    },
    onShareAppMessage: function() {
        return wx.reportAnalytics("share_common", {
            button_name: "Share",
            channel: "Friends",
            page_name: "Thoery",
            uid: a.globalData.userInfo.id
        }), {
            title: "与好友一起静享正念时刻",
            path: "/pages/index/index?scene=inviter:" + a.globalData.userInfo.id,
            imageUrl: a.shareImg
        };
    }
});