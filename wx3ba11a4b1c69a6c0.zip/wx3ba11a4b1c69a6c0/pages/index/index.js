var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = getApp(), o = require("../../api/user.js"), r = o.getFollowList, n = o.receiveVIP, i = require("../../api/index.js"), s = i.getEveryDayV2, c = i.getCourseRecommend, l = require("../../api/gift_code.js"), u = l.getGiftCodeRecordInfo, d = l.exchangeGiftCode, g = require("../../api/banner.js").getBannerList, f = require("../../api/course.js").getPageData, h = require("../../utils/util.js"), p = h.doubleClick, v = h.formatTime, w = h.currentYearDate, m = require("../../api/course").getSearchPopularList, b = require("../../contants/common").PAGE_INDEX, x = require("../../utils/router").hlNavigateTo, D = require("../../utils/gio-minp/index.js").default, y = p(), T = p();

Page({
    data: {
        pushPopupKey: b,
        onLoaded: !1,
        everyDay: null,
        loading: !0,
        user: {},
        setting: {},
        iconRemove: "",
        hideBgPlayIcon: !0,
        date: {
            year: null,
            date: null
        },
        follows: [],
        followTotal: 0,
        discovers: [],
        recommends: [],
        recommendTypes: {},
        popularTitle: "",
        showGift: !1,
        giftLoading: !1,
        giftButtonContent: "立即领取",
        showGiftConfirm: !1,
        showLogo: !0,
        banners: null,
        currentBannerIndex: 0,
        showCodeGift: !1,
        codeGiftInfo: {},
        discoverPage: 1,
        discoverPagesize: 4,
        discoverNoMore: !1,
        showStickySearch: !1,
        needStickySearchHeight: 600,
        needHideLogoHeigth: 500,
        needShowDiscoverTitleHeight: 800,
        needShowRecommendTitleHeight: 1200,
        pageTitle: "",
        columnScroll: {
            id: 0,
            times: 0
        },
        showValentineBox: !1
    },
    getBanner: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, g("index");

                  case 3:
                    0 == (o = e.sent).meta.code && a.setData({
                        banners: o.data
                    }), e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(0), console.log(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 7 ] ]);
        }))();
    },
    closeGift: function() {
        wx.reportAnalytics("receive_rewards", {
            uid: a.globalData.userInfo.id,
            receive_result: "Reject",
            rewards_type: a.inviter ? "Refrral" : "RewardforNew",
            page_name: "HomePage",
            invite_id: a.inviter ? a.inviter : "NA"
        }), this.setData({
            showGift: !1
        });
    },
    onGiftConfirmClose: function() {
        this.setData({
            showGiftConfirm: !1
        });
    },
    getEveryDayM: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a.setData({
                        loading: !0
                    }), e.prev = 1, e.next = 4, s();

                  case 4:
                    0 == (o = e.sent).meta.code ? (o.data && o.data.length > 0 && o.data.forEach(function(e, t) {
                        var a = e.date.split("-");
                        e.date = {
                            year: a[0],
                            date: a[1] + "-" + a[2]
                        };
                    }), a.setData({
                        everyDay: o.data
                    })) : wx.showToast({
                        title: o.meta.message,
                        icon: "none"
                    }), e.next = 11;
                    break;

                  case 8:
                    e.prev = 8, e.t0 = e.catch(1), wx.showToast({
                        title: "获取每日冥想失败",
                        icon: "none"
                    });

                  case 11:
                    a.setData({
                        loading: !1
                    });

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 8 ] ]);
        }))();
    },
    scrollToRight: function(e) {
        console.log(e);
        var t = e.currentTarget.dataset.id;
        this.data.columnScroll[t] && 1 == this.data.columnScroll[t].times ? this.goColumnList({
            currentTarget: {
                dataset: {
                    id: t
                }
            }
        }) : this.data.columnScroll[t] = {
            times: 1
        };
    },
    getGift: function() {
        var o = this;
        return t(e.default.mark(function t() {
            var r, i;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!a.needRegister("/pages/index/index", "switch")) {
                        e.next = 3;
                        break;
                    }
                    return a.store.on(a.events.register, function() {
                        o.getGift();
                    }, "getGift"), e.abrupt("return");

                  case 3:
                    return o.setData({
                        giftLoading: !0,
                        giftButtonContent: ""
                    }), r = {
                        giftLoading: !1,
                        giftButtonContent: "领取成功"
                    }, e.prev = 5, e.next = 8, n();

                  case 8:
                    0 == (i = e.sent).meta.code ? (a.globalData.userInfo.level = i.data.level, a.globalData.userInfo.vip_expire_date = i.data.expire_date, 
                    wx.reportAnalytics("receive_rewards", {
                        uid: a.globalData.userInfo.id,
                        receive_result: "Accept",
                        rewards_type: a.inviter ? "Refrral" : "RewardforNew",
                        page_name: "HomePage",
                        invite_id: a.inviter ? a.inviter : "NA"
                    }), r.showGiftConfirm = !0, r.showGift = !1, wx.reportAnalytics("user_click", {
                        uid: a.globalData.userInfo.id,
                        button_name: "7DaysFree",
                        type: "Home"
                    })) : (wx.reportAnalytics("receive_rewards", {
                        uid: a.globalData.userInfo.id,
                        receive_result: "Failed",
                        rewards_type: a.inviter ? "Refrral" : "RewardforNew",
                        page_name: "HomePage",
                        invite_id: a.inviter ? a.inviter : "NA"
                    }), 500 != i.meta.code && (r.showGift = !1), wx.showToast({
                        title: i.meta.message,
                        icon: "none"
                    }), r.giftButtonContent = "立即领取"), e.next = 15;
                    break;

                  case 12:
                    e.prev = 12, e.t0 = e.catch(5), console.log(e.t0);

                  case 15:
                    o.setData(r);

                  case 16:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 5, 12 ] ]);
        }))();
    },
    getGiftCodeAward: function() {
        var o = this;
        return t(e.default.mark(function t() {
            var r, n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!a.needRegister("/pages/index/index", "switch")) {
                        e.next = 3;
                        break;
                    }
                    return a.store.on(a.events.register, function() {
                        o.getGiftCodeAward();
                    }, "getGiftCodeAward"), e.abrupt("return");

                  case 3:
                    return o.setData({
                        giftLoading: !0,
                        giftButtonContent: ""
                    }), r = {
                        giftLoading: !1,
                        giftButtonContent: "领取成功"
                    }, e.prev = 5, e.next = 8, d(a.giftCode);

                  case 8:
                    0 == (n = e.sent).meta.code ? (a.globalData.userInfo.level = n.data.level, a.globalData.userInfo.vip_expire_date = n.data.expire_date, 
                    r.showGiftConfirm = !0, r.showCodeGift = !1, wx.reportAnalytics("receive_rewards", {
                        uid: a.globalData.userInfo.id,
                        receive_result: "Accept",
                        rewards_type: "SpecialGift",
                        page_name: "HomePage",
                        invite_id: a.giftCode
                    })) : (wx.reportAnalytics("receive_rewards", {
                        uid: a.globalData.userInfo.id,
                        receive_result: "Failed",
                        rewards_type: "SpecialGift",
                        page_name: "HomePage",
                        invite_id: a.giftCode
                    }), 500 != n.meta.code && (r.showCodeGift = !1), wx.showToast({
                        title: n.meta.message,
                        icon: "none"
                    }), r.giftButtonContent = "立即领取"), e.next = 15;
                    break;

                  case 12:
                    e.prev = 12, e.t0 = e.catch(5), console.log(e.t0);

                  case 15:
                    setTimeout(function() {
                        o.setData(r);
                    }, 200);

                  case 16:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 5, 12 ] ]);
        }))();
    },
    currentYearDate: function() {
        this.setData({
            date: w()
        });
    },
    onPageScroll: function(e) {
        e.scrollTop > 600 && this.data.showLogo ? this.setData({
            showLogo: !1
        }) : e.scrollTop < 600 && !this.data.showLogo && this.setData({
            showLogo: !0
        });
    },
    getFollows: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, r(1, 6);

                  case 3:
                    0 == (o = e.sent).meta.code && a.setData({
                        follows: o.data.list ? o.data.list : [],
                        followTotal: o.data.total
                    }), e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(0), console.log(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 7 ] ]);
        }))();
    },
    getSearchPopularList: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var o, r, n, i;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, m();

                  case 3:
                    o = e.sent, r = o.meta, n = o.data, i = void 0 === n ? [] : n, 0 === r.code ? a.setData({
                        popularTitle: i[0] ? i[0].title : ""
                    }) : wx.showToast({
                        title: r.message,
                        icon: "none"
                    }), e.next = 13;
                    break;

                  case 10:
                    e.prev = 10, e.t0 = e.catch(0), console.log(e.t0);

                  case 13:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 10 ] ]);
        }))();
    },
    goSearch: function() {
        wx.navigateTo({
            url: "/pages/search/search"
        }), D("track", "ClickSearch", {
            userID: a.globalData.userInfo.id,
            PageLocation: "发现页"
        });
    },
    onShow: function(e) {
        var t = this;
        "function" == typeof this.getTabBar && this.getTabBar() && this.getTabBar().setData({
            selected: 0
        }), a.jwtReady(function() {
            if (console.log("gift code:", a.giftCode, a.giftCodeShow), "" != a.giftCode && a.giftCodeShow && (t.showGiftCodeInfo(), 
            a.giftCodeShow = !1), t.data.onLoaded) {
                var e = a.getBgAudio();
                t.data.hideBgPlayIcon && e.paused ? setTimeout(function() {
                    a.getBgAudio().play(), a.hideBgPlayIcon = !0;
                }, 1e3) : t.data.hideBgPlayIcon || e.paused || t.setData({
                    hideBgPlayIcon: !0
                }), t.setData({
                    setting: a.getUserSetting(),
                    user: a.globalData.userInfo
                });
            }
            t.getFollows(), a.loadPopupList().then(function() {
                var e = t.selectComponent("#push-popup");
                e && e.initPopup();
            });
        });
    },
    onHide: function() {
        var e = this.selectComponent("#push-popup");
        e && e.unMounted();
    },
    playOrPause: function() {
        if (a.getBgAudio().paused) return this.setData({
            hideBgPlayIcon: !0
        }), a.hideBgPlayIcon = !0, void a.getBgAudio().play();
        this.setData({
            hideBgPlayIcon: !1
        }), a.hideBgPlayIcon = !1, a.getBgAudio().pause();
    },
    onLoad: function(e) {
        var t = this, o = a.globalData.WindowWidth / 750, r = 360 * o, n = a.globalData.WindowHeight - r - a.globalData.CustomBar;
        console.log(r, a.globalData.WindowHeight, n), this.data.needHideLogoHeigth = n;
        var i = n;
        i += 213 + .185 * a.globalData.WindowWidth + 40 + 52 + 40 + 24 + 360 + 40 + 52 + 24;
        var s = (i += 616) + 1344;
        this.setData({
            needShowRecommendTitleHeight: i * o,
            needShowDiscoverTitleHeight: s * o,
            customBarHeight: a.globalData.CustomBar,
            needStickySearchHeight: a.globalData.WindowHeight + 120 * o - a.globalData.CustomBar
        }), this.currentYearDate(), a.store.on(a.events.levelUp, function(e) {
            t.setData({
                user: a.globalData.userInfo
            });
        }), a.store.on(a.events.badgeChange, function() {
            "function" == typeof t.getTabBar && t.getTabBar() && t.getTabBar().reloadTabBar();
        }), wx.reportAnalytics("user_coming", {
            is_first_time: a.globalData.userInfo.IsFirst,
            time: v(new Date()),
            uid: a.globalData.userInfo.id,
            type: "Home"
        }), D("track", "userComming", {
            isFirst: a.globalData.userInfo.isFirst,
            time: v(new Date()),
            userID: a.globalData.userInfo.id,
            pageTitle: "Home"
        });
        var c = {};
        if (e.scene) {
            var l = decodeURIComponent(e.scene);
            l = l.split(";");
            for (var u = 0; u < l.length; u++) {
                var d = l[u].split(":");
                c[d[0]] = d[1];
            }
        }
        a.jwtReady(function() {
            var o = {
                setting: a.getUserSetting(),
                onLoaded: !0,
                user: a.globalData.userInfo
            };
            if (!a.isALDActivity(e) && "" == a.giftCode && 1 == a.globalData.userInfo.isNew && a.isReleased()) try {
                wx.getStorageSync("firstCome") || (o.showGift = !0, wx.setStorage({
                    key: "firstCome",
                    data: !0
                }));
            } catch (e) {} else c.showGoods && a.isReleased() && wx.navigateTo({
                url: "/pages/goods/goods"
            });
            t.setData(o), t.getBanner(), t.getCourseRecommend(), t.getSearchPopularList(), setTimeout(function() {
                t.setData({
                    iconRemove: "opacity: 0"
                });
            }, 2e3), t.openValentineBox(), a.isGameActivity(e) && a.needRegister();
        }), this.getEveryDayM();
    },
    closeGiftCode: function() {
        wx.reportAnalytics("receive_rewards", {
            uid: a.globalData.userInfo.id,
            receive_result: "Reject",
            rewards_type: "SpecialGift",
            page_name: "HomePage",
            invite_id: a.giftCode
        }), this.setData({
            showCodeGift: !1
        });
    },
    goExercise: function() {
        wx.switchTab({
            url: "/pages/tabBar/exercise/exercise"
        });
    },
    showGiftCodeInfo: function() {
        var o = this;
        return t(e.default.mark(function t() {
            var r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, u(a.giftCode);

                  case 3:
                    (r = e.sent).meta && 0 == r.meta.code && o.setData({
                        showCodeGift: !0,
                        codeGiftInfo: r.data
                    }), e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(0), console.log(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 7 ] ]);
        }))();
    },
    openValentineBox: function() {
        if ("" == a.giftCode && a.activityLogicMap.valentineDay && this.data.user && 1 != this.data.user.isNew) try {
            var e = w() + "_valentineShown";
            wx.getStorageSync(e) || (this.setData({
                showValentineBox: !0
            }), wx.setStorage({
                key: e,
                data: !0
            }));
        } catch (e) {}
    },
    closeValentineBox: function() {
        this.setData({
            showValentineBox: !1
        });
    },
    goGoods: function() {
        wx.navigateTo({
            url: "/pages/goods/goods"
        }), this.closeValentineBox();
    },
    onReachBottom: function() {
        this.data.discoverNoMore || this.loadData();
    },
    reloadCourseRecommend: function() {
        var a = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (T()) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return e.next = 4, a.getCourseRecommend(!0);

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    getCourseRecommend: function(a) {
        var o = this;
        return t(e.default.mark(function t() {
            var r, n, i;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a && o.setData({
                        loading: !0
                    }), e.prev = 1, e.next = 4, c(o.data.recommendTypes);

                  case 4:
                    r = e.sent, n = r.data || [], i = {}, n.forEach(function(e) {
                        i[e.type] = e.filters;
                    }), o.setData({
                        recommends: r.data || [],
                        recommendTypes: i
                    }), e.next = 13;
                    break;

                  case 11:
                    e.prev = 11, e.t0 = e.catch(1);

                  case 13:
                    a && o.setData({
                        loading: !1
                    });

                  case 14:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 11 ] ]);
        }))();
    },
    loadData: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var o, r, n, i;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!a.data.discoverNoMore) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return a.setData({
                        loading: !0
                    }), e.prev = 3, o = {}, e.next = 7, f(1, a.data.discoverPage, a.data.discoverPagesize);

                  case 7:
                    if (0 != (r = e.sent).meta.code) {
                        e.next = 41;
                        break;
                    }
                    if (o.total = r.data.total, 0 != r.data.total) {
                        e.next = 14;
                        break;
                    }
                    o.discoverNoMore = !0, e.next = 38;
                    break;

                  case 14:
                    if (!r.data || !r.data.list) {
                        e.next = 36;
                        break;
                    }
                    n = 0;

                  case 16:
                    if (!(n < r.data.list.length)) {
                        e.next = 36;
                        break;
                    }
                    if (!r.data.list[n].courses) {
                        e.next = 33;
                        break;
                    }
                    i = 0;

                  case 19:
                    if (!(i < r.data.list[n].courses.length)) {
                        e.next = 33;
                        break;
                    }
                    e.t0 = r.data.list[n].courses[i].tag, e.next = "免费" === e.t0 ? 23 : "上新" === e.t0 ? 25 : "精选" === e.t0 ? 27 : 29;
                    break;

                  case 23:
                    return r.data.list[n].courses[i].tag_img = "free_tag", e.abrupt("break", 30);

                  case 25:
                    return r.data.list[n].courses[i].tag_img = "new_course", e.abrupt("break", 30);

                  case 27:
                    return r.data.list[n].courses[i].tag_img = "good_teacher", e.abrupt("break", 30);

                  case 29:
                    return e.abrupt("break", 30);

                  case 30:
                    i++, e.next = 19;
                    break;

                  case 33:
                    n++, e.next = 16;
                    break;

                  case 36:
                    1 == a.data.discoverPage ? o.discovers = r.data.list ? r.data.list : [] : o.discovers = a.data.discovers.concat(r.data.list), 
                    a.data.discoverPage * a.data.discoverPagesize >= r.data.total ? o.discoverNoMore = !0 : o.discoverPage = a.data.discoverPage + 1;

                  case 38:
                    a.setData(o), e.next = 42;
                    break;

                  case 41:
                    wx.showToast({
                        title: r.meta.message,
                        icon: "none"
                    });

                  case 42:
                    e.next = 47;
                    break;

                  case 44:
                    e.prev = 44, e.t1 = e.catch(3), console.log();

                  case 47:
                    a.setData({
                        loading: !1
                    });

                  case 48:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 3, 44 ] ]);
        }))();
    },
    onViewScroll: function(e) {
        var t = e.detail.scrollTop, a = this.data, o = a.showLogo, r = a.needHideLogoHeigth, n = a.needShowRecommendTitleHeight, i = a.needShowDiscoverTitleHeight, s = a.needStickySearchHeight;
        t > r && o ? this.setData({
            showLogo: !1
        }) : t < r && !o && this.setData({
            showLogo: !0
        }), t > s ? this.setData({
            showStickySearch: !0
        }) : this.setData({
            showStickySearch: !1
        }), t > n && t < i ? this.setData({
            pageTitle: "为你推荐"
        }) : t > i ? this.setData({
            pageTitle: "发现"
        }) : this.setData({
            pageTitle: ""
        });
    },
    audioPlayer: function(e) {
        a.bgAudioPlayer(e.bgAudioUrl, e.bgVolume, !0), a.getBgAudio().loop = !0;
    },
    bannerChange: function(e) {
        this.setData({
            currentBannerIndex: e.detail.current
        });
    },
    bannerTap: function(e) {
        wx.reportAnalytics("user_click", {
            uid: a.globalData.userInfo.id,
            button_name: "Banner",
            type: "首页"
        });
        var t = this.data.banners[e.currentTarget.dataset.index];
        if (t) if ("image" == t.type) wx.previewImage({
            urls: [ t.content ]
        }); else if ("webview" == t.type) wx.navigateTo({
            url: "/pages/webview/webview?url=" + t.content
        }); else if ("miniprogram" == t.type) {
            if (!t.content) return;
            x(t.content);
        } else if ("other_miniprogram" == t.type) {
            var o = t.content.split(",");
            2 == o.length && wx.navigateToMiniProgram({
                appId: o[0],
                path: o[1]
            });
        }
    },
    showSetting: function() {
        this.getTabBar().setData({
            hideTabbar: !0
        }), wx.reportAnalytics("user_click", {
            uid: a.globalData.userInfo.id,
            button_name: "BackSetting",
            type: "首页"
        });
        var e = this.selectComponent("#bg-settings-sheet");
        e && e.show();
    },
    onBgSettingsChange: function() {
        this.setData({
            setting: a.getUserSetting(),
            hideBgPlayIcon: !0
        });
    },
    closeSetting: function() {
        var e = this;
        setTimeout(function() {
            e.getTabBar().setData({
                hideTabbar: !1
            });
        }, 300);
    },
    goLesson: function(e) {
        if (y()) {
            if (!e.currentTarget.dataset.ok) {
                if (a.needRegister()) return;
                return wx.reportAnalytics("user_click", {
                    uid: a.globalData.userInfo.id,
                    button_name: "会员购买",
                    type: "首页-收藏"
                }), void wx.navigateTo({
                    url: "/pages/goods/goods"
                });
            }
            wx.navigateTo({
                url: "/pages/lesson/lesson?id=" + e.currentTarget.dataset.id + "&pagetype=" + e.currentTarget.dataset.pagetype
            });
        }
    },
    goFollowList: function() {
        wx.reportAnalytics("user_click", {
            uid: a.globalData.userInfo.id,
            button_name: "FavorAll",
            type: "首页"
        }), wx.navigateTo({
            url: "/pages/follow/list"
        });
    },
    goCourse: function(e) {
        T() && wx.navigateTo({
            url: "/pages/course/course?course_id=" + e.currentTarget.dataset.id
        });
    },
    goColumnList: function(e) {
        a.exerciseColumnID = e.currentTarget.dataset.id, wx.switchTab({
            url: "/pages/tabBar/exercise/exercise"
        });
    },
    onShareAppMessage: function() {
        return wx.reportAnalytics("share_common", {
            button_name: "Share",
            channel: "Friends",
            page_name: "Home",
            uid: a.globalData.userInfo.id
        }), {
            title: "与好友一起静享正念时刻",
            path: "/pages/index/index?scene=inviter:" + a.globalData.userInfo.id,
            imageUrl: a.shareImg
        };
    },
    getEndOfYear: function() {
        wx.navigateTo({
            url: "/pages/year_end_report/2022/index/index"
        });
    }
});