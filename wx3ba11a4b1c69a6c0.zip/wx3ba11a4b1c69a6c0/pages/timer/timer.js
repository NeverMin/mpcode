Page({
    data: {
        moveFlag: !1,
        ox: 150,
        oy: 150,
        or: 120,
        br: 10,
        canvas: {},
        ctx: {}
    },
    onLoad: function(t) {
        wx.createSelectorQuery().select("#canvas").fields({
            node: !0,
            size: !0
        }).exec(this.init.bind(this));
    },
    init: function(t) {
        var a = t[0].width, i = t[0].height, e = t[0].node, h = e.getContext("2d");
        this.setData({
            canvas: e,
            ctx: h
        });
        var s = wx.getSystemInfoSync().pixelRatio;
        e.width = a * s, e.height = i * s, h.scale(s, s), this.draw(.25);
    },
    offset: function(t, a) {
        return {
            x: -Math.sin(t) * a,
            y: Math.cos(t) * a
        };
    },
    draw: function(t) {
        var a = this.data.ctx;
        a.clearRect(0, 0, this.data.canvas.width, this.data.canvas.height), a.strokeStyle = "#99a", 
        a.lineWidth = 5, a.beginPath(), a.arc(this.data.ox, this.data.oy, this.data.or, 0, 2 * Math.PI, !0), 
        a.stroke(), a.strokeStyle = "#fff", a.lineWidth = 5, a.beginPath(), a.arc(this.data.ox, this.data.oy, this.data.or, Math.PI, (2 * t + .5) * Math.PI, !1), 
        a.stroke(), a.fillStyle = "#fff", a.font = "18px Arial", a.textAlign = "center", 
        a.textBaseline = "middle";
        var i = t;
        0 == i ? i = 100 : i < .25 ? i += .75 : i -= .25, a.fillText(Math.round(60 * i), this.data.ox, this.data.oy), 
        a.fillStyle = "#fff", a.beginPath();
        var e = this.offset(2 * t * Math.PI, this.data.or);
        a.arc(this.data.ox + e.x, this.data.oy + e.y, this.data.br, 0, 2 * Math.PI, !0), 
        a.fill();
    },
    touchStart: function() {
        this.setData({
            moveFlag: !0
        });
    },
    touchMove: function(t) {
        if (this.data.moveFlag) {
            var a = this.getXY(t, this.data.canvas), i = Math.atan2(a.x - this.data.ox, this.data.oy - a.y), e = (Math.PI + i) / (2 * Math.PI);
            this.draw(e);
        }
    },
    getXY: function(t, a) {
        console.log(t, a);
        var i = t.touches ? t.touches[0] : t, e = i.x, h = i.y;
        return {
            x: e - a._left,
            y: h - a._top
        };
    },
    touchEnd: function() {
        this.setData({
            moveFlag: !1
        });
    },
    onShareAppMessage: function() {}
});