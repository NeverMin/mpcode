var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../api/course.js").getColumnCourseList, r = getApp(), n = require("../../utils/util"), i = n.doubleClick, s = n.formatTime, o = i();

Page({
    data: {
        columnID: "",
        columnTitle: "",
        page: 1,
        pagesize: 8,
        loading: !0,
        list: [],
        total: null,
        noMore: !1
    },
    onLoad: function(e) {
        var t = this;
        this.setData({
            columnTitle: e.title,
            columnID: e.id
        }), this.setData({
            loading: !0
        }), r.jwtReady(function() {
            t.getList(), wx.reportAnalytics("user_click", {
                uid: r.globalData.userInfo.id,
                button_name: e.id + "-更多",
                type: "练习-栏目-更多"
            }), wx.reportAnalytics("user_coming", {
                is_first_time: r.globalData.userInfo.isFirst,
                time: s(new Date()),
                uid: r.globalData.userInfo.id,
                type: "PracticeList"
            });
        });
    },
    onReachBottom: function() {
        this.data.noMore || this.getList();
    },
    getList: function() {
        var r = this;
        return t(e.default.mark(function t() {
            var n, i, s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r.setData({
                        loading: !0
                    }), e.prev = 1, n = {}, e.next = 5, a(r.data.columnID, r.data.page, r.data.pagesize);

                  case 5:
                    if (0 != (i = e.sent).meta.code) {
                        e.next = 34;
                        break;
                    }
                    if (n.total = i.data.total, 0 != i.data.total) {
                        e.next = 12;
                        break;
                    }
                    n.noMore = !0, e.next = 30;
                    break;

                  case 12:
                    if (!i.data || !i.data.list) {
                        e.next = 28;
                        break;
                    }
                    s = 0;

                  case 14:
                    if (!(s < i.data.list.length)) {
                        e.next = 28;
                        break;
                    }
                    e.t0 = i.data.list[s].tag, e.next = "免费" === e.t0 ? 18 : "上新" === e.t0 ? 20 : "精选" === e.t0 ? 22 : 24;
                    break;

                  case 18:
                    return i.data.list[s].tag_img = "free_tag", e.abrupt("break", 25);

                  case 20:
                    return i.data.list[s].tag_img = "new_course", e.abrupt("break", 25);

                  case 22:
                    return i.data.list[s].tag_img = "good_teacher", e.abrupt("break", 25);

                  case 24:
                    return e.abrupt("break", 25);

                  case 25:
                    s++, e.next = 14;
                    break;

                  case 28:
                    1 == r.data.page ? n.list = i.data.list : n.list = r.data.list.concat(i.data.list), 
                    r.data.page * r.data.pagesize >= i.data.total ? n.noMore = !0 : n.page = r.data.page + 1;

                  case 30:
                    console.log("nnnnnnno more", n.noMore), r.setData(n), e.next = 35;
                    break;

                  case 34:
                    wx.showToast({
                        title: i.meta.message,
                        icon: "none"
                    });

                  case 35:
                    e.next = 40;
                    break;

                  case 37:
                    e.prev = 37, e.t1 = e.catch(1), console.log(e.t1);

                  case 40:
                    r.setData({
                        loading: !1
                    });

                  case 41:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 37 ] ]);
        }))();
    },
    goCourse: function(e) {
        o() && wx.navigateTo({
            url: "/pages/course/course?course_id=" + e.currentTarget.dataset.id + "&pagetype=ColumnList"
        });
    },
    onShareAppMessage: function() {
        return wx.reportAnalytics("share_common", {
            button_name: "Share",
            channel: "Friends",
            page_name: "PracticeList",
            uid: r.globalData.userInfo.id
        }), {
            title: "与好友一起静享正念时刻",
            path: "/pages/index/index?scene=inviter:" + r.globalData.userInfo.id,
            imageUrl: r.shareImg
        };
    }
});