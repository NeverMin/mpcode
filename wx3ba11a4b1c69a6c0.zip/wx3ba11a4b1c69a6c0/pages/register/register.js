var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../api/user.js"), r = a.getPhoneNumber, n = a.register, o = a.getPhoneNumberV2, i = getApp(), l = (0, 
require("../../utils/util").doubleClick)();

Page({
    data: {
        redirectTo: null,
        pageType: "redirect",
        tel: "",
        telHide: "",
        loading: !1,
        loginButtonColor: "rgba(6,102,38,0.4)",
        retryCount: 0
    },
    onLoad: function(e) {
        i.jwtReady(function() {
            "" != i.globalData.userInfo.tel && -1 == i.globalData.userInfo.avatar.indexOf("/heartlylab/imgs/default_avatar.png") && wx.switchTab({
                url: "/pages/index/index"
            });
        });
        var t = {}, a = i.globalData.userInfo.tel;
        if (a) {
            var r = a.replace(/(\d{3})\d*(\d{4})/, "$1 **** $2");
            t.tel = a, t.telHide = r;
        }
        e.redirect && (console.log(e.redirect, e.type ? e.type : "redirect"), t.redirectTo = decodeURIComponent(e.redirect), 
        t.pageType = e.type ? e.type : "redirect"), t && this.setData(t);
    },
    loginAlert: function() {
        "" == this.data.tel && wx.showToast({
            title: "请先授权手机号",
            icon: "none"
        });
    },
    getUserInfo: function(e) {
        var t = this;
        l() && 0 == this.data.loading && i.jwtReady(function() {
            t._getUserInfo(e);
        });
    },
    _getUserInfo: function(a) {
        var r = this;
        return t(e.default.mark(function t() {
            var o, l, s, u, c, d, g, f;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ("getUserProfile:ok" == a.detail.errMsg) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return r.setData({
                        loading: !0
                    }), o = !1, e.prev = 4, l = getCurrentPages(), s = l[l.length - 2], u = "LessonDetails", 
                    s && s.route && (-1 != s.route.indexOf("index") ? u = "Homepage" : -1 != s.route.indexOf("center") && (u = "Me")), 
                    c = "", d = "", i.lunchOpts && i.lunchOpts.ad ? (c = i.lunchOpts.ad, d = "ad") : i.inviter && (c = i.inviter, 
                    d = "invitation"), g = a.detail.userInfo, e.next = 15, n(g.nickName, g.gender, g.avatarUrl, g.city, i.inviter, i.gioLinkID);

                  case 15:
                    if (0 != (f = e.sent).meta.code) {
                        e.next = 42;
                        break;
                    }
                    if (o = !0, i.globalData.userInfo.avatar = g.avatarUrl, i.globalData.userInfo.name = g.nickName, 
                    f.data.level > 0 && (i.globalData.userInfo.level = f.data.level, i.globalData.userInfo.vip_expire_date = f.data.expire_date), 
                    r.setData({
                        loading: !1
                    }), wx.reportAnalytics("login", {
                        uid: i.globalData.userInfo.id,
                        button_name: "Login",
                        type: u,
                        login_result: o,
                        source: c,
                        source_type: d
                    }), r.data.redirectTo) {
                        e.next = 27;
                        break;
                    }
                    wx.switchTab({
                        url: "/pages/tabBar/user/center"
                    }), e.next = 40;
                    break;

                  case 27:
                    e.t0 = r.data.pageType, e.next = "normal" === e.t0 ? 30 : "redirect" === e.t0 ? 32 : "switch" === e.t0 ? 34 : 37;
                    break;

                  case 30:
                    return wx.navigateTo({
                        url: r.data.redirectTo
                    }), e.abrupt("break", 40);

                  case 32:
                    return wx.redirectTo({
                        url: r.data.redirectTo
                    }), e.abrupt("break", 40);

                  case 34:
                    return console.log("switch", r.data.redirectTo), wx.switchTab({
                        url: r.data.redirectTo
                    }), e.abrupt("break", 40);

                  case 37:
                    return console.log("navigate back to"), wx.navigateBack({
                        delta: 1
                    }), e.abrupt("break", 40);

                  case 40:
                    e.next = 44;
                    break;

                  case 42:
                    wx.showToast({
                        title: f.meta.message,
                        icon: "none"
                    }), wx.reportAnalytics("login", {
                        uid: i.globalData.userInfo.id,
                        button_name: "Login",
                        type: u,
                        login_result: o,
                        source: c,
                        source_type: d
                    });

                  case 44:
                    e.next = 49;
                    break;

                  case 46:
                    e.prev = 46, e.t1 = e.catch(4), console.log(e.t1);

                  case 49:
                    r.setData({
                        loading: !1
                    });

                  case 50:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 4, 46 ] ]);
        }))();
    },
    getphonev2: function(a, r) {
        var n = this;
        return t(e.default.mark(function t() {
            var l, s, u;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, o(a, r);

                  case 3:
                    if (0 != (l = e.sent).meta.code) {
                        e.next = 19;
                        break;
                    }
                    if (0 == l.data.exist_user_id || "false" != l.data.continue && !1 !== l.data.continue) {
                        e.next = 11;
                        break;
                    }
                    return i.globalData.userInfo.token = "", wx.switchTab({
                        url: "/pages/index/index"
                    }), e.abrupt("return");

                  case 11:
                    "true" != l.data.continue && !0 !== l.data.continue || (i.globalData.userInfo.id = l.data.exist_user_id, 
                    i.globalData.userInfo.token = l.data.new_token);

                  case 12:
                    i.globalData.userInfo.tel = l.data.tel, i.store.emit(i.events.register, {}), s = /(\d{3})\d*(\d{4})/, 
                    u = l.data.tel.replace(s, "$1 **** $2"), n.setData({
                        tel: l.data.tel,
                        telHide: u
                    }), e.next = 20;
                    break;

                  case 19:
                    wx.showToast({
                        title: l.meta.message,
                        icon: "none"
                    });

                  case 20:
                    e.next = 25;
                    break;

                  case 22:
                    e.prev = 22, e.t0 = e.catch(0), console.log(e.t0);

                  case 25:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 22 ] ]);
        }))();
    },
    getphone: function(a) {
        var n = this;
        return t(e.default.mark(function t() {
            var o, l;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ("getPhoneNumber:ok" == a.detail.errMsg) {
                        e.next = 3;
                        break;
                    }
                    return wx.showToast({
                        title: "授权失败",
                        icon: "error"
                    }), e.abrupt("return");

                  case 3:
                    if (n.setData({
                        phoneLoading: !0
                    }), o = wx.getStorageSync("inviter"), !a.detail || !a.detail.code) {
                        e.next = 10;
                        break;
                    }
                    return e.next = 8, n.getphonev2(a.detail.code, o);

                  case 8:
                    return n.setData({
                        phoneLoading: !1
                    }), e.abrupt("return");

                  case 10:
                    l = n, i.jwtReady(function() {
                        r(a.detail.encryptedData, a.detail.iv, o).then(function(e) {
                            if (0 == e.meta.code) {
                                if (0 != e.data.exist_user_id && ("false" == e.data.continue || !1 === e.data.continue)) return i.globalData.userInfo.token = "", 
                                i.login(), void wx.switchTab({
                                    url: "/pages/index/index"
                                });
                                "true" != e.data.continue && !0 !== e.data.continue || (i.globalData.userInfo.id = e.data.exist_user_id, 
                                i.globalData.userInfo.token = e.data.new_token, i.login()), i.globalData.userInfo.tel = e.data.tel, 
                                i.store.emit(i.events.register, {});
                                var t = e.data.tel.replace(/(\d{3})\d*(\d{4})/, "$1 **** $2");
                                l.setData({
                                    tel: e.data.tel,
                                    telHide: t
                                });
                            } else i.login(), wx.showToast({
                                title: e.meta.message,
                                icon: "none"
                            });
                        }).catch(function(e) {
                            console.log(e);
                        }).finally(function(e) {
                            n.setData({
                                phoneLoading: !1
                            });
                        });
                    });

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    }
});