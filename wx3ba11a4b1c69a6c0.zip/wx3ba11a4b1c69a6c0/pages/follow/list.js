var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../api/user.js").getFollowList, n = getApp(), o = (0, 
require("../../utils/util").doubleClick)();

Page({
    data: {
        isVip: 0,
        page: 1,
        pagesize: 10,
        loading: !0,
        list: [],
        total: null,
        noMore: !1
    },
    onShow: function() {
        var e = this;
        n.jwtReady(function() {
            e.setData({
                isVip: n.globalData.userInfo.level
            });
        });
    },
    onLoad: function(e) {
        var t = this;
        this.setData({
            columnTitle: e.title,
            columnID: e.id
        }), this.setData({
            loading: !0
        }), n.jwtReady(function() {
            t.getList();
        });
    },
    onReachBottom: function() {
        this.data.noMore || this.getList();
    },
    getList: function() {
        var n = this;
        return t(e.default.mark(function t() {
            var o, r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!n.data.noMore) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return n.setData({
                        loading: !0
                    }), e.prev = 3, o = {}, e.next = 7, a(n.data.page, n.data.pagesize);

                  case 7:
                    0 == (r = e.sent).meta.code ? (o.total = r.data.total, 0 == r.data.total ? o.noMore = !0 : (1 == n.data.page ? o.list = r.data.list : o.list = n.data.list.concat(r.data.list), 
                    n.data.page * n.data.pagesize >= r.data.total ? o.noMore = !0 : o.page = n.data.page + 1), 
                    n.setData(o)) : wx.showToast({
                        title: r.meta.message,
                        icon: "none"
                    }), e.next = 14;
                    break;

                  case 11:
                    e.prev = 11, e.t0 = e.catch(3), console.log(e.t0);

                  case 14:
                    n.setData({
                        loading: !1
                    });

                  case 15:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 3, 11 ] ]);
        }))();
    },
    goLesson: function(e) {
        o() && (e.currentTarget.dataset.ok ? wx.navigateTo({
            url: "/pages/lesson/lesson?id=" + e.currentTarget.dataset.id + "&pagetype=FavourList"
        }) : wx.navigateTo({
            url: "/pages/goods/goods"
        }));
    },
    onShareAppMessage: function() {
        return wx.reportAnalytics("share_common", {
            button_name: "Share",
            channel: "Friends",
            page_name: "FavourList",
            uid: n.globalData.userInfo.id
        }), {
            title: "与好友一起静享正念时刻",
            path: "/pages/index/index?scene=inviter:" + n.globalData.userInfo.id,
            imageUrl: n.shareImg
        };
    }
});