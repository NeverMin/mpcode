var t = (0, require("../../../utils/util.js").doubleClick)();

Component({
    properties: {
        theme: {
            type: String,
            default: "dark"
        },
        list: {
            type: Array,
            default: function() {
                return [];
            },
            observer: function(t) {
                this.list = t.map(function(t) {
                    switch (t.tag) {
                      case "免费":
                        t.tag_img = "free_tag";
                        break;

                      case "上新":
                        t.tag_img = "new_course";
                        break;

                      case "精选":
                        t.tag_img = "good_teacher";
                    }
                    return t;
                }), this.setData({
                    finalData: this.list
                });
            }
        }
    },
    data: {
        finalData: []
    },
    methods: {
        goCourse: function(e) {
            t() && wx.navigateTo({
                url: "/pages/course/course?course_id=" + e.currentTarget.dataset.id
            });
        }
    }
});