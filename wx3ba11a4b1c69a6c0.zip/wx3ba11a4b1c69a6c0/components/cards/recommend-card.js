Component({
    properties: {
        info: {
            type: Object,
            default: function() {}
        }
    },
    data: {
        info: {}
    },
    methods: {}
});