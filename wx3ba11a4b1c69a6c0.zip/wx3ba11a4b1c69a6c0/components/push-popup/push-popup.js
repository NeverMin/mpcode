var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../utils/router"), i = (a.getRouteInfoByPopup, 
a.hlNavigateTo), r = getApp(), o = require("../../utils/gio-minp/index.js").default;

Component({
    properties: {
        routeName: {
            type: String,
            default: ""
        }
    },
    data: {
        show: !1,
        detail: {},
        timer: null
    },
    methods: {
        initPopup: function() {
            var a = this;
            return t(e.default.mark(function t() {
                var i;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!a.data.show) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return");

                      case 2:
                        if (i = r.globalData.popupData[a.properties.routeName] || {}, a.setData({
                            detail: i
                        }), 0 !== Object.keys(a.data.detail).length) {
                            e.next = 6;
                            break;
                        }
                        return e.abrupt("return");

                      case 6:
                        a.checkIsShowPopup();

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        unMounted: function() {
            this.data.timer && (console.debug("[unMounted] RouteName: ".concat(this.properties.routeName, ", push popup is unMounted! ")), 
            clearTimeout(this.data.timer), this.setData({
                timer: null
            }));
        },
        getStorageKey: function() {
            return "push-popup__click_time_".concat(this.properties.routeName);
        },
        checkIsShowPopup: function() {
            var e = wx.getStorageSync(this.getStorageKey());
            (new Date() - e) / 1e3 >= this.data.detail.interval_in_seconds ? this.setData({
                show: !0
            }) : this.delayCheckTime();
        },
        delayCheckTime: function() {
            var e = this;
            this.data.time && clearTimeout(this.data.time);
            var t = wx.getStorageSync(this.getStorageKey()), a = (new Date() - t) / 1e3, i = this.data.detail.interval_in_seconds, r = i - a;
            console.debug("[delayCheckTime] currInterval: ".concat(a, ", interval_in_seconds: ").concat(i, ", delay: ").concat(r));
            var o = setTimeout(function() {
                e.checkIsShowPopup();
            }, 1e3 * r);
            this.setData({
                timer: o
            });
        },
        cachePopupClickTime: function() {
            0 !== Object.keys(this.data.detail).length && (wx.setStorageSync(this.getStorageKey(), new Date()), 
            this.delayCheckTime());
        },
        handleClickBanner: function() {
            if (0 !== Object.keys(this.data.detail).length) {
                var e = this.data.detail.redirect_target;
                if (e) {
                    var t = e || {}, a = t.type, n = t.url_scheme, s = t.extra_args;
                    if (n) {
                        switch (a) {
                          case "image":
                            wx.previewImage({
                                urls: [ s.url ]
                            });
                            break;

                          case "h5":
                            wx.navigateTo({
                                url: "/pages/webview/webview?url=" + s.url
                            });
                            break;

                          case "mini_program":
                            if (!s.app_id || r.appid === s.app_id) i(s.path, s); else {
                                if (!s.app_id) return;
                                wx.navigateToMiniProgram({
                                    appId: s.app_id,
                                    path: s.path,
                                    extraData: s
                                });
                            }
                            break;

                          case "app":
                            wx.showToast({
                                title: "暂不支持APP配置",
                                icon: "none"
                            });
                        }
                        this.setData({
                            show: !1
                        }), this.cachePopupClickTime(), o("track", "ClickPopupWindow", {
                            userID: r.globalData.userInfo.id,
                            PopupID: this.data.detail.id,
                            DeviceType: "小程序"
                        });
                    }
                }
            }
        },
        closeBox: function() {
            this.setData({
                show: !1
            }), this.cachePopupClickTime(), o("track", "ClosePopupWindow", {
                userID: r.globalData.userInfo.id,
                PopupID: this.data.detail.id,
                DeviceType: "小程序"
            });
        }
    }
});