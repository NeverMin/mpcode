Component({
    externalClasses: [ "ht-custom-textarea", "ht-textarea" ],
    properties: {
        value: {
            type: String,
            observer: function(t) {
                t !== this.value && (this.setData({
                    innerValue: t
                }), this.value = t);
            }
        },
        maxlength: {
            type: Number,
            default: -1
        },
        disabled: {
            type: Boolean,
            default: !1
        },
        adjustPosition: {
            type: Boolean,
            default: !0
        },
        placeholder: {
            type: String,
            default: ""
        },
        autoFocus: Boolean
    },
    data: {
        innerValue: "",
        focus: !1
    },
    methods: {
        created: function() {
            this.value = this.data.value, this.setData({
                innerValue: this.value
            });
        },
        bindinput: function(t) {
            var e = t.detail.value;
            this.value = e, this.triggerEvent("input", e), this.triggerEvent("change", e);
        },
        bindkeyboardheightchange: function(t) {
            this.triggerEvent("keyboardheightchange", t.detail);
        },
        onfocus: function() {
            this.setData({
                focus: !0
            });
        },
        onblur: function() {
            this.setData({
                focus: !1
            });
        },
        handleClickPlaceholder: function() {
            this.setData({
                focus: !0
            });
        }
    }
});