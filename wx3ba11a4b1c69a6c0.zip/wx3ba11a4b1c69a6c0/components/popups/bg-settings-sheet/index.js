var e = require("../../../api/bg_setting.js").updateBgSetting, t = getApp();

Component({
    properties: {
        showHeaderTitle: {
            type: Boolean,
            default: !0
        },
        showBgSettings: {
            type: Boolean,
            default: !1
        },
        fullscreen: {
            type: Boolean,
            default: !0
        }
    },
    data: {
        bgSetting: [],
        setting: {},
        bgIcon: "sound",
        bgVolume: 0,
        userSettingClass: "big",
        showOverlay: !1,
        fullscreenStyle: ""
    },
    methods: {
        computeSettingBox: function() {
            var e = "big";
            t.globalData.ScreenHeight < 800 && (e = "small");
            var a = "height: 100vh; padding-top: ".concat(2 * t.globalData.CustomBar, "rpx");
            this.setData({
                userSettingClass: e,
                fullscreenStyle: this.properties.fullscreen ? a : ""
            });
        },
        updateSetting: function(t, a, o) {
            try {
                e(t, a, o);
            } catch (e) {
                console.log(e);
            }
        },
        onGuideVolumeChange: function(e) {
            var a = {
                guideVolume: e.detail
            };
            0 === e.detail && "mute" !== this.data.guideIcon ? a.guideIcon = "mute" : 0 !== e.detail && "mute" === this.data.guideIcon && (a.guideIcon = "sound"), 
            t.userSetting.guideVolume = e.detail, this.setData(a), this.updateSetting(0, this.data.bgVolume, e.detail);
        },
        onBgVolumeChange: function(e) {
            var a = e.detail;
            t.setBgVolume(a);
            var o = {
                bgVolume: a
            };
            0 === a && "mute" !== this.data.bgIcon ? o.bgIcon = "mute" : 0 !== a && "mute" === this.data.bgIcon && (o.bgIcon = "sound"), 
            this.setData(o);
        },
        chooseBg: function(e) {
            var a = e.currentTarget.dataset, o = a.bgid, i = a.vip;
            if (0 !== o && o !== this.data.setting.bgID) if (i && 0 === t.globalData.userInfo.level) wx.navigateTo({
                url: "/pages/goods/goods"
            }); else {
                t.updateBgSetting(o), this.setData({
                    setting: t.getUserSetting(),
                    hideBgPlayIcon: !0
                }), this.triggerEvent("on-bg-change");
                var n = "";
                switch (o) {
                  case 1:
                    n = "Rain";
                    break;

                  case 2:
                    n = "Wave";
                    break;

                  case 3:
                    n = "Forest";
                    break;

                  case 4:
                    n = "Bonfire";
                }
                wx.reportAnalytics("user_click", {
                    uid: t.globalData.userInfo.id,
                    button_name: n,
                    type: "设置背景"
                });
            }
        },
        stopScroll: function() {},
        show: function() {
            this.computeSettingBox();
            for (var e = t.getUserSetting(), a = [], o = [], i = t.bgSetting, n = 0, s = 0; s < i.length; s++) n++, 
            o.push(i[s]), 3 === n && (a.push(o), o = [], n = 0);
            i.length % 3 != 0 && a.push(o), this.setData({
                setting: e,
                showOverlay: !0,
                bgSetting: a,
                bgVolume: e.bgVolume,
                bgIcon: 0 === e.bgVolume ? "mute" : "sound",
                guideVolume: e.guideVolume
            });
        },
        close: function() {
            this.setData({
                showOverlay: !1
            }), this.triggerEvent("on-close");
        }
    }
});