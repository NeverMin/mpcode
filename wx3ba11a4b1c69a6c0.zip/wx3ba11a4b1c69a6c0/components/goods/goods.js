var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = getApp(), r = require("../../api/goods.js"), n = r.getGoodsList, o = r.createOrder, s = r.getPayResult, i = (0, 
require("../../utils/util").doubleClick)();

Component({
    properties: {
        pagetype: {
            type: String,
            value: ""
        }
    },
    data: {
        goods: [],
        show: !1,
        choosed: 1,
        loading: !1
    },
    attached: function() {
        var e = this;
        n().then(function(t) {
            if (0 == t.meta.code) {
                if (t.data.length < 3) for (;3 - t.data.length > 0; ) t.data.push({});
                e.setData({
                    goods: t.data
                });
            }
        });
    },
    methods: {
        doCreateOrder: function() {
            var r = this;
            return t(e.default.mark(function t() {
                var n, u;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (i()) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return");

                      case 2:
                        return r.setData({
                            loading: !0
                        }), n = r, e.prev = 4, e.next = 7, o(r.data.goods[r.data.choosed].id);

                      case 7:
                        0 == (u = e.sent).meta.code && wx.requestPayment({
                            nonceStr: u.data.nonceStr,
                            package: u.data.package,
                            paySign: u.data.paySign,
                            timeStamp: u.data.timestamp,
                            signType: u.data.signType,
                            success: function(e) {
                                var t = setInterval(function() {
                                    s(u.data.order_code).then(function(e) {
                                        0 == e.meta.code ? 1 == e.data.status && (clearInterval(t), n.close(), a.globalData.userInfo.level = e.data.level, 
                                        a.globalData.userInfo.vip_expire_date = e.data.vip_expire_date, a.store.emit(a.events.levelUp, e.data)) : wx.showToast({
                                            title: e.meta.message,
                                            icon: "none"
                                        });
                                    });
                                }, 2e3);
                            },
                            fail: function(e) {
                                n.setData({
                                    loading: !1
                                }), wx.showToast({
                                    title: "取消支付",
                                    icon: "none"
                                });
                            }
                        }), wx.reportAnalytics("user_click", {
                            uid: a.globalData.userInfo.id,
                            button_name: "会员购买",
                            type: r.properties.pagetype
                        }), e.next = 15;
                        break;

                      case 12:
                        e.prev = 12, e.t0 = e.catch(4), console.log(e.t0);

                      case 15:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 4, 12 ] ]);
            }))();
        },
        choose: function(e) {
            this.setData({
                choosed: e.currentTarget.dataset.index
            }), wx.reportAnalytics("user_click", {
                uid: a.globalData.userInfo.id,
                button_name: "PurchaseSourse",
                type: this.properties.pagetype
            });
        },
        show: function() {
            a.isReleased() && this.setData({
                show: !0
            });
        },
        close: function(e) {
            e && e.currentTarget && "tapclose" == e.currentTarget.dataset.event && a.store.emit("unbuy", "notpay"), 
            this.setData({
                show: !1,
                loading: !1
            });
        }
    }
});