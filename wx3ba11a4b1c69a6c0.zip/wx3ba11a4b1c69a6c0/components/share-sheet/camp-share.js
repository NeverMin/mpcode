var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../api/camp.js"), a = require("wx-canvas-2d"), n = require("../../utils/util.js"), s = n.currentYearDateObject, o = n.zoomCanvasDrawInfoSeries, i = getApp(), u = require("../../utils/poster_extend.js"), c = s();

a.WxCanvas2d.use(a.SaveToAlbum), a.WxCanvas2d.use(u);

var l = new a.WxCanvas2d();

Component({
    properties: {
        campId: {
            type: Number,
            default: -1
        },
        show: {
            type: Boolean,
            default: !1
        },
        canvasId: {
            type: String,
            default: ""
        }
    },
    data: {
        loading: !1,
        showShareButton: !1,
        postGenerated: !1,
        shareTmpImage: "",
        banner: {},
        lesson: {}
    },
    methods: {
        getCampShareMeta: function(a) {
            var n = this;
            return t(e.default.mark(function t() {
                var s, o;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, e.next = 3, (0, r.getCampShareMeta)(a);

                      case 3:
                        s = e.sent, o = s.data, 0 === s.meta.code ? (o.study_duration = parseInt(o.study_duration / 60), 
                        n.setData({
                            banner: o,
                            lesson: o.lesson
                        })) : wx.showToast({
                            title: "订阅失败",
                            icon: "none"
                        }), e.next = 12;
                        break;

                      case 9:
                        e.prev = 9, e.t0 = e.catch(0), console.error("getCampShareMeta: ", e.t0);

                      case 12:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 0, 9 ] ]);
            }))();
        },
        show: function() {
            var r = this;
            return t(e.default.mark(function t() {
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (0 !== Object.keys(r.data.banner).length) {
                            e.next = 3;
                            break;
                        }
                        return e.next = 3, r.getCampShareMeta(r.properties.campId);

                      case 3:
                        l.create({
                            query: ".".concat(r.properties.canvasId),
                            rootWidth: 1500
                        }), r.setData({
                            showShareButton: !0
                        });

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        hide: function() {
            this.setData({
                showShareButton: !1
            });
        },
        closeShareButton: function() {
            this.setData({
                showShareButton: !1
            });
        },
        openShareButton: function() {
            var r = this;
            return t(e.default.mark(function a() {
                return e.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (!r.data.loading) {
                            a.next = 2;
                            break;
                        }
                        return a.abrupt("return");

                      case 2:
                        if (r.setData({
                            loading: !0
                        }), a.prev = 3, r.triggerEvent("load"), r.data.postGenerated) {
                            a.next = 10;
                            break;
                        }
                        return a.next = 8, new Promise(function(a, n) {
                            i.getShareQrcode(function() {
                                var s = t(e.default.mark(function t(s, o) {
                                    var i;
                                    return e.default.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            if (o) {
                                                e.next = 6;
                                                break;
                                            }
                                            return console.log("分享二维码下载失败"), r.setData({
                                                loading: !1
                                            }), r.triggerEvent("finish"), a(), e.abrupt("return");

                                          case 6:
                                            return e.prev = 6, e.next = 9, r.createPoster(s);

                                          case 9:
                                            if (!(i = e.sent)) {
                                                e.next = 14;
                                                break;
                                            }
                                            return e.next = 13, r.saveSharePost();

                                          case 13:
                                            r.setData({
                                                shareTmpImage: i,
                                                postGenerated: !0,
                                                loading: !1
                                            });

                                          case 14:
                                            a(), e.next = 20;
                                            break;

                                          case 17:
                                            e.prev = 17, e.t0 = e.catch(6), n(e.t0);

                                          case 20:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, t, null, [ [ 6, 17 ] ]);
                                }));
                                return function(e, t) {
                                    return s.apply(this, arguments);
                                };
                            }());
                        });

                      case 8:
                        a.next = 13;
                        break;

                      case 10:
                        return a.next = 12, r.saveSharePost();

                      case 12:
                        r.triggerEvent("finish");

                      case 13:
                        a.next = 19;
                        break;

                      case 15:
                        a.prev = 15, a.t0 = a.catch(3), wx.showToast({
                            title: "捕获画图错误",
                            icon: "none"
                        }), console.log("捕获画图错误", a.t0);

                      case 19:
                        r.triggerEvent("finish"), r.setData({
                            loading: !1
                        });

                      case 21:
                      case "end":
                        return a.stop();
                    }
                }, a, null, [ [ 3, 15 ] ]);
            }))();
        },
        saveSharePost: function() {
            return t(e.default.mark(function t() {
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, e.next = 3, l.save({
                            destWidth: 1500,
                            destHeight: 2668
                        });

                      case 3:
                        wx.showToast({
                            title: "分享图已保存至系统相册，快去分享给朋友吧",
                            icon: "none"
                        }), e.next = 9;
                        break;

                      case 6:
                        e.prev = 6, e.t0 = e.catch(0), console.error(e.t0);

                      case 9:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 0, 6 ] ]);
            }))();
        },
        createPoster: function(r) {
            var n = this;
            return t(e.default.mark(function t() {
                var s, u, h, p;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return s = n.data.lesson, u = s.img, h = s.title, p = s.share_info, e.next = 3, 
                        l.draw({
                            series: o([ {
                                type: a.Image,
                                url: u,
                                x: 0,
                                y: 0,
                                width: 500,
                                height: 667,
                                mode: "aspectFill",
                                radius: 0,
                                zIndex: 0
                            }, {
                                type: a.Image,
                                url: "https://cdn.heartlylab.com/heartlylab/imgs/share_logo.png",
                                width: 158,
                                height: 45.38,
                                x: 20,
                                y: 30
                            }, {
                                type: a.Rect,
                                x: 302.52,
                                y: 30,
                                width: 52.48,
                                height: 64,
                                lineStyle: {
                                    color: "#fff",
                                    width: 2
                                },
                                zIndex: 0,
                                radius: 10
                            }, {
                                type: a.Text,
                                text: c.year,
                                color: "rgba(250,250,246,0.8)",
                                fontSize: 14,
                                width: 34.56,
                                align: "center",
                                x: 311.48,
                                y: 35.12,
                                lineHeight: 20,
                                ellipsis: 1
                            }, {
                                type: a.Text,
                                text: "/",
                                color: "rgba(250,250,246,0.8)",
                                fontSize: 14,
                                width: 7.68,
                                align: "center",
                                x: 324.28,
                                y: 58.16,
                                lineHeight: 8,
                                ellipsis: 1
                            }, {
                                type: a.Text,
                                text: c.month + "." + c.day,
                                color: "rgba(250,250,246,0.8)",
                                fontSize: 14,
                                width: 38.4,
                                align: "center",
                                x: 308.92,
                                y: 68.4,
                                lineHeight: 20,
                                ellipsis: 1
                            }, {
                                type: a.Image,
                                url: "https://heartlylab.holdno.com/heartlylab/icon/share_page_icon.png",
                                x: 143,
                                y: 220,
                                width: 88,
                                height: 88
                            }, {
                                type: a.Text,
                                text: "#每日冥想: " + h,
                                color: "rgba(250,250,246,0.8)",
                                fontSize: 12,
                                width: 335,
                                x: 20,
                                y: 443,
                                lineHeight: 18,
                                ellipsis: 1
                            }, {
                                type: a.Text,
                                text: p,
                                color: "#fff",
                                fontSize: 16,
                                width: 335,
                                x: 20,
                                y: 465,
                                lineHeight: 24,
                                ellipsis: 3
                            }, {
                                type: a.Rect,
                                x: 0,
                                y: 547,
                                width: 375,
                                height: 120,
                                bgColor: "#fff",
                                lineStyle: {
                                    color: "#fff",
                                    width: 0
                                },
                                zIndex: 0
                            }, {
                                type: a.Image,
                                url: i.globalData.userInfo.avatar,
                                width: 51,
                                height: 51,
                                x: 20,
                                y: 582,
                                radius: 25
                            }, {
                                type: a.Text,
                                text: i.globalData.userInfo.name,
                                color: "#000",
                                fontSize: 16,
                                x: 79,
                                y: 582,
                                lineHeight: 24
                            }, {
                                type: a.Text,
                                text: "累计冥想 " + n.data.banner.total_study_days + " 天",
                                color: "#878792",
                                fontSize: 14,
                                x: 79,
                                y: 610,
                                lineHeight: 20
                            }, {
                                type: a.Image,
                                url: r,
                                width: 76,
                                height: 76,
                                x: 275,
                                y: 569
                            } ], 4)
                        });

                      case 3:
                        return e.prev = 3, e.next = 6, l.getTmpPath({
                            destWidth: 1500,
                            destHeight: 2668
                        });

                      case 6:
                        return e.abrupt("return", e.sent);

                      case 9:
                        e.prev = 9, e.t0 = e.catch(3), console.error(e.t0);

                      case 12:
                        return e.abrupt("return", null);

                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 3, 9 ] ]);
            }))();
        },
        backToCamp: function() {
            this.triggerEvent("backToCamp"), this.setData({
                showShareButton: !1
            });
        }
    }
});