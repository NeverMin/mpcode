Component({
    properties: {
        height: {
            type: Number,
            default: 183
        },
        size: {
            type: String,
            default: "normal"
        },
        list: {
            type: Array,
            default: function() {
                return [];
            },
            observer: function(t) {
                var e = 0;
                t.forEach(function(t) {
                    t.count > e && (e = t.count);
                }), this.list = t.map(function(t) {
                    return t.percentage = t.count / e, t;
                }), this.setData({
                    finalData: this.list
                });
            }
        }
    },
    data: {
        finalData: []
    },
    methods: {}
});