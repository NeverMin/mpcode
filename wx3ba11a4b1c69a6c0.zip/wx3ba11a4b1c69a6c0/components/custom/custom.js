var t = getApp();

Component({
    options: {
        addGlobalClass: !0,
        multipleSlots: !0
    },
    properties: {
        hiddenContent: {
            type: Boolean,
            default: !1
        },
        bgColor: {
            type: String,
            default: ""
        },
        isCustom: {
            type: [ Boolean, String ],
            default: !1
        },
        isBack: {
            type: [ Boolean, String ],
            default: !1
        },
        bgImage: {
            type: String,
            default: ""
        },
        leftButton: {
            type: String,
            default: "black"
        },
        fixed: {
            type: Boolean,
            default: !1
        },
        leftTitle: {
            type: String,
            default: ""
        }
    },
    data: {
        StatusBar: t.globalData.StatusBar,
        CustomBar: t.globalData.CustomBar,
        Custom: t.globalData.Custom
    },
    methods: {
        BackPage: function() {
            1 != getCurrentPages().length ? wx.navigateBack({
                delta: 1
            }) : this.toHome();
        },
        toHome: function() {
            wx.switchTab({
                url: "/pages/index/index"
            });
        }
    }
});