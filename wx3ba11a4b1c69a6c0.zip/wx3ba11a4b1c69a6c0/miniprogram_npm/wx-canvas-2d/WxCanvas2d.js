function t(t) {
    return function(t) {
        if (Array.isArray(t)) return e(t);
    }(t) || function(t) {
        if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t);
    }(t) || function(t, n) {
        if (t) {
            if ("string" == typeof t) return e(t, n);
            var r = Object.prototype.toString.call(t).slice(8, -1);
            return "Object" === r && t.constructor && (r = t.constructor.name), "Map" === r || "Set" === r ? Array.from(t) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? e(t, n) : void 0;
        }
    }(t) || function() {
        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }();
}

function e(t, e) {
    (null == e || e > t.length) && (e = t.length);
    for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
    return r;
}

function n(t, e) {
    var n = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(t);
        e && (r = r.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
        })), n.push.apply(n, r);
    }
    return n;
}

function r(t) {
    for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2 ? n(Object(r), !0).forEach(function(e) {
            i(t, e, r[e]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r)) : n(Object(r)).forEach(function(e) {
            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(r, e));
        });
    }
    return t;
}

function i(t, e, n) {
    return e in t ? Object.defineProperty(t, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = n, t;
}

function o(t, e) {
    for (var n = 0; n < e.length; n++) {
        var r = e[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
        Object.defineProperty(t, r.key, r);
    }
}

var a = wx.getSystemInfoSync(), c = function() {
    function e() {
        (function(t, e) {
            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
        })(this, e), this.query = null, this.bgColor = null, this.radius = null, this.component = null, 
        this.canvas = null, this.canvasInfo = null, this.ctx = null, this.dpr = null, this.rootWidth = null, 
        this.fontFamily = "sans-serif", this.startTime = null, this.$listener = {};
    }
    return function(t, e, n) {
        e && o(t.prototype, e), n && o(t, n);
    }(e, [ {
        key: "canvasSize",
        get: function() {
            return {
                width: this.canvas.width / a.screenWidth / this.dpr * this.rootWidth,
                height: this.canvas.height / a.screenWidth / this.dpr * this.rootWidth
            };
        }
    }, {
        key: "queryCanvas",
        value: function() {
            var t = this;
            return new Promise(function(e, n) {
                (t.component || wx).createSelectorQuery().select(t.query).fields({
                    node: !0,
                    size: !0
                }).exec(function(r) {
                    r[0] ? e(r) : (t.debugLogout("找不到画布", "error"), n(r));
                });
            });
        }
    }, {
        key: "create",
        value: function(t) {
            var e = this;
            return new Promise(function(n, i) {
                var o = r({
                    query: "",
                    rootWidth: 375
                }, t);
                o.query || i(new Error("[WxCanvas2d] 'query' is empty.")), e.query = o.query, e.bgColor = o.bgColor, 
                e.component = o.component, e.radius = o.radius, e.queryCanvas().then(function(t) {
                    var r = t[0].node, i = r.getContext("2d"), c = a.pixelRatio;
                    e.canvas = r, e.canvasInfo = t, e.ctx = i, e.dpr = c, e.rootWidth = o.rootWidth, 
                    e.canvas.width = t[0].width * e.dpr, e.canvas.height = t[0].height * e.dpr, n();
                }).catch(function(t) {
                    i(t);
                });
            });
        }
    }, {
        key: "clear",
        value: function() {
            var t, e, n = [ 0, 0, this.xDpr(this.canvasSize.width), this.xDpr(this.canvasSize.height) ];
            (t = this.ctx).clearRect.apply(t, n), this.radius && (this.drawRectPath({
                x: 0,
                y: 0,
                width: this.canvasSize.width,
                height: this.canvasSize.height,
                radius: this.radius
            }), this.ctx.clip()), this.bgColor && (this.ctx.fillStyle = this.bgColor, (e = this.ctx).fillRect.apply(e, n));
        }
    }, {
        key: "xDpr",
        value: function(t) {
            return t * this.dpr * a.screenWidth / this.rootWidth;
        }
    }, {
        key: "draw",
        value: function(t) {
            var e = this;
            return new Promise(function(n, i) {
                e.startTime = Date.now();
                var o = t.series;
                e.queryCanvas().then(function(t) {
                    e.canvas.width = t[0].width * e.dpr, e.canvas.height = t[0].height * e.dpr, e.clear();
                    var a = o.map(function(t) {
                        return r(r({}, t), {}, {
                            zIndex: t.zIndex || 0
                        });
                    }).sort(function(t, e) {
                        return t.zIndex - e.zIndex;
                    });
                    e.debugLogout("开始绘制"), function t() {
                        var r = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 0, o = Date.now(), c = a[r];
                        if (e.ctx.save(), r < a.length) {
                            var s = c.type, u = (s = void 0 === s ? {} : s).name, h = s.handler;
                            u && "function" == typeof h ? (e.emit("beforeDraw", {
                                index: r,
                                config: c
                            }), h.call(e, c).then(function() {
                                e.debugLogout("绘制成功 - ".concat(u, " [").concat(r + 1, "/").concat(a.length, "] (").concat(Date.now() - o, "ms)")), 
                                e.emit("afterDraw", {
                                    index: r,
                                    config: c
                                }), t(++r);
                            }).catch(function(t) {
                                e.debugLogout("绘制失败"), e.emit("afterDraw", {
                                    index: r,
                                    config: c,
                                    error: t
                                }), i(t);
                            })) : (e.debugLogout("未知类型", "error"), t(++r));
                        } else e.debugLogout("绘制完成 (".concat(Date.now() - e.startTime, "ms)")), n();
                        e.ctx.restore();
                    }();
                }).catch(function(t) {
                    i(t);
                });
            });
        }
    }, {
        key: "drawRectPath",
        value: function(e) {
            var n = this, r = e.x, i = void 0 === r ? 0 : r, o = e.y, a = void 0 === o ? 0 : o, c = e.width, s = void 0 === c ? 0 : c, u = e.height, h = void 0 === u ? 0 : u, l = Math.min(s, h) / 2, f = Math.max(0, Math.min(e.radius || 0, l)), d = {
                top: 1.5 * Math.PI,
                right: 0,
                bottom: .5 * Math.PI,
                left: Math.PI
            }, p = [ [ d.left, d.top ], [ d.top, d.right ], [ d.right, d.bottom ], [ d.bottom, d.left ] ], v = [ [ i + f, a + f ].map(function(t) {
                return n.xDpr(t);
            }), [ i + s - f, a + f ].map(function(t) {
                return n.xDpr(t);
            }), [ i + s - f, a + h - f ].map(function(t) {
                return n.xDpr(t);
            }), [ i + f, a + h - f ].map(function(t) {
                return n.xDpr(t);
            }) ];
            this.ctx.beginPath(), Array(4).fill().forEach(function(e, r) {
                var i;
                (i = n.ctx).arc.apply(i, t(v[r]).concat([ n.xDpr(f) ], t(p[r])));
            }), this.ctx.closePath();
        }
    }, {
        key: "setLineStyle",
        value: function() {
            var t = this, e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {}, n = e.cap, r = void 0 === n ? "butt" : n, i = e.join, o = void 0 === i ? "bevel" : i, a = e.offset, c = void 0 === a ? 0 : a, s = e.dash, u = void 0 === s ? [ 1, 0 ] : s, h = e.color, l = void 0 === h ? "#000" : h, f = e.width, d = void 0 === f ? 2 : f;
            this.ctx.lineCap = r, this.ctx.setLineDash(u.map(function(e) {
                return t.xDpr(e);
            })), this.ctx.lineDashOffset = this.xDpr(c), this.ctx.lineJoin = o, this.ctx.lineWidth = this.xDpr(d), 
            this.ctx.strokeStyle = l;
        }
    }, {
        key: "debugLogout",
        value: function() {}
    }, {
        key: "on",
        value: function(t, e) {
            this.$listener[t] ? this.$listener[t].includes(e) || this.$listener[t].push(e) : this.$listener[t] = [ e ];
        }
    }, {
        key: "off",
        value: function(t, e) {
            var n = this, r = this.$listener[t];
            r && (e ? r.some(function(r, i) {
                return r === e && delete n.$listener[t][i];
            }) : delete this.$listener[t]);
        }
    }, {
        key: "emit",
        value: function(t, e) {
            Array.isArray(this.$listener[t]) && this.$listener[t].forEach(function(n) {
                return n(r({
                    event: t
                }, e));
            });
        }
    } ]), e;
}();

c.use = function() {
    var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
    t.name && t.handler && (c.prototype[t.name] = function() {
        for (var e, n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
        return (e = t.handler).call.apply(e, [ this ].concat(r));
    });
}, module.exports = c;