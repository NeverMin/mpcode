var r = require("../modules/stackblur-es.min.js");

module.exports = {
    name: "Blur",
    handler: function() {
        var i = this, e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
        return new Promise(function(n, o) {
            var s = e.x, t = void 0 === s ? 0 : s, v = e.y, a = void 0 === v ? 0 : v, d = e.width, u = void 0 === d ? 0 : d, l = e.height, c = void 0 === l ? 0 : l, h = e.blur, x = void 0 === h ? 0 : h;
            (0, r.canvasRGB)(i.canvas, i.xDpr(t), i.xDpr(a), i.xDpr(u), i.xDpr(c), x), n();
        });
    }
};