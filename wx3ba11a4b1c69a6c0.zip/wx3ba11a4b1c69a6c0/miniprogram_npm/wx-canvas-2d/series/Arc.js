module.exports = {
    name: "Arc",
    handler: function() {
        var e = this, r = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
        return new Promise(function(t, i) {
            var n = r.x, o = void 0 === n ? 0 : n, d = r.y, v = void 0 === d ? 0 : d, s = r.r, c = void 0 === s ? 0 : s, x = r.start, a = void 0 === x ? 0 : x, l = r.end, u = void 0 === l ? 0 : l, h = r.reverse, p = void 0 !== h && h, m = r.lineStyle;
            e.setLineStyle(m), e.ctx.beginPath(), e.ctx.arc(e.xDpr(o), e.xDpr(v), e.xDpr(c), a, u, p), 
            e.ctx.stroke(), t();
        });
    }
};