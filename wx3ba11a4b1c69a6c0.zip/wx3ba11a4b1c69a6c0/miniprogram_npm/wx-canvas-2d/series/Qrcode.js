var o = require("../modules/qrcode.min.js");

module.exports = {
    name: "Qrcode",
    handler: function() {
        var r = this, e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {}, i = e.text, d = void 0 === i ? "" : i, n = e.x, t = void 0 === n ? 0 : n, c = e.y, v = void 0 === c ? 0 : c, s = e.size, x = void 0 === s ? 0 : s, p = e.color, u = void 0 === p ? "#000" : p, a = e.bgColor, l = void 0 === a ? "#fff" : a, m = e.ecc, f = void 0 === m ? 2 : m;
        return new Promise(function(e, i) {
            o.api.draw(d, r.ctx, r.xDpr(t), r.xDpr(v), r.xDpr(x), r.xDpr(x), l, u, r.component, f), 
            e();
        });
    }
};