module.exports = {
    name: "Text",
    handler: function() {
        var t = this, i = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
        return new Promise(function(e, o) {
            var n = i.x, c = void 0 === n ? 0 : n, l = i.y, r = void 0 === l ? 0 : l, a = i.color, x = void 0 === a ? "#000" : a, d = i.fontSize, f = void 0 === d ? 12 : d, v = i.fontWeight, s = void 0 === v ? "" : v, h = i.width, g = void 0 === h ? 1 / 0 : h, p = i.baseline, u = void 0 === p ? "top" : p, m = i.align, S = void 0 === m ? "left" : m, D = i.text, w = void 0 === D ? "" : D, y = i.ellipsis, E = void 0 === y ? 0 : y, T = i.lineHeight, z = void 0 === T ? i.fontSize || 12 : T, b = 0, A = [];
            t.ctx.textAlign = S, t.ctx.textBaseline = u, t.ctx.fillStyle = x, t.ctx.font = "".concat(s, " ").concat(t.xDpr(f), "px ").concat(t.fontFamily), 
            [].concat(w).forEach(function(i, e) {
                var o = 0;
                String(i).split("").forEach(function(e, n) {
                    var c = String(i).slice(o, n + 1);
                    t.ctx.measureText(c).width < t.xDpr(g) ? A[b] = c : (A[b + 1] = e, o = n, b++);
                }), b++;
            }), E && A.length > E && ((A = A.slice(0, E))[E - 1] = A[E - 1].slice(0, -1) + "..."), 
            A.forEach(function(i, e) {
                t.ctx.fillText(i, t.xDpr({
                    left: c,
                    start: c,
                    right: c + g,
                    end: c + g,
                    center: c + g / 2
                }[S] || c), t.xDpr(r + z * e + (z - f) / 2));
            }), e();
        });
    }
};