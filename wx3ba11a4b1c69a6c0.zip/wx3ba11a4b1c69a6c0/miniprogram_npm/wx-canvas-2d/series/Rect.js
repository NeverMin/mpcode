module.exports = {
    name: "Rect",
    handler: function() {
        var t = this, i = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
        return new Promise(function(e, o) {
            var d = i.x, r = void 0 === d ? 0 : d, l = i.y, n = void 0 === l ? 0 : l, h = i.width, a = void 0 === h ? 0 : h, c = i.height, s = void 0 === c ? 0 : c, v = i.bgColor, u = void 0 === v ? "" : v, x = i.radius, m = void 0 === x ? 0 : x, y = i.lineStyle;
            m = Math.min(m, Math.min(a, s) / 2), t.setLineStyle(y), t.ctx.fillStyle = u, t.drawRectPath({
                x: r,
                y: n,
                width: a,
                height: s,
                radius: m
            }), y.color && t.ctx.stroke(), u && t.ctx.fill(), e();
        });
    }
};