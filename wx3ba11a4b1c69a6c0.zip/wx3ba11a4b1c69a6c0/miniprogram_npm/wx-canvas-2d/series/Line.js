function t(t) {
    return function(t) {
        if (Array.isArray(t)) return r(t);
    }(t) || function(t) {
        if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t);
    }(t) || function(t, n) {
        if (t) {
            if ("string" == typeof t) return r(t, n);
            var e = Object.prototype.toString.call(t).slice(8, -1);
            return "Object" === e && t.constructor && (e = t.constructor.name), "Map" === e || "Set" === e ? Array.from(t) : "Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? r(t, n) : void 0;
        }
    }(t) || function() {
        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }();
}

function r(t, r) {
    (null == r || r > t.length) && (r = t.length);
    for (var n = 0, e = new Array(r); n < r; n++) e[n] = t[n];
    return e;
}

module.exports = {
    name: "Line",
    handler: function() {
        var r = this, n = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
        return new Promise(function(e, o) {
            var i = n.lineStyle, a = n.line, u = void 0 === a ? [] : a;
            r.setLineStyle(i), u.forEach(function(n, e) {
                var o, i;
                e ? ((o = r.ctx).lineTo.apply(o, t(n.point.map(function(t) {
                    return r.xDpr(t);
                }))), r.ctx.stroke()) : (r.ctx.beginPath(), (i = r.ctx).moveTo.apply(i, t(n.point.map(function(t) {
                    return r.xDpr(t);
                }))));
            }), e();
        });
    }
};