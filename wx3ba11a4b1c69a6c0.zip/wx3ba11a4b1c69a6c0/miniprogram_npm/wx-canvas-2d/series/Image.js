function t(t) {
    return function(t) {
        if (Array.isArray(t)) return i(t);
    }(t) || function(t) {
        if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t);
    }(t) || function(t, e) {
        if (t) {
            if ("string" == typeof t) return i(t, e);
            var r = Object.prototype.toString.call(t).slice(8, -1);
            return "Object" === r && t.constructor && (r = t.constructor.name), "Map" === r || "Set" === r ? Array.from(t) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? i(t, e) : void 0;
        }
    }(t) || function() {
        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }();
}

function i(t, i) {
    (null == i || i > t.length) && (i = t.length);
    for (var e = 0, r = new Array(i); e < i; e++) r[e] = t[e];
    return r;
}

module.exports = {
    name: "Image",
    handler: function() {
        var i = this, e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
        return new Promise(function(r, o) {
            var h = e.url, n = void 0 === h ? "" : h, a = e.x, c = void 0 === a ? 0 : a, d = e.y, l = void 0 === d ? 0 : d, u = e.width, g = void 0 === u ? 0 : u, s = e.height, f = void 0 === s ? 0 : s, w = e.mode, p = void 0 === w ? "scaleToFill" : w, m = e.radius, v = void 0 === m ? 0 : m, y = i.canvas.createImage();
            y.src = n, y.onload = function() {
                wx.getImageInfo({
                    src: n,
                    success: function(e) {
                        var o, h = e.width, n = e.height, a = g / f, d = 1, u = 1;
                        "aspectFit" === p ? (d = e.width / e.height < a ? g / e.width * e.height / f : 1, 
                        u = e.width / e.height > a ? f / e.height * e.width / g : 1) : "aspectFill" === p && (d = e.width / e.height > a ? g / e.width * e.height / f : 1, 
                        u = e.width / e.height < a ? f / e.height * e.width / g : 1);
                        var s = {
                            scaleToFill: [ 0, 0, h, n ],
                            aspectFit: [ (e.width - e.width * d) / 2, (e.height - e.height * u) / 2, e.width * d, e.height * u ],
                            aspectFill: [ (e.width - e.width * d) / 2, (e.height - e.height * u) / 2, e.width * d, e.height * u ],
                            widthFix: [],
                            top: [ (h - g) / 2, 0, g, f ],
                            bottom: [ (h - g) / 2, n - f, g, f ],
                            center: [ (h - g) / 2, (n - f) / 2, g, f ],
                            left: [ 0, (n - f) / 2, g, f ],
                            right: [ h - g, (n - f) / 2, g, f ],
                            "top left": [ 0, 0, g, f ],
                            "top right": [ h - g, 0, g, f ],
                            "bottom left": [ 0, n - f, g, f ],
                            "bottom right": [ h - g, n - f, g, f ]
                        };
                        v && (i.ctx.save(), i.drawRectPath({
                            x: c,
                            y: l,
                            width: g,
                            height: f,
                            radius: v
                        }), i.ctx.clip()), (o = i.ctx).drawImage.apply(o, [ y ].concat(t(s[p] || []), [ i.xDpr(c) || 0, i.xDpr(l) || 0, i.xDpr(g || e.width), i.xDpr(f || e.height) ])), 
                        v && i.ctx.restore(), r();
                    },
                    fail: function(t) {
                        o(t);
                    }
                });
            }, y.onerror = function(t) {
                o(t);
            };
        });
    }
};