function e(e, t) {
    var r = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(e);
        t && (n = n.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), r.push.apply(r, n);
    }
    return r;
}

function t(e, t, r) {
    return t in e ? Object.defineProperty(e, t, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = r, e;
}

require("../../../@babel/runtime/helpers/Arrayincludes");

module.exports = {
    name: "save",
    handler: function(r) {
        var n = this;
        return new Promise(function(o, i) {
            var c = function(r) {
                for (var n = 1; n < arguments.length; n++) {
                    var o = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? e(Object(o), !0).forEach(function(e) {
                        t(r, e, o[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(o)) : e(Object(o)).forEach(function(e) {
                        Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(o, e));
                    });
                }
                return r;
            }({
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                destWidth: 0,
                destHeight: 0,
                modalOption: {}
            }, r);
            wx.canvasToTempFilePath({
                x: c.x,
                y: c.y,
                width: c.width,
                height: c.height,
                destWidth: n.xDpr(c.destWidth),
                destHeight: n.xDpr(c.destHeight),
                canvas: n.canvas,
                success: function(e) {
                    var t = e.tempFilePath;
                    (function(e) {
                        return new Promise(function(t, r) {
                            wx.getSetting({
                                success: function(r) {
                                    var n = function(e) {
                                        return {
                                            settings: r,
                                            code: e
                                        };
                                    };
                                    void 0 !== r.authSetting["scope." + e] && !0 !== r.authSetting["scope." + e] ? t(n(1)) : void 0 === r.authSetting["scope." + e] ? t(n(2)) : t(n(3));
                                },
                                fail: function(e) {
                                    r(e);
                                }
                            });
                        });
                    })("writePhotosAlbum").then(function(e) {
                        1 === e.code ? wx.showModal({
                            title: c.modalOption.title || "获取权限",
                            content: c.modalOption.content || "请前往开启相册权限",
                            success: c.modalOption.success || function(e) {
                                e.confirm ? (wx.openSetting(), n.debugLogout("用户前往授权页", "error"), i(Error("用户前往授权页"))) : e.cancel && (n.debugLogout("用户拒绝授权", "error"), 
                                i(Error("用户拒绝授权")));
                            }
                        }) : [ 2, 3 ].includes(e.code) && function(e) {
                            return new Promise(function(t, r) {
                                wx.saveImageToPhotosAlbum({
                                    filePath: e,
                                    success: function(e) {
                                        t();
                                    },
                                    fail: function(e) {
                                        r(e);
                                    }
                                });
                            });
                        }(t).then(function(e) {
                            n.debugLogout("保存图片到相册成功"), o();
                        }).catch(function() {
                            n.debugLogout("保存图片到相册失败", "error"), i(Error("保存图片到相册失败"));
                        });
                    }).catch(function() {
                        n.debugLogout("获取设置信息失败", "error"), i(Error("获取设置信息失败"));
                    });
                },
                fail: function() {
                    n.debugLogout("生成图片失败", "error"), i(Error("生成图片失败"));
                }
            });
        });
    }
};