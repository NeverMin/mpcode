var e = function() {
    return (e = Object.assign || function(e) {
        for (var t, n = 1, o = arguments.length; n < o; n++) for (var r in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
        return e;
    }).apply(this, arguments);
};

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = {
    selector: "#van-notify",
    type: "danger",
    message: "",
    background: "",
    duration: 3e3,
    zIndex: 110,
    top: 0,
    color: require("../common/color").WHITE,
    safeAreaInsetTop: !1,
    onClick: function() {},
    onOpened: function() {},
    onClose: function() {}
};

function n(e) {
    return null == e ? {} : "string" == typeof e ? {
        message: e
    } : e;
}

function o() {
    var e = getCurrentPages();
    return e[e.length - 1];
}

function r(r) {
    var c = ((r = e(e({}, t), n(r))).context || o()).selectComponent(r.selector);
    if (delete r.context, delete r.selector, c) return c.setData(r), c.show(), c;
    console.warn("未找到 van-notify 节点，请确认 selector 及 context 是否正确");
}

exports.default = r, r.clear = function(r) {
    var c = ((r = e(e({}, t), n(r))).context || o()).selectComponent(r.selector);
    c && c.hide();
};