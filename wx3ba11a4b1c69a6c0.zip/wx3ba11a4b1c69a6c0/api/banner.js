var t = require("../utils/request").request;

module.exports = {
    getBanner: function(e) {
        return t({
            url: "/api/v1/banner",
            method: "get",
            data: {
                position: e
            }
        });
    },
    getBannerList: function(e) {
        return t({
            url: "/api/v2/banner/list",
            method: "get",
            data: {
                position: e
            }
        });
    }
};