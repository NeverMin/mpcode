var t = require("../utils/request").request;

module.exports = {
    getInvitationStat: function() {
        return t({
            url: "/api/v1/user/invitation/stat",
            method: "get"
        });
    },
    getInvitationList: function(e, i) {
        return t({
            url: "/api/v1/user/invitation/list",
            method: "get",
            data: {
                page: e,
                pagesize: i
            }
        });
    }
};