var e = require("../utils/request").request;

module.exports = {
    createUserLessonScore: function(r) {
        return e({
            url: "/api/v1/user/score/create",
            method: "post",
            data: r
        });
    },
    getUserLessonStudyScore: function(r) {
        return e({
            url: "/api/v1/user/score/lesson/list",
            method: "get",
            data: r
        });
    }
};