var e = require("../utils/request").request;

module.exports = {
    getAccountQrcodeAddress: function() {
        return e({
            url: "/api/v1/wechat_account/qrcode/address",
            method: "get"
        });
    },
    getDiscover: function(t) {
        return e({
            url: "/api/v2/discover",
            method: "get",
            data: t
        });
    },
    getEveryDay: function() {
        return e({
            url: "/api/v1/every_day",
            method: "get"
        });
    },
    getEveryDayV2: function() {
        return e({
            url: "/api/v2/every_day",
            method: "get"
        });
    },
    getCourseRecommend: function(t) {
        return e({
            url: "/api/v1/course/recommend",
            method: "post",
            header: {
                "content-type": "application/json;charset=UTF-8"
            },
            data: {
                filters: t
            }
        });
    },
    getPopupList: function() {
        return e({
            url: "/api/v1/popup/list",
            method: "get",
            data: {
                platform: "miniprogram"
            }
        });
    },
    getThemedPage: function(t, r) {
        var o = {};
        return t && (o.id = Number(t)), r && (o.flag = r), e({
            url: "/api/v1/themed_page",
            method: "get",
            data: o
        });
    }
};