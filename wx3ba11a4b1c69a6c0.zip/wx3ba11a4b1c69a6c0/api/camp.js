var t = require("../utils/request").request;

module.exports = {
    getCampList: function(a, e) {
        return t({
            url: "/api/v1/camp/list",
            method: "get",
            data: {
                page: a,
                pagesize: e
            }
        });
    },
    getCampdetail: function(a) {
        return t({
            url: "/api/v1/camp/detail",
            method: "get",
            data: {
                id: a
            }
        });
    },
    getCampParts: function(a) {
        return t({
            url: "/api/v1/camp/parts",
            method: "get",
            data: {
                camp_id: a
            }
        });
    },
    getCampPartGuided: function(a) {
        return t({
            url: "/api/v1/camp/sub_part/guided",
            method: "get",
            data: {
                sub_part_id: a
            }
        });
    },
    getCampPartAction: function(a) {
        return t({
            url: "/api/v1/camp/sub_part/action",
            method: "get",
            data: {
                sub_part_id: a
            }
        });
    },
    getCampPartFurther: function(a) {
        return t({
            url: "/api/v1/camp/part/further",
            method: "get",
            data: {
                part_id: a
            }
        });
    },
    createCampOrder: function(a) {
        return t({
            url: "/api/v1/camp/order/create",
            method: "post",
            data: {
                camp_id: a,
                type: "JSAPI"
            }
        });
    },
    getCampPayResult: function(a) {
        return t({
            url: "/api/v1/camp/pay/result",
            method: "get",
            data: {
                order_code: a
            }
        });
    },
    getCampQa: function(a, e) {
        return t({
            url: "/api/v1/camp/sub_part/qa",
            method: "get",
            data: {
                sub_part_id: a,
                lesson_id: e
            }
        });
    },
    getCampAnswerDetail: function(a) {
        return t({
            url: "/api/v1/camp/sub_part/answer/detail",
            method: "get",
            data: {
                id: a
            }
        });
    },
    submitCampAnswer: function(a) {
        return t({
            url: "/api/v1/camp/sub_part/answer",
            method: "post",
            header: {
                "content-type": "application/json;charset=UTF-8"
            },
            data: {
                sub_part_id: a.part_id,
                camp_id: a.camp_id,
                answer: a.answer,
                q_id: a.id
            }
        });
    },
    updateCampAnswer: function(a, e) {
        return t({
            url: "/api/v1/camp/sub_part/answer/update",
            method: "post",
            header: {
                "content-type": "application/json;charset=UTF-8"
            },
            data: {
                id: a,
                answers: e || []
            }
        });
    },
    submitCampStepReport: function(a, e, r) {
        return t({
            url: "/api/v1/camp/step/report",
            method: "post",
            data: {
                camp_id: a,
                sub_part_id: e,
                current_step: r
            }
        });
    },
    submitCampPartFinished: function(a) {
        return t({
            url: "/api/v1/camp/sub_part/finished",
            method: "post",
            data: {
                sub_part_id: a
            }
        });
    },
    getCampShareMeta: function(a) {
        return t({
            url: "/api/v1/camp/sub_part/share/meta",
            method: "get",
            data: {
                sub_part_id: a
            }
        });
    }
};