var e = require("../utils/request").request;

module.exports = {
    getColumnList: function(t, u, r) {
        return e({
            url: "/api/v1/course/column/list",
            method: "get",
            data: {
                type: t,
                page: u,
                pagesize: r
            }
        });
    }
};