var e = require("../utils/request").request;

module.exports = {
    getPayResult: function(t) {
        return e({
            url: "/api/v1/goods/order/pay_result",
            method: "get",
            data: {
                order_code: t
            }
        });
    },
    getGoodsList: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 3;
        return e({
            url: "/api/v1/goods/list",
            method: "get",
            data: {
                page: t,
                pagesize: r
            }
        });
    },
    createOrder: function(t) {
        return e({
            url: "/api/v1/goods/order/create",
            method: "post",
            data: {
                goods_id: t
            }
        });
    }
};