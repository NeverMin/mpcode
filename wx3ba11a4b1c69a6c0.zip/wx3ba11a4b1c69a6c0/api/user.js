var e = require("../@babel/runtime/helpers/typeof"), t = require("../utils/request"), r = t.request, n = t.gateRequest;

module.exports = {
    studyInfo: function() {
        return r({
            url: "/api/v1/user/study/info",
            method: "get"
        });
    },
    delegateMessage: function(t) {
        return "object" !== e(t) && (t = [ t ]), r({
            url: "/api/v1/user/message/delegate",
            method: "post",
            header: {
                "content-type": "application/json;charset=UTF-8"
            },
            data: {
                accepts: t
            }
        });
    },
    studyEndShare: function() {
        return r({
            url: "/api/v1/user/study/ending_share",
            method: "get"
        });
    },
    getVipInfo: function() {
        return r({
            url: "/api/v1/user/vip/info",
            method: "get"
        });
    },
    login: function(e, t, n) {
        return r({
            url: "/api/v1/user/login",
            method: "post",
            data: {
                code: e,
                appid: t,
                source: n
            }
        });
    },
    register: function(e, t, n, o, a, u) {
        return r({
            url: "/api/v1/user/register",
            method: "post",
            data: {
                name: e,
                sex: t,
                head: n,
                home: o,
                inviter: a,
                gio_link_id: u
            }
        });
    },
    getPhoneNumberV2: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return r({
            url: "/api/v1/user/getphonev2",
            method: "post",
            data: {
                code: e,
                inviter: "number" == typeof t || t ? t : 0
            }
        });
    },
    getPhoneNumber: function(e, t, n) {
        return r({
            url: "/api/v1/user/phone",
            method: "post",
            data: {
                encrypted_data: e,
                iv: t,
                inviter: n
            }
        });
    },
    isFollow: function(e) {
        return r({
            url: "/api/v1/user/is_follow",
            method: "get",
            data: {
                lesson_id: e
            }
        });
    },
    follow: function(e) {
        return r({
            url: "/api/v1/user/follow",
            method: "post",
            data: {
                lesson_id: e
            }
        });
    },
    receiveVIP: function() {
        return r({
            url: "/api/v1/user/vip/receive",
            method: "post"
        });
    },
    getFollowList: function(e, t) {
        return r({
            url: "/api/v1/user/follow/list",
            method: "get",
            data: {
                page: e,
                pagesize: t,
                version: 1
            }
        });
    },
    getAgreement: function(e) {
        return r({
            url: "/api/v1/user/agreement/".concat(e),
            method: "get",
            data: {}
        });
    },
    getEndOfYear2022PartOne: function() {
        return n({
            url: "/micro/heartlylab/activity/EndOfYear2022/GenUserPartOne",
            method: "post",
            data: {}
        });
    },
    getEndOfYear2022PartTwo: function() {
        return n({
            url: "/micro/heartlylab/activity/EndOfYear2022/GenUserPartTwo",
            method: "post",
            data: {}
        });
    },
    getEndOfYear2022PartThree: function() {
        return n({
            url: "/micro/heartlylab/activity/EndOfYear2022/GenUserPartThree",
            method: "post",
            data: {}
        });
    }
};