var e = require("../utils/request").request;

module.exports = {
    getWeekActivity: function() {
        return e({
            url: "/api/v1/week_activity/detail",
            method: "get"
        });
    },
    joinWeekActivity: function(t) {
        return e({
            url: "/api/v1/week_activity/join",
            method: "post",
            data: {
                activity_id: t
            }
        });
    },
    receiveWeekActivityAward: function(t) {
        return e({
            url: "/api/v1/week_activity/receive_award",
            method: "post",
            data: {
                task_id: t
            }
        });
    },
    checkUnread: function() {
        return e({
            url: "/api/v1/user/unread",
            method: "get",
            data: {
                type: "week_activity"
            }
        });
    },
    reportUnread: function() {
        return e({
            url: "/api/v1/user/report/unread",
            method: "post",
            data: {
                type: "week_activity"
            }
        });
    }
};