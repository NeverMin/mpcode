var e = require("../utils/request").request;

module.exports = {
    getPageData: function(t, r, s) {
        return e({
            url: "/api/v1/course/list",
            method: "get",
            data: {
                page_type: t,
                page: r,
                pagesize: s
            }
        });
    },
    getCouseLessons: function(t, r, s) {
        return e({
            url: "/api/v2/course/detail",
            method: "get",
            data: {
                course_id: t,
                page: r,
                pagesize: s
            }
        });
    },
    getLessonDetail: function(t) {
        return e({
            url: "/api/v1/course/lesson/detail",
            method: "get",
            data: {
                id: t
            }
        });
    },
    getLessonStudyRecord: function(t, r) {
        return e({
            url: "/api/v1/course/lesson/user/study/record",
            method: "get",
            data: {
                page: t,
                pagesize: r
            }
        });
    },
    reportStudyRecord: function(t, r, s, u) {
        return e({
            url: "/api/v1/course/lesson/study_record/report",
            method: "post",
            data: {
                lesson_id: t,
                is_finished: r,
                latest_second: s,
                duration: u
            }
        });
    },
    getColumnCourseLessons: function(t, r, s) {
        return e({
            url: "/api/v1/course/column_course/course_lesson_list",
            method: "get",
            data: {
                column_id: t,
                page: r,
                pagesize: s
            }
        });
    },
    getSimilarLesson: function(t, r) {
        return e({
            url: "/api/v1/course/similar/lesson",
            method: "get",
            data: {
                course_id: t,
                lesson_id: r
            }
        });
    },
    getColumnCourseList: function(t, r, s) {
        return e({
            url: "/api/v1/course/column_course/list",
            method: "get",
            data: {
                column_id: t,
                page: r,
                pagesize: s
            }
        });
    },
    reportFinishedLesson: function(t) {
        return e({
            url: "/api/v1/user/data/report/finished_lesson",
            method: "post",
            data: {
                lesson_id: t
            }
        });
    },
    getSearchList: function(t, r, s) {
        return e({
            url: "/api/v1/search",
            method: "get",
            data: {
                q: t,
                type: 1,
                page: r,
                pagesize: s
            }
        });
    },
    getSearchPopularList: function() {
        return e({
            url: "/api/v1/search/popular",
            method: "get"
        });
    },
    getSimilarList: function(t) {
        return e({
            url: "/api/v1/course/similar",
            method: "get",
            data: {
                course_id: t
            }
        });
    },
    getSkillOtherCourses: function(t, r) {
        return e({
            url: "/api/v1/course/skill/other_courses",
            method: "get",
            data: {
                current_course_id: t,
                skill_id: r
            }
        });
    },
    getCourseCurrentStudyUsers: function(t) {
        return e({
            url: "/api/v1/course/current_study_users",
            method: "get",
            data: {
                course_id: t
            }
        });
    }
};