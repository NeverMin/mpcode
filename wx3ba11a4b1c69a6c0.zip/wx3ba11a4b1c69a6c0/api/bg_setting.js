var t = require("../utils/request").request;

module.exports = {
    bgList: function() {
        return t({
            url: "/api/v1/bg/list",
            method: "get"
        });
    },
    updateBgSetting: function(e, u, r) {
        return t({
            url: "/api/v1/user/setting/update",
            method: "post",
            data: {
                bg_id: e,
                bg_volume: u,
                guide_volume: r
            }
        });
    }
};