var e = require("../utils/request").request;

module.exports = {
    getGiftCodeRecordInfo: function(t) {
        return e({
            url: "/api/v1/gift/code/info",
            method: "get",
            data: {
                code: t
            }
        });
    },
    exchangeGiftCode: function(t) {
        return e({
            url: "/api/v1/gift/code/exchange",
            method: "post",
            data: {
                code: t
            }
        });
    },
    getGiftCodeInfoByOrderCode: function(t) {
        return e({
            url: "/api/v1/gift/gift_code_by_order",
            method: "get",
            data: {
                order_code: t
            }
        });
    }
};