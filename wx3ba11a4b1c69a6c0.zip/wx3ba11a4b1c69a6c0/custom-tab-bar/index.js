var e = getApp(), a = require("../utils/gio-minp/index.js").default;

Component({
    options: {
        addGlobalClass: !0,
        multipleSlots: !0
    },
    data: {
        selected: 0,
        color: "rgba(250, 250, 246, 0.45)",
        selectedColor: "#fff",
        tabBarList: [],
        hideTabbar: !1
    },
    attached: function() {
        var e = this;
        wx.getSystemInfo({
            success: function(a) {
                for (var t = a.model, s = !1, o = [ "X", "11", "12", "13", "14" ], n = 0; n < o.length; n++) if (-1 != t.search(o[n])) {
                    s = !0;
                    break;
                }
                e.setData({
                    isIphoneX: s
                }), e.reloadTabBar();
            }
        });
    },
    methods: {
        switchTab: function(t) {
            var s = t.currentTarget.dataset;
            wx.reportAnalytics("user_click", {
                uid: e.globalData.userInfo.id,
                button_name: s.tabName,
                type: "首页"
            }), a("track", "ClickTab", {
                pageTitle: s.tabName,
                userID: e.globalData.userInfo.id
            });
            var o = s.path;
            "/pages/tabBar/user/center" == o && e.needRegister() || (wx.switchTab({
                url: o
            }), this.setData({
                selected: s.index
            }));
        },
        reloadTabBar: function() {
            this.setData({
                tabBarList: [ {
                    pagePath: "/pages/index/index",
                    iconPath: "/images/icons/home_normal.png",
                    selectedIconPath: "/images/icons/home_selected.png",
                    text: "发现",
                    tabName: "HomePage"
                }, {
                    pagePath: "/pages/tabBar/exercise/exercise",
                    iconPath: "/images/icons/theory_normal.png",
                    selectedIconPath: "/images/icons/theory_selected.png",
                    text: "冥想",
                    tabName: "Thoery"
                }, {
                    pagePath: "/pages/tabBar/square/square",
                    iconPath: "/images/icons/square_normal.png",
                    selectedIconPath: "/images/icons/square_selected.png",
                    text: "广场",
                    tabName: "Square",
                    showBadge: e.globalData.showBadge.square || !1
                }, {
                    pagePath: "/pages/tabBar/user/center",
                    iconPath: "/images/icons/my_normal.png",
                    selectedIconPath: "/images/icons/my_selected.png",
                    text: "我",
                    tabName: "Me"
                } ]
            });
        }
    }
});